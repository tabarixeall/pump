from flask import Flask, request, session, redirect, url_for
from werkzeug.utils import secure_filename
import os, zipfile, functools

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024 * 1024
app.secret_key = "your-secret-key-change-this-in-production"
PFP_DIR = "/root/viking-bot/database/pfps"
BANNER_DIR = "/root/viking-bot/database/banners"
PASSWORD = "monkey"


def login_required(f):
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if "logged_in" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)

    return decorated_function


@app.route("/login", methods=["POST"])
def login():
    if request.form.get("password") == PASSWORD:
        session["logged_in"] = True
        return "", 204
    return "Invalid password", 401


@app.route("/logout", methods=["POST"])
def logout():
    session.pop("logged_in", None)
    return "", 204


@app.route("/check_auth", methods=["GET"])
def check_auth():
    if "logged_in" in session:
        return "", 204
    return "", 401


@app.route("/upload_pfp", methods=["POST"])
@login_required
def upload_pfp():
    f = request.files["zipfile"]
    zippath = os.path.join(PFP_DIR, secure_filename(f.filename))
    f.save(zippath)
    with zipfile.ZipFile(zippath) as z:
        imgs = [
            n
            for n in z.namelist()
            if n.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".webp"))
            and not n.endswith("/")
        ]
        [
            open(os.path.join(PFP_DIR, os.path.basename(n)), "wb").write(z.read(n))
            for n in imgs
        ]
    os.remove(zippath)
    return "", 204


@app.route("/upload_banner", methods=["POST"])
@login_required
def upload_banner():
    f = request.files["zipfile"]
    zippath = os.path.join(BANNER_DIR, secure_filename(f.filename))
    f.save(zippath)
    with zipfile.ZipFile(zippath) as z:
        imgs = [
            n
            for n in z.namelist()
            if n.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".webp"))
            and not n.endswith("/")
        ]
        [
            open(os.path.join(BANNER_DIR, os.path.basename(n)), "wb").write(z.read(n))
            for n in imgs
        ]
    os.remove(zippath)
    return "", 204


if __name__ == "__main__":
    os.makedirs(PFP_DIR, exist_ok=True)
    os.makedirs(BANNER_DIR, exist_ok=True)
    app.run(host="0.0.0.0", port=5405)
