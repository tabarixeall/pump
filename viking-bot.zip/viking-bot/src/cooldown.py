import time
import config


class Cooldown:
    def __init__(self, delay):
        self.delay = delay
        self.timestamps = {}

    async def check(self, user_id, command):
        if user_id in config.OWNERS:
            return True
        now = time.time()
        if user_id in self.timestamps and command in self.timestamps[user_id]:
            if now - self.timestamps[user_id][command] < self.delay:
                return False
        if user_id not in self.timestamps:
            self.timestamps[user_id] = {}
        self.timestamps[user_id][command] = now
        return True
