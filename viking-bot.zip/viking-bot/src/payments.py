import asyncio
import traceback
import httpx
from typing import Union
from dataclasses import dataclass

from config import CRYPTO_ADDRESSES
from src.cryapi import CryptAPI
import aiohttp
from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse

from src.db import DatabaseManager


@dataclass
class PaymentConfig:
    """Configuration for payment processing"""

    callback_url: str
    order_id: str
    user_id: int
    product_id: str
    quantity: int = 1
    convert: int = 1
    multi_token: int = 1
    pending: int = 0
    json: int = 1
    confirmations: int = 1


@dataclass
class PaymentData:
    """Payment data returned from API"""

    address: str
    minimum: float
    coin_type: str
    expected_amount: float
    usd_amount: float
    qr_code: str = ""
    invoice_id: str = ""


class PaymentProcessor:
    """Handles cryptocurrency payment processing via the CryptAPI SDK."""

    COINS = {
        "USDT_TRC20": "trc20/usdt",
        "USDT_ERC20": "erc20/usdt",
        "USDT_BEP20": "bep20/usdt",
        "BTC": "btc",
        "ETH": "eth",
        "LTC": "ltc",
    }

    ADDRESSES = CRYPTO_ADDRESSES

    def __init__(self, config: PaymentConfig, db):
        self.config = config
        self.db: DatabaseManager = db
        self.cryptapi = CryptAPI()

    async def get_coin_price(self, coin: str) -> float:
        """
        Get the current price of the coin (in USD) by querying CryptAPI's info endpoint.
        """
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                url = f"https://api.cryptapi.io/{self.COINS[coin]}/info/"
                response = await client.get(url)
                data = response.json()
                return float(data.get("prices", {}).get("USD", 0))
        except httpx.TimeoutException:
            print(f"Timeout fetching coin price for {coin}")
            return 0
        except Exception as e:
            print(f"Error fetching coin price for {coin}: {e}")
            return 0

    async def get_qr_code(
        self, coin_type: str, address: str, amount: float = None
    ) -> str:
        """Generate QR code for payment address"""
        try:
            ticker = self.COINS.get(coin_type, coin_type)
            params = {"address": address, "size": 512}

            if amount:
                params["value"] = amount

            async with aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30)
            ) as session:
                url = f"https://api.cryptapi.io/{ticker}/qrcode/"
                async with session.get(url, params=params, ssl=False) as response:
                    if response.status == 200:
                        return await response.json()
            return {"qr_code": ""}
        except asyncio.TimeoutError:
            print(f"Timeout generating QR code for {coin_type}")
            return {"qr_code": ""}
        except Exception as e:
            print(f"Error generating QR code: {e}")
            return {"qr_code": ""}

    def add_callback_params(self, callback_url: str, params: dict) -> str:
        """
        Add or update query parameters in the callback URL.

        Args:
            callback_url (str): The original callback URL.
            params (dict): A dictionary of parameters to add or update.

        Returns:
            str: The updated URL with the new query parameters.
        """
        url_parts = list(urlparse(callback_url))

        query = dict(parse_qsl(url_parts[4]))

        query.update(params)

        url_parts[4] = urlencode(query)

        return urlunparse(url_parts)

    async def create_payment(
        self, network: str, usd_amount: float
    ) -> tuple[bool, Union[PaymentData, str]]:
        """Create a new payment invoice using CryptAPI SDK."""
        try:
            coin_price = await self.get_coin_price(network)
            if coin_price == 0:
                return False, "Could not fetch coin price."
            crypto_amount = round(usd_amount / coin_price, 8)

            callback_url = self.add_callback_params(
                self.config.callback_url,
                {
                    "order_id": self.config.order_id,
                    "user_id": self.config.user_id,
                    "product_id": self.config.product_id,
                    "quantity": self.config.quantity,
                    "total_amount": usd_amount,
                    "payment_currency": network,
                },
            )

            ticker = self.COINS.get(network, network)
            forward_address = self.ADDRESSES.get(network, "default_address")

            try:
                invoice = await self.cryptapi.create_address(
                    ticker,
                    callback_url,
                    forward_address,
                    pending=int(self.config.pending),
                    confirmations=self.config.confirmations,
                    email="string",
                    post_method=0,
                    json_format=int(self.config.json),
                    priority="default",
                    multi_token=int(self.config.multi_token),
                    convert=int(self.config.convert),
                )
            except httpx.TimeoutException:
                return False, "Payment creation timed out. Please try again."

            if "error" in invoice:
                return False, invoice["error"]

            min_tx = float(invoice.get("minimum_transaction_coin", crypto_amount))
            if crypto_amount < min_tx:
                print(f"Invoice request amount is ${usd_amount} on {network}")
                return False, (
                    f"Minimum order value is {min_tx} {network}. Choose a different payment method or\nPurchase from our website for smaller quantities."
                )

            qr_code = await self.get_qr_code(
                network, invoice["address_in"], crypto_amount
            )

            return True, PaymentData(
                address=invoice["address_in"],
                minimum=float(invoice.get("minimum_transaction_coin", 0)),
                coin_type=network,
                expected_amount=crypto_amount,
                usd_amount=usd_amount,
                qr_code=qr_code.get("qr_code"),
                invoice_id=self.config.order_id,
            )

        except httpx.TimeoutException:
            print(f"Timeout during payment creation for {network}")
            return False, "Payment creation timed out. Please try again."
        except Exception as e:
            traceback.print_exc()
            print(f"Payment creation error: {e}")
            return False, f"Payment creation error: {e}"

    async def close(self):
        pass
