class EmailVerificationError(Exception):
    """Base exception for email verification errors"""

    pass


class RateLimitExceeded(EmailVerificationError):
    """Raised when too many verification attempts are made"""

    pass


class InvalidEmailError(EmailVerificationError):
    """Raised when email format is invalid"""

    pass


class SMTPError(EmailVerificationError):
    """Raised when SMTP operations fail"""

    pass


class TweetNotFound(Exception):
    def __init__(self):
        super().__init__("Tweet not found.")


class UserNotFound(Exception):
    def __init__(self):
        super().__init__("User not found.")


class InvalidCredentials(Exception):
    def __init__(self):
        super().__init__("Invalid credentials.")


class AccountSuspended(Exception):
    def __init__(self):
        super().__init__("Account suspended.")


class InvalidToken(Exception):
    def __init__(self):
        super().__init__("Invalid token.")


class InvalidOTP(Exception):
    def __init__(self):
        super().__init__("Invalid OTP.")


class InvalidEmail(Exception):
    def __init__(self):
        super().__init__("Invalid email.")


class CaptchaFailed(Exception):
    def __init__(self):
        super().__init__("Captcha failed.")
