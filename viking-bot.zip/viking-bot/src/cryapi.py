import httpx
from typing import Optional, Dict


class CryptAPI:
    BASE_URL = "https://api.cryptapi.io"

    def __init__(self):
        self.session = httpx.AsyncClient()

    async def create_address(
        self,
        ticker: str,
        callback: str,
        address: str,
        pending: Optional[int] = 0,
        confirmations: Optional[int] = 1,
        email: Optional[str] = "string",
        post_method: Optional[int] = 0,
        json_format: Optional[int] = 0,
        priority: Optional[str] = "default",
        multi_token: Optional[int] = 0,
        convert: Optional[int] = 0,
    ) -> Dict:
        """
        This method generates a new payment address where clients can send crypto.

        :param ticker: The ticker (e.g., 'btc' for Bitcoin) for the cryptocurrency
        :param callback: URL to notify once the payment is received
        :param address: Address where the payment will be forwarded
        :param pending: Whether to notify about pending transactions (0 or 1)
        :param confirmations: Number of required blockchain confirmations
        :param email: Email to receive notifications
        :param post_method: Method to post the callback (0 for GET, 1 for POST)
        :param json_format: Whether to send callback data in JSON format (0 or 1)
        :param priority: Transaction priority, e.g., 'fast', 'default'
        :param multi_token: Allow payment in multiple tokens (0 or 1)
        :param convert: Convert crypto to fiat (0 or 1)
        :return: A dictionary containing the response from the API
        """
        url = f"{self.BASE_URL}/{ticker}/create/"
        params = {
            "callback": callback,
            "address": address,
            "pending": pending,
            "confirmations": confirmations,
            "email": email,
            "post": post_method,
            "json": json_format,
            "priority": priority,
            "multi_token": multi_token,
            "convert": convert,
        }
        response = await self.session.get(url, params=params)
        data = response.json()
        return data

    async def get_service_info(self, prices: int = 0) -> Dict:
        """
        Fetch information about supported blockchains, cryptocurrencies, and tokens from CryptAPI.

        :param prices: Optional flag to include coin prices in the response (1 to include, 0 to exclude).
        :return: A dictionary containing service information.
        """
        url = f"{self.BASE_URL}/info/"
        params = {"prices": prices}
        response = await self.session.get(url, params=params)
        data = response.json()
        return data

    async def close(self) -> None:
        """
        Closes the httpx session.
        """
        await self.session.aclose()
