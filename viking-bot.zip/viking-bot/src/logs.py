class Logs:
    def info(self, message: str):
        print(f"\033[94m[INFO] {message}\033[0m")

    def warning(self, message: str):
        print(f"\033[93m[WARNING] {message}\033[0m")

    def error(self, message: str):
        print(f"\033[91m[ERROR] {message}\033[0m")

    def success(self, message: str):
        print(f"\033[92m[SUCCESS] {message}\033[0m")

    def debug(self, message: str):
        print(f"\033[90m[DEBUG] {message}\033[0m")

    def warn(self, message: str):
        print(f"\033[93m[WARNING] {message}\033[0m")

    def err(self, message: str):
        print(f"\033[91m[ERROR] {message}\033[0m")

    def debug(self, message: str):
        print(f"\033[90m[DEBUG] {message}\033[0m")

    def log(self, message: str):
        print(f"\033[90m[LOG] {message}\033[0m")

    def exception(self, message: str):
        print(f"\033[91m[EXCEPTION] {message}\033[0m")

    def critical(self, message: str):
        print(f"\033[91m[CRITICAL] {message}\033[0m")
