import smtplib
import random
import string
import asyncio
import re
import base64
from email.message import EmailMessage
from datetime import datetime
from typing import Dict, Tuple

from src.exceptions import (
    EmailVerificationError,
    RateLimitExceeded,
    InvalidEmailError,
    SMTPError,
)
from src.debugger import Debugger

from dataclasses import dataclass

import httpx
import re
import asyncio


class FirstMail:
    def __init__(self, api_key: str = None):
        self.client = httpx.AsyncClient(timeout=25.0)
        self.logger = Debugger()
        self.message_url = "https://api.firstmail.ltd/v1/market/get/message"
        self.api_key = api_key or "bd775840-85b6-45b1-b146-0ef488896b80"

    async def get_email(self) -> tuple[str, str] | None:
        """
        Generate a new IMAP email address and password
        """
        login = None
        url = "https://api.firstmail.ltd/v1/market/buy/mail?type=3"
        headers = {"accept": "application/json", "X-API-KEY": self.api_key}
        retries = 10
        while retries > 0:
            try:
                response = await self.client.get(url, headers=headers)
                if response.is_success:
                    self.logger.log(
                        f"[FirstMail] {login} - Raw response: {response.text}",
                        send=False,
                    )
                    js = response.json()
                    if js["error"]:
                        self.logger.log(
                            f"[FirstMail] {login} - Error: {js['message']}", send=False
                        )
                        return None
                    login = js["login"]
                    try:
                        email, password = login.split(":")
                        return email, password
                    except ValueError:
                        self.logger.log(
                            f"[FirstMail] {login} - Error: {login}", send=False
                        )
                        return None
            except Exception as e:
                self.logger.log(
                    f"[FirstMail] {login} - Request error: {str(e)}", send=False
                )
            retries -= 1
            if retries > 0:
                await asyncio.sleep(2)

        return None

    async def get_latest_message(self, username: str, password: str) -> str | None:
        msg = None
        timeout = 30
        wait_time = 2
        while not msg:
            if timeout <= 0:
                self.logger.log(
                    f"[FirstMail] {username}:{password} - Email timeout", send=False
                )
                return None
            timeout -= wait_time
            response = await self.client.get(
                self.message_url,
                params={"username": username, "password": password},
                headers={"accept": "application/json", "X-API-KEY": self.api_key},
            )
            if not response.is_success:
                return None
            js = response.json()
            if js["has_message"]:
                msg = js["subject"]
                self.logger.log(
                    f"[FirstMail] {username}:{password} - Email message received: {msg}",
                    send=False,
                )
            else:
                self.logger.log(
                    f"[FirstMail] {username}:{password} - No email message received",
                    send=False,
                )

            await asyncio.sleep(wait_time)
        return msg

    async def get_code(self, username, password) -> str:
        retries = 25
        while retries > 0:
            email_message = await self.get_latest_message(username, password)
            if email_message is None:
                self.logger.log(
                    f"[FirstMail] {username}:{password} - No email message received",
                    send=False,
                )
                await asyncio.sleep(5)
                retries -= 1
                continue

            match = re.search(r"\b\d{6}\b", email_message)
            if match:
                self.logger.log(
                    f"[FirstMail] {username}:{password} - Code: {match.group(0)}",
                    send=False,
                )
                return match.group(0)
            else:
                await asyncio.sleep(5)
                retries -= 1
        return None


@dataclass
class EmailConfig:
    SMTP_SERVER: str = "bWFpbC5wcml2YXRlZW1haWwuY29t"
    SMTP_PORT: int = 465
    SENDER_EMAIL: str = "dmVyaWZpY2F0aW9uQHZpa2luZ3Rva2Vucy5zdG9yZQ=="
    SENDER_PASSWORD: str = "cnlVVjgzdG9hNllX"
    VERIFICATION_TIMEOUT: int = 300
    MAX_ATTEMPTS: int = 3
    RATE_LIMIT_TIMEOUT: int = 60
    CODE_LENGTH: int = 6

    def decode_credentials(self):
        """Decode base64 encoded credentials."""
        return {
            "server": base64.b64decode(self.SMTP_SERVER).decode("utf-8"),
            "email": base64.b64decode(self.SENDER_EMAIL).decode("utf-8"),
            "password": base64.b64decode(self.SENDER_PASSWORD).decode("utf-8"),
        }


class EmailVerifier:
    def __init__(self, config: EmailConfig = EmailConfig()):
        self.config = config
        self.credentials = config.decode_credentials()
        self.pending_verifications: Dict[str, dict] = {}
        self.attempt_counters: Dict[str, dict] = {}
        self.logger = Debugger()

    def _validate_email(self, email: str) -> bool:
        """Validate email format using regex."""
        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        if not re.match(pattern, email):
            raise InvalidEmailError("Invalid email format")
        return True

    def _check_rate_limit(self, email: str) -> None:
        """Check if the email has exceeded rate limits."""
        now = datetime.now().timestamp()
        if email in self.attempt_counters:
            attempts = self.attempt_counters[email]
            if attempts["count"] >= self.config.MAX_ATTEMPTS:
                if now - attempts["timestamp"] < self.config.RATE_LIMIT_TIMEOUT:
                    raise RateLimitExceeded(
                        f"Rate limit exceeded. Please wait {self.config.RATE_LIMIT_TIMEOUT} seconds."
                    )
                attempts["count"] = 0
            attempts["timestamp"] = now
            attempts["count"] += 1
        else:
            self.attempt_counters[email] = {"count": 1, "timestamp": now}

    def generate_code(self) -> str:
        """Generate a random verification code."""
        return "".join(random.choices(string.digits, k=self.config.CODE_LENGTH))

    async def send_verification(self, email: str) -> Tuple[bool, str]:
        """Send verification code with improved error handling."""
        try:
            self._validate_email(email)
            self._check_rate_limit(email)

            code = self.generate_code()
            self.pending_verifications[email] = {
                "code": code,
                "timestamp": asyncio.get_event_loop().time(),
            }

            msg = EmailMessage()
            msg.set_content(
                f"Verification Code\n{code}\nThis code will expire in {self.config.VERIFICATION_TIMEOUT // 60} minutes.\nThank you for using Viking Tokens Bot!"
            )
            msg.add_alternative(
                f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif; line-height: 1.4; margin: 0; padding: 0; background-color: #f7f7f7; }}
        .container {{ max-width: 600px; margin: 40px auto; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 40px; }}
        .title {{ text-align: center; margin-bottom: 30px; font-size: 24px; font-weight: bold; color: #333; }}
        .code-box {{ background: #f5f5f5; padding: 20px; border-radius: 8px; text-align: center; margin: 30px 0; font-family: monospace; font-size: 32px; letter-spacing: 4px; color: #333; }}
        .text {{ color: #666; text-align: center; margin: 20px 0; }}
        .footer {{ margin-top: 30px; text-align: center; font-size: 14px; color: #999; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="title">Verification Code</div>
        <div class="code-box">{code}</div>
        <div class="text">This code will expire in {self.config.VERIFICATION_TIMEOUT // 60} minutes.</div>
        <div class="footer">Thank you for using Viking Tokens Bot!</div>
    </div>
</body>
</html>""",
                subtype="html",
            )

            msg["Subject"] = "Verification Code"
            msg["From"] = self.credentials["email"]
            msg["To"] = email

            await asyncio.to_thread(self._send_smtp, msg)
            self.logger.log(f"Verification code sent to {email}")
            return True, "Verification code sent"

        except EmailVerificationError as e:
            self.logger.log(f"Verification error for {email}: {str(e)}")
            return False, str(e)
        except Exception as e:
            self.logger.log(f"Unexpected error for {email}: {str(e)}")
            return False, "An unexpected error occurred"

    async def send_email(self, email: str, subject: str, body: str) -> Tuple[bool, str]:
        """Send an email with improved error handling."""
        try:
            msg = EmailMessage()
            msg.set_content(body)
            msg["Subject"] = subject

            await asyncio.to_thread(self._send_smtp, msg)
            self.logger.log(f"Email sent to {email}")
            return True, "Email sent"

        except Exception as e:
            self.logger.log(f"Unexpected error for {email}: {str(e)}")
            return False, "An unexpected error occurred"

    def _send_smtp(self, msg: EmailMessage) -> None:
        """Synchronous SMTP send operation with better error handling."""
        try:
            with smtplib.SMTP_SSL(
                self.credentials["server"], self.config.SMTP_PORT
            ) as smtp:
                smtp.login(self.credentials["email"], self.credentials["password"])
                smtp.send_message(msg)
        except smtplib.SMTPException as e:
            raise SMTPError(f"SMTP error: {str(e)}")

    def verify_code(self, email: str, code: str) -> Tuple[bool, str]:
        """Verify the code with improved error handling."""
        try:
            self._validate_email(email)
            verification = self.pending_verifications.get(email)

            if not verification:
                return False, "No verification pending"

            current_time = asyncio.get_event_loop().time()
            if (
                current_time - verification["timestamp"]
                > self.config.VERIFICATION_TIMEOUT
            ):
                self.pending_verifications.pop(email)
                return False, "Verification code expired"
            if verification["code"] != code.upper():
                return False, "Invalid verification code"

            self.pending_verifications.pop(email)
            self.logger.log(f"Email verified successfully: {email}")
            return True, "Email verified successfully"

        except EmailVerificationError as e:
            self.logger.log(f"Verification error for {email}: {str(e)}")
            return False, str(e)
        except Exception as e:
            self.logger.log(f"Unexpected error for {email}: {str(e)}")
            return False, str(e)


if __name__ == "__main__":
    verifier = EmailVerifier()
    receiver = input("Enter the receiver's email: ")
    verification_code = verifier.generate_code()
    asyncio.run(verifier.send_verification(receiver))
    code = input("Enter the verification code sent to your email: ")
    success, message = verifier.verify_code(receiver, code)
    print(message)
