import traceback
from typing import Any, Literal, Iterable
from time import time
import asyncio
import base64
import json
import re

import aiohttp
from loguru import logger
from curl_cffi import requests
from yarl import URL

from ._capsolver.fun_captcha import FunCaptcha, FunCaptchaTypeEnm

from .errors import (
    TwitterException,
    FailedToFindDuplicatePost,
    HTTPException,
    BadRequest,
    Unauthorized,
    Forbidden,
    NotFound,
    RateLimited,
    ServerError,
    BadAccount,
    BadAccountToken,
    AccountLocked,
    AccountConsentLocked,
    AccountSuspended,
    AccountNotFound,
    InvalidEmail,
    InvalidCredentials,
)
from .base import BaseHTTPClient
from .account import Account, AccountStatus
from .models import User, Tweet, Media, Subtask
from .auth import Email
from .utils import parse_oauth_html
from .utils import parse_unlock_html
from .utils import tweets_data_from_instructions
from .utils import encode_x_client_transaction_id
from src.logs import Logs
from src.debugger import Debugger

logs = Logs()


class Client(BaseHTTPClient):
    _BEARER_TOKEN = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"
    _DEFAULT_HEADERS = {
        "authority": "x.com",
        "origin": "https://x.com",
        "x-twitter-active-user": "yes",
        "x-twitter-client-language": "en",
    }
    _GRAPHQL_URL = "https://x.com/i/api/graphql"
    _ACTION_TO_QUERY_ID = {
        "CreateRetweet": "ojPdsZsimiJrUGLR1sjUtA",
        "FavoriteTweet": "lI07N6Otwv1PhnEgXILM7A",
        "UnfavoriteTweet": "ZYKSe-w7KEslx3JhSIk5LA",
        "CreateTweet": "oB-5XsHNAbjvARJEc8CZFw",
        "TweetResultByRestId": "V3vfsYzNEyD9tsf4xoFRgw",
        "ModerateTweet": "p'jF:GVqCjTcZol0xcBJjw",
        "DeleteTweet": "VaenaVgh5q5ih7kvyVjgtg",
        "UserTweets": "V1ze5q3ijDS1VeLwLY0m7g",
        "TweetDetail": "VWFGPVAGkZMGRKGe3GFFnA",
        "ProfileSpotlightsQuery": "9zwVLJ48lmVUk8u_Gh9DmA",
        "Following": "t-BPOrMIduGUJWO_LxcvNQ",
        "Followers": "3yX7xr2hKjcZYnXt6cU6lQ",
        "UserByScreenName": "G3KGOASz96M-Qu0nwmGXNg",
        "UsersByRestIds": "itEhGywpgX9b3GJCzOtSrA",
        "Viewer": "-876iyxD1O_0X0BqeykjZA",
    }
    _CAPTCHA_URL = "https://x.com/account/access"
    _CAPTCHA_SITE_KEY = "0152B4EB-D2DC-460A-89A1-629838B529C9"

    @classmethod
    def _action_to_url(cls, action: str) -> tuple[str, str]:
        """
        :return: URL and Query ID
        """
        query_id = cls._ACTION_TO_QUERY_ID[action]
        url = f"{cls._GRAPHQL_URL}/{query_id}/{action}"
        return url, query_id

    def __init__(
        self,
        account: Account,
        *,
        wait_on_rate_limit: bool = True,
        capsolver_api_key: str = None,
        max_unlock_attempts: int = 5,
        auto_relogin: bool = False,
        update_account_info_on_startup: bool = True,
        **session_kwargs,
    ):
        super().__init__(**session_kwargs)
        self.account = account

        self.wait_on_rate_limit = wait_on_rate_limit
        self.capsolver_api_key = capsolver_api_key
        self.max_unlock_attempts = max_unlock_attempts
        self.auto_relogin = auto_relogin
        self._update_account_info_on_startup = update_account_info_on_startup

    async def __aenter__(self):
        await self.on_startup()
        return await super().__aenter__()

    async def _request(
        self,
        method: str,
        url: str | URL,
        *,
        auth: bool = True,
        bearer: bool = True,
        wait_on_rate_limit: bool = None,
        **kwargs,
    ) -> tuple[requests.Response, Any]:
        cookies = kwargs["cookies"] = kwargs.get("cookies", {})
        headers = kwargs["headers"] = kwargs.get("headers", {})

        url = URL(url)
        headers["x-client-transaction-id"] = encode_x_client_transaction_id(url.path)

        if bearer:
            headers["authorization"] = f"Bearer {self._BEARER_TOKEN}"

        if auth:
            if not self.account.auth_token:
                raise ValueError("No auth_token. Login before")

            cookies["auth_token"] = self.account.auth_token
            headers["x-twitter-auth-type"] = "OAuth2Session"
            if self.account.ct0:
                cookies["ct0"] = self.account.ct0
                headers["x-csrf-token"] = self.account.ct0
        else:
            if "auth_token" in cookies:
                del cookies["auth_token"]
            if "x-twitter-auth-type" in headers:
                del headers["x-twitter-auth-type"]

        log_message = (
            f"(auth_token={self.account.auth_token}, id={self.account.id}, username={self.account.username})"
            f" ==> Request {method} {url}"
        )
        if kwargs.get("data"):
            log_message += f"\nRequest data: {kwargs.get('data')}"
        if kwargs.get("json"):
            log_message += f"\nRequest data: {kwargs.get('json')}"
        logger.debug(log_message)

        try:
            response = await self._session.request(method, str(url), **kwargs)
        except requests.errors.RequestsError as exc:
            if exc.code == 35:
                msg = (
                    "The IP address may have been blocked by Twitter. Blocked countries: Russia. "
                    + str(exc)
                )
                raise requests.errors.RequestsError(msg, 35, exc.response)
            raise

        data = response.text

        logger.debug(
            f"(auth_token={self.account.auth_token}, id={self.account.id}, username={self.account.username})"
            f" <== Response {method} {url}"
            f"\nStatus code: {response.status_code}"
            f"\nResponse data: {data}"
        )

        if ct0 := self._session.cookies.get("ct0", domain=".x.com"):
            self.account.ct0 = ct0

        auth_token = self._session.cookies.get("auth_token")
        if auth_token and auth_token != self.account.auth_token:
            self.account.auth_token = auth_token
            logger.warning(
                f"(auth_token={self.account.auth_token}, id={self.account.id}, username={self.account.username})"
                f" Requested new auth_token!"
            )

        try:
            data = response.json()
        except json.decoder.JSONDecodeError:
            pass

        if 300 > response.status_code >= 200:
            if isinstance(data, dict) and "errors" in data:
                exc = HTTPException(response, data)

                if 141 in exc.error_codes or 37 in exc.error_codes:
                    self.account.status = AccountStatus.SUSPENDED
                    raise AccountSuspended(exc, self.account)

                if 326 in exc.error_codes:
                    for error_data in exc.errors:
                        if (
                            error_data.get("code") == 326
                            and error_data.get("bounce_location")
                            == "/i/flow/consent_flow"
                        ):
                            self.account.status = AccountStatus.CONSENT_LOCKED
                            raise AccountConsentLocked(exc, self.account)

                    self.account.status = AccountStatus.LOCKED
                    raise AccountLocked(exc, self.account)
                raise exc

            return response, data

        if response.status_code == 400:
            exc = BadRequest(response, data)

            if 399 in exc.error_codes:
                self.account.status = AccountStatus.NOT_FOUND
                raise AccountNotFound(exc, self.account)

            raise exc

        if response.status_code == 401:
            exc = Unauthorized(response, data)

            if 32 in exc.error_codes:
                self.account.status = AccountStatus.BAD_TOKEN
                raise BadAccountToken(exc, self.account)

            raise exc

        if response.status_code == 403:
            exc = Forbidden(response, data)

            if 64 in exc.error_codes:
                self.account.status = AccountStatus.SUSPENDED
                raise AccountSuspended(exc, self.account)

            if 326 in exc.error_codes:
                for error_data in exc.errors:
                    if (
                        error_data.get("code") == 326
                        and error_data.get("bounce_location") == "/i/flow/consent_flow"
                    ):
                        self.account.status = AccountStatus.CONSENT_LOCKED
                        raise AccountConsentLocked(exc, self.account)

                self.account.status = AccountStatus.LOCKED
                raise AccountLocked(exc, self.account)

            raise exc

        if response.status_code == 404:
            raise NotFound(response, data)

        if response.status_code == 429:
            if wait_on_rate_limit is None:
                wait_on_rate_limit = self.wait_on_rate_limit
            if not wait_on_rate_limit:
                raise RateLimited(response, data)

            reset_time = int(response.headers["x-rate-limit-reset"])
            sleep_time = reset_time - int(time()) + 1
            if sleep_time > 0:
                logger.warning(
                    f"(auth_token={self.account.auth_token}, id={self.account.id}, username={self.account.username})"
                    f"Rate limited! Sleep time: {sleep_time} sec."
                )
                await asyncio.sleep(sleep_time)
            return await self._request(
                method,
                url,
                auth=auth,
                bearer=bearer,
                wait_on_rate_limit=wait_on_rate_limit,
                **kwargs,
            )

        if response.status_code >= 500:
            raise ServerError(response, data)

    async def request(
        self,
        method: str,
        url: str | URL,
        *,
        auto_unlock: bool = True,
        auto_relogin: bool = False,
        rerequest_on_bad_ct0: bool = True,
        **kwargs,
    ) -> tuple[requests.Response, Any]:
        try:
            return await self._request(method, url, **kwargs)

        except AccountLocked:
            if not self.capsolver_api_key or not auto_unlock:
                raise

            return await self._request(method, url, **kwargs)

        except BadAccountToken:
            logs.err(f"Invalid token {self.account.auth_token}")
            raise
        except Forbidden as exc:
            if (
                rerequest_on_bad_ct0
                and 353 in exc.error_codes
                and "ct0" in exc.response.cookies
            ):
                return await self.request(
                    method, url, rerequest_on_bad_ct0=False, **kwargs
                )
            else:
                raise

    async def on_startup(self):
        if self._update_account_info_on_startup:
            await self.update_account_info()
            await self.establish_status()

    async def get_ct0(self):
        url = "https://x.com/i/api/fleets/v1/avatar_content"
        async with aiohttp.ClientSession() as session:
            response = await session.get(
                url,
                cookies={"auth_token": self.account.auth_token},
                headers={
                    "Accept": "*/*",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
                    "Authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
                },
            )
            ct0 = response.cookies.get("ct0")
            if ct0:
                self.account.ct0 = ct0.value
                return ct0.value
            else:
                return None

    async def _update_account_username(self):
        url = "https://api.x.com/1.1/account/settings.json"
        response, response_json = await self.request("POST", url)
        self.account.username = response_json["screen_name"]

    async def _request_user_by_username(self, username: str) -> User | None:
        url, query_id = self._action_to_url("UserByScreenName")
        variables = {
            "screen_name": username,
            "withSafetyModeUserFields": True,
        }
        features = {
            "profile_likes_enabled": True,
            "profile_subscriptions_enabled": True,
            "hidden_profile_likes_enabled": True,
            "hidden_profile_subscriptions_enabled": True,
            "responsive_web_graphql_exclude_directive_enabled": True,
            "verified_phone_label_enabled": False,
            "subscriptions_verification_info_is_identity_verified_enabled": True,
            "subscriptions_verification_info_verified_since_enabled": True,
            "highlights_tweets_tab_ui_enabled": True,
            "creator_subscriptions_tweet_preview_api_enabled": True,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True,
        }
        field_toggles = {
            "withAuxiliaryUserLabels": False,
        }
        params = {
            "variables": variables,
            "features": features,
            "fieldToggles": field_toggles,
        }
        response, data = await self.request("GET", url, params=params)
        if not data["data"]:
            return None
        return User.from_raw_data(data["data"]["user"]["result"])

    async def request_user_by_username(self, username: str) -> User | Account | None:
        """
        :param username: Имя пользователя без знака `@`
        :return: Пользователь, если существует, иначе None. Или собственный аккаунт, если совпадает имя пользователя.
        """
        if not self.account.username:
            await self.update_account_info()

        user = await self._request_user_by_username(username)

        if user and user.username == self.account.username:
            self.account.update(**user.model_dump())
            return self.account

        return user

    async def _request_users_by_ids(
        self, user_ids: Iterable[str | int]
    ) -> dict[int : User | Account]:
        url, query_id = self._action_to_url("UsersByRestIds")
        variables = {"userIds": list({str(user_id) for user_id in user_ids})}
        features = {
            "responsive_web_graphql_exclude_directive_enabled": True,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True,
            "verified_phone_label_enabled": False,
        }
        query = {"variables": variables, "features": features}
        response, data = await self.request("GET", url, params=query)

        users = {}
        for user_data in data["data"]["users"]:
            user_data = user_data["result"]
            user = User.from_raw_data(user_data)
            users[user.id] = user
            if user.id == self.account.id:
                users[self.account.id] = self.account
        return users

    async def request_user_by_id(self, user_id: int | str) -> User | Account | None:
        """
        :param user_id: ID пользователя
        :return: Пользователь, если существует, иначе None. Или собственный аккаунт, если совпадает ID.
        """
        if not self.account.id:
            await self.update_account_info()

        users = await self._request_users_by_ids((user_id,))
        user = users[user_id]
        return user

    async def request_users_by_ids(
        self, user_ids: Iterable[str | int]
    ) -> dict[int : User | Account]:
        """
        :param user_ids: ID пользователей
        :return: Пользователи, если существует, иначе None. Или собственный аккаунт, если совпадает ID.
        """
        return await self._request_users_by_ids(user_ids)

    async def update_account_info(self):
        if not self.account.username:
            await self._update_account_username()

        await self.request_user_by_username(self.account.username)

    async def change_username(self, username: str) -> bool:
        url = "https://x.com/i/api/1.1/account/settings.json"
        payload = {"screen_name": username}
        response, data = await self.request("POST", url, data=payload)
        new_username = data["screen_name"]
        changed = new_username == username
        self.account.username = new_username
        return changed

    async def change_password(self, password: str) -> bool:
        url = "https://x.com/i/api/i/account/change_password.json"
        headers = {
            "connection": "keep-alive",
            "sec-ch-ua-platform": '"macOS"',
            "authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
            "x-csrf-token": self.account.ct0,
            "sec-ch-ua": '"Brave";v="135", "Not-A.Brand";v="8", "Chromium";v="135"',
            "x-twitter-client-language": "en",
            "sec-ch-ua-mobile": "?0",
            "x-twitter-active-user": "yes",
            "x-client-transaction-id": "PcQWXhDoMXXpLkIJvhwW7Jugy1SpKWm7duRfJ9/hiRYX+Vf2CXxmUNkKo0FeTm4ZiyN4hz7vuEPTxDOL5VghJvaYynC4Pg",
            "x-twitter-auth-type": "OAuth2Session",
            "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
            "accept": "*/*",
            "content-type": "application/x-www-form-urlencoded",
            "sec-gpc": "1",
            "accept-language": "en-US,en;q=0.6",
            "sec-fetch-site": "same-origin",
            "sec-fetch-mode": "cors",
            "sec-fetch-dest": "empty",
            "cookie": f"ct0={self.account.ct0}; auth_token={self.account.auth_token}",
        }
        body = {
            "current_password": self.account.password,
            "password": password,
            "password_confirmation": password,
        }

        try:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        url, headers=headers, data=body
                    ) as response:
                        if response.status == 200:
                            try:
                                response_data = await response.json()
                                if response_data["status"] == "ok":
                                    cookies = response.cookies
                                    if "auth_token" in cookies:
                                        self.account.auth_token = cookies[
                                            "auth_token"
                                        ].value
                                        self.account.password = password
                                        self.account.ct0 = await self.get_ct0()
                                        return True

                                    cookie_header = response.headers.get(
                                        "Set-Cookie", ""
                                    )
                                    if "auth_token" in cookie_header:
                                        regex = r"auth_token=(.*?);"
                                        match = re.search(regex, cookie_header)
                                        if match:
                                            self.account.auth_token = match.group(1)
                                            self.account.password = password
                                            self.account.ct0 = await self.get_ct0()
                                            return True
                            except:
                                pass
            except Exception:
                pass

            return False
        except Exception as e:
            return False

    async def update_profile(
        self,
        name: str = None,
        description: str = None,
        location: str = None,
        website: str = None,
    ) -> bool:
        """
        Locks an account!
        """
        if name is None and description is None:
            raise ValueError("Specify at least one param")

        url = "https://x.com/i/api/1.1/account/update_profile.json"

        payload = {
            k: v
            for k, v in [
                ("name", name),
                ("description", description),
                ("location", location),
                ("url", website),
            ]
            if v is not None
        }
        response, data = await self.request("POST", url, data=payload)

        updated = all(
            data.get(key) == value for key, value in payload.items() if key != "url"
        )
        if website:
            updated &= URL(website) == URL(
                data["entities"]["url"]["urls"][0]["expanded_url"]
            )
        await self.update_account_info()
        return updated

    async def establish_status(self):
        url = "https://api.x.com/1.1/account/personalization/p13n_preferences.json"
        try:
            await self.request("GET", url, auto_unlock=False, auto_relogin=False)
            self.account.status = AccountStatus.GOOD
        except BadAccount:
            pass

    async def update_backup_code(self):
        url = "https://api.x.com/1.1/account/backup_code.json"
        response, response_json = await self.request("GET", url)
        self.account.backup_code = response_json["codes"][0]

    async def _send_raw_subtask(self, **request_kwargs) -> tuple[str, list[Subtask]]:
        """
        :return: flow_token and subtasks
        """
        url = "https://api.x.com/1.1/onboarding/task.json"
        response, data = await self.request("POST", url, **request_kwargs)
        subtasks = [
            Subtask.from_raw_data(subtask_data) for subtask_data in data["subtasks"]
        ]
        log_message = (
            f"(auth_token={self.account.auth_token}, id={self.account.id}, username={self.account.username})"
            f" Requested subtasks:"
        )
        for subtask in subtasks:
            log_message += f"\n\t{subtask.id}"
            if subtask.primary_text:
                log_message += f"\n\tPrimary text: {subtask.primary_text}"
            if subtask.secondary_text:
                log_message += f"\n\tSecondary text: {subtask.secondary_text}"
            if subtask.detail_text:
                log_message += f"\n\tDetail text: {subtask.detail_text}"
        logger.debug(log_message)
        return data["flow_token"], subtasks

    async def _complete_subtask(
        self,
        flow_token: str,
        inputs: list[dict],
        **request_kwargs,
    ) -> tuple[str, list[Subtask]]:
        payload = request_kwargs["json"] = request_kwargs.get("json") or {}
        payload.update(
            {
                "flow_token": flow_token,
                "subtask_inputs": inputs,
            }
        )
        return await self._send_raw_subtask(**request_kwargs)

    async def _request_guest_token(self) -> str:
        """
        Помимо запроса guest_token также устанавливает в сессию guest_id cookie

        :return: guest_token
        """
        response, data = await self._request(
            "POST",
            "https://api.x.com/1.1/guest/activate.json",
            auth=False,
        )
        return data["guest_token"]

    async def totp_is_enabled(self):
        if not self.account.id:
            await self.update_account_info()

        url = f"https://x.com/i/api/1.1/strato/column/User/{self.account.id}/account-security/twoFactorAuthSettings2"
        response, data = await self.request("GET", url)

        return "Totp" in [
            method_data["twoFactorType"] for method_data in data["methods"]
        ]

    async def _request_2fa_tasks(
        self, enable: bool = True
    ) -> tuple[str, list[Subtask]]:
        """
        :return: flow_token, tasks
        """

        query = {
            "flow_name": (
                "two-factor-auth-app-enrollment"
                if enable
                else "two-factor-unenrollment"
            ),
        }

        common_payload = {
            "input_flow_data": {
                "flow_context": {
                    "debug_overrides": {},
                    "start_location": {"location": "settings"},
                }
            },
            "subtask_versions": {
                "action_list": 2,
                "alert_dialog": 1,
                "app_download_cta": 1,
                "check_logged_in_account": 1,
                "choice_selection": 3,
                "contacts_live_sync_permission_prompt": 0,
                "cta": 7,
                "email_verification": 2,
                "end_flow": 1,
                "enter_date": 1,
                "enter_email": 2,
                "enter_password": 5,
                "enter_phone": 2,
                "enter_recaptcha": 1,
                "enter_text": 5,
                "enter_username": 2,
                "generic_urt": 3,
                "in_app_notification": 1,
                "interest_picker": 3,
                "js_instrumentation": 1,
                "menu_dialog": 1,
                "notifications_permission_prompt": 2,
                "open_account": 2,
                "open_home_timeline": 1,
                "open_link": 1,
                "phone_verification": 4,
                "privacy_options": 1,
                "security_key": 3,
                "select_avatar": 4,
                "select_banner": 2,
                "settings_list": 7,
                "show_code": 1,
                "sign_up": 2,
                "sign_up_review": 4,
                "tweet_selection_urt": 1,
                "update_users": 1,
                "upload_media": 1,
                "user_recommendations_list": 4,
                "user_recommendations_urt": 1,
                "wait_spinner": 3,
                "web_modal": 1,
            },
        }

        if not enable:
            common_payload = {
                "input_flow_data": {
                    "requested_variant": '{"method":"authenticationApp"}',
                    "flow_context": {
                        "debug_overrides": {},
                        "start_location": {"location": "settings"},
                    },
                },
                "subtask_versions": {
                    "action_list": 2,
                    "alert_dialog": 1,
                    "app_download_cta": 1,
                    "check_logged_in_account": 1,
                    "choice_selection": 3,
                    "contacts_live_sync_permission_prompt": 0,
                    "cta": 7,
                    "email_verification": 2,
                    "end_flow": 1,
                    "enter_date": 1,
                    "enter_email": 2,
                    "enter_password": 5,
                    "enter_phone": 2,
                    "enter_recaptcha": 1,
                    "enter_text": 5,
                    "enter_username": 2,
                    "generic_urt": 3,
                    "in_app_notification": 1,
                    "interest_picker": 3,
                    "js_instrumentation": 1,
                    "menu_dialog": 1,
                    "notifications_permission_prompt": 2,
                    "open_account": 2,
                    "open_home_timeline": 1,
                    "open_link": 1,
                    "phone_verification": 4,
                    "privacy_options": 1,
                    "security_key": 3,
                    "select_avatar": 4,
                    "select_banner": 2,
                    "settings_list": 7,
                    "show_code": 1,
                    "sign_up": 2,
                    "sign_up_review": 4,
                    "tweet_selection_urt": 1,
                    "update_users": 1,
                    "upload_media": 1,
                    "user_recommendations_list": 4,
                    "user_recommendations_urt": 1,
                    "wait_spinner": 3,
                    "web_modal": 1,
                },
            }

        return await self._send_raw_subtask(params=query, json=common_payload)

    async def _two_factor_enrollment_verify_password_subtask(
        self, flow_token: str
    ) -> tuple[str, list[Subtask]]:
        inputs = [
            {
                "subtask_id": "TwoFactorEnrollmentVerifyPasswordSubtask",
                "enter_password": {
                    "link": "next_link",
                    "password": self.account.password,
                },
            }
        ]
        return await self._complete_subtask(flow_token, inputs)

    async def _two_factor_enrollment_authentication_app_begin_subtask(
        self, flow_token: str
    ) -> tuple[str, list[Subtask]]:
        inputs = [
            {
                "subtask_id": "TwoFactorEnrollmentAuthenticationAppBeginSubtask",
                "action_list": {"link": "next_link"},
            }
        ]
        return await self._complete_subtask(flow_token, inputs)

    async def _two_factor_enrollment_authentication_app_plain_code_subtask(
        self,
        flow_token: str,
    ) -> tuple[str, list[Subtask]]:
        subtask_inputs = [
            {
                "subtask_id": "TwoFactorEnrollmentAuthenticationAppPlainCodeSubtask",
                "show_code": {"link": "next_link"},
            },
            {
                "subtask_id": "TwoFactorEnrollmentAuthenticationAppEnterCodeSubtask",
                "enter_text": {
                    "link": "next_link",
                    "text": self.account.get_totp_code(),
                },
            },
        ]
        return await self._complete_subtask(flow_token, subtask_inputs)

    async def _finish_2fa_task(self, flow_token: str):
        subtask_inputs = [
            {
                "subtask_id": "TwoFactorEnrollmentAuthenticationAppCompleteSubtask",
                "cta": {"link": "finish_link"},
            }
        ]
        await self._complete_subtask(flow_token, subtask_inputs)

    async def _enable_totp(self):
        flow_token, subtasks = await self._request_2fa_tasks()

        for subtask in subtasks:
            if subtask.id == "TwoFactorEnrollmentVerifyConfirmedEmailBeginSubtask":
                raise ValueError("Email verification required for 2FA setup")

        flow_token, subtasks = (
            await self._two_factor_enrollment_verify_password_subtask(flow_token)
        )

        if "TwoFactorEnrollmentVerifyConfirmedEmailBeginSubtask" in [
            subtask.id for subtask in subtasks
        ]:
            raise ValueError("Email verification required for 2FA setup")

        if "TwoFactorEnrollmentAuthenticationAppBeginSubtask" in [
            subtask.id for subtask in subtasks
        ]:
            flow_token, subtasks = (
                await self._two_factor_enrollment_authentication_app_begin_subtask(
                    flow_token
                )
            )

        for subtask in subtasks:
            if subtask.id == "TwoFactorEnrollmentAuthenticationAppQrCodeSubtask":
                qr_code_url = subtask.raw_data["show_code"]["code"]
                secret = re.search(r"secret=([A-Z0-9]+)", qr_code_url).group(1)
                self.account.totp_secret = secret
                break
            elif subtask.id == "TwoFactorEnrollmentAuthenticationAppPlainCodeSubtask":
                self.account.totp_secret = subtask.raw_data["show_code"]["code"]
                break

        flow_token, subtasks = (
            await self._two_factor_enrollment_authentication_app_plain_code_subtask(
                flow_token
            )
        )

        for subtask in subtasks:
            if subtask.id == "TwoFactorEnrollmentAuthenticationAppCompleteSubtask":
                result = re.search(
                    r"\n[a-z0-9]{12}\n",
                    subtask.raw_data["cta"]["secondary_text"]["text"],
                )
                backup_code = result[0].strip() if result else None
                self.account.backup_code = backup_code
                break

        await self._finish_2fa_task(flow_token)

    async def enable_totp(self):
        if await self.totp_is_enabled():
            return

        if not self.account.password:
            raise ValueError("Password required to enable TOTP")

        await self._enable_totp()

    async def _two_factor_unenrollment_subtask(
        self, flow_token: str
    ) -> tuple[str, list[Subtask]]:
        inputs = [
            {
                "subtask_id": "TwoFactorUnenrollmentSubtask",
                "cta": {
                    "link": "next_link",
                },
            }
        ]
        return await self._complete_subtask(flow_token, inputs)

    async def _two_factor_unerollment_verify_password_subtask(
        self, flow_token: str
    ) -> tuple[str, list[Subtask]]:
        inputs = [
            {
                "subtask_id": "TwoFactorUnenrollmentVerifyPasswordSubtask",
                "enter_password": {
                    "link": "next_link",
                    "password": self.account.password,
                },
            }
        ]
        return await self._complete_subtask(flow_token, inputs)

    async def disable_totp(self):
        if not await self.totp_is_enabled():
            return "Already disabled"

        flow_token, subtasks = await self._request_2fa_tasks(False)

        for subtask in subtasks:
            if subtask.id == "TwoFactorUnenrollmentVerifyPasswordSubtask":
                logger.debug(
                    f"(auth_token={self.account.auth_token}, id={self.account.id}, username={self.account.username})"
                    f" Requested TOTP unenrollment"
                )
                flow_token, subtasks = (
                    await self._two_factor_unerollment_verify_password_subtask(
                        flow_token
                    )
                )
                break

        for subtask in subtasks:
            if subtask.id == "TwoFactorUnenrollmentSubtask":
                logger.debug(
                    f"(auth_token={self.account.auth_token}, id={self.account.id}, username={self.account.username})"
                    f" Requested TOTP unenrollment"
                )
                flow_token, subtasks = await self._two_factor_unenrollment_subtask(
                    flow_token
                )
                if not subtasks:
                    self.account.totp_secret = None
                    self.account.backup_code = None
                    return True

        return False

    async def change_email(self):
        if not self.account.password:
            logs.err(
                f"Email change skipped - Password not set for account > {self.account.auth_token}"
            )
            return False

        try:
            mailclient = Email(
                proxy=None, auth_token=self.account.auth_token, ct0=self.account.ct0
            )

            changed = await mailclient.change_email(self.account.password)
            if isinstance(changed, tuple):
                if changed[0] is True:
                    self.account.email = changed[1]
                    self.account.email_pass = changed[2]
                    logs.err(
                        f"Email successfully changed to {changed[1]} > {self.account.auth_token}"
                    )
                    return True
                else:
                    logs.err(
                        f"Email change failed - {changed[1]} > {self.account.auth_token}"
                    )
                    return changed[1]

            elif isinstance(changed, str):
                if changed in ["locked", "suspended", "skip"]:
                    logs.err(
                        f"Email change skipped - Account status: {changed} > {self.account.auth_token}"
                    )
                else:
                    logs.err(
                        f"Email change failed - Unknown error: {changed} > {self.account.auth_token}"
                    )
                return changed

        except TypeError as e:
            if "NoneType" in str(e):
                logs.err(
                    f"Email change failed - NoneType value encountered in API response > {self.account.auth_token}"
                )
                return False
            else:
                traceback.print_exc()
                logs.err(
                    f"Email change failed - TypeError: {str(e)} > {self.account.auth_token}"
                )
                return False
        except Exception as e:
            logs.err(
                f"Email change failed - Unexpected error: {str(e)} > {self.account.auth_token}"
            )
            return False

    async def enable_protection(self) -> bool:
        """
        Enable password reset protection from security settings

        Returns:
            bool: True if protection was enabled successfully, False otherwise
        """
        try:
            email_client = Email(
                proxy=None, auth_token=self.account.auth_token, ct0=self.account.ct0
            )
            result = await email_client.enable_protection(self.account.password)
            return result
        except Exception as e:
            logs.err(
                f"Error enabling password reset protection: {str(e)} {self.account.auth_token}"
            )
            return False
