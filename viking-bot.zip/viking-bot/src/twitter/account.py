from pathlib import Path
from typing import Sequence, Iterable

from pydantic import Field
import pyotp

from .utils import value, load_lines, write_lines
from .enums import AccountStatus
from .models import User


class Account(User):

    auth_token: str | None = Field(default=None, pattern=r"^[a-f0-9]{40}$")
    ct0: str | None = None
    password: str | None = None
    email: str | None = None
    email_pass: str | None = None
    totp_secret: str | None = None
    backup_code: str | None = None
    status: AccountStatus = AccountStatus.UNKNOWN

    @property
    def auth_token(self) -> str | None:
        return value(self.auth_token) if self.auth_token else None

    @property
    def password(self) -> str | None:
        return value(self.password) if self.password else None

    @property
    def totp_secret(self) -> str | None:
        return value(self.totp_secret) if self.totp_secret else None

    @property
    def backup_code(self) -> str | None:
        return value(self.backup_code) if self.backup_code else None

    @property
    def email_pass(self) -> str | None:
        return value(self.email_pass) if self.email_pass else None

    def __str__(self):
        return self.auth_token

    def __repr__(self):
        return f"{self.__class__.__name__}(id={self.id}, username={self.username}, auth_token={self.auth_token})"

    def update(self, **data: dict):
        update = self.dict()
        update.update(data)
        for k, v in self.validate(update).dict(exclude_defaults=True).items():
            setattr(self, k, v)

    def get_totp_code(self) -> str | None:
        if not self.totp_secret:
            raise ValueError("No totp_secret")

        return str(pyotp.TOTP(self.totp_secret).now())


def load_accounts_from_file(
    filepath: Path | str,
    *,
    separator: str = ":",
    fields: Sequence[str] = (
        "auth_token",
        "password",
        "email",
        "email_pass",
        "username",
    ),
) -> list[Account]:
    """
    :param filepath: Path to the file containing account data.
    :param separator: Separator between data in the line.
    :param fields: Tuple containing the names of the fields in the order they appear in the line.
    :return: List of Twitter accounts.
    """
    accounts = []
    for line in load_lines(filepath):
        data = dict(zip(fields, line.split(separator)))
        data.update({key: None for key in data if not data[key]})
        accounts.append(Account(**data))
    return accounts


def extract_accounts_to_file(
    filepath: Path | str,
    accounts: Iterable[Account],
    *,
    separator: str = ":",
    fields: Sequence[str] = ("auth_token", "password", "email", "username"),
):
    lines = []
    for account in accounts:
        account_data = []
        for field_name in fields:
            field = getattr(account, field_name)
            field = field if field is not None else ""
            account_data.append(field)
        lines.append(separator.join(account_data))
    write_lines(filepath, lines)
