import aiohttp
import uuid
import httpx
import traceback
from ..constants import AUTHORIZATION, USER_AGENT
from ..mail import FirstMail
from src.debugger import Debugger

debugger = Debugger()


def auth(ct0: str, auth_token: str) -> tuple:
    debugger.log("Generating auth headers")
    return {
        "accept": "*/*",
        "accept-language": "en-US,en;q=0.9",
        "authorization": AUTHORIZATION,
        "origin": "https://x.com",
        "referer": "https://x.com/settings/profile",
        "user-agent": USER_AGENT,
        "x-twitter-active-User": "yes",
        "x-twitter-auth-type": "OAuth2Session",
        "x-twitter-client-language": "en",
        "x-csrf-token": ct0,
    }, {"auth_token": auth_token, "ct0": ct0}


async def get_ct0(auth_token: str) -> str:
    debugger.log("Fetching ct0 token")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                url="https://x.com/i/api/fleets/v1/avatar_content",
                headers={
                    "accept": "*/*",
                    "user-agent": USER_AGENT,
                    "Authorization": AUTHORIZATION,
                    "cookie": f"auth_token={auth_token}",
                },
                cookies={"auth_token": auth_token},
                ssl=False,
            ) as ct0:
                if "ct0" in ct0.cookies:
                    debugger.log("ct0 token fetched successfully")
                    return ct0.cookies["ct0"].value
                else:
                    debugger.log("ct0 token not found in cookies")
                    return None

    except Exception as e:
        debugger.log(f"Failed to get ct0: {e}")
        return None


class Email:
    def __init__(self, proxy: str = None, auth_token: str = None, ct0: str = None):
        self.auth_token = auth_token
        self.csrf_token = ct0
        self.email_client = FirstMail(None)
        self._private_client = httpx.AsyncClient(
            proxy=f"http://{proxy}" if proxy else None,
            timeout=httpx.Timeout(10, read=30),
        )
        self._public_client = httpx.AsyncClient(
            proxy=f"http://{proxy}" if proxy else None,
            timeout=httpx.Timeout(10, read=30),
        )
        self.csrf_token = get_ct0(self.auth_token) if not ct0 else ct0
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
        self.user_agent = ua
        self._private_client.headers.update(
            {
                "User-Agent": self.user_agent,
            }
        )
        self._public_client.headers.update(
            {
                "User-Agent": self.user_agent,
            }
        )
        self._private_client.cookies.update(
            {"ct0": self.csrf_token, "auth_token": self.auth_token}
        )
        self._public_client.cookies.update(
            {
                "ct0": self.csrf_token,
            }
        )

    @property
    def graphql_headers(self):
        return {
            "Authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
            "X-Client-Transaction-Id": "EqjcC+Oqz5rVgWFdZa+I58llasRyV8ro8eQlSvR8dPYKLaShdUkhgT2PV0QHokoKMJPHYBDVoFyik9MqBN2IQ0OQwUisEQ",
            "X-Twitter-Active-User": "yes",
            "X-Twitter-Client-Language": "en",
        }

    async def check_if_email_available(self, email: str):
        url = "https://x.com/i/api/i/users/email_available.json"

        querystring = {"email": email}

        headers = self.graphql_headers
        headers.update(
            {
                "Referer": "https://x.com/",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "same-site",
                "X-Csrf-Token": self.csrf_token,
                "X-Twitter-Auth-Type": "OAuth2Session",
            }
        )

        r = await self._private_client.get(url, headers=headers, params=querystring)
        if r.is_success:
            js = r.json()
            if "msg" in js:
                return js["msg"] == "Available!"
            return False
        else:
            debugger.log("Failed to check email")
            return False

    async def get_email_phone_info(self):
        headers = {
            "Referer": "https://x.com/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "X-Csrf-Token": self.csrf_token,
            "X-Twitter-Auth-Type": "OAuth2Session",
        }
        headers.update(self.graphql_headers)
        r = await self._private_client.get(
            "https://x.com/i/api/1.1/users/email_phone_info.json?include_pending_email=true",
            headers=headers,
        )
        js = r.json()
        if r.status_code == 200:
            return js
        else:
            debugger.log("Failed to get email phone info")
            return False

    async def check_email(self, new_email: str):
        headers = {
            "Referer": "https://x.com/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "X-Csrf-Token": self.csrf_token,
            "X-Twitter-Auth-Type": "OAuth2Session",
        }
        headers.update(self.graphql_headers)
        r = await self._private_client.get(
            "https://x.com/i/api/1.1/users/email_phone_info.json?include_pending_email=true",
            headers=headers,
        )
        js = r.json()
        if r.status_code == 200:

            if len(js["emails"]) > 0 and isinstance(js["emails"][0], dict):
                email_verified = js["emails"][0].get("email_verified", False)
                if not isinstance(email_verified, bool) or not email_verified:
                    debugger.log("Account has unverified email", self.auth_token)
                    return False

            if "emails" in js:
                for e in js["emails"]:
                    if e["email"] == new_email:
                        debugger.log(f"Email exists {new_email}")
                        return True
            return False
        elif r.status_code == 401:
            return "unauthorized"
        elif "errors" in r.text:
            if "this account is temporarily locked." in js["errors"][0]["message"]:
                return "locked"
            elif (
                "Due to new session activity on your account"
                in js["errors"][0]["message"]
            ):
                return "skip"
            elif "suspended" in js["errors"][0]["message"]:
                return "suspended"
        else:
            debugger.log(f"Failed to check email {r.text}")
            return False

    async def change_email(self, x_password: str):
        uid = str(uuid.uuid4())
        new_email, imap_password = await self.email_client.get_email()
        exists = await self.check_email(new_email)
        if isinstance(exists, str):
            debugger.log(f"Email change skipped - Account status: {exists} > {self.auth_token}")
            return exists

        headers = {
            "Referer": "https://x.com/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "X-Csrf-Token": self.csrf_token,
            "x-client-uuid": uid,
            "X-Twitter-Auth-Type": "OAuth2Session",
        }
        headers.update(self.graphql_headers)

        debugger.log(f"Initiating email change process > {self.auth_token}", send=False)
        body = {
            "input_flow_data": {
                "flow_context": {
                    "debug_overrides": {},
                    "start_location": {"location": "settings"},
                }
            },
            "subtask_versions": {
                "action_list": 2,
                "alert_dialog": 1,
                "app_download_cta": 1,
                "check_logged_in_account": 1,
                "choice_selection": 3,
                "contacts_live_sync_permission_prompt": 0,
                "cta": 7,
                "email_verification": 2,
                "end_flow": 1,
                "enter_date": 1,
                "enter_email": 2,
                "enter_password": 5,
                "enter_phone": 2,
                "enter_recaptcha": 1,
                "enter_text": 5,
                "enter_username": 2,
                "generic_urt": 3,
                "in_app_notification": 1,
                "interest_picker": 3,
                "js_instrumentation": 1,
                "menu_dialog": 1,
                "notifications_permission_prompt": 2,
                "open_account": 2,
                "open_home_timeline": 1,
                "open_link": 1,
                "phone_verification": 4,
                "privacy_options": 1,
                "security_key": 3,
                "select_avatar": 4,
                "select_banner": 2,
                "settings_list": 7,
                "show_code": 1,
                "sign_up": 2,
                "sign_up_review": 4,
                "tweet_selection_urt": 1,
                "update_users": 1,
                "upload_media": 1,
                "user_recommendations_list": 4,
                "user_recommendations_urt": 1,
                "wait_spinner": 3,
                "web_modal": 1,
            },
        }
        r = await self._private_client.post(
            "https://api.x.com/1.1/onboarding/task.json?flow_name=add_email",
            headers=headers,
            json=body,
        )
        if not r.is_success:
            js = r.json()
            message = js["errors"][0]["message"]
            if "this account is temporarily locked." in message:
                debugger.log(f"Email change skipped - Account locked > {self.auth_token}")
                return "locked"
            elif "Due to new session activity on your account" in message:
                debugger.log(f"Email change skipped - New session verification required > {self.auth_token}")
                return "skip"
            elif "suspended" in message:
                debugger.log(f"Email change skipped - Account suspended > {self.auth_token}")
                return "suspended"
            debugger.log(f"Email change failed - Error: {message} > {self.auth_token}")
            return False

        data = r.json()
        flow_token = data["flow_token"]

        body = {
            "flow_token": flow_token,
            "subtask_inputs": [
                {
                    "subtask_id": "DeviceAssocEnterPassword",
                    "enter_password": {"password": x_password, "link": "next_link"},
                }
            ],
        }
        r = await self._private_client.post(
            "https://api.x.com/1.1/onboarding/task.json", headers=headers, json=body
        )
        if not r.is_success:
            debugger.log(f"Email change failed - Password verification failed > {self.auth_token}")
            return False

        flow_token = r.json()["flow_token"]

        body = {"email": new_email, "flow_token": flow_token}

        r = await self._private_client.post(
            "https://api.x.com/1.1/onboarding/begin_verification.json",
            headers=headers,
            json=body,
        )
        if not r.is_success:
            debugger.log(f"Email change failed - Could not begin verification flow > {self.auth_token}")
            return False

        otp = await self.email_client.get_code(new_email, imap_password)

        if otp is None:
            debugger.log(f"Email change failed - Could not retrieve OTP for {new_email} > {self.auth_token}")
            return False

        body = {
            "flow_token": flow_token,
            "subtask_inputs": [
                {
                    "subtask_id": "EmailAssocEnterEmail",
                    "enter_email": {
                        "setting_responses": [
                            {
                                "key": "email_discoverability_setting",
                                "response_data": {"boolean_data": {"result": False}},
                            }
                        ],
                        "email": new_email,
                        "link": "next_link",
                    },
                },
                {
                    "subtask_id": "EmailAssocVerifyEmail",
                    "email_verification": {
                        "code": otp,
                        "email": new_email,
                        "link": "next_link",
                    },
                },
            ],
        }

        max_retries = 5
        retry_count = 0

        try:
            while retry_count <= max_retries:
                r = await self._private_client.post(
                    "https://api.x.com/1.1/onboarding/task.json",
                    headers=headers,
                    json=body,
                )

                if r.is_success:
                    if r.json().get("status") == "success":
                        debugger.log(
                            f"Email successfully changed to {new_email} > {self.auth_token}",
                            send=False,
                        )
                        return True, new_email, imap_password
                    else:
                        debugger.log(
                            f"Email change failed - API returned unsuccessful status > {self.auth_token}",
                            send=False
                        )
                        return False

                if "The code you entered is incorrect" in r.text:
                    debugger.log(
                        f"OTP verification failed (attempt {retry_count + 1}/{max_retries}) > {self.auth_token}",
                        send=False
                    )
                    otp = await self.email_client.get_code(new_email, imap_password)

                    if not otp:
                        debugger.log(
                            f"Email change failed - Could not retrieve new OTP after {retry_count + 1} attempts > {self.auth_token}",
                            send=False
                        )
                        return False

                    body["subtask_inputs"][1]["email_verification"]["code"] = otp
                    retry_count += 1
                elif "This email is already associated with another account" in r.text:
                    debugger.log(
                        f"Email change failed - Email {new_email} already associated with another account > {self.auth_token}",
                        send=False,
                    )
                    return False
                else:
                    debugger.log(
                        f"Email change failed - Unexpected error during verification > {self.auth_token}",
                        send=False
                    )
                    print(r.json())
                    return False

            debugger.log(
                f"Email change failed - Exceeded maximum OTP verification attempts ({max_retries}) > {self.auth_token}",
                send=False
            )
            return False

        except Exception as e:
            traceback.print_exc()
            debugger.log(
                f"Email change failed - Unexpected error: {str(e)} > {self.auth_token}",
                send=False
            )
            return False

    async def enable_protection(self, x_password: str):
        """
        enable password change protection from security settings
        """
        try:
            url = "https://api.x.com/1.1/account/settings.json"

            payload = {
                "include_mention_filter": "true",
                "include_nsfw_user_flag": "true",
                "include_nsfw_admin_flag": "true",
                "include_ranked_timeline": "true",
                "include_alt_text_compose": "true",
                "protect_password_reset": "true",
                "current_password": x_password,
            }
            headers = {
                "host": "api.x.com",
                "connection": "keep-alive",
                "sec-ch-ua-platform": '"Windows"',
                "authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
                "x-csrf-token": self.csrf_token,
                "sec-ch-ua": '"Google Chrome";v="135", "Not-A.Brand";v="8", "Chromium";v="135"',
                "x-twitter-client-language": "en",
                "sec-ch-ua-mobile": "?0",
                "x-twitter-active-user": "yes",
                "x-client-transaction-id": "cpktx7Zou0cdt3QkpdxUymfcdZK/kNPB0sSLDEZMKXHfRlk3JtjW5+apho4fXNcfgOfL23Hx/Hrj7tZT9ZxNe1RENkIJcQ",
                "x-twitter-auth-type": "OAuth2Session",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
                "content-type": "application/x-www-form-urlencoded",
                "accept": "*/*",
                "origin": "https://x.com",
                "sec-fetch-site": "same-site",
                "sec-fetch-mode": "cors",
                "sec-fetch-dest": "empty",
                "referer": "https://x.com/",
                "accept-language": "en-US,en;q=0.9",
            }

            response = await self._private_client.post(
                url, data=payload, headers=headers
            )

            if response.is_success:
                debugger.log(
                    f"Password change protection enabled {self.auth_token}", send=False
                )
                return True
            else:
                debugger.log(
                    f"Failed to enable protection {self.auth_token}", send=False
                )
                return False
        except Exception as e:
            traceback.print_exc()
            debugger.log(
                f"Error during password change protection: {str(e)} {self.auth_token}",
                send=False,
            )
            return False


if __name__ == "__main__":
    email = Email(
        auth_token="a18c6e790a335f452085a6633b83d19958ff7d01",
        ct0="5477ce139e710f1f65b94ced251db69bd4679a25ea5fa966ef43edc9e3c9c81adb405a41a77879f5bb070e6983009fbf19e7a39c69f5c6366562981844d60e8d53eb992aa061554e1c845a763269e994",
    )
    print(email.enable_protection("SSC2025#"))
