from dataclasses import dataclass, field, fields, MISSING
from typing import List, Optional, Dict, Any
from datetime import datetime
from src.products import ProductAttributes


class DirectCryptoCharge:
    """Represents a HoodPay direct crypto charge.

    Attributes
    ----------
    amount: `float`
        The amount of the charge.
    currency: `str`
        The currency of the charge."""

    def __init__(self, data: dict):
        self.amount = data["amount"]
        self.currency = data["currency"]


class Payment:
    """Represents a HoodPay payment.

    Attributes
    ----------
    id: `int`
        The ID of the payment.
    end_amount: `float`
        The amount of the payment.
    currency: `str`
        The currency of the payment.
    description: `str`
        The description of the payment.
    customer_email: `str`
        The email of the customer.
    created_at: `datetime`
        The time the payment was created.
    status: `str`
        The status of the payment.
    selected_payment_method: `str`
        The payment method used for the payment.
    direct_crypto_charge: `DirectCryptoCharge`
        The direct crypto charge of the payment.
    """

    def __init__(self, data: dict):
        self.id = data["id"]
        self.end_amount = data["endAmount"]
        self.currency = data["currency"]
        self.description = data["description"]
        self.customer_email = data["customerEmail"]
        self.created_at = datetime.fromtimestamp(data["createdAt"])
        self.status = data["status"]
        self.selected_payment_method = data["selectedPaymentMethod"]
        self.direct_crypto_charge = DirectCryptoCharge(data["directCryptoCharge"])


@dataclass
class StatusHistory:
    id: int
    invoice_id: str
    status: str
    details: str
    created_at: int

    def __init__(self, **kwargs):
        cls_fields = fields(self)
        field_names = {f.name for f in cls_fields}

        for f in cls_fields:
            if f.name in kwargs:
                value = kwargs.pop(f.name)
                setattr(self, f.name, value)
            elif f.default is not MISSING:
                setattr(self, f.name, f.default)
            elif f.default_factory is not MISSING:
                setattr(self, f.name, f.default_factory())
            else:
                setattr(self, f.name, None)

        for key, value in kwargs.items():
            setattr(self, key, value)

    def to_dict(self):
        return {f.name: getattr(self, f.name) for f in fields(self)}


@dataclass
class MinPrice:
    amount: float
    currency: str

    def __init__(self, **kwargs):
        cls_fields = fields(self)
        field_names = {f.name for f in cls_fields}

        for f in cls_fields:
            if f.name in kwargs:
                value = kwargs.pop(f.name)
                setattr(self, f.name, value)
            elif f.default is not MISSING:
                setattr(self, f.name, f.default)
            elif f.default_factory is not MISSING:
                setattr(self, f.name, f.default_factory())
            else:
                setattr(self, f.name, None)

    def to_dict(self):
        return {f.name: getattr(self, f.name) for f in fields(self)}


@dataclass
class CustomerBalance:
    amount: float
    currency: str

    def __init__(self, **kwargs):
        cls_fields = fields(self)
        field_names = {f.name for f in cls_fields}

        for f in cls_fields:
            if f.name in kwargs:
                value = kwargs.pop(f.name)
                setattr(self, f.name, value)
            elif f.default is not MISSING:
                setattr(self, f.name, f.default)
            elif f.default_factory is not MISSING:
                setattr(self, f.name, f.default_factory())
            else:
                setattr(self, f.name, None)

    def to_dict(self):
        return {f.name: getattr(self, f.name) for f in fields(self)}


@dataclass
class Customer:
    id: int
    name: str
    email: str
    balance: CustomerBalance
    totalOrders: int
    totalSpendUSD: float
    firstPurchase: str

    def __init__(self, **kwargs):
        cls_fields = fields(self)
        field_names = {f.name for f in cls_fields}

        for f in cls_fields:
            if f.name in kwargs:
                if f.name == "balance" and isinstance(kwargs[f.name], dict):
                    value = CustomerBalance(**kwargs[f.name])
                else:
                    value = kwargs.pop(f.name)
                setattr(self, f.name, value)
            elif f.default is not MISSING:
                setattr(self, f.name, f.default)
            elif f.default_factory is not MISSING:
                setattr(self, f.name, f.default_factory())
            else:
                setattr(self, f.name, None)

    def to_dict(self):
        return {
            f.name: (
                getattr(self, f.name).to_dict()
                if f.name == "balance"
                else getattr(self, f.name)
            )
            for f in fields(self)
        }


@dataclass
class Product:
    id: str
    title: str
    price: float
    stock: int
    type: str
    attributes: Optional[ProductAttributes] = None

    def __init__(self, **kwargs):
        cls_fields = fields(self)
        field_names = {f.name for f in cls_fields}

        for f in cls_fields:
            if f.name in kwargs:
                value = kwargs.pop(f.name)
                setattr(self, f.name, value)
            elif f.default is not MISSING:
                setattr(self, f.name, f.default)
            elif f.default_factory is not MISSING:
                setattr(self, f.name, f.default_factory())
            else:
                setattr(self, f.name, None)

    def to_dict(self):
        return {f.name: getattr(self, f.name) for f in fields(self)}


@dataclass
class OrderPrice:
    amount: float
    currency: str

    def __init__(self, **kwargs):
        cls_fields = fields(self)
        field_names = {f.name for f in cls_fields}

        for f in cls_fields:
            if f.name in kwargs:
                value = kwargs.pop(f.name)
                setattr(self, f.name, value)
            elif f.default is not MISSING:
                setattr(self, f.name, f.default)
            elif f.default_factory is not MISSING:
                setattr(self, f.name, f.default_factory())
            else:
                setattr(self, f.name, None)

    def to_dict(self):
        return {f.name: getattr(self, f.name) for f in fields(self)}


@dataclass
class EndPrice:
    amount: float
    currency: str

    def __init__(self, **kwargs):
        cls_fields = fields(self)
        field_names = {f.name for f in cls_fields}

        for f in cls_fields:
            if f.name in kwargs:
                value = kwargs.pop(f.name)
                setattr(self, f.name, value)
            elif f.default is not MISSING:
                setattr(self, f.name, f.default)
            elif f.default_factory is not MISSING:
                setattr(self, f.name, f.default_factory())
            else:
                setattr(self, f.name, None)

    def to_dict(self):
        return {f.name: getattr(self, f.name) for f in fields(self)}


@dataclass
class Order:
    id: str
    user_id: int
    product_id: str
    quantity: int
    status: str
    created_at: str

    def __init__(self, **kwargs):
        cls_fields = fields(self)
        field_names = {f.name for f in cls_fields}

        for f in cls_fields:
            if f.name in kwargs:
                value = kwargs.pop(f.name)
                setattr(self, f.name, value)
            elif f.default is not MISSING:
                setattr(self, f.name, f.default)
            elif f.default_factory is not MISSING:
                setattr(self, f.name, f.default_factory())
            else:
                setattr(self, f.name, None)

    def to_dict(self):
        return {f.name: getattr(self, f.name) for f in fields(self)}

    @property
    def created_datetime(self) -> datetime:
        """Convert ISO format string to datetime object"""
        return datetime.fromisoformat(self.createdAt.replace("Z", "+00:00"))


@dataclass
class ResponseData:
    data: List[Any]
    message: str = ""
    errors: List[str] = field(default_factory=list)

    def __init__(self, data_type=Product, **kwargs):
        if "data" in kwargs:
            data = kwargs["data"]
            if isinstance(data, dict):
                self.data = [data_type(**data)]
            elif isinstance(data, list):
                self.data = [
                    data_type(**item) for item in data if isinstance(item, dict)
                ]
            else:
                self.data = []
        else:
            self.data = []

        self.message = kwargs.get("message", "")
        self.errors = kwargs.get("errors", [])

    def to_dict(self):
        return {
            "data": [item.to_dict() for item in self.data],
            "message": self.message,
            "errors": self.errors,
        }


@dataclass
class OrderResponse(ResponseData):
    def __init__(self, **kwargs):
        super().__init__(data_type=Order, **kwargs)
