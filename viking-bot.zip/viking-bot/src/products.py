import yaml
import os
from dataclasses import dataclass
from typing import Tuple, Optional, List, Dict, Any, Union
from src import debugger
from src.db import DatabaseManager
import asyncio
import config


class Types:
    FOLLOWERS = "follower"
    BLUES = "blue"
    GREYS = "grey"
    GOLD = "gold"
    NORMAL = "normal"
    BLUEPLUS = "blueplus"
    CHARS = "chars"
    UNVERIFIED = "unverified"
    MIXED = "mixed"
    MSTATS = "mstats"


db = DatabaseManager()


@dataclass
class ProductAttributes:
    mail_access: bool
    fully_verified: bool
    unverified: bool
    mixed: bool
    range: Optional[Tuple[int, int]]
    product_type: str
    price: float
    fresh: bool = False


@dataclass
class Product:
    id: str
    title: str
    description: str
    price: float
    attributes: ProductAttributes

    @classmethod
    def from_dict(cls, data: Dict[str, Any], product_type: str = "normal"):
        """Create a Product instance from a dictionary representation"""
        attrs = data.get("attributes", {})
        range_value = attrs.get("range")
        range_tuple = tuple(range_value) if range_value else None

        attributes = ProductAttributes(
            mail_access=attrs.get("mail_access", False),
            fully_verified=attrs.get("fully_verified", False),
            unverified=attrs.get("unverified", False),
            mixed=attrs.get("mixed", False),
            range=range_tuple,
            product_type=product_type,
            price=float(data.get("price", 0.0)),
            fresh=attrs.get("fresh", False),
        )

        return cls(
            id=data.get("id", ""),
            title=data.get("title", ""),
            description=data.get("description", ""),
            price=float(data.get("price", 0.0)),
            attributes=attributes,
        )


class ProductTypes:
    """Product management class with YAML-based configuration."""

    _products_cache = {}
    _cache_ttl = 30
    _config_loaded = False
    _config_file = os.path.join("database", "products.yml")
    _product_config = {}
    _lock = asyncio.Lock()

    @classmethod
    def load_config(cls, force_reload=False):
        """Load product configuration from YAML file"""
        if cls._config_loaded and not force_reload:
            return

        try:

            os.makedirs(os.path.dirname(cls._config_file), exist_ok=True)

            if not os.path.exists(cls._config_file):
                with open(cls._config_file, "w") as file:
                    yaml.dump({"products": {}}, file, default_flow_style=False)

            with open(cls._config_file, "r") as file:
                cls._product_config = yaml.safe_load(file) or {"products": {}}

            if "products" not in cls._product_config:
                cls._product_config["products"] = {}

            cls._config_loaded = True
        except Exception as e:
            print(f"Error loading product configuration: {e}")
            cls._product_config = {"products": {}}

    @classmethod
    async def save_config(cls):
        """Save product configuration to YAML file with locking for thread safety"""
        async with cls._lock:
            try:
                with open(cls._config_file, "w") as file:
                    yaml.dump(cls._product_config, file, default_flow_style=False)
            except Exception as e:
                print(f"Error saving product configuration: {e}")

    @classmethod
    def clear_cache(cls):
        cls._products_cache = {}

    @classmethod
    async def get_product_by_id(cls, product_id: str) -> Optional[Product]:
        print(f"[DEBUG] Looking for product_id: {product_id}", flush=True)
        cls.load_config(force_reload=True)
        cls.clear_cache()
        if product_id in cls._products_cache:
            print(f"[DEBUG] Found in cache: {product_id}", flush=True)
            return cls._products_cache[product_id]
        products = cls._product_config.get("products", {})
        for category_name, category_data in products.items():
            if (
                isinstance(category_data, dict)
                and category_data.get("id")
            ):
                print(f"[DEBUG] Checking {category_name} id: {category_data.get('id')}", flush=True)
            if (
                isinstance(category_data, dict)
                and category_data.get("id") == product_id
            ):
                print(f"[DEBUG] Match found in {category_name}", flush=True)
                product = Product.from_dict(category_data, category_name)
                cls._products_cache[product_id] = product
                return product
            if category_name == "normal" and isinstance(category_data, dict):
                if "ranges" in category_data:
                    ranges = category_data["ranges"]
                    for range_name, range_variants in ranges.items():
                        for variant_name, variant_data in range_variants.items():
                            if isinstance(variant_data, dict) and variant_data.get("id"):
                                print(f"[DEBUG] Checking normal/ranges {range_name}/{variant_name} id: {variant_data.get('id')}", flush=True)
                            if (
                                isinstance(variant_data, dict)
                                and variant_data.get("id") == product_id
                            ):
                                print(f"[DEBUG] Match found in normal/ranges {range_name}/{variant_name}", flush=True)
                                product = Product.from_dict(variant_data, "normal")
                                cls._products_cache[product_id] = product
                                return product
        print(f"[DEBUG] No match found for product_id: {product_id}", flush=True)
        return None

    @classmethod
    async def _add_product_to_yaml(cls, product: Product):
        """Add a product to the YAML configuration"""
        cls.load_config()

        product_type = product.attributes.product_type
        products = cls._product_config.setdefault("products", {})

        if product_type == "normal":

            category = products.setdefault("normal", {})

            if product.attributes.range:

                ranges = category.setdefault("ranges", {})

                range_str = (
                    f"{product.attributes.range[0]}-{product.attributes.range[1]}"
                )
                range_category = ranges.setdefault(range_str, {})

                variant_key = ""
                if product.attributes.fresh:
                    variant_key = "fresh"
                elif product.attributes.fully_verified:
                    variant_key = "fully_verified"
                elif product.attributes.unverified:
                    variant_key = "unverified"
                elif product.attributes.mixed:
                    variant_key = "mixed"
                else:
                    variant_key = "mixed"

                if product.attributes.mail_access:
                    variant_key += "_mail"

                range_category[variant_key] = {
                    "id": product.id,
                    "title": product.title,
                    "description": product.description,
                    "price": product.price,
                    "attributes": {
                        "mail_access": product.attributes.mail_access,
                        "fully_verified": product.attributes.fully_verified,
                        "unverified": product.attributes.unverified,
                        "mixed": product.attributes.mixed,
                        "fresh": product.attributes.fresh,
                        "range": (
                            list(product.attributes.range)
                            if product.attributes.range
                            else None
                        ),
                    },
                }
            else:

                categories = category.setdefault("categories", {})

                category_key = ""
                if product.attributes.fresh:
                    category_key = "fresh"
                elif product.attributes.fully_verified:
                    category_key = "fully_verified"
                elif product.attributes.unverified:
                    category_key = "unverified"
                elif product.attributes.mixed:
                    category_key = "mixed"
                else:
                    category_key = "email_verified"

                if product.attributes.mail_access:
                    category_key += "_mail"

                categories[category_key] = {
                    "id": product.id,
                    "title": product.title,
                    "description": product.description,
                    "price": product.price,
                    "attributes": {
                        "mail_access": product.attributes.mail_access,
                        "fully_verified": product.attributes.fully_verified,
                        "unverified": product.attributes.unverified,
                        "mixed": product.attributes.mixed,
                        "fresh": product.attributes.fresh,
                        "range": None,
                    },
                }
        else:

            products[product_type] = {
                "id": product.id,
                "title": product.title,
                "description": product.description,
                "price": product.price,
                "attributes": {
                    "mail_access": product.attributes.mail_access,
                    "fully_verified": product.attributes.fully_verified,
                    "unverified": product.attributes.unverified,
                    "mixed": product.attributes.mixed,
                    "fresh": product.attributes.fresh,
                    "range": (
                        list(product.attributes.range)
                        if product.attributes.range
                        else None
                    ),
                },
            }

        await cls.save_config()

    @classmethod
    async def get_productId_by_type(cls, product_type: str) -> Optional[str]:
        """Find first product matching the given type"""
        cls.load_config()

        products = cls._product_config.get("products", {})
        if product_type in products:
            category_data = products[product_type]
            if isinstance(category_data, dict) and "id" in category_data:
                return category_data["id"]

        products = await db.list_bot_products()
        for product in products:
            if product["type"].startswith(product_type):
                return product["id"]
        return None

    @classmethod
    async def add_product(
        cls,
        product_id: str,
        product_type: str,
        range_str: Optional[str],
        verifications: Optional[List[str]] = None,
        mail_access: bool = False,
        price: float = 0.0,
        title: str = "",
        description: str = "",
        fresh: bool = False,
    ) -> bool:
        """Add a product to database and update YAML config"""

        if verifications is None:
            verifications = []

        if not fresh and title:
            if "fresh" in title.lower() or "2025" in title:
                fresh = True

        if fresh and "fresh" not in verifications:
            verifications.append("fresh")

        db_result = await db.add_bot_product(
            product_id=product_id,
            product_type=product_type,
            range_str=range_str,
            verifications=verifications,
            mail_access=mail_access,
            price=price,
            fresh=fresh,
        )

        if not title:
            title = await cls.fetch_and_cache_product_title(product_id)

        if title:
            await db.cache_product_title(product_id, title)

            if not fresh and ("fresh" in title.lower() or "2025" in title):
                fresh = True
                if "fresh" not in verifications:
                    verifications.append("fresh")
        else:

            if range_str:
                title = f"Twitter {product_type.capitalize()} Accounts ({range_str} Followers)"
            else:
                title = f"Twitter {product_type.capitalize()} Accounts"

            if fresh:
                title = f"Fresh 2025 {title}"

        range_tuple = None
        if range_str:
            try:
                start, end = map(int, range_str.split("-"))
                range_tuple = (start, end)
            except (ValueError, TypeError):
                range_tuple = None

        product = Product(
            id=product_id,
            title=title,
            description=description or f"{title} - {product_type} accounts",
            price=price,
            attributes=ProductAttributes(
                mail_access=mail_access,
                fully_verified="fv" in verifications,
                unverified="uv" in verifications,
                mixed="mixed" in verifications or not verifications,
                range=range_tuple,
                product_type=product_type,
                price=price,
                fresh=fresh,
            ),
        )

        await cls._add_product_to_yaml(product)

        if product_id in cls._products_cache:
            del cls._products_cache[product_id]

        return db_result

    @classmethod
    async def get_product_attributes(
        cls, product_id: str
    ) -> Optional[ProductAttributes]:
        """Get product attributes by ID"""
        cls.load_config()

        products = cls._product_config.get("products", {})

        for category_name, category_data in products.items():

            normalized_category = (
                "normal" if category_name == "normals" else category_name
            )

            if (
                isinstance(category_data, dict)
                and category_data.get("id") == product_id
            ):
                attrs = category_data.get("attributes", {})

                is_fresh_by_title = False
                title = category_data.get("title", "").lower()
                if "fresh" in title or "2025" in title:
                    is_fresh_by_title = True

                return ProductAttributes(
                    mail_access=attrs.get("mail_access", False),
                    fully_verified=attrs.get("fully_verified", False),
                    unverified=attrs.get("unverified", False),
                    mixed=attrs.get("mixed", False),
                    range=tuple(attrs.get("range")) if attrs.get("range") else None,
                    product_type=normalized_category,
                    price=float(category_data.get("price", 0.0)),
                    fresh=attrs.get("fresh", False) or is_fresh_by_title,
                )

            if isinstance(category_data, dict):

                if category_name == "normal" and "ranges" in category_data:
                    ranges = category_data.get("ranges", {})
                    for range_name, range_variants in ranges.items():
                        for variant_name, variant_data in range_variants.items():
                            if (
                                isinstance(variant_data, dict)
                                and variant_data.get("id") == product_id
                            ):
                                attrs = variant_data.get("attributes", {})

                                is_fresh_by_title = False
                                title = variant_data.get("title", "").lower()
                                if "fresh" in title or "2025" in title:
                                    is_fresh_by_title = True

                                return ProductAttributes(
                                    mail_access=attrs.get("mail_access", False),
                                    fully_verified=attrs.get("fully_verified", False),
                                    unverified=attrs.get("unverified", False),
                                    mixed=attrs.get("mixed", False),
                                    range=(
                                        tuple(attrs.get("range"))
                                        if attrs.get("range")
                                        else None
                                    ),
                                    product_type="normal",
                                    price=float(variant_data.get("price", 0.0)),
                                    fresh=attrs.get("fresh", False)
                                    or is_fresh_by_title,
                                )

                for subcategory_name, subcategory_data in category_data.items():
                    if (
                        subcategory_name != "ranges"
                        and isinstance(subcategory_data, dict)
                        and subcategory_data.get("id") == product_id
                    ):
                        attrs = subcategory_data.get("attributes", {})

                        is_fresh_by_title = False
                        title = subcategory_data.get("title", "").lower()
                        if "fresh" in title or "2025" in title:
                            is_fresh_by_title = True

                        return ProductAttributes(
                            mail_access=attrs.get("mail_access", False),
                            fully_verified=attrs.get("fully_verified", False),
                            unverified=attrs.get("unverified", False),
                            mixed=attrs.get("mixed", False),
                            range=(
                                tuple(attrs.get("range"))
                                if attrs.get("range")
                                else None
                            ),
                            product_type=normalized_category,
                            price=float(subcategory_data.get("price", 0.0)),
                            fresh=attrs.get("fresh", False) or is_fresh_by_title,
                        )

        db_product = await db.get_bot_product(product_id)
        if not db_product:
            return None

        try:
            type_parts = db_product["type"].split(":")
            product_type = type_parts[0].lower()
            verifications = type_parts[1].split(",") if len(type_parts) > 1 else []
            mail_access = bool(int(type_parts[2])) if len(type_parts) > 2 else False

            fully_verified = "fv" in verifications
            unverified = "uv" in verifications
            mixed = "mixed" in verifications
            fresh = "fresh" in verifications

            title = db_product.get("title", f"Product {db_product['id']}")
            if title and ("fresh" in title.lower() or "2025" in title.lower()):
                fresh = True

            range_val = db_product.get("range")
            range_tuple = None
            if isinstance(range_val, str):
                try:
                    start, end = map(int, range_val.split("-"))
                    range_tuple = (start, end)
                except (ValueError, TypeError):
                    pass
            elif isinstance(range_val, (tuple, list)):
                range_tuple = tuple(map(int, range_val))

            return ProductAttributes(
                mail_access=mail_access,
                fully_verified=fully_verified,
                unverified=unverified,
                mixed=mixed,
                range=range_tuple,
                product_type=product_type,  # Set the product_type from database
                price=float(db_product.get("price", 0.0)),
                fresh=fresh,
            )
        except Exception as e:
            print(f"Error parsing product attributes for {product_id}: {e}")
            return None

    @classmethod
    async def list_all_products(cls) -> List[Product]:
        """List all products from configuration"""
        cls.load_config()

        products_list = []

        products = cls._product_config.get("products", {})
        for category_name, category_data in products.items():

            if category_name == "normal":

                if "categories" in category_data:
                    categories = category_data.get("categories", {})
                    for subcategory_name, subcategory_data in categories.items():
                        if (
                            isinstance(subcategory_data, dict)
                            and "id" in subcategory_data
                        ):
                            product = Product.from_dict(subcategory_data, "normal")
                            products_list.append(product)

                if "ranges" in category_data:
                    ranges = category_data.get("ranges", {})
                    for range_name, range_variants in ranges.items():
                        for variant_name, variant_data in range_variants.items():
                            if isinstance(variant_data, dict) and "id" in variant_data:
                                product = Product.from_dict(variant_data, "normal")
                                products_list.append(product)
            else:

                if isinstance(category_data, dict) and "id" in category_data:
                    product = Product.from_dict(category_data, category_name)
                    products_list.append(product)

        db_products = await db.list_bot_products()
        yaml_product_ids = {p.id for p in products_list}

        for db_product in db_products:
            if db_product["id"] not in yaml_product_ids:

                title = db_product.get("title", f"Product {db_product['id']}")

                attributes = await cls.get_product_attributes(db_product["id"])
                if attributes and hasattr(attributes, 'product_type'):
                    product = Product(
                        id=db_product["id"],
                        title=title,
                        description="",
                        price=float(db_product.get("price", 0.0)),
                        attributes=attributes,
                    )
                    products_list.append(product)

        return products_list

    @classmethod
    async def get_accounts_for_product(
        cls, product_attrs: ProductAttributes, quantity: int = 0
    ) -> List[Dict[str, Any]]:
        """Get accounts matching the product attributes"""
        return await db.get_accounts_by_product_attributes(product_attrs, quantity)

    @classmethod
    async def get_stock_count_for_product(
        cls, product_or_attrs: Union[str, ProductAttributes, Product]
    ) -> int:
        """Get stock count for a product or product attributes"""
        if isinstance(product_or_attrs, str):
            product_attrs = await cls.get_product_attributes(product_or_attrs)
            if not product_attrs:
                return 0
        elif hasattr(product_or_attrs, 'attributes'):
            # Handle Product objects
            product_attrs = product_or_attrs.attributes
        else:
            product_attrs = product_or_attrs
        
        return await db.get_stock_count_by_product_attributes(product_attrs)

    @classmethod
    def invalidate_stock_cache(cls, product_id: str = None):
        """Method kept for backward compatibility but does nothing"""
        pass

    @classmethod
    async def get_products_by_category(
        cls, category: str = "normal", follower_range: str = None
    ) -> List[Product]:
        """Get all products in a category, optionally filtered by follower range"""
        cls.load_config()
        products = await cls.list_all_products()
        
        # Special handling for mstats
        if category == "mstats":
            return [p for p in products if p.attributes.product_type == Types.MSTATS]
            
        # First try getting from config
        products_list = []
        if category == "normal":
            normal_category = cls._product_config.get("products", {}).get("normal", {})
            
            if follower_range:
                range_variants = normal_category.get("ranges", {}).get(follower_range, {})
                for variant_data in range_variants.values():
                    if isinstance(variant_data, dict) and "id" in variant_data:
                        products_list.append(Product.from_dict(variant_data, "normal"))
            else:
                # Get from categories
                for subcategory_data in normal_category.get("categories", {}).values():
                    if isinstance(subcategory_data, dict) and "id" in subcategory_data:
                        products_list.append(Product.from_dict(subcategory_data, "normal"))
                        
                # Get from all ranges
                for range_variants in normal_category.get("ranges", {}).values():
                    for variant_data in range_variants.values():
                        if isinstance(variant_data, dict) and "id" in variant_data:
                            products_list.append(Product.from_dict(variant_data, "normal"))
        else:
            category_data = cls._product_config.get("products", {}).get(category, {})
            if isinstance(category_data, dict) and "id" in category_data:
                products_list.append(Product.from_dict(category_data, category))
                
        # If no products found in config, filter from all products
        if not products_list:
            products_list = [p for p in products if p.attributes.product_type.lower() == category.lower()]
            
            if follower_range and category == "normal":
                try:
                    min_followers, max_followers = map(int, follower_range.split("-"))
                    products_list = [
                        p for p in products_list
                        if p.attributes.range 
                        and p.attributes.range[0] >= min_followers
                        and p.attributes.range[1] <= max_followers
                    ]
                except (ValueError, TypeError):
                    pass
                    
        return products_list

    @classmethod
    async def sync_from_database(cls):
        """Sync all products from database to YAML config"""

        cls.load_config()

        cls._product_config = {"products": {"normal": {"categories": {}, "ranges": {}}}}

        db_products = await db.list_bot_products()
        processed_count = 0

        for db_product in db_products:
            try:

                type_parts = db_product["type"].split(":")
                product_type = type_parts[0].lower()
                verifications = type_parts[1].split(",") if len(type_parts) > 1 else []
                mail_access = bool(int(type_parts[2])) if len(type_parts) > 2 else False

                title = db_product.get("title", f"Product {db_product['id']}")
                if not title:
                    title = (
                        await db.get_product_title(db_product["id"])
                        or f"Product {db_product['id']}"
                    )

                is_fresh_by_title = "fresh" in title.lower() or "2025" in title
                if is_fresh_by_title and "fresh" not in verifications:
                    verifications.append("fresh")

                range_val = db_product.get("range")
                range_tuple = None
                if isinstance(range_val, str):
                    try:
                        start, end = map(int, range_val.split("-"))
                        range_tuple = (start, end)
                    except (ValueError, TypeError):
                        pass
                elif isinstance(range_val, (tuple, list)):
                    range_tuple = tuple(map(int, range_val))

                product = Product(
                    id=db_product["id"],
                    title=title,
                    description=f"{title} - synced from database",
                    price=float(db_product.get("price", 0.0)),
                    attributes=ProductAttributes(
                        mail_access=mail_access,
                        fully_verified="fv" in verifications,
                        unverified="uv" in verifications,
                        mixed="mixed" in verifications or not verifications,
                        range=range_tuple,
                        product_type=product_type,
                        price=float(db_product.get("price", 0.0)),
                        fresh="fresh" in verifications or is_fresh_by_title,
                    ),
                )

                await cls._add_product_to_yaml(product)
                processed_count += 1
            except Exception as e:
                print(f"Error processing product {db_product['id']}: {e}")

        await cls.save_config()

        cls._products_cache = {}

        return processed_count

    @classmethod
    async def is_fresh_product(
        cls,
        product_id: str = None,
        product_title: str = None,
        product_attrs: ProductAttributes = None,
    ) -> bool:
        """
        Check if a product is for fresh accounts (2025)

        Args:
            product_id: Product ID to check
            product_title: Product title to check
            product_attrs: Product attributes to check

        Returns:
            bool: True if the product is for fresh accounts, False otherwise

        Note: At least one parameter must be provided
        """
        if not (product_id or product_title or product_attrs):
            return False

        if product_attrs:
            if hasattr(product_attrs, "fresh") and product_attrs.fresh:
                return True

        if product_title:
            title_lower = product_title.lower()
            if "fresh" in title_lower or "2025" in title_lower:
                return True

        if product_id and not product_attrs:
            product_attrs = await cls.get_product_attributes(product_id)
            if (
                product_attrs
                and hasattr(product_attrs, "fresh")
                and product_attrs.fresh
            ):
                return True

            title = await db.get_product_title(product_id)
            if title:
                title_lower = title.lower()
                if "fresh" in title_lower or "2025" in title_lower:
                    return True

        if product_id:
            cls.load_config()
            products = cls._product_config.get("products", {})

            for category_data in products.values():
                if isinstance(category_data, dict):

                    if category_data.get("id") == product_id:
                        attrs = category_data.get("attributes", {})
                        if attrs.get("fresh"):
                            return True
                        title = category_data.get("title", "").lower()
                        if "fresh" in title or "2025" in title:
                            return True

                    for subcategory_name, subcategory_data in category_data.items():
                        if isinstance(subcategory_data, dict):
                            if subcategory_data.get("id") == product_id:
                                attrs = subcategory_data.get("attributes", {})
                                if attrs.get("fresh"):
                                    return True
                                title = subcategory_data.get("title", "").lower()
                                if "fresh" in title or "2025" in title:
                                    return True

                        if isinstance(subcategory_data, dict):
                            for range_variants in subcategory_data.values():
                                if isinstance(range_variants, dict):
                                    for variant_data in range_variants.values():
                                        if (
                                            isinstance(variant_data, dict)
                                            and variant_data.get("id") == product_id
                                        ):
                                            attrs = variant_data.get("attributes", {})
                                            if attrs.get("fresh"):
                                                return True
                                            title = variant_data.get(
                                                "title", ""
                                            ).lower()
                                            if "fresh" in title or "2025" in title:
                                                return True

        return False

    @classmethod
    async def get_fresh_products(cls) -> List[Product]:
        """
        Get all products that are for fresh accounts (2025)

        Returns:
            List[Product]: List of fresh account products
        """
        all_products = await cls.list_all_products()
        fresh_products = []

        for product in all_products:
            if await cls.is_fresh_product(
                product_id=product.id, product_attrs=product.attributes
            ):
                fresh_products.append(product)

        return fresh_products


if __name__ == "__main__":
    import asyncio

    async def main():

        products = await ProductTypes.list_all_products()
        print(f"Found {len(products)} products in YAML config")

        normal_products = await ProductTypes.get_products_by_category("normal", "0-9")
        print(f"\nFound {len(normal_products)} normal products with 0-9 followers:")

        for p in normal_products:
            print(f"  - {p.id}: {p.title} - ${p.price}")
            stock = await ProductTypes.get_stock_count_for_product(p.id)
            print(
                f"    Stock: {stock} | Mail Access: {p.attributes.mail_access} | Fully Verified: {p.attributes.fully_verified} | Fresh: {p.attributes.fresh}"
            )

        product_id = normal_products[0].id if normal_products else "274326"
        product = await ProductTypes.get_product_by_id(product_id)
        if product:
            print(f"\nProduct details for {product_id}:")
            print(f"  Title: {product.title}")
            print(f"  Price: ${product.price}")
            print(f"  Type: {product.attributes.product_type}")
            print(f"  Range: {product.attributes.range}")
            print(f"  Mail Access: {product.attributes.mail_access}")
            print(f"  Fully Verified: {product.attributes.fully_verified}")
            print(f"  Mixed: {product.attributes.mixed}")
            print(f"  Fresh (2025): {product.attributes.fresh}")

            is_fresh = await ProductTypes.is_fresh_product(product_id)
            print(f"  Is Fresh (utility method): {is_fresh}")

        fresh_products = await ProductTypes.get_fresh_products()
        print(f"\nFound {len(fresh_products)} fresh (2025) products:")
        for p in fresh_products:
            print(f"  - {p.id}: {p.title} - ${p.price}")
            stock = await ProductTypes.get_stock_count_for_product(p.id)
            print(f"    Stock: {stock} | Mail Access: {p.attributes.mail_access}")

        print("\nSyncing products from database to YAML...")
        processed = await ProductTypes.sync_from_database()
        print(f"Synced {processed} products from database")

    asyncio.run(main())
