from datetime import datetime
import httpx
import config
import asyncio
import os

os.makedirs("logs", exist_ok=True)

DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1372348053297692746/MBPUHMsve46c4fIAUE5zPIBaI6AdHfcWqMHVRFD7Hl9W29MBqhftA3-TRjSNlbPOH3U0"
OWNER_WEBOHOK = "https://discord.com/api/webhooks/1372348053297692746/MBPUHMsve46c4fIAUE5zPIBaI6AdHfcWqMHVRFD7Hl9W29MBqhftA3-TRjSNlbPOH3U0"


class Log:
    def info(self, message):
        try:
            print(f"INFO: {message}")
        except UnicodeEncodeError:
            print(f"INFO: {message.encode('utf-8', errors='replace').decode('utf-8')}")

    def warning(self, message):
        print(f"WARNING: {message}")

    def critical(self, message):
        print(f"CRITICAL: {message}")


import aiohttp

log = Log()


class Debugger:
    def __init__(self):
        self.log_queue = []
        self.discord_log_queue = []
        self.is_sending_logs = False
        self.is_sending_discord_logs = False
        self.current_token_index = 0
        self.chatId = config.DEBUG_CHANNEL
        if not config.DEBUGGER_BOT_TOKENS:
            log.critical("No debugger bot tokens configured!")
        if not config.DEBUG_CHANNEL:
            log.critical("No debug channel configured!")

    @property
    def api(self):
        token = config.DEBUGGER_BOT_TOKENS[self.current_token_index]
        self.current_token_index = (self.current_token_index + 1) % len(
            config.DEBUGGER_BOT_TOKENS
        )
        return f"https://api.telegram.org/bot{token}/sendMessage"

    async def log_async(self, log_message: str, send: bool = True) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_message = f"*{timestamp}* `»` {log_message.lower()}"
        clean_log = log_message.lower()
        clean_log = (
            clean_log.replace("`", "").replace("*", "").replace("tg://user?id=", "ID: ")
        )
        while "\x1b[" in clean_log and "\x1b[0m" in clean_log:
            start = clean_log.find("\x1b[")
            end = clean_log.find("m", start) + 1
            clean_log = clean_log[:start] + clean_log[end:]
        clean_log = clean_log.replace("\x1b[0m", "")
        await asyncio.get_event_loop().run_in_executor(None, log.info, clean_log)

        if send:
            self.discord_log_queue.append(clean_log)
            asyncio.create_task(self.send_discord_logs())

    def log(self, log_message: str = "", send: bool = True) -> None:
        try:
            log_message = log_message.encode("utf-8").decode("utf-8")
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self.log_async(log_message, send))
            except RuntimeError:
                log.info(log_message)
                if send:
                    self.discord_log_queue.append(log_message)
            except Exception as e:
                try:
                    loop = asyncio.get_running_loop()
                    loop.run_in_executor(
                        None, log.critical, f"Error in logging: {str(e)}"
                    )
                except RuntimeError:
                    log.critical(f"Error in logging: {str(e)}")
        except Exception as e:
            try:
                loop = asyncio.get_running_loop()
                loop.run_in_executor(None, log.critical, f"Error in logging: {str(e)}")
            except RuntimeError:
                log.critical(f"Error in logging: {str(e)}")

    async def send_discord_logs(self):
        if self.is_sending_discord_logs:
            return
        self.is_sending_discord_logs = True
        try:
            while self.discord_log_queue:
                batched_logs = "\n".join(self.discord_log_queue[:20])
                self.discord_log_queue = self.discord_log_queue[20:]

                content = {
                    "content": (
                        f"```\n{batched_logs[:1950]}\n```"
                        if len(batched_logs) <= 1950
                        else f"```\n{batched_logs[:1950]}...\n```"
                    )
                }

                try:
                    async with aiohttp.ClientSession(
                        connector=aiohttp.TCPConnector(ssl=False)
                    ) as session:
                        async with session.post(
                            DISCORD_WEBHOOK_URL, json=content, timeout=5
                        ) as response:
                            if response.status not in [200, 204]:
                                log_text = f"Failed to send logs to Discord. Status: {response.status}"
                                await asyncio.get_event_loop().run_in_executor(
                                    None, log.warning, log_text
                                )
                except Exception as e:
                    log_text = f"Error sending logs to Discord: {str(e)}"
                    await asyncio.get_event_loop().run_in_executor(
                        None, log.warning, log_text
                    )

                await asyncio.sleep(1)
        finally:
            self.is_sending_discord_logs = False

    async def send_logs(self):
        if self.is_sending_logs:
            return
        self.is_sending_logs = True
        try:
            while self.log_queue:
                batched_logs = "\n".join(self.log_queue[:10])
                self.log_queue = self.log_queue[10:]
                params = {
                    "chat_id": self.chatId,
                    "text": batched_logs,
                    "parse_mode": "Markdown",
                }
                sent = False
                retry_count = 0
                max_retries = 10
                while retry_count < max_retries and not sent:
                    try:
                        async with aiohttp.ClientSession(
                            connector=aiohttp.TCPConnector(ssl=False)
                        ) as session:
                            async with session.post(
                                self.api, json=params, timeout=5
                            ) as response:
                                if response.status == 200:
                                    sent = True
                                elif response.status == 400:
                                    response_text = await response.text()
                                    if "can't parse entities" in response_text:
                                        params.pop("parse_mode")
                                        params["text"] = batched_logs.replace(
                                            "*", ""
                                        ).replace("`", "")
                                        async with session.post(
                                            self.api, json=params
                                        ) as response2:
                                            if response2.status == 200:
                                                sent = True
                                elif response.status == 429:
                                    log.warning(
                                        "WARNING: Failed to send logs to Discord. Status: 429"
                                    )
                                    retry_count += 1
                                    await asyncio.sleep(3)
                                    continue
                    except Exception as e:
                        asyncio.create_task(
                            asyncio.get_event_loop().run_in_executor(
                                None, log.warning, f"Failed to send logs: {str(e)}"
                            )
                        )
                    break
                if not sent:
                    asyncio.create_task(
                        asyncio.get_event_loop().run_in_executor(
                            None, log.critical, "Failed to send logs"
                        )
                    )
                    self.log_queue = batched_logs.split("\n") + self.log_queue
                    break
                await asyncio.sleep(3)
        finally:
            self.is_sending_logs = False

    async def send_message(self, user_id: str, message: str = "Test message") -> None:
        await asyncio.get_event_loop().run_in_executor(
            None, log.info, f"Message (not sent to Telegram): {message}"
        )

        content = {"content": f"Message to user {user_id}: {message}"}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    DISCORD_WEBHOOK_URL, json=content, timeout=5
                ) as response:
                    if response.status not in [200, 204]:
                        log_text = f"Failed to send message to Discord. Status: {response.status}"
                        await asyncio.get_event_loop().run_in_executor(
                            None, log.warning, log_text
                        )
        except Exception as e:
            log_text = f"Error sending message to Discord: {str(e)}"
            await asyncio.get_event_loop().run_in_executor(None, log.warning, log_text)

    async def notify_owner(self, message: str = "Test message") -> None:
        try:
            if not config.DEBUGGER_BOT_TOKENS:
                await asyncio.get_event_loop().run_in_executor(
                    None, log.critical, "No bot tokens configured for notifying owner"
                )
                return

            if not hasattr(config, "NOTIFY_USER") or not config.NOTIFY_USER:
                await asyncio.get_event_loop().run_in_executor(
                    None, log.critical, "No notification user configured"
                )
                return

            content = {
                "content": (
                    f"Owner notification: {message[:1950]}"
                    if len(message) <= 1950
                    else f"Owner notification: {message[:1950]}..."
                )
            }
            try:
                async with aiohttp.ClientSession() as session:
                    await session.post(OWNER_WEBOHOK, json=content, timeout=5)
                    await session.post(DISCORD_WEBHOOK_URL, json=content, timeout=5)
            except Exception as e:
                log_text = f"Error sending notification to Discord: {str(e)}"
                await asyncio.get_event_loop().run_in_executor(
                    None, log.warning, log_text
                )

            if len(message) > 4096:
                chunks = [message[i : i + 4096] for i in range(0, len(message), 4096)]
                for chunk in chunks:
                    params = {
                        "chat_id": config.NOTIFY_USER,
                        "text": chunk,
                        "parse_mode": "Markdown",
                    }
                    sent = False
                    tried = 0
                    while tried < len(config.DEBUGGER_BOT_TOKENS) and not sent:
                        try:
                            async with aiohttp.ClientSession(
                                connector=aiohttp.TCPConnector(ssl=False)
                            ) as session:
                                async with session.post(
                                    self.api, json=params, timeout=5
                                ) as response:
                                    if response.status == 200:
                                        sent = True
                                    elif response.status == 429:
                                        tried += 1
                                        continue
                        except Exception as e:
                            await asyncio.get_event_loop().run_in_executor(
                                None,
                                log.critical,
                                f"Error in notifying owner: {str(e)}",
                            )
                        break
            else:
                params = {
                    "chat_id": config.NOTIFY_USER,
                    "text": message,
                    "parse_mode": "Markdown",
                }
                sent = False
                tried = 0
                while tried < len(config.DEBUGGER_BOT_TOKENS) and not sent:
                    try:
                        async with aiohttp.ClientSession(
                            connector=aiohttp.TCPConnector(ssl=False)
                        ) as session:
                            async with session.post(
                                self.api, json=params, timeout=5
                            ) as response:
                                if response.status == 200:
                                    sent = True
                                elif response.status == 429:
                                    tried += 1
                                    continue
                    except Exception as e:
                        await asyncio.get_event_loop().run_in_executor(
                            None, log.critical, f"Error in notifying owner: {str(e)}"
                        )
                    break
        except Exception as e:
            await asyncio.get_event_loop().run_in_executor(
                None, log.critical, f"Error in notifying owner: {str(e)}"
            )
