import aiosqlite
import asyncio
import os
import shutil
from datetime import datetime
from typing import List, Dict, Any, Optional
from src.colors import *
from src.debugger import Debugger
from src.twitter import auth


class DatabaseManager:
    def __init__(self) -> None:
        self.debug = Debugger()
        self.conn: Optional[aiosqlite.Connection] = None
        self.account_types = {
            "follow": "follow",
            "follows": "follow",
            "follower": "follow",
            "followers": "follow",
            "blue": "blue",
            "blues": "blue",
            "grey": "grey",
            "greys": "grey",
            "gray": "grey",
            "grays": "grey",
            "gold": "gold",
            "golds": "gold",
            "normal": "normal",
            "normals": "normal",
            "norm": "normal",
            "blueplus": "blueplus",
            "blueplusses": "blueplus",
            "blue+": "blueplus",
            "blue_plus": "blueplus",
            "unverified": "unverified",
            "uv": "unverified",
            "chars": "chars",
            "char": "chars",
            "mstats": "mstats",
            "mstat": "mstats",
            "mstats_accounts": "mstats_accounts",
            "mstat_accounts": "mstats_accounts",
        }
        self.tables = [
            """
    CREATE TABLE IF NOT EXISTS normals (
        username TEXT NOT NULL PRIMARY KEY,
        password TEXT NOT NULL,
        email TEXT NOT NULL,
        mailpwd TEXT,
        ct0 TEXT,
        auth TEXT,        
        followers TEXT,
        following TEXT,
        year TEXT,
        backup_code TEXT,
        verified TEXT
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS follower_accounts (
        username TEXT NOT NULL PRIMARY KEY,
        password TEXT NOT NULL,
        email TEXT NOT NULL,
        mailpwd TEXT,
        ct0 TEXT,
        auth TEXT,        
        followers TEXT,
        following TEXT,
        year TEXT,
        backup_code TEXT,
        verified TEXT
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS customers (
        user_id INTEGER PRIMARY KEY,
        email TEXT,
        username TEXT
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS blue_verified_accounts (
        username TEXT NOT NULL PRIMARY KEY,
        password TEXT NOT NULL,
        email TEXT NOT NULL,
        mailpwd TEXT,
        ct0 TEXT,
        auth TEXT,        
        followers TEXT,
        following TEXT,
        year TEXT,
        backup_code TEXT,
        verified TEXT
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS grey_verified_accounts (
        username TEXT NOT NULL PRIMARY KEY,
        password TEXT NOT NULL,
        email TEXT NOT NULL,
        mailpwd TEXT,
        ct0 TEXT,
        auth TEXT,        
        followers TEXT,
        following TEXT,
        year TEXT,
        backup_code TEXT,
        verified TEXT
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS gold_verified_accounts (
        username TEXT NOT NULL PRIMARY KEY,
        password TEXT NOT NULL,
        email TEXT NOT NULL,
        mailpwd TEXT,
        ct0 TEXT,
        auth TEXT,        
        followers TEXT,
        following TEXT,
        year TEXT,
        backup_code TEXT,
        verified TEXT
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS blueplus_accounts (
        username TEXT NOT NULL PRIMARY KEY,
        password TEXT NOT NULL,
        email TEXT NOT NULL,
        mailpwd TEXT,
        ct0 TEXT,
        auth TEXT,        
        followers TEXT,
        following TEXT,
        year TEXT,
        backup_code TEXT,
        verified TEXT
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS bot_products (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        range TEXT,
        verifications TEXT,
        mail_access BOOLEAN DEFAULT FALSE,
        price REAL DEFAULT 0.0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS coupons (
        code TEXT PRIMARY KEY,
        discount REAL NOT NULL,
        max_uses INTEGER,
        uses INTEGER DEFAULT 0,
        expiry_date TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS chars_accounts (
        username TEXT NOT NULL PRIMARY KEY,
        password TEXT NOT NULL,
        email TEXT NOT NULL,
        mailpwd TEXT,
        ct0 TEXT,
        auth TEXT,        
        followers TEXT,
        following TEXT,
        year TEXT,
        backup_code TEXT,
        verified TEXT
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        product_id TEXT NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 1,
        total_amount REAL NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        payment_txid TEXT,
        payment_amount REAL,
        payment_currency TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        completed_at TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES customers(user_id)
    );
    """,
            """
    CREATE TABLE IF NOT EXISTS product_titles (
        product_id TEXT PRIMARY KEY,
        title TEXT NOT NULL
    )
    """,
            """
    CREATE TABLE IF NOT EXISTS locked_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        password TEXT,
        email TEXT,
        mailpwd TEXT,
        auth_token TEXT,
        ct0 TEXT,
        followers INTEGER,
        following INTEGER,
        year INTEGER,
        backup_code TEXT,
        verified TEXT,
        source TEXT,
        locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """,
            """
    CREATE TABLE IF NOT EXISTS faq (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        order_index INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """,
            """
    CREATE TABLE IF NOT EXISTS terms_of_service (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        section TEXT NOT NULL,
        content TEXT NOT NULL,
        order_index INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """,
            """
    CREATE INDEX IF NOT EXISTS idx_locked_username ON locked_tokens (username)
    """,
            """
    CREATE INDEX IF NOT EXISTS idx_locked_auth ON locked_tokens (auth_token)
    """,
            """
    CREATE TABLE IF NOT EXISTS normal_accounts (
        username TEXT PRIMARY KEY,
        password TEXT,
        email TEXT,
        mailpwd TEXT,
        ct0 TEXT,
        auth TEXT,
        followers TEXT,
        following TEXT,
        year TEXT,
        backup_code TEXT,
        verified TEXT
    )
    """,

    """
    CREATE TABLE IF NOT EXISTS mstats_accounts (
        username TEXT PRIMARY KEY,
        password TEXT,
        email TEXT,
        mailpwd TEXT,
        ct0 TEXT,
        auth TEXT,
        followers TEXT,
        following TEXT,
        year TEXT,
        backup_code TEXT,
        verified TEXT
    )
    """,
            """
    CREATE TABLE IF NOT EXISTS trash_accounts (
        username TEXT PRIMARY KEY,
        password TEXT,
        email TEXT,
        mailpwd TEXT,
        ct0 TEXT,
        auth TEXT,
        followers TEXT,
        following TEXT,
        year TEXT,
        backup_code TEXT,
        verified TEXT,
        error_code TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """,
            """
    CREATE TABLE IF NOT EXISTS subscribers (
        user_id INTEGER PRIMARY KEY,
        subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """,
            """
    CREATE TABLE IF NOT EXISTS payment_messages (
        order_uuid TEXT PRIMARY KEY,
        chat_id INTEGER NOT NULL,
        message_id INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,
        ]

        self.indexes = [
            "CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)",
            "CREATE INDEX IF NOT EXISTS idx_orders_order_id ON orders(order_id)",
        ]

        self.db_path = "database/production.db"
        self.backup_dir = "database/backups"
        try:
            self.loop = asyncio.get_running_loop()
        except RuntimeError:
            self.loop = asyncio.get_event_loop()

        if self.loop.is_running():
            self.loop.create_task(self.connect())
        else:
            self.loop.run_until_complete(self.connect())

    async def check_integrity(self) -> bool:
        """Check database integrity and return True if database is OK"""
        try:
            async with self.conn.execute("PRAGMA integrity_check") as cursor:
                result = await cursor.fetchone()
                return result[0] == "ok"
        except Exception as e:
            self.debug.log(f"Integrity check failed: {e}")
            return False

    async def create_backup(self) -> str:
        """Create a backup of the current database"""
        try:
            os.makedirs(self.backup_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"{self.backup_dir}/production_{timestamp}.db"

            shutil.copy2(self.db_path, backup_path)
            self.debug.log(f"Created backup at {backup_path}")
            return backup_path
        except Exception as e:
            self.debug.log(f"Backup creation failed: {e}")
            raise

    async def restore_from_backup(self, backup_path: str) -> bool:
        """Restore database from backup file"""
        try:
            if not os.path.exists(backup_path):
                self.debug.log(f"Backup file not found: {backup_path}")
                return False

            shutil.copy2(backup_path, self.db_path)
            await self.connect()
            await self.createTables()
            self.debug.log(f"Restored from backup: {backup_path}")
            return True
        except Exception as e:
            self.debug.log(f"Restore failed: {e}")
            return False

    async def get_latest_backup(self) -> str:
        """Get path of most recent backup file"""
        try:
            backups = [
                f for f in os.listdir(self.backup_dir) if f.startswith("production_")
            ]
            if not backups:
                return ""
            return f"{self.backup_dir}/{sorted(backups)[-1]}"
        except Exception:
            return ""

    async def connect(self) -> None:
        db_path = "database/production.db"
        db_dir = os.path.dirname(db_path)
        if not os.path.exists(db_dir):
            os.makedirs(db_dir)
            self.debug.log(f"Created database directory: {db_dir}")
        try:
            if self.conn:
                try:
                    await self.conn.close()
                except Exception:
                    pass
            self.conn = await aiosqlite.connect(db_path, check_same_thread=False)
            self.conn.row_factory = aiosqlite.Row
            await self.conn.executescript(
                """
                PRAGMA journal_mode=WAL;
                PRAGMA busy_timeout = 5000;
                PRAGMA foreign_keys = ON;
            """
            )
            await self.createTables()
            self.debug.log(f"Successfully connected to the database: {db_path}")
        except aiosqlite.Error as e:
            self.debug.log(f"Database connection failed: {e}")
            self.conn = None
            raise

    async def _ensure_connection(self) -> None:
        if self.conn is None:
            self.debug.log("Database connection is not active. Reconnecting...")
            await self.connect()
        else:
            try:
                await self.conn.execute("SELECT 1")
            except Exception:
                self.debug.log("Database connection lost. Reconnecting...")
                await self.connect()

    async def close(self) -> None:
        if self.conn:
            await self.conn.close()
            self.conn = None

    async def createTables(self) -> None:
        """Create database tables with improved error handling"""
        try:
            for table in self.tables:
                try:
                    await self.execute(table)
                except Exception as table_error:
                    self.debug.log(f"Error creating table: {table_error}")
                    continue

            for index in self.indexes:
                try:
                    await self.execute(index)
                except Exception as index_error:
                    self.debug.log(f"Error creating index: {index_error}")
                    continue

            await self.execute(
                """
            CREATE TABLE IF NOT EXISTS product_titles (
                product_id TEXT PRIMARY KEY,
                title TEXT NOT NULL
            )
            """
            )

            await self.execute(
                """
                CREATE TABLE IF NOT EXISTS normal_accounts (
                    username TEXT PRIMARY KEY,
                    password TEXT,
                    email TEXT,
                    mailpwd TEXT,
                    ct0 TEXT,
                    auth TEXT,
                    followers TEXT,
                    following TEXT,
                    year TEXT,
                    backup_code TEXT,
                    verified TEXT
                )
            """
            )
            await self.execute(
                """
                CREATE TABLE IF NOT EXISTS trash_accounts (
                    username TEXT PRIMARY KEY,
                    password TEXT,
                    email TEXT,
                    mailpwd TEXT,
                    ct0 TEXT,
                    auth TEXT,
                    followers TEXT,
                    following TEXT,
                    year TEXT,
                    backup_code TEXT,
                    verified TEXT,
                    error_code TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            self.debug.log("Tables and indexes created")

        except Exception as e:
            self.debug.log(f"Error creating tables: {e}")

    async def fetch(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        await self._ensure_connection()
        try:
            async with self.conn.execute(query, params) as cursor:
                rows = await cursor.fetchall()
                return [dict(row) for row in rows] if rows else []
        except aiosqlite.Error as e:
            self.debug.log(f"Error fetching data: {e}")
            return []

    async def fetch_one(self, query: str, params: tuple = ()) -> Dict[str, Any]:
        await self._ensure_connection()
        try:
            async with self.conn.execute(query, params) as cursor:
                row = await cursor.fetchone()
                return dict(row) if row else {}
        except aiosqlite.Error as e:
            self.debug.log(f"Error fetching single row: {e}")
            return {}

    async def execute(self, query: str, params: tuple = ()) -> tuple[bool, int]:
        await self._ensure_connection()
        try:
            async with self.conn.execute(query, params) as cursor:
                await self.conn.commit()
                return True, cursor.rowcount
        except aiosqlite.Error as e:
            self.debug.log(f"Error executing query: {e}")
            await self.conn.rollback()
            return False, 0
        except Exception as e:
            self.debug.log(f"Unexpected error executing query: {e}")
            await self.conn.rollback()
            return False, 0

    async def execute_script(self, script: str) -> None:
        await self._ensure_connection()
        try:
            await self.conn.executescript(script)
            await self.conn.commit()
        except aiosqlite.Error as e:
            self.debug.log(f"Error executing script: {e}")
            await self.conn.rollback()

    async def insert_account(self, table: str, capture: tuple) -> None:
        field_names = [
            "username",
            "password",
            "email",
            "mailpwd",
            "ct0",
            "auth",
            "followers",
            "following",
            "year",
            "backup_code",
            "verified",
        ]

        if len(capture) != len(field_names):
            self.debug.log(f"Capture tuple has insufficient elements: {capture}")
            return

        account_data = dict(zip(field_names, capture))

        if (
            account_data["backup_code"]
            and isinstance(account_data["backup_code"], int)
            and 1900 <= account_data["backup_code"] <= 2100
        ):
            account_data["backup_code"] = None

        if not account_data["followers"]:
            account_data["followers"] = "1"
        if not account_data["following"]:
            account_data["following"] = "1"

        check_query = f"SELECT * FROM {table} WHERE username = ?"
        existing_account = await self.fetch_one(
            check_query, (account_data["username"],)
        )

        if existing_account:
            fields_to_update = [
                f"{field} = ?"
                for field in field_names[1:]
                if existing_account.get(field) != account_data.get(field)
                and account_data.get(field)
            ]
            values_to_update = [
                account_data[field]
                for field in field_names[1:]
                if existing_account.get(field) != account_data.get(field)
                and account_data.get(field)
            ]

            if fields_to_update:
                update_query = f"UPDATE {table} SET {', '.join(fields_to_update)} WHERE username = ?"
                await self.execute(
                    update_query, (*values_to_update, account_data["username"])
                )
                self.debug.log(
                    f"Account with username {account_data['username']} updated in {table}.",
                    send=False,
                )
            else:
                self.debug.log(
                    f"Account with username {account_data['username']} already exists in {table} with no changes. Skipping update.",
                    send=False,
                )
        else:
            insert_query = f"""
                INSERT INTO {table} ({', '.join(field_names)})
                VALUES ({', '.join(['?' for _ in field_names])})
            """
            insert_values = tuple(
                account_data[field] if account_data[field] else ""
                for field in field_names
            )
            await self.execute(insert_query, insert_values)
            self.debug.log(
                f"Account with username {account_data['username']} inserted into {table}.",
                send=False,
            )

    async def insert_blue_verified_account(self, capture: tuple) -> None:
        username = capture[0]
        await self.remove_account_from_conflicting_tables(
            username, target_table="blue_verified_accounts"
        )
        await self.insert_account("blue_verified_accounts", capture)

    async def insert_grey_verified_account(self, capture: tuple) -> None:
        username = capture[0]
        await self.remove_account_from_conflicting_tables(
            username, target_table="grey_verified_accounts"
        )
        await self.insert_account("grey_verified_accounts", capture)

    async def insert_gold_verified_account(self, capture: tuple) -> None:
        username = capture[0]
        await self.remove_account_from_conflicting_tables(
            username, target_table="gold_verified_accounts"
        )
        await self.insert_account("gold_verified_accounts", capture)

    async def insert_follower_account(self, capture: tuple) -> None:
        username = capture[0]
        await self.remove_account_from_conflicting_tables(
            username, target_table="follower_accounts"
        )
        await self.insert_account("follower_accounts", capture)

    async def insert_normal_account(self, capture: tuple) -> None:
        username = capture[0]
        await self.remove_account_from_conflicting_tables(
            username, target_table="normals"
        )
        await self.insert_account("normals", capture)

    async def insert_mstats_account(self, capture: tuple) -> None:
        username = capture[0]
        await self.remove_account_from_conflicting_tables(
            username, target_table="mstats_accounts"
        )
        await self.insert_account("mstats_accounts", capture)

    async def insert_blueplus_account(self, capture: tuple) -> None:
        username = capture[0]
        await self.execute(
            "DELETE FROM blue_verified_accounts WHERE username = ?", (username,)
        )
        await self.insert_account("blueplus_accounts", capture)

    async def insert_chars_account(self, capture: tuple) -> None:
        await self.insert_account("chars_accounts", capture)

    async def bulk_insert_normal_accounts(self, accounts: List[dict[str]]) -> None:
        tasks = [
            self.insert_normal_account(tuple(account.values())) for account in accounts
        ]
        await asyncio.gather(*tasks)

    async def fetch_accounts(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Return format: {
            "follower_accounts": List[Dict[str, Any]],
            "blue_verified_accounts": List[Dict[str, Any]],
            "grey_verified_accounts": List[Dict[str, Any]],
            "gold_verified_accounts": List[Dict[str, Any]],
            "mstats_accounts": List[Dict[str, Any]]
        }
        """
        account_types = [
            "normals",
            "follower_accounts",
            "blue_verified_accounts",
            "grey_verified_accounts",
            "gold_verified_accounts",
            "mstats_accounts",
        ]
        accounts_data: Dict[str, List[Dict[str, Any]]] = {
            account_type: [] for account_type in account_types
        }

        for account_type in account_types:
            query = f"SELECT * FROM {account_type}"
            results = await self.fetch(query)
            accounts_data[account_type].extend(results)

        return accounts_data

    async def get_normal_accounts(self, limit: int = 0) -> List[Dict[str, Any]]:
        query = "SELECT * FROM normals ORDER BY RANDOM()" + (
            f" LIMIT ?" if limit else ""
        )
        params = (limit,) if limit else ()
        return await self.fetch(query, params)

    async def get_mstats_accounts(self, limit: int = 0) -> List[Dict[str, Any]]:
        query = "SELECT * FROM mstats_accounts ORDER BY RANDOM()" + (
            f" LIMIT ?" if limit else ""
        )
        params = (limit,) if limit else ()
        return await self.fetch(query, params)

    async def get_follower_accounts(self, limit: int = 0) -> List[Dict[str, Any]]:
        query = "SELECT * FROM follower_accounts ORDER BY RANDOM()" + (
            f" LIMIT ?" if limit else ""
        )
        params = (limit,) if limit else ()
        return await self.fetch(query, params)

    async def get_blue_accounts(self, limit: int = 0) -> List[Dict[str, Any]]:
        query = "SELECT * FROM blue_verified_accounts ORDER BY RANDOM()" + (
            f" LIMIT ?" if limit else ""
        )
        params = (limit,) if limit else ()
        return await self.fetch(query, params)

    async def get_blues_accounts(self, limit: int = 0) -> List[Dict[str, Any]]:
        query = "SELECT * FROM blue_verified_accounts ORDER BY RANDOM()" + (
            f" LIMIT ?" if limit else ""
        )
        params = (limit,) if limit else ()
        return await self.fetch(query, params)

    async def get_gold_accounts(self, limit: int = 0) -> List[Dict[str, Any]]:
        query = "SELECT * FROM gold_verified_accounts ORDER BY RANDOM()" + (
            f" LIMIT ?" if limit else ""
        )
        params = (limit,) if limit else ()
        return await self.fetch(query, params)

    async def get_grey_accounts(self, limit: int = 0) -> List[Dict[str, Any]]:
        query = "SELECT * FROM grey_verified_accounts ORDER BY RANDOM()" + (
            f" LIMIT ?" if limit else ""
        )
        params = (limit,) if limit else ()
        return await self.fetch(query, params)

    async def get_blueplus_accounts(self, limit: int = 0) -> List[Dict[str, Any]]:
        query = "SELECT * FROM blueplus_accounts ORDER BY RANDOM()" + (
            f" LIMIT ?" if limit else ""
        )
        params = (limit,) if limit else ()
        return await self.fetch(query, params)

    async def get_chars_accounts(self, limit: int = 0) -> List[Dict[str, Any]]:
        query = "SELECT * FROM chars_accounts ORDER BY RANDOM()" + (
            f" LIMIT ?" if limit else ""
        )
        params = (limit,) if limit else ()
        return await self.fetch(query, params)

    async def get_unverified_accounts(self, limit: int = 0) -> List[Dict[str, Any]]:
        """Get normal accounts that are unverified (verification status is 'uv')"""
        query = "SELECT * FROM normals WHERE verified = 'uv' ORDER BY RANDOM()" + (
            f" LIMIT ?" if limit else ""
        )
        params = (limit,) if limit else ()
        return await self.fetch(query, params)

    def get_account_type(self, input_type: str) -> Optional[str]:
        """Helper method to get standardized account type using direct dictionary lookup"""
        input_type = input_type.lower()
        return self.account_types.get(input_type)

    async def migrate_normal_to_mstats(self):
        """Migrate accounts from normals to mstats that meet the criteria:
        - Follower count between 100-999
        - Verification status in [fv, pv, ev, uv]
        """
        normals = await self.get_normal_accounts()
        mstat_accounts = [
            acc for acc in normals
            if acc.get("verified") in ["fv", "pv", "ev", "uv"]
            and acc.get("followers")
            and str(acc["followers"]).isdigit()
            and 100 <= int(acc["followers"]) <= 999
        ]
        
        migrated_count = 0
        for account in mstat_accounts:
            try:
                # Insert into mstats table
                await self.insert_mstats_account((
                    account["username"],
                    account["password"],
                    account.get("email", ""),
                    account.get("mailpwd", ""),
                    account.get("ct0", ""),
                    account.get("auth", ""),
                    account.get("followers", ""),
                    account.get("following", ""),
                    account.get("year", ""),
                    account.get("backup_code", ""),
                    account.get("verified", "")
                ))
                
                # Remove from normals table
                await self.execute(
                    "DELETE FROM normals WHERE username = ?",
                    (account["username"],)
                )
                
                migrated_count += 1
            except Exception as e:
                self.debug.log(f"Error migrating account {account['username']}: {e}")
                continue
            
        self.debug.log(f"Migrated {migrated_count} accounts from normals to mstats")
        return migrated_count

    async def update_stock(
        self, account_type: str, valid_accounts: List[Dict[str, Any]]
    ) -> None:
        if not valid_accounts:
            self.debug.log("No valid accounts to update.")
            return

        account_type = self.get_account_type(account_type)
        if not account_type:
            self.debug.log(
                f"Unknown account type: {account_type}, skipping stock update."
            )
            return

        usernames = tuple(acc["username"] for acc in valid_accounts)
        placeholders = ",".join(["?" for _ in usernames])

        table_mapping = {
            "follow": "follower_accounts",
            "blue": "blue_verified_accounts",
            "gold": "gold_verified_accounts",
            "grey": "grey_verified_accounts",
            "normal": "normals",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
        }

        table = table_mapping.get(account_type)
        if not table:
            self.debug.log(f"Unknown account type: {account_type}")
            return

        query = f"DELETE FROM {table} WHERE username NOT IN ({placeholders})"
        await self.execute(query, usernames)

    async def clear(self, account_type: str) -> None:
        account_type = self.get_account_type(account_type)
        table_mapping = {
            "follow": "follower_accounts",
            "blue": "blue_verified_accounts",
            "gold": "gold_verified_accounts",
            "grey": "grey_verified_accounts",
            "normal": "normals",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
        }

        table = table_mapping.get(account_type)
        if not table:
            self.debug.log(f"Unknown account type: {account_type}")
            return

        query = f"DELETE FROM {table}"
        await self.execute(query)

    async def remove_accounts(
        self,
        account_type: Optional[str] = None,
        usernames: Optional[List[str]] = None,
        auth_tokens: Optional[List[str]] = None,
    ) -> None:
        if not usernames and not auth_tokens:
            self.debug.log(
                "Either usernames or auth tokens must be provided to remove accounts."
            )
            return

        table_mapping = {
            "follow": "follower_accounts",
            "blue": "blue_verified_accounts",
            "gold": "gold_verified_accounts",
            "grey": "grey_verified_accounts",
            "normal": "normals",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
        }

        if account_type:
            account_type = self.get_account_type(account_type)
            table = table_mapping.get(account_type)
            if not table:
                self.debug.log(f"Unknown account type: {account_type}")
                return

            if usernames:
                self.debug.log(
                    f"Removing {len(usernames)} accounts from {account_type}"
                )
                query = f"DELETE FROM {table} WHERE username IN ({','.join(['?']*len(usernames))})"
                await self.execute(query, tuple(usernames))
            if auth_tokens:
                self.debug.log(
                    f"Removing {len(auth_tokens)} accounts by auth token from {account_type}"
                )
                query = f"DELETE FROM {table} WHERE auth IN ({','.join(['?']*len(auth_tokens))})"
                await self.execute(query, tuple(auth_tokens))
        else:
            self.debug.log("No account type specified, searching all tables")
            for table in table_mapping.values():
                if usernames:
                    query = f"DELETE FROM {table} WHERE username IN ({','.join(['?']*len(usernames))})"
                    await self.execute(query, tuple(usernames))
                if auth_tokens:
                    query = f"DELETE FROM {table} WHERE auth IN ({','.join(['?']*len(auth_tokens))})"
                    await self.execute(query, tuple(auth_tokens))

    async def remove_account(
        self,
        account_type: Optional[str] = None,
        username: Optional[str] = None,
        auth_token: Optional[str] = None,
    ) -> bool:
        """
        Efficiently remove an account from the specified table or all tables if no type specified.
        Args:
            account_type: Optional type of account to remove from
            username: Optional username to remove
            auth_token: Optional auth token to remove
        Returns:
            bool: True if at least one account was removed, False otherwise
        """
        if not username and not auth_token:
            self.debug.log(
                "Username or auth token must be provided to remove an account."
            )
            return False

        table_mapping = {
            "follow": "follower_accounts",
            "blue": "blue_verified_accounts",
            "gold": "gold_verified_accounts",
            "grey": "grey_verified_accounts",
            "normal": "normals",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
        }

        where_clauses = []
        params = []
        if username:
            where_clauses.append("username = ?")
            params.append(username)
        if auth_token:
            where_clauses.append("auth = ?")
            params.append(auth_token)
        if not where_clauses:
            self.debug.log("No valid identifier provided for account removal.")
            return False
        where_sql = " OR ".join(where_clauses)

        total_removed = 0

        try:
            tables_to_check = []
            if account_type:
                std_type = self.get_account_type(account_type)
                table = table_mapping.get(std_type)
                if not table:
                    self.debug.log(f"Unknown account type: {account_type}")
                    return False
                tables_to_check = [table]
            else:
                tables_to_check = list(table_mapping.values())

            for table in tables_to_check:
                query = f"DELETE FROM {table} WHERE {where_sql}"

                try:

                    success, rowcount = await self.execute(query, tuple(params))
                except Exception as e:
                    self.debug.log(f"Error executing delete on {table}: {e}")
                    continue
                if success and rowcount > 0:
                    self.debug.log(
                        f"Removed {rowcount} accounts from {table} with username={username}, auth_token={auth_token}",
                        send=False,
                    )
                    total_removed += rowcount

            if total_removed > 0:
                self.debug.log(f"Total accounts removed: {total_removed}", send=False)
                from src.products import ProductTypes

                ProductTypes.invalidate_stock_cache()
                return True
            else:
                self.debug.log(
                    f"No accounts removed with username={username}, auth_token={auth_token}",
                    send=False,
                )
                return False

        except Exception as e:
            self.debug.log(f"Error removing account: {e}")
            return False

    async def change_password(
        self, table: str, username: str, new_password: str, ct0: str, auth_token: str
    ) -> None:
        table = self.get_account_type(table)
        table_mapping = {
            "follow": "follower_accounts",
            "blue": "blue_verified_accounts",
            "gold": "gold_verified_accounts",
            "grey": "grey_verified_accounts",
            "normal": "normals",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
        }

        table_name = table_mapping.get(table)
        if not table_name:
            self.debug.log(f"Unknown table type: {table}")
            return

        query = f"UPDATE {table_name} SET password = ?, ct0 = ?, auth = ? WHERE username = ?"
        await self.execute(query, (new_password, ct0, auth_token, username))

    async def update_email(
        self,
        table: str,
        username: str,
        new_email: str,
        new_mailpwd: str,
        auth_token: str = None,
    ) -> None:
        """Update the email and mail password for an account in a specific table."""
        table_name = self.get_account_type(table)
        if not table_name:
            self.debug.log(f"Unknown table type for email update: {table}")
            return

        table_map = {
            "follow": "follower_accounts", 
            "blue": "blue_verified_accounts",
            "gold": "gold_verified_accounts",
            "grey": "grey_verified_accounts",
            "normal": "normals",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
        }

        actual_table_name = table_map.get(table_name)
        if not actual_table_name:
            self.debug.log(f"No valid table found for type: {table_name}")
            return

        query_parts = ["UPDATE", actual_table_name, "SET email = ?, mailpwd = ?"]
        params = [new_email, new_mailpwd]

        if auth_token:
            query_parts.append(", auth = ?")
            params.append(auth_token)

        # Use auth_token to identify account if username is empty/None
        if not username and auth_token:
            query_parts.append("WHERE auth = ?")
            params.append(auth_token)
        else:
            query_parts.append("WHERE username = ?")
            params.append(username)

        query = " ".join(query_parts)
        await self.execute(query, tuple(params))
        identifier = username if username else auth_token
        self.debug.log(
            f"Email updated for {identifier} in {actual_table_name}", send=False
        )

    async def update_2fa(
        self, table: str, username: str, backup_code: str, ct0: str
    ) -> None:
        """Update the backup_code and ct0 for an account in a specific table."""
        table_name = self.get_account_type(table)
        if not table_name:
            self.debug.log(f"Unknown table type for 2FA update: {table}")
            return

        table_map = {
            "follow": "follower_accounts",
            "blue": "blue_verified_accounts",
            "gold": "gold_verified_accounts",
            "grey": "grey_verified_accounts",
            "normal": "normals",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
        }

        actual_table_name = table_map.get(table_name)
        if not actual_table_name:
            self.debug.log(f"No valid table found for type: {table_name}")
            return

        query = f"UPDATE {actual_table_name} SET backup_code = ?, ct0 = ? WHERE username = ?"
        await self.execute(query, (backup_code, ct0, username))
        self.debug.log(
            f"2FA (backup_code, ct0) updated for {username} in {actual_table_name}",
            send=False,
        )

    async def add_customer(self, user_id: int, email: str, username: str = None) -> None:
        query = "INSERT OR REPLACE INTO customers (user_id, email, username) VALUES (?, ?, ?)"
        await self.execute(query, (user_id, email, username))

    async def get_customer_id(self, email: str) -> Optional[int]:
        query = "SELECT user_id FROM customers WHERE email = ?"
        result = await self.fetch_one(query, (email,))
        return result.get("user_id") if result else None

    async def get_customer_email(self, user_id: int) -> Optional[str]:
        query = "SELECT email FROM customers WHERE user_id = ?"
        result = await self.fetch_one(query, (user_id,))
        return result.get("email") if result else None

    async def get_customer_by_id(self, user_id: int) -> Optional[dict]:
        query = "SELECT * FROM customers WHERE user_id = ?"
        result = await self.fetch_one(query, (user_id,))
        return result if result else None

    async def get_all_customers(self) -> str:
        """Return a formatted string with all customers by their id with emojis for Telegram"""
        query = "SELECT * FROM customers"
        customers = await self.fetch(query)

        if not customers:
            return "📝 No customers have used the bot."

        separator = "〰️" * 8
        lines = [
            "📋 Customer List 📋",
            separator,
            *[f"👤 ID: {c['user_id']} | 📧 Email: {c['email']}" for c in customers],
        ]

        return "\n".join(lines)

    async def get_product_count(self, product_type: str) -> int:
        """Get count of available products by type"""
        table_mapping = {
            "follow": "follower_accounts",
            "blue": "blue_verified_accounts",
            "gold": "gold_verified_accounts",
            "grey": "grey_verified_accounts",
            "normal": "normals",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
        }

        table = table_mapping.get(product_type)
        if not table:
            return 0

        query = f"SELECT COUNT(*) as count FROM {table}"
        result = await self.fetch_one(query)
        return result.get("count", 0)

    async def get_follower_accounts_count(self) -> int:
        query = "SELECT COUNT(*) as count FROM follower_accounts"
        result = await self.fetch_one(query)
        return result.get("count", 0)

    async def get_normal_accounts_count(self) -> int:
        query = "SELECT COUNT(*) as count FROM normals"
        result = await self.fetch_one(query)
        return result.get("count", 0)

    async def get_gold_accounts_count(self) -> int:
        query = "SELECT COUNT(*) as count FROM gold_verified_accounts"
        result = await self.fetch_one(query)
        return result.get("count", 0)

    async def get_blue_accounts_count(self) -> int:
        query = "SELECT COUNT(*) as count FROM blue_verified_accounts"
        result = await self.fetch_one(query)
        return result.get("count", 0)

    async def get_grey_accounts_count(self) -> int:
        query = "SELECT COUNT(*) as count FROM grey_verified_accounts"
        result = await self.fetch_one(query)
        return result.get("count", 0)

    async def get_blueplus_accounts_count(self) -> int:
        query = "SELECT COUNT(*) as count FROM blueplus_accounts"
        result = await self.fetch_one(query)
        return result.get("count", 0)

    async def get_chars_accounts_count(self) -> int:
        query = "SELECT COUNT(*) as count FROM chars_accounts"
        result = await self.fetch_one(query)
        return result.get("count", 0) if result else 0

    async def get_mstats_accounts_count(self) -> int:
        query = "SELECT COUNT(*) as count FROM mstats_accounts"
        result = await self.fetch_one(query)
        return result.get("count", 0) if result else 0

    async def check_product_availability(
        self, product_type: str, quantity: int
    ) -> tuple[bool, int]:
        """Atomic stock check considering reservations"""
        async with self.conn.execute("BEGIN IMMEDIATE"):
            available = await self.get_product_count(product_type)
            reserved = await self.fetch_one(
                "SELECT SUM(quantity) as total FROM stock_reservations WHERE product_type = ?",
                (product_type,),
            )
            reserved_qty = reserved["total"] or 0
            net_available = available - reserved_qty
            return net_available >= quantity, net_available

    async def update_customer_email(self, user_id: int, new_email: str) -> None:
        query = "UPDATE customers SET email = ? WHERE user_id = ?"
        await self.execute(query, (new_email, user_id))

    async def get_products_availability(self) -> Dict[str, int]:
        """Get availability of all products,
        Returns a dictionary with the product type as the key and the availability as the value
        """
        product_types = [
            "follow",
            "blue",
            "gold",
            "grey",
            "normal",
            "blueplus",
            "chars",
            "mstats",
            ]
        return {
            product_type: await self.get_product_count(product_type)
            for product_type in product_types
        }

    async def add_queue_item(
        self, order_uniqid: str, user_id: int, message_id: int, chat_id: int
    ):
        await self.execute(
            """
            INSERT INTO queue_items (order_uniqid, user_id, message_id, chat_id)
            VALUES (?, ?, ?, ?)
        """,
            (order_uniqid, user_id, message_id, chat_id),
        )
        await self.conn.commit()

    async def remove_queue_item(self, order_uniqid: str):
        await self.execute(
            "DELETE FROM queue_items WHERE order_uniqid = ?", (order_uniqid,)
        )
        await self.conn.commit()

    async def get_pending_queue_items(self):
        cursor = await self.conn.execute("SELECT * FROM queue_items")
        return await cursor.fetchall()

    async def add_coupon(
        self,
        code: str,
        discount: float,
        max_uses: Optional[int] = None,
        expiry_days: Optional[int] = None,
    ) -> bool:
        """Add a new coupon to the database"""
        if max_uses == 0:
            max_uses = None
        try:
            expiry = (
                f"datetime('now', '+{expiry_days} days')"
                if expiry_days and expiry_days > 0
                else "NULL"
            )
            await self.execute(
                f"INSERT INTO coupons (code, discount, max_uses, expiry_date) VALUES (?, ?, ?, {expiry})",
                (code, discount, max_uses),
            )
            return True
        except Exception as e:
            self.debug.log(f"Error adding coupon: {e}")
            return False

    async def use_coupon(self, code: str) -> Optional[float]:
        """Use a coupon and return its discount percentage"""
        try:
            coupon = await self.fetch_one(
                """SELECT discount, max_uses, uses, expiry_date 
                   FROM coupons 
                   WHERE code = ? AND (expiry_date IS NULL OR expiry_date > datetime('now'))""",
                (code,),
            )

            if not coupon:
                return None

            if coupon["max_uses"] and coupon["uses"] >= coupon["max_uses"]:
                return None

            await self.execute(
                "UPDATE coupons SET uses = uses + 1 WHERE code = ?", (code,)
            )

            return coupon["discount"]
        except Exception as e:
            self.debug.log(f"Error using coupon: {e}")
            return None

    async def delete_coupon(self, code: str) -> bool:
        """Delete a coupon from the database"""
        result = await self.execute("DELETE FROM coupons WHERE code = ?", (code,))
        return bool(result)

    async def get_coupon_info(self, code: str) -> Optional[dict]:
        """Get information about a specific coupon"""
        return await self.fetch_one("SELECT * FROM coupons WHERE code = ?", (code,))

    async def list_coupons(self) -> List[dict]:
        """Get all active coupons with days remaining"""
        coupons = await self.fetch(
            """
            SELECT *, 
                CASE 
                    WHEN expiry_date IS NOT NULL 
                    THEN CAST(ROUND(JULIANDAY(expiry_date) - JULIANDAY('now')) AS INTEGER)
                END as days_remaining
            FROM coupons 
            ORDER BY created_at DESC
        """
        )
        return coupons

    async def get_coupon_discount(self, code: str) -> Optional[float]:
        """Get discount percentage without marking as used"""
        coupon = await self.fetch_one(
            """SELECT discount FROM coupons 
               WHERE code = ? AND (expiry_date IS NULL OR expiry_date > datetime('now'))""",
            (code,),
        )
        return coupon.get("discount") if coupon else None

    async def add_bot_product(
        self,
        product_id: str,
        product_type: str,
        range_str: Optional[str],
        verifications: List[str],
        mail_access: bool = False,
        price: float = 0.0,
        fresh: bool = False,
    ) -> bool:
        """Add a new product to the bot_products table"""
        try:

            if fresh and "fresh" not in verifications:
                verifications = verifications.copy()
                verifications.append("fresh")

            verification_str = ",".join(verifications) if verifications else "0"
            mail_access_int = 1 if mail_access else 0
            type_str = f"{product_type}:{verification_str}:{mail_access_int}"

            range_value = range_str if range_str else None

            existing = await self.fetch_one(
                "SELECT 1 FROM bot_products WHERE id = ?", (product_id,)
            )
            if existing:
                await self.execute(
                    """
                    UPDATE bot_products 
                    SET type = ?, range = ?, price = ?
                    WHERE id = ?
                    """,
                    (type_str, range_value, price, product_id),
                )
            else:

                await self.execute(
                    """
                    INSERT INTO bot_products 
                    (id, type, range, price) 
                    VALUES (?, ?, ?, ?)
                    """,
                    (product_id, type_str, range_value, price),
                )
            return True
        except Exception as e:
            print(
                f"Database error adding product: {str(e)} | Product ID: {product_id}, Type: {product_type}"
            )
            return False

    async def get_bot_product(self, product_id: str) -> Optional[dict]:
        """
        Get bot product with properly parsed attributes
        Returns dict with:
        {
            'id': str,
            'type': str,
            'range': Optional[Tuple[int, int]],
            'fully_verified': bool,
            'unverified': bool,
            'mixed': bool,
            'fresh': bool,
            'mail_access': bool,
            'price': float
        }
        """
        try:
            product = await self.fetch_one(
                "SELECT * FROM bot_products WHERE id = ?", (product_id,)
            )
            if not product:
                return None

            type_parts = product["type"].split(":")
            base_type = type_parts[0]

            verifications = (
                type_parts[1].split(",")
                if len(type_parts) > 1 and type_parts[1]
                else []
            )
            fully_verified = "fv" in verifications
            unverified = "uv" in verifications
            mixed = "mixed" in verifications
            fresh = "fresh" in verifications

            mail_access = bool(int(type_parts[2])) if len(type_parts) > 2 else False

            range_tuple = None
            if product["range"] and "-" in str(product["range"]):
                try:
                    start, end = map(int, str(product["range"]).split("-"))
                    range_tuple = (start, end)
                except (ValueError, TypeError):
                    range_tuple = None

            return {
                "id": product["id"],
                "type": base_type,
                "range": range_tuple,
                "fully_verified": fully_verified,
                "unverified": unverified,
                "mixed": mixed,
                "fresh": fresh,
                "mail_access": mail_access,
                "price": float(product.get("price", 0)),
            }

        except Exception as e:
            self.debug.log(f"Error getting bot product: {e}")
            return None

    async def list_bot_products(self) -> List[dict]:
        """List all bot products with properly parsed attributes"""
        try:

            table_exists = await self.fetch_one(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='bot_products'"
            )

            if not table_exists:
                print("Warning: bot_products table does not exist")
                return []

            products = await self.fetch("SELECT * FROM bot_products ORDER BY id")
            if not products:
                print("No products found in database")
                return []

            parsed_products = []

            for product in products:
                try:

                    if "type" not in product or not product["type"]:
                        print(
                            f"Warning: Product {product.get('id')} missing type field"
                        )
                        continue

                    type_parts = product["type"].split(":")
                    base_type = type_parts[0].lower()

                    if base_type == "normals":
                        base_type = "normal"

                    verifications = []
                    if len(type_parts) > 1 and type_parts[1]:
                        verifications = type_parts[1].split(",")

                    fully_verified = "fv" in verifications
                    unverified = "uv" in verifications
                    mixed = "mixed" in verifications or (not verifications)
                    fresh = "fresh" in verifications
                    mail_access = (
                        bool(int(type_parts[2])) if len(type_parts) > 2 else False
                    )

                    range_tuple = None
                    if "range" in product and product["range"]:
                        try:
                            if (
                                isinstance(product["range"], str)
                                and "-" in product["range"]
                            ):
                                start, end = map(int, product["range"].split("-"))
                                range_tuple = (start, end)
                            elif (
                                isinstance(product["range"], (list, tuple))
                                and len(product["range"]) == 2
                            ):
                                range_tuple = tuple(map(int, product["range"]))
                        except (ValueError, TypeError, IndexError) as e:
                            print(
                                f"Error parsing range for product {product.get('id')}: {e}"
                            )

                    price = 0.0
                    if "price" in product and product["price"] is not None:
                        try:
                            price = float(product["price"])
                        except (ValueError, TypeError) as e:
                            print(
                                f"Error parsing price for product {product.get('id')}: {e}"
                            )

                    parsed_products.append(
                        {
                            "id": product.get("id", ""),
                            "type": f"{base_type}:{','.join(verifications)}:{int(mail_access)}",
                            "range": product.get("range"),
                            "price": price,
                            "fully_verified": fully_verified,
                            "unverified": unverified,
                            "mixed": mixed,
                            "fresh": fresh,
                            "mail_access": mail_access,
                        }
                    )
                except Exception as e:
                    print(
                        f"Error processing product {product.get('id', 'unknown')}: {e}"
                    )

                    parsed_products.append(product)

            return parsed_products

        except Exception as e:
            print(f"Error listing bot products: {e}")

            return []

    async def delete_bot_product(self, product_id: str) -> bool:
        try:
            await self.execute("DELETE FROM bot_products WHERE id = ?", (product_id,))
            return True
        except Exception as e:
            self.debug.log(f"Error deleting bot product: {e}")
            return False

    async def update_product_price(self, product_id: str, new_price: float) -> bool:
        """Update the price of a product"""
        try:
            await self.execute(
                "UPDATE bot_products SET price = ? WHERE id = ?",
                (new_price, product_id),
            )
            return True
        except Exception as e:
            self.debug.log(f"Error updating product price: {e}")
            return False

    async def update_product_category(self, product_id: str, new_category: str) -> bool:
        """Update the category (type) of a product"""
        if new_category not in ["fresh_accounts", "cracked_accounts"]:
            self.debug.log(f"Invalid category: {new_category}")
            return False

        try:
            await self.execute(
                "UPDATE bot_products SET type = ? WHERE id = ?",
                (new_category, product_id),
            )
            return True
        except Exception as e:
            self.debug.log(f"Error updating product category: {e}")
            return False

    async def update_product_range(
        self, product_id: str, new_range: Optional[str]
    ) -> bool:
        """Update the follower range of a product"""
        try:
            await self.execute(
                "UPDATE bot_products SET range = ? WHERE id = ?",
                (new_range, product_id),
            )
            return True
        except Exception as e:
            self.debug.log(f"Error updating product range: {e}")
            return False

    async def toggle_product_mail_access(self, product_id: str) -> bool:
        """Toggle the mail access flag for a product"""
        try:
            cursor = await self.execute(
                "SELECT mail_access FROM bot_products WHERE id = ?", (product_id,)
            )
            row = await cursor.fetchone()

            if not row:
                return False

            current_value = bool(row[0])
            new_value = not current_value

            await self.execute(
                "UPDATE bot_products SET mail_access = ? WHERE id = ?",
                (int(new_value), product_id),
            )
            return True
        except Exception as e:
            self.debug.log(f"Error toggling product mail access: {e}")
            return False

    async def bulk_update_product_prices(
        self, category: str, price_multiplier: float
    ) -> tuple[int, int]:
        """Update prices for all products in a category by a multiplier"""
        try:

            if category.lower() == "all":
                cursor = await self.execute(
                    "UPDATE bot_products SET price = price * ? WHERE price > 0",
                    (price_multiplier,),
                )
            else:
                cursor = await self.execute(
                    "UPDATE bot_products SET price = price * ? WHERE type = ? AND price > 0",
                    (price_multiplier, category),
                )

            return (cursor.rowcount, 0)
        except Exception as e:
            self.debug.log(f"Error bulk updating product prices: {e}")
            return (0, 0)

    async def migrate_chars_accounts(self) -> tuple[int, int]:
        """
        Migrate accounts with usernames <= 4 characters from normals to chars table.
        Returns tuple of (migrated_count, failed_count)
        """
        migrated = 0
        failed = 0

        try:

            char_accounts = await self.fetch(
                "SELECT * FROM normals WHERE length(username) <= 4"
            )

            if not char_accounts:
                self.debug.log("No char accounts found to migrate")
                return (0, 0)

            for account in char_accounts:
                try:

                    await self.insert_chars_account(
                        (
                            account["username"],
                            account["password"],
                            account["email"],
                            account["mailpwd"],
                            account["ct0"],
                            account["auth"],
                            account["followers"],
                            account["following"],
                            account["year"],
                            account["backup_code"],
                            account["verified"],
                        )
                    )

                    await self.execute(
                        "DELETE FROM normals WHERE username = ?", (account["username"],)
                    )

                    migrated += 1

                except Exception as e:
                    self.debug.log(
                        f"Failed to migrate account {account['username']}: {e}"
                    )
                    failed += 1

            self.debug.log(f"Migrated {migrated} char accounts, {failed} failed")
            return (migrated, failed)

        except Exception as e:
            self.debug.log(f"Error during char accounts migration: {e}")
            return (migrated, failed)

    async def fix_migration(self) -> None:
        """Fix migration issues by moving accounts back to normals"""
        try:
            char_accounts = await self.fetch("SELECT * FROM chars_accounts")

            if not char_accounts:
                self.debug.log("No char accounts found to fix")
                return

            for account in char_accounts:
                try:

                    await self.insert_normal_account(
                        (
                            account["username"],
                            account["password"],
                            account["email"],
                            account["mailpwd"],
                            account["ct0"],
                            account["auth"],
                            account["followers"],
                            account["following"],
                            account["year"],
                            account["backup_code"],
                            account["verified"],
                        )
                    )

                    await self.execute(
                        "DELETE FROM chars_accounts WHERE username = ?",
                        (account["username"],),
                    )

                except Exception as e:
                    self.debug.log(f"Failed to fix account {account['username']}: {e}")

            self.debug.log("Fixed char accounts migration")

        except Exception as e:
            self.debug.log(f"Error fixing char accounts migration: {e}")

    async def create_order(
        self,
        user_id: int,
        product_id: str,
        quantity: int,
        total_amount: float,
        uuid: str = "",
        payment_currency: str = "",
    ) -> Optional[dict]:
        """Create a new order with payment details"""
        try:
            existing_order = await self.fetch_one(
                "SELECT order_id FROM orders WHERE order_id = ?", (uuid,)
            )

            if existing_order:
                self.debug.log(
                    f"Order with UUID {uuid} already exists, updating with new information"
                )
                await self.execute(
                    """UPDATE orders 
                       SET user_id = ?, product_id = ?, quantity = ?, 
                           total_amount = ?, payment_currency = ?
                       WHERE order_id = ?""",
                    (
                        user_id,
                        product_id,
                        quantity,
                        total_amount,
                        payment_currency,
                        uuid,
                    ),
                )
                return await self.get_order_by_uuid(uuid)

            await self.execute(
                """INSERT INTO orders 
                   (order_id, user_id, product_id, quantity, total_amount, payment_currency, status)
                   VALUES (?, ?, ?, ?, ?, ?, 'pending')""",
                (uuid, user_id, product_id, quantity, total_amount, payment_currency),
            )

            return await self.get_order_by_uuid(uuid)

        except Exception as e:
            self.debug.log(f"Error creating order: {e}")
            return None

    async def complete_order_by_uuid(self, uuid: str, txid: str) -> bool:
        """Complete order using UUID"""
        try:
            await self.execute(
                """UPDATE orders 
                   SET status = 'completed',
                       payment_txid = ?,
                       completed_at = CURRENT_TIMESTAMP 
                   WHERE order_id = ?""",
                (txid, uuid),
            )
            return True
        except Exception as e:
            self.debug.log(f"Error completing order by UUID: {e}")
            return False

    async def update_order_status(self, uuid: str, status: str) -> bool:
        """Update order status using UUID"""
        try:
            await self.execute(
                "UPDATE orders SET status = ? WHERE order_id = ?", (status, uuid)
            )
            return True
        except Exception as e:
            self.debug.log(f"Error updating order status: {e}")
            return False

    async def remove_account_from_conflicting_tables(
        self,
        username: str,
        target_table: str,
        insert: bool = False,
        capture: tuple = None,
    ) -> None:
        """
        Delete the given username from all account tables except the target_table.
        This makes it so that a single account lives in only one table.
        """
        tables = {
            "normals",
            "follower_accounts",
            "blue_verified_accounts",
            "grey_verified_accounts",
            "gold_verified_accounts",
            "blueplus_accounts",
            "chars_accounts",
        }
        tables.discard(target_table)
        for table in tables:
            success, rows = await self.execute(
                f"DELETE FROM {table} WHERE username = ?", (username,)
            )
            if success and rows > 0:
                self.debug.log(
                    f"Removed {username} from {table} during table consolidation",
                    send=False,
                )
        if insert:
            await self.insert_account(target_table, capture)

    async def transition_account(
        self, old_table: str, new_table: str, username: str, capture: tuple
    ) -> None:
        """
        Transition an account from one table to another.

        Args:
            old_table: Current table of the account
            new_table: Target table to move the account to
            username: Account username
            capture: Account data tuple
        """
        try:
            await self.execute(
                f"DELETE FROM {old_table} WHERE username = ?", (username,)
            )
            insert_methods = {
                "normals": self.insert_normal_account,
                "follower_accounts": self.insert_follower_account,
                "blue_verified_accounts": self.insert_blue_verified_account,
                "grey_verified_accounts": self.insert_grey_verified_account,
                "gold_verified_accounts": self.insert_gold_verified_account,
                "blueplus_accounts": self.insert_blueplus_account,
                "chars_accounts": self.insert_chars_account,
                "mstats_accounts": self.insert_mstats_account,
            }


            insert_method = insert_methods.get(new_table)
            if insert_method:
                await insert_method(capture)

            self.debug.log(
                f"Transitioned account {username} from {old_table} to {new_table}"
            )

        except Exception as e:
            self.debug.log(f"Error transitioning account {username}: {e}")

    async def get_account_current_table(self, username: str) -> Optional[str]:
        """
        Find which table currently contains the given username.
        Returns the table name or None if not found.
        """
        tables = [
            "grey_verified_accounts",
            "gold_verified_accounts",
            "blueplus_accounts",
            "blue_verified_accounts",
            "follower_accounts",
            "chars_accounts",
            "normals",
            "mstats_accounts",
        ]

        for table in tables:
            result = await self.fetch_one(
                f"SELECT 1 FROM {table} WHERE username = ?", (username,)
            )
            if result:
                return table
        return None

    async def cache_product_title(self, product_id: str, title: str) -> None:
        """Cache the title for a product"""
        try:

            await self.execute(
                """
                INSERT OR REPLACE INTO product_titles 
                (product_id, title) 
                VALUES (?, ?)
                """,
                (product_id, title),
            )
            print(f"Cached title for product {product_id}: {title}")
        except Exception as e:
            print(f"Database error caching title: {str(e)}")

    async def get_product_title(self, product_id: str) -> Optional[str]:
        """Get a cached product title"""
        try:

            result = await self.fetch_one(
                "SELECT title FROM product_titles WHERE product_id = ?",
                (str(product_id),),
            )

            if result:
                return result["title"]

            self.debug.log(f"no cached title found for {product_id}", send=False)
            return None
        except Exception as e:
            self.debug.log(f"Error getting cached product title: {e}", send=False)
            return None

    async def get_order_by_uuid(self, uuid: str) -> Optional[dict]:
        """Get order by uuid"""
        query = """
            SELECT o.*, pt.title as product_title
            FROM orders o
            LEFT JOIN product_titles pt ON o.product_id = pt.product_id
            WHERE o.order_id = ? AND o.status = 'pending'
        """
        return await self.fetch_one(query, (uuid,))

    async def get_user_orders(self, user_id: int) -> List[Dict[str, Any]]:
        """Get all orders for a specific user from local database"""
        query = """
            SELECT o.*, pt.title as product_title
            FROM orders o
            LEFT JOIN product_titles pt ON o.product_id = pt.product_id
            WHERE o.user_id = ?
            ORDER BY o.created_at DESC
        """
        try:
            return await self.fetch(query, (user_id,))
        except Exception as e:
            self.debug.log(f"Error getting user orders: {e}")
            return []

    async def mark_order_delivered(
        self, order_id: str, payment_info: dict = None
    ) -> bool:
        """Mark an order as delivered by updating its status and payment details in the orders table"""
        try:

            order = await self.fetch_one(
                "SELECT status FROM orders WHERE order_id = ?", (order_id,)
            )

            if not order:
                self.debug.log(f"Order {order_id} not found", send=False)
                return False

            if order.get("status") == "completed":
                self.debug.log(
                    f"Order {order_id} already marked as completed", send=False
                )
                return True

            query_parts = [
                "UPDATE orders SET status = 'completed', completed_at = CURRENT_TIMESTAMP"
            ]
            params = []

            if payment_info:
                if payment_info.get("amount"):
                    query_parts.append("payment_amount = ?")
                    params.append(payment_info["amount"])

                if payment_info.get("txid"):
                    query_parts.append("payment_txid = ?")
                    params.append(payment_info["txid"])

                if payment_info.get("currency"):
                    query_parts.append("payment_currency = ?")
                    params.append(payment_info["currency"])

            query = ", ".join(query_parts) + " WHERE order_id = ?"
            params.append(order_id)

            await self.execute(query, tuple(params))
            return True
        except Exception as e:
            self.debug.log(f"Error marking order as delivered: {e}")
            return False

    async def is_order_delivered(self, order_id: str) -> bool:
        """Check if an order has already been delivered"""
        try:
            result = await self.fetch_one(
                "SELECT status FROM orders WHERE order_id = ? AND status = 'completed'",
                (order_id,),
            )
            return bool(result)
        except Exception as e:
            self.debug.log(f"Error checking delivered order: {e}")
            return False

    def migrate_add_order_id(self, conn):
        """Add order_id column to orders table safely"""
        cursor = conn.cursor()

        cursor.execute(
            """
            alter table orders 
            add column order_id text;
        """
        )

        cursor.execute(
            """
            update orders 
            set order_id = 'ORD-' || printf('%010d', rowid) 
            where order_id is null;
        """
        )

        cursor.execute(
            """
            create unique index idx_orders_order_id on orders(order_id);
        """
        )

        cursor.execute(
            """
            create table orders_new as 
            select * from orders;
            
            drop table orders;
            
            create table orders as 
            select * from orders_new;
            
            drop table orders_new;
        """
        )

        conn.commit()

    async def clear_bot_products(self) -> bool:
        """Clear all products from the bot_products table"""
        try:

            await self.execute("DELETE FROM product_titles")
            self.debug.log("Cleared product_titles table")

            await self.execute("DELETE FROM bot_products")
            self.debug.log("Cleared bot_products table")
            return True
        except Exception as e:
            self.debug.log(f"Error clearing product tables: {e}")
            return False

    async def add_locked_token(self, account, source: str = "unknown") -> None:
        """Add a locked token to the database

        Args:
            account: Tuple or dictionary containing account information
            source: Source of the locked token
        """
        try:

            if isinstance(account, dict):

                username = account.get("username", "")
                password = account.get("password", "")
                email = account.get("email", "")
                mailpwd = account.get("mailpwd", "")
                ct0 = account.get("ct0", "")
                auth_token = account.get("auth", "")
                followers = account.get("followers", "")
                following = account.get("following", "")
                year = account.get("year", "")
                backup_code = account.get("backup_code", "")
                verified = account.get("verified", "uv")
            else:

                username = account[0] if len(account) > 0 else ""
                password = account[1] if len(account) > 1 else ""
                email = account[2] if len(account) > 2 else ""
                mailpwd = account[3] if len(account) > 3 else ""
                ct0 = account[4] if len(account) > 4 else ""
                auth_token = account[5] if len(account) > 5 else ""
                followers = account[6] if len(account) > 6 else ""
                following = account[7] if len(account) > 7 else ""
                year = account[8] if len(account) > 8 else ""
                backup_code = account[9] if len(account) > 9 else ""
                verified = (
                    account[10] if len(account) > 10 and account[10] != "" else "uv"
                )

            existing_token = None
            if auth_token:
                existing_token = await self.fetch_one(
                    "SELECT * FROM locked_tokens WHERE auth_token = ?", (auth_token,)
                )
            elif username:
                existing_token = await self.fetch_one(
                    "SELECT * FROM locked_tokens WHERE username = ?", (username,)
                )

            if existing_token:

                fields_to_update = []
                values_to_update = []

                field_mapping = {
                    "password": password,
                    "email": email,
                    "mailpwd": mailpwd,
                    "ct0": ct0,
                    "auth_token": auth_token,
                    "followers": followers,
                    "following": following,
                    "year": year,
                    "backup_code": backup_code,
                    "verified": verified,
                    "source": source,
                }

                for field, new_value in field_mapping.items():
                    if new_value and str(existing_token.get(field, "")) != str(
                        new_value
                    ):
                        fields_to_update.append(f"{field} = ?")
                        values_to_update.append(new_value)

                if fields_to_update:

                    if auth_token:
                        update_query = f"UPDATE locked_tokens SET {', '.join(fields_to_update)}, locked_at = CURRENT_TIMESTAMP WHERE auth_token = ?"
                        values_to_update.append(auth_token)
                    else:
                        update_query = f"UPDATE locked_tokens SET {', '.join(fields_to_update)}, locked_at = CURRENT_TIMESTAMP WHERE username = ?"
                        values_to_update.append(username)

                    await self.execute(update_query, tuple(values_to_update))
                    self.debug.log(
                        f"Updated locked token for {username or auth_token} from {source}",
                        send=False,
                    )
                else:
                    self.debug.log(
                        f"Locked token for {username or auth_token} already exists with no changes",
                        send=False,
                    )
            else:

                query = """
                INSERT INTO locked_tokens 
                (username, password, email, mailpwd, auth_token, ct0, followers, following, year, backup_code, verified, source)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """

                await self.execute(
                    query,
                    (
                        username,
                        password,
                        email,
                        mailpwd,
                        auth_token,
                        ct0,
                        followers,
                        following,
                        year,
                        backup_code,
                        verified,
                        source,
                    ),
                )
                self.debug.log(
                    f"Added new locked token for {username or auth_token} from {source}",
                    send=False,
                )
        except Exception as e:
            self.debug.log(f"Error adding locked token: {e}")

    async def get_locked_tokens(
        self, limit: int = 0, remove_after_fetch: bool = True
    ) -> List[Dict[str, Any]]:
        """Get locked tokens from the database

        Args:
            limit: Maximum number of tokens to return (0 for all)
            remove_after_fetch: Whether to remove tokens after fetching

        Returns:
            List of locked token dictionaries
        """
        query = "SELECT * FROM locked_tokens ORDER BY locked_at DESC"
        if limit > 0:
            query += f" LIMIT {limit}"

        tokens = await self.fetch(query)

        if tokens and remove_after_fetch:

            async with self.conn.execute("BEGIN IMMEDIATE"):
                try:

                    ids = [token["id"] for token in tokens]
                    placeholders = ",".join(["?"] * len(ids))

                    delete_query = (
                        f"DELETE FROM locked_tokens WHERE id IN ({placeholders})"
                    )
                    await self.execute(delete_query, tuple(ids))

                    self.debug.log(
                        f"Removed {len(tokens)} locked tokens after fetching"
                    )
                    await self.conn.commit()
                except Exception as e:
                    await self.conn.rollback()
                    self.debug.log(f"Error removing locked tokens: {e}")

        return tokens

    async def remove_locked_token(self, auth_token: str) -> None:
        """Remove a locked token from the database

        Args:
            auth_token: Auth token to remove
        """
        query = "DELETE FROM locked_tokens WHERE auth_token = ?"
        await self.execute(query, (auth_token,))

    async def migrate_locked_tokens_column(self) -> bool:
        """
        Migrate locked_tokens table to rename email_password column to mailpwd
        Returns True if migration was successful, False otherwise
        """
        try:

            columns_info = await self.fetch("PRAGMA table_info(locked_tokens)")
            column_names = [col["name"] for col in columns_info]

            if "mailpwd" in column_names and "email_password" not in column_names:
                self.debug.log("No migration needed for locked_tokens table")
                return True

            if "email_password" not in column_names:
                self.debug.log(
                    "Cannot migrate locked_tokens: email_password column not found"
                )
                return False

            await self.execute(
                """
                CREATE TABLE locked_tokens_new (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT,
                    password TEXT,
                    email TEXT,
                    mailpwd TEXT,
                    auth_token TEXT,
                    ct0 TEXT,
                    followers INTEGER,
                    following INTEGER,
                    year INTEGER,
                    backup_code TEXT,
                    verified TEXT,
                    source TEXT,
                    locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            await self.execute(
                """
                INSERT INTO locked_tokens_new 
                (id, username, password, email, mailpwd, auth_token, ct0, followers, following, year, backup_code, verified, source, locked_at)
                SELECT 
                    id, username, password, email, email_password, auth_token, ct0, followers, following, year, backup_code, verified, source, locked_at
                FROM locked_tokens
            """
            )

            await self.execute("DROP TABLE locked_tokens")

            await self.execute("ALTER TABLE locked_tokens_new RENAME TO locked_tokens")

            await self.execute(
                "CREATE INDEX IF NOT EXISTS idx_locked_username ON locked_tokens (username)"
            )
            await self.execute(
                "CREATE INDEX IF NOT EXISTS idx_locked_auth ON locked_tokens (auth_token)"
            )

            self.debug.log(
                "Successfully migrated locked_tokens table: renamed email_password to mailpwd"
            )
            return True

        except Exception as e:
            self.debug.log(f"Error migrating locked_tokens table: {e}")
            return False

    async def get_accounts_by_product_attributes(
        self,
        product_attrs: Any,
        limit: int = 0,
        auth_tokens_to_exclude: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Fetch accounts directly from database based on product attributes.
        This is more efficient than fetching all accounts and filtering them after.
        Args:
            product_attrs: ProductAttributes object with criteria to match
            limit: Maximum number of accounts to return
            auth_tokens_to_exclude: Optional list of auth tokens to exclude from the results.
        """
        product_type = product_attrs.product_type.lower()
        table_map = {
            "normal": "normals",
            "blue": "blue_verified_accounts",
            "grey": "grey_verified_accounts",
            "gold": "gold_verified_accounts",
            "follower": "follower_accounts",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
            "unverified": "normals",
        }

        table = table_map.get(product_type)
        if not table:
            return []

        query_parts = ["SELECT * FROM " + table + " WHERE 1=1"]
        params = []

        if product_attrs.range:
            query_parts.append(
                "AND CAST(followers AS INTEGER) >= ? AND CAST(followers AS INTEGER) <= ?"
            )
            params.extend([product_attrs.range[0], product_attrs.range[1]])

        if product_type == "normal":
            verifications = []
            if product_attrs.fully_verified:
                verifications.append("'fv'")
            if product_attrs.unverified:
                verifications.append("'uv'")
            if product_attrs.mixed:
                verifications.extend(["'ev'", "'uv'"])

            if verifications:
                query_parts.append(f"AND verified IN ({','.join(verifications)})")

        if product_type == "unverified":
            query_parts.append("AND verified = 'uv'")

        if product_attrs.mail_access:
            query_parts.append("AND mailpwd IS NOT NULL AND mailpwd != ''")

        if hasattr(product_attrs, "fresh") and product_attrs.fresh:
            query_parts.append("AND year = '2025'")

        query_parts.append("AND (backup_code IS NOT NULL AND backup_code != '' AND backup_code != '0' AND backup_code != 'None' AND LENGTH(backup_code) >= 8)")
        query_parts.append("AND auth IS NOT NULL AND auth != '' AND auth != 'None'")

        if auth_tokens_to_exclude:
            if isinstance(auth_tokens_to_exclude, set):
                auth_tokens_to_exclude = list(auth_tokens_to_exclude)
            if auth_tokens_to_exclude:
                placeholders = ",".join(["?" for _ in auth_tokens_to_exclude])
                query_parts.append(f"AND auth NOT IN ({placeholders})")
                params.extend(auth_tokens_to_exclude)

        if limit > 0:
            query_parts.append(f"LIMIT ?")
            params.append(limit)

        query = " ".join(query_parts)
        return await self.fetch(query, tuple(params))

    async def get_accounts_by_product_id(
        self, product_id: str, limit: int = 0
    ) -> List[Dict[str, Any]]:
        """
        Fetch accounts directly from database based on product ID.
        This function first retrieves the product attributes, then uses them to query the accounts.
        """
        from src.products import ProductTypes

        product_attrs = await ProductTypes.get_product_attributes(product_id)
        if not product_attrs:
            return []

        return await self.get_accounts_by_product_attributes(product_attrs, limit)

    async def get_stock_count_by_product_id(self, product_id: str) -> int:
        """
        Get the count of available accounts that match a specific product's criteria
        without fetching all the accounts.

        Args:
            product_id: The product ID to check stock for

        Returns:
            int: Number of accounts matching the product's criteria
        """
        from src.products import ProductTypes

        product_attrs = await ProductTypes.get_product_attributes(product_id)
        if not product_attrs:
            return 0

        return await self.get_stock_count_by_product_attributes(product_attrs)

    async def get_stock_count_by_product_attributes(
        self, product_attrs: Any, auth_tokens_to_exclude: Optional[List[str]] = None
    ) -> int:
        """
        Get the count of available accounts that match specific product attributes
        without fetching all the accounts.

        Args:
            product_attrs: ProductAttributes object with criteria to match
            auth_tokens_to_exclude: Optional list of auth tokens to exclude from the count.

        Returns:
            int: Number of accounts matching the criteria
        """
        product_type = product_attrs.product_type.lower()
        table_map = {
            "normal": "normals",
            "blue": "blue_verified_accounts",
            "grey": "grey_verified_accounts",
            "gold": "gold_verified_accounts",
            "follower": "follower_accounts",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
            "unverified": "normals",
        }

        table = table_map.get(product_type)
        if not table:
            return 0

        query_parts = ["SELECT COUNT(*) as count FROM " + table + " WHERE 1=1"]
        params = []

        query_parts.append("AND backup_code IS NOT NULL")
        query_parts.append("AND backup_code != ''")
        query_parts.append("AND backup_code != '0'")
        query_parts.append("AND backup_code != 'None'")
        query_parts.append("AND mailpwd IS NOT NULL")
        query_parts.append("AND mailpwd != ''")
        query_parts.append("AND mailpwd != 'None'")

        if product_attrs.range:
            query_parts.append(
                "AND CAST(followers AS INTEGER) >= ? AND CAST(followers AS INTEGER) <= ?"
            )
            params.extend([product_attrs.range[0], product_attrs.range[1]])

        if product_type == "normal" or product_type == "unverified":
            verifications = []
            if product_attrs.fully_verified:
                verifications.append("'fv'")
            if product_attrs.unverified:
                verifications.append("'uv'")
            if product_attrs.mixed:
                verifications.extend(["'ev'", "'uv'"])

            if verifications:
                query_parts.append(f"AND verified IN ({','.join(verifications)})")

            if product_type == "unverified":
                query_parts = [
                    part for part in query_parts if not part.startswith("AND verified")
                ]
                query_parts.append("AND verified = 'uv'")

        if product_attrs.mail_access:
            query_parts.append("AND mailpwd IS NOT NULL AND mailpwd != ''")

        if hasattr(product_attrs, "fresh") and product_attrs.fresh:
            query_parts.append("AND year = '2025'")

        if auth_tokens_to_exclude:
            if isinstance(auth_tokens_to_exclude, set):
                auth_tokens_to_exclude = list(auth_tokens_to_exclude)
            if auth_tokens_to_exclude:
                placeholders = ",".join(["?" for _ in auth_tokens_to_exclude])
                query_parts.append(f"AND auth NOT IN ({placeholders})")
                params.extend(auth_tokens_to_exclude)

        query = " ".join(query_parts)
        result = await self.fetch_one(query, tuple(params))
        return result.get("count", 0) if result else 0

    async def ensure_product_titles_table(self) -> None:
        """Ensure product_titles table exists with the proper schema"""

        await self.execute(
            """
            CREATE TABLE IF NOT EXISTS product_titles (
                product_id TEXT PRIMARY KEY,
                title TEXT
            )
        """
        )

    async def add_sellapp_order(self, order_id: str, status: str = "PENDING") -> bool:
        """Add a new sell.app order to the tracking table"""
        try:
            await self.execute(
                """
                INSERT INTO sellapp_orders (order_id, status, created_at, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ON CONFLICT(order_id) DO UPDATE SET 
                status = excluded.status,
                updated_at = CURRENT_TIMESTAMP
                """,
                (order_id, status),
            )
            return True
        except Exception as e:
            print(f"Error adding sell.app order: {e}")
            return False

    async def is_sellapp_order_delivered(self, order_id: str) -> bool:
        """Check if a sell.app order has already been delivered"""
        try:
            result = await self.fetch_one(
                "SELECT status FROM sellapp_orders WHERE order_id = ?", (order_id,)
            )
            return result is not None and result.get("status") == "COMPLETED"
        except Exception as e:
            print(f"Error checking sell.app order status: {e}")
            return False

    async def mark_sellapp_order_delivered(self, order_id: str) -> bool:
        """Mark a sell.app order as delivered"""
        try:
            await self.execute(
                """
                INSERT INTO sellapp_orders (order_id, status, created_at, updated_at)
                VALUES (?, 'COMPLETED', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ON CONFLICT(order_id) DO UPDATE SET 
                status = 'COMPLETED',
                updated_at = CURRENT_TIMESTAMP
                """,
                (order_id,),
            )
            return True
        except Exception as e:
            print(f"Error marking sell.app order as delivered: {e}")
            return False

    async def get_all_orders(self) -> List[Dict[str, Any]]:
        """Get all orders from the database"""
        query = """
        SELECT o.*, pt.title as product_title
        FROM orders o
        LEFT JOIN product_titles pt ON o.product_id = pt.product_id
        ORDER BY o.created_at DESC
        """
        return await self.fetch(query)

    async def get_orders_by_status(self, status: str) -> List[Dict[str, Any]]:
        """Get orders by status"""
        query = """
        SELECT o.*, pt.title as product_title
        FROM orders o
        LEFT JOIN product_titles pt ON o.product_id = pt.product_id
        WHERE o.status = ?
        ORDER BY o.created_at DESC
        """
        return await self.fetch(query, (status,))

    async def add_faq(self, question: str, answer: str, order_index: int = 0) -> bool:
        """Add a new FAQ entry"""
        try:
            await self.execute(
                """INSERT INTO faq (question, answer, order_index) 
                   VALUES (?, ?, ?)""",
                (question, answer, order_index),
            )
            return True
        except Exception as e:
            self.debug.log(f"Error adding FAQ: {e}")
            return False

    async def update_faq(
        self,
        faq_id: int,
        question: str = None,
        answer: str = None,
        order_index: int = None,
    ) -> bool:
        """Update an existing FAQ entry"""
        try:
            updates = []
            params = []
            if question is not None:
                updates.append("question = ?")
                params.append(question)
            if answer is not None:
                updates.append("answer = ?")
                params.append(answer)
            if order_index is not None:
                updates.append("order_index = ?")
                params.append(order_index)

            if not updates:
                return False

            params.append(faq_id)
            query = f"""UPDATE faq 
                       SET {', '.join(updates)}, updated_at = CURRENT_TIMESTAMP 
                       WHERE id = ?"""
            await self.execute(query, tuple(params))
            return True
        except Exception as e:
            self.debug.log(f"Error updating FAQ: {e}")
            return False

    async def delete_faq(self, faq_id: int) -> bool:
        """Delete an FAQ entry"""
        try:
            await self.execute("DELETE FROM faq WHERE id = ?", (faq_id,))
            return True
        except Exception as e:
            self.debug.log(f"Error deleting FAQ: {e}")
            return False

    async def get_all_faqs(self) -> List[Dict[str, Any]]:
        """Get all FAQ entries ordered by order_index"""
        return await self.fetch(
            "SELECT * FROM faq ORDER BY order_index ASC, created_at ASC"
        )

    async def get_faq(self, faq_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific FAQ entry"""
        return await self.fetch_one("SELECT * FROM faq WHERE id = ?", (faq_id,))

    async def add_terms_section(
        self, section: str, content: str, order_index: int = 0
    ) -> bool:
        """Add a new terms of service section"""
        try:
            await self.execute(
                """INSERT INTO terms_of_service (section, content, order_index) 
                   VALUES (?, ?, ?)""",
                (section, content, order_index),
            )
            return True
        except Exception as e:
            self.debug.log(f"Error adding terms section: {e}")
            return False

    async def update_terms_section(
        self,
        section_id: int,
        section: str = None,
        content: str = None,
        order_index: int = None,
    ) -> bool:
        """Update an existing terms of service section"""
        try:
            updates = []
            params = []
            if section is not None:
                updates.append("section = ?")
                params.append(section)
            if content is not None:
                updates.append("content = ?")
                params.append(content)
            if order_index is not None:
                updates.append("order_index = ?")
                params.append(order_index)

            if not updates:
                return False

            params.append(section_id)
            query = f"""UPDATE terms_of_service 
                       SET {', '.join(updates)}, updated_at = CURRENT_TIMESTAMP 
                       WHERE id = ?"""
            await self.execute(query, tuple(params))
            return True
        except Exception as e:
            self.debug.log(f"Error updating terms section: {e}")
            return False

    async def delete_terms_section(self, section_id: int) -> bool:
        """Delete a terms of service section"""
        try:
            await self.execute(
                "DELETE FROM terms_of_service WHERE id = ?", (section_id,)
            )
            return True
        except Exception as e:
            self.debug.log(f"Error deleting terms section: {e}")
            return False

    async def get_all_terms(self) -> List[Dict[str, Any]]:
        """Get all terms of service sections ordered by order_index"""
        return await self.fetch(
            "SELECT * FROM terms_of_service ORDER BY order_index ASC, created_at ASC"
        )

    async def get_terms_section(self, section_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific terms of service section"""
        return await self.fetch_one(
            "SELECT * FROM terms_of_service WHERE id = ?", (section_id,)
        )

    async def insert_trash_account(self, capture: tuple, error_code: str = "") -> None:
        username = capture[0]
        auth_token = capture[5]

        tables = [
            "normal_accounts",
            "blue_verified_accounts",
            "grey_verified_accounts",
            "gold_verified_accounts",
            "follower_accounts",
            "blueplus_accounts",
            "chars_accounts",
            "mstats_accounts",
        ]

        for table in tables:
            if username:
                await self.execute(
                    f"DELETE FROM {table} WHERE username = ?", (username,)
                )
            if auth_token:
                await self.execute(f"DELETE FROM {table} WHERE auth = ?", (auth_token,))

        await self.execute(
            """
            INSERT OR REPLACE INTO trash_accounts (
                username, password, email, mailpwd, ct0, auth, followers, 
                following, year, backup_code, verified, error_code
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
            capture + (error_code,),
        )

    async def fetch_trash_accounts(
        self, limit: int = 0, remove_after_fetch: bool = True
    ) -> list[dict]:
        query = "SELECT * FROM trash_accounts ORDER BY timestamp DESC"
        if limit > 0:
            query += f" LIMIT {limit}"
        accounts = await self.fetch(query)
        if accounts and remove_after_fetch:
            async with self.conn.execute("BEGIN IMMEDIATE"):
                try:
                    ids = [acc["username"] for acc in accounts if acc.get("username")]
                    if ids:
                        placeholders = ",".join(["?"] * len(ids))
                        await self.execute(
                            f"DELETE FROM trash_accounts WHERE username IN ({placeholders})",
                            tuple(ids),
                        )
                    await self.conn.commit()
                except Exception as e:
                    await self.conn.rollback()
                    self.debug.log(f"Error removing trash accounts: {e}")
        return accounts

    async def get_unsecured_accounts(
        self, account_type: str, filters: dict = None, limit: int = 0
    ) -> List[Dict[str, Any]]:
        """
        Get accounts that haven't been secured with 2FA (no backup codes) for security enhancement.
        Supports the same filtering options as getstock command.

        Args:
            account_type: Type of accounts to retrieve ('normal', 'follower', 'blue', etc.)
            filters: Dictionary containing filter options:
                - range: Tuple of (min, max) follower counts
                - verification: Verification type ('fv', 'ev', 'pv', 'uv', 'mixed')
                - mail_access: Whether account needs mail access
            limit: Maximum number of accounts to return (0 for all)

        Returns:
            List of unsecured account dictionaries
        """
        table_map = {
            "normal": "normals",
            "follower": "follower_accounts",
            "blue": "blue_verified_accounts",
            "grey": "grey_verified_accounts",
            "gold": "gold_verified_accounts",
            "blueplus": "blueplus_accounts",
            "chars": "chars_accounts",
            "mstats": "mstats_accounts",
        }

        table = table_map.get(account_type)
        if not table:
            self.debug.log(
                f"Invalid account type for security enhancement: {account_type}"
            )
            return []

        filters = filters or {}

        conditions = [
            "(backup_code IS NULL OR backup_code = '' OR backup_code = '0' OR backup_code = 'None')",
            "auth IS NOT NULL",
            "auth != ''",
        ]
        params = []

        if "range" in filters:
            min_followers, max_followers = filters["range"]
            conditions.append(
                """
                CAST(
                    CASE 
                        WHEN followers = '' THEN '0'
                        WHEN followers IS NULL THEN '0'
                        ELSE followers 
                    END AS INTEGER
                ) BETWEEN ? AND ?
            """
            )
            params.extend([min_followers, max_followers])

        if account_type == "normal" and "verification" in filters:
            verification = filters["verification"]
            if verification == "mixed":
                conditions.append("verified IN ('ev', 'uv')")
            else:
                conditions.append("verified = ?")
                params.append(verification)

        if filters.get("mail_access"):
            conditions.append("mailpwd IS NOT NULL AND mailpwd != ''")

        query = f"""
            SELECT * FROM {table}
            WHERE {' AND '.join(conditions)}
            ORDER BY RANDOM()
            {f'LIMIT ?' if limit > 0 else ''}
        """

        if limit > 0:
            params.append(limit)

        try:
            accounts = await self.fetch(query, tuple(params))
            filter_desc = []
            if "range" in filters:
                filter_desc.append(f"followers={filters['range']}")
            if "verification" in filters:
                filter_desc.append(f"verification={filters['verification']}")
            if filters.get("mail_access"):
                filter_desc.append("mail_access=True")

            self.debug.log(
                f"Found {len(accounts)} unsecured accounts in {table}"
                + (f" (filters: {', '.join(filter_desc)})" if filter_desc else ""),
                send=False,
            )
            return accounts
        except Exception as e:
            self.debug.log(f"Error fetching unsecured accounts: {e}")
            return []

    async def cleanup_old_backups(self):
        now = datetime.now().timestamp()
        files = [
            f
            for f in os.listdir(self.backup_dir)
            if f.startswith("production_") and f.endswith(".db")
        ]
        old_files = [
            f
            for f in files
            if now - os.path.getmtime(os.path.join(self.backup_dir, f)) > 259200
        ]
        [os.remove(os.path.join(self.backup_dir, f)) for f in old_files]

    async def add_subscriber(self, user_id: int) -> bool:
        """Add a user to the subscribers list."""
        try:
            await self.execute(
                "INSERT OR IGNORE INTO subscribers (user_id) VALUES (?)", (user_id,)
            )
            return True
        except Exception as e:
            self.debug.log(f"Error adding subscriber: {e}")
            return False

    async def remove_subscriber(self, user_id: int) -> bool:
        """Remove a user from the subscribers list."""
        try:
            success, rowcount = await self.execute(
                "DELETE FROM subscribers WHERE user_id = ?", (user_id,)
            )
            return success and rowcount > 0
        except Exception as e:
            self.debug.log(f"Error removing subscriber: {e}")
            return False

    async def is_subscribed(self, user_id: int) -> bool:
        """Check if a user is subscribed."""
        try:
            result = await self.fetch_one(
                "SELECT 1 FROM subscribers WHERE user_id = ?", (user_id,)
            )
            return bool(result)
        except Exception as e:
            self.debug.log(f"Error checking subscription: {e}")
            return False

    async def get_all_subscribers(self) -> List[int]:
        """Get a list of all subscribed user IDs."""
        try:
            rows = await self.fetch("SELECT user_id FROM subscribers")
            return [row["user_id"] for row in rows]
        except Exception as e:
            self.debug.log(f"Error getting all subscribers: {e}")
            return []

    async def move_account_to_trash(
        self, account_details: Dict[str, Any], error_code: str
    ) -> None:
        """Helper method to prepare account data and move it to the trash table."""
        if not account_details:
            self.debug.log("Attempted to move an empty account_details to trash.")
            return

        username = account_details.get("username", "")
        password = account_details.get("password", "")
        email = account_details.get("email", "")
        mailpwd = account_details.get("mailpwd", "")
        ct0 = account_details.get("ct0", "")
        auth = account_details.get("auth", account_details.get("auth_token", ""))
        followers = account_details.get("followers", "")
        following = account_details.get("following", "")
        year = account_details.get("year", "")
        backup_code = account_details.get("backup_code", "")
        verified = account_details.get("verified", "")

        if not auth and not username:
            self.debug.log(
                f"Cannot move account to trash: missing auth token and username. Details: {account_details}, Error: {error_code}"
            )
            return

        capture = (
            username,
            password,
            email,
            mailpwd,
            ct0,
            auth,
            followers,
            following,
            year,
            backup_code,
            verified,
        )
        await self.insert_trash_account(capture, error_code)
        self.debug.log(
            f"Moved account {username or auth} to trash with error code: {error_code}",
            send=False,
        )

    async def store_payment_message(
        self, order_uuid: str, chat_id: int, message_id: int
    ):
        """
        Stores or updates the chat_id and message_id for a given order_uuid.
        Uses UPSERT logic: inserts if new, updates if order_uuid already exists.
        """
        await self._ensure_connection()
        query = """
        INSERT INTO payment_messages (order_uuid, chat_id, message_id, created_at)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(order_uuid) DO UPDATE SET
            chat_id = excluded.chat_id,
            message_id = excluded.message_id,
            created_at = CURRENT_TIMESTAMP;
        """
        try:
            await self.execute(query, (order_uuid, chat_id, message_id))

            self.debug.log(
                f"Stored/Updated payment message details for order {order_uuid} (Chat: {chat_id}, Msg: {message_id})"
            )
        except Exception as e:
            self.debug.log(
                f"Database error storing payment message for order {order_uuid}: {e}"
            )

    async def get_payment_message(self, order_uuid: str) -> Optional[tuple[int, int]]:
        """
        Retrieves the chat_id and message_id for a given order_uuid.
        Returns a tuple (chat_id, message_id) or None if not found.
        """
        await self._ensure_connection()
        query = "SELECT chat_id, message_id FROM payment_messages WHERE order_uuid = ?;"
        try:
            row = await self.fetch_one(query, (order_uuid,))
            if row and "chat_id" in row and "message_id" in row:
                self.debug.log(
                    f"Retrieved payment message details for order {order_uuid}: ({row['chat_id']}, {row['message_id']})"
                )
                return int(row["chat_id"]), int(row["message_id"])
            else:
                self.debug.log(
                    f"No payment message details found for order {order_uuid}"
                )
                return None
        except Exception as e:
            self.debug.log(
                f"Database error retrieving payment message for order {order_uuid}: {e}"
            )
            return None

    async def delete_payment_message(self, order_uuid: str):
        """
        Deletes the payment message details for a given order_uuid.
        """
        await self._ensure_connection()
        query = "DELETE FROM payment_messages WHERE order_uuid = ?;"
        try:
            success, rowcount = await self.execute(query, (order_uuid,))
            if success and rowcount > 0:
                self.debug.log(
                    f"Deleted payment message details for order {order_uuid}"
                )
            else:
                self.debug.log(
                    f"No payment message details to delete or error for order {order_uuid}"
                )
        except Exception as e:
            self.debug.log(
                f"Database error deleting payment message for order {order_uuid}: {e}"
            )

    async def update_customer_username(self, user_id: int, username: str) -> None:
        query = "UPDATE customers SET username = ? WHERE user_id = ?"
        await self.execute(query, (username, user_id))

    async def get_customer_username(self, user_id: int) -> str | None:
        query = "SELECT username FROM customers WHERE user_id = ?"
        result = await self.fetch_one(query, (user_id,))
        return result.get("username") if result else None