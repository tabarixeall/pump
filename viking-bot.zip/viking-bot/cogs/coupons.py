import random
import string
from typing import Optional
from datetime import datetime, timedelta
from src.db import DatabaseManager


class CouponManager:
    def __init__(self, database: DatabaseManager):
        self.db = database

    def generate_code(self, length: int = 8) -> str:
        chars = string.ascii_uppercase + string.digits
        return "".join(random.choices(chars, k=length))

    async def add_coupon(
        self,
        code: str,
        discount: float,
        max_uses: Optional[int] = None,
        expiry_days: Optional[int] = None,
    ) -> bool:
        """Add a new coupon with optional expiry in days"""
        return await self.db.add_coupon(code, discount, max_uses, expiry_days)

    async def use_coupon(self, code: str) -> Optional[float]:
        """Mark coupon as used and return discount percentage"""
        return await self.db.use_coupon(code)

    async def get_coupon_discount(self, code: str) -> Optional[float]:
        """Get discount percentage without marking as used"""
        return await self.db.get_coupon_discount(code)

    async def delete_coupon(self, code: str) -> bool:
        return await self.db.delete_coupon(code)

    async def get_coupon_info(self, code: str) -> Optional[dict]:
        """Get detailed coupon information including expiry"""
        coupon = await self.db.get_coupon_info(code)
        if coupon and coupon.get("expiry_date"):
            expiry_date = datetime.fromisoformat(
                coupon["expiry_date"].replace("Z", "+00:00")
            )
            coupon["is_expired"] = expiry_date < datetime.utcnow()
        return coupon

    async def list_coupons(self) -> list:
        """List all coupons with days remaining"""
        coupons = await self.db.list_coupons()
        for coupon in coupons:
            days = coupon.get("days_remaining")
            if days is not None:
                coupon["is_expired"] = days <= 0
                coupon["expiry_status"] = (
                    f"Expired" if days <= 0 else f"Expires in {days} days"
                )
        return coupons

    async def validate_coupon(self, coupon_code: str) -> bool:
        """
        Validate if the coupon code exists and is active.
        For demonstration, any coupon code with 5 or more characters is considered valid.
        Replace this logic with your actual coupon validation.
        """
        return len(coupon_code) >= 5
