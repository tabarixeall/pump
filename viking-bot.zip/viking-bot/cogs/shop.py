import asyncio
from decimal import Decimal
import os
import re
from math import ceil
import traceback
from typing import Optional
import time
import random
import json
import hmac
import hashlib
import uuid
import aiohttp
import string
from io import BytesIO
import base64
import httpx
import html
import aiofiles
from pathlib import Path

from telegram import InputMediaPhoto, Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import BadRequest
from telegram.ext import ConversationHandler, ContextTypes

from cogs.utils import *
import config
from core import client
from src.models import Order, Product
from src.products import ProductAttributes, ProductTypes, Types

from datetime import datetime
from src.mail import EmailVerifier
from cogs.coupons import CouponManager
from src.payments import PaymentProcessor, PaymentConfig
from src.db import DatabaseManager
from src.debugger import Debugger

GET_EMAIL = 1
CONFIRM_EMAIL = 2
EMAIL_LOGIN, EMAIL_VERIFY = range(2)
GET_TXID = 3

MAX_MESSAGE_LENGTH = 4096


class ShopModule:
    def __init__(self, main) -> None:
        self.main = main
        self.database: DatabaseManager = main.database
        self.debug: Debugger = main.debug
        self.config = main.config
        self.cooldown = main.cooldown
        self.UPLOAD_DIR = config.UPLOAD_DIR
        self.BOT_OWNERS = config.OWNERS
        self.coupon_manager = CouponManager(self.database)

        self.BINANCE_PAY_ENABLED = (
            hasattr(config, "BINANCE_PAY_ENABLED") and config.BINANCE_PAY_ENABLED
        )
        self.binance_api_key = getattr(config, "BINANCE_API_KEY", "")
        self.binance_secret_key = getattr(config, "BINANCE_SECRET_KEY", "")

        self.products = []
        self.current_page = 0
        self.product_cache = []
        self.client = httpx.AsyncClient(timeout=30.0)
        self.email_verifier = EmailVerifier()

        self.discord_webhook_url = getattr(config, "DISCORD_WEBHOOK_URL", "")

    async def send_discord_webhook(
        self, title: str, description: str, color: int = 0x5865F2, fields: list = None
    ) -> None:
        """Send a message to Discord webhook"""
        if (
            not hasattr(config, "DISCORD_WEBHOOK_ENABLED")
            or not config.DISCORD_WEBHOOK_ENABLED
            or not hasattr(config, "DISCORD_WEBHOOK_URL")
        ):
            return

        embed = {
            "title": title,
            "description": description,
            "color": color,
            "timestamp": datetime.now().isoformat(),
        }

        if fields:
            embed["fields"] = fields

        payload = {"embeds": [embed]}

        try:
            if not self.client:
                self.client = httpx.AsyncClient(timeout=30.0)

            await self.client.post(
                config.DISCORD_WEBHOOK_URL,
                json=payload,
                headers={"Content-Type": "application/json"},
            )
        except Exception as e:
            self.debug.log(f"Error sending Discord webhook: {str(e)}")

    async def verify_products(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Verify that all configured products exist on SellApp."""
        try:
            status_message = await update.message.reply_text(
                "🔍 Checking SellApp products..."
            )

            try:
                sellapp_response = self.sellapp.get_all_products()
                sellapp_products = [
                    p
                    for p in sellapp_response.get("data", [])
                    if "twitter" in p["title"].lower()
                ]

                if not sellapp_products:
                    await status_message.edit_text(
                        "⚠️ No Twitter products found on SellApp."
                    )
                    return
            except Exception as api_error:
                self.debug.log(f"SellApp API error: {str(api_error)}")
                await status_message.edit_text(
                    f"❌ Error connecting to SellApp API: {str(api_error)[:100]}"
                )
                return

            bot_products = await self.database.list_bot_products()
            if not bot_products:
                await status_message.edit_text(
                    "⚠️ No products found in database\nPlease run /defaults to add products."
                )
                return

            sellapp_product_ids = {str(p["id"]): p["title"] for p in sellapp_products}
            bot_product_ids = {str(p.get("id")): p for p in bot_products}

            not_in_sellapp = [
                id for id in bot_product_ids if id not in sellapp_product_ids
            ]
            not_in_db = [id for id in sellapp_product_ids if id not in bot_product_ids]

            message_parts = []

            if not not_in_sellapp and not not_in_db:
                await status_message.edit_text(
                    f"✅ All {len(bot_products)} Twitter products are synced between SellApp and database."
                )
                return

            if not_in_sellapp:
                not_found_msg = "\n".join(
                    [f"🔹 ID: {product_id}" for product_id in not_in_sellapp]
                )
                message_parts.append(
                    f"⚠️ {len(not_in_sellapp)} products in database not found on SellApp:\n{not_found_msg}"
                )

            if not_in_db:
                missing_db_msg = "\n".join(
                    [f"🔹 ID: {id} ({sellapp_product_ids[id]})" for id in not_in_db]
                )
                message_parts.append(
                    f"⚠️ {len(not_in_db)} SellApp products not in database:\n{missing_db_msg}"
                )

            message = "\n\n".join(message_parts)
            message += (
                "\n\n📝 Please update your products.yml file and run /defaults again."
            )

            await status_message.edit_text(message)

        except Exception as e:
            self.debug.log(
                f"Error verifying products: {str(e)}\n{traceback.format_exc()}"
            )
            await update.message.reply_text(
                "❌ Error verifying products. Check logs for details."
            )

    async def login(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Start the login process"""
        try:
            user_id = update.effective_user.id
            username = (
                f"@{update.effective_user.username}" if update.effective_user.username else f"{update.effective_user.first_name} {update.effective_user.last_name or ''}"
            )
            if await self.database.get_customer_by_id(user_id):
                await self.database.update_customer_username(user_id, username)
                message = "You are already logged in!"
                if update.message:
                    await update.message.reply_text(message)
                else:
                    await update.callback_query.message.reply_text(message)
                return ConversationHandler.END
            context.user_data["state"] = "login_email"
            context.user_data["login_user_id"] = user_id
            context.user_data["login_username"] = username
            if update.message:
                await update.message.reply_text("Please enter your email address:")
            else:
                await update.callback_query.message.reply_text("Please enter your email address:")
            return GET_EMAIL
            
        except Exception as e:
            self.debug.log(f"Login error: {e}")
            error_msg = "⚠️ An error occurred. Please try again."
            
            if update.message:
                await update.message.reply_text(error_msg)
            elif update.callback_query and update.callback_query.message:
                await update.callback_query.message.reply_text(error_msg)
            else:
                await context.bot.send_message(user_id, error_msg)
                
            return ConversationHandler.END

    async def cmd_login(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle email input and initiate verification"""
        try:
            email = update.message.text.strip()

            if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                await update.message.reply_text(
                    "⚠️ Invalid email format. Please try again."
                )
                return EMAIL_LOGIN

            context.user_data["temp_email"] = email
            success, message = await self.email_verifier.send_verification(email)

            if success:
                await update.message.reply_text(
                    "✉️ Verification code sent!\n"
                    "Please check your email and enter the code below.\n"
                    "Send /cancel to abort"
                )
                return EMAIL_VERIFY
            else:
                await update.message.reply_text(f"❌ Verification failed: {message}")
                return EMAIL_LOGIN

        except Exception as e:
            self.debug.log(f"Email verification error: {e}")
            await update.message.reply_text("⚠️ An error occurred. Please try again.")
            return ConversationHandler.END

    async def confirm_login(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle verification code confirmation"""
        try:
            user_id = context.user_data.get("login_user_id")
            username = context.user_data.get("login_username")
            email = update.message.text.strip()
            await self.database.add_customer(user_id, email, username)
            await update.message.reply_text("✅ You are now logged in!")
            return ConversationHandler.END

        except Exception as e:
            self.debug.log(f"Login confirmation error: {e}")
            await update.message.reply_text("⚠️ An error occurred. Please try again.")
            return ConversationHandler.END

    async def send_msg(self, update: Update, text: str, order_id: Optional[str] = None):
        """Send a message or a document based on the text length."""
        if len(text) > 4096:
            os.makedirs(self.UPLOAD_DIR, exist_ok=True)
            temp_file_path = os.path.join(self.UPLOAD_DIR, f"{order_id}.txt")
            with open(temp_file_path, "w") as temp_file:
                temp_file.write(text)
            await update.message.reply_document(
                document=open(temp_file_path, "rb"), filename=f"{order_id}.txt"
            )
        else:
            await update.message.reply_text(
                f"```\n{text}\n```",
                parse_mode="Markdown",
                disable_web_page_preview=True,
            )

    async def cmd_products(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Display the list of available products."""
        context.user_data.clear()
        self.current_page = 0

        await self.show_categories(update)

    async def get_categories(self):
        """Get available product categories with counts and fresh accounts highlighted"""
        categories = []

        all_normal_products = await ProductTypes.get_products_by_category("normal")
        fresh_products = await ProductTypes.get_fresh_products()

        premium_products = await ProductTypes.get_products_by_category("premium")
        aged_products = await ProductTypes.get_products_by_category("aged")

        if all_normal_products:
            basic_accounts = [p for p in all_normal_products if not p.attributes.range]
            range_accounts = [p for p in all_normal_products if p.attributes.range]

            if basic_accounts:

                basic_stock = sum(
                    await asyncio.gather(
                        *[
                            ProductTypes.get_stock_count_for_product(p.id)
                            for p in basic_accounts
                        ]
                    )
                )
                if basic_stock > 0:
                    categories.append(("basic", "📱 Basic Accounts", basic_stock))

            ranges = self._get_follower_ranges(range_accounts)
            range_stock_tasks = {}
            for range_key in ranges:

                products_in_range = [
                    p
                    for p in range_accounts
                    if f"{p.attributes.range[0]}-{p.attributes.range[1]}" == range_key
                ]
                if products_in_range:

                    range_stock_tasks[range_key] = asyncio.gather(
                        *[
                            ProductTypes.get_stock_count_for_product(p.id)
                            for p in products_in_range
                        ]
                    )

            range_results = await asyncio.gather(*range_stock_tasks.values())
            for range_key, stock_counts in zip(range_stock_tasks.keys(), range_results):
                total_range_stock = sum(stock_counts)
                if total_range_stock > 0:
                    categories.append(
                        ("range", f"👥 {range_key}", total_range_stock, range_key)
                    )

        if fresh_products:
            fresh_stock = sum(
                await asyncio.gather(
                    *[
                        ProductTypes.get_stock_count_for_product(p.id)
                        for p in fresh_products
                    ]
                )
            )
            if fresh_stock > 0:
                categories.append(("fresh", "🆕 Fresh 2025 Accounts", fresh_stock))

        category_map = {
            "premium": ("💎 Premium Accounts", premium_products),
            "aged": ("🕰️ Aged Accounts", aged_products),
        }

        for cat_key, (display_name, product_list) in category_map.items():
            if product_list:
                stock = sum(
                    await asyncio.gather(
                        *[
                            ProductTypes.get_stock_count_for_product(p.id)
                            for p in product_list
                        ]
                    )
                )
                if stock > 0:
                    categories.append((cat_key, display_name, stock))

        def sort_key(cat_tuple):
            cat_type = cat_tuple[0]
            if cat_type == "fresh":
                return (0,)
            if cat_type == "basic":
                return (1,)
            if cat_type == "range":

                try:
                    lower_bound = int(cat_tuple[3].split("-")[0])
                    return (2, lower_bound)
                except:
                    return (2, float("inf"))
            if cat_type == "premium":
                return (3,)
            if cat_type == "aged":
                return (4,)
            return (5,)

        categories.sort(key=sort_key)

        return categories

    async def show_categories(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE = None
    ):
        """Show available product categories with counts and improved layout"""
        try:
            self.product_cache = []
            ProductTypes.invalidate_stock_cache()

            categories = await self.get_categories()

            if not categories:
                no_cat_text = "🤷‍♂️ No product categories currently available. Please check back later."
                if update.callback_query:
                    await update.callback_query.edit_message_text(no_cat_text)
                elif update.message:
                    await update.message.reply_text(no_cat_text)
                return

            title = "🛒 *Select a Twitter Account Category*"
            keyboard = []
            rows = []

            for category_info in categories:
                stock_count = category_info[2]
                display_name = category_info[1]
                button_text = f"{display_name} ({stock_count})"

                if category_info[0] == "range":

                    range_key = category_info[3]
                    data = f"range_{range_key}"

                    rows.append(InlineKeyboardButton(button_text, callback_data=data))
                else:

                    cat_type = category_info[0]
                    data = f"category_{cat_type}"

                    keyboard.append(
                        [InlineKeyboardButton(button_text, callback_data=data)]
                    )

            for i in range(0, len(rows), 2):
                keyboard.append(rows[i : i + 2])

            keyboard.append(
                [
                    InlineKeyboardButton(
                        "🔄 Refresh Categories", callback_data="refresh_categories"
                    )
                ]
            )

            reply_markup = InlineKeyboardMarkup(keyboard)
            message_text = f"{title}\n\nSelect a category to view available accounts:"

            target_message = (
                update.callback_query.message
                if update.callback_query
                else update.message
            )

            if update.callback_query:
                try:

                    current_text = (
                        target_message.text_markdown
                        if hasattr(target_message, "text_markdown")
                        else target_message.text
                    )
                    current_markup = target_message.reply_markup

                    if current_text == message_text and self._compare_markups(
                        current_markup, reply_markup
                    ):
                        await update.callback_query.answer(
                            "✅ Categories already up to date", show_alert=False
                        )
                    else:
                        await update.callback_query.edit_message_text(
                            message_text,
                            reply_markup=reply_markup,
                            parse_mode="Markdown",
                        )
                except BadRequest as e:
                    if "message is not modified" in str(e).lower():
                        await update.callback_query.answer(
                            "✅ Already up to date", show_alert=False
                        )
                    else:
                        self.debug.log(f"Error editing message in show_categories: {e}")
                        await update.callback_query.answer(
                            "Error updating categories", show_alert=True
                        )
            elif update.message:
                await update.message.reply_text(
                    message_text, reply_markup=reply_markup, parse_mode="Markdown"
                )

        except Exception as e:
            self.debug.log(f"Error in show_categories: {e}\n{traceback.format_exc()}")
            error_text = "❌ Error loading categories. Please try again."
            try:
                if update.callback_query:
                    await update.callback_query.edit_message_text(error_text)
                elif update.message:
                    await update.message.reply_text(error_text)
            except Exception as final_error:
                self.debug.log(f"Error reporting show_categories error: {final_error}")
                if update.callback_query:
                    await update.callback_query.answer(
                        "Critical error loading categories", show_alert=True
                    )

    async def show_products(
        self, update: Update, category: str = None, follower_range: str = None
    ):
        try:

            context = None
            if hasattr(update, "context") and hasattr(update.context, "user_data"):
                context = update.context

            current_category = category or (
                context.user_data.get("current_category") if context else None
            )
            current_range = follower_range or (
                context.user_data.get("current_range") if context else None
            )

            if context:
                context.user_data["current_category"] = current_category
                context.user_data["current_range"] = current_range

            async with asyncio.Lock():
                if current_range:
                    products = await ProductTypes.get_products_by_category(
                        "normal", current_range
                    )
                    title = f"👥 *Twitter Accounts: {current_range} Followers*"
                elif current_category == "fresh":
                    products = await ProductTypes.get_fresh_products()
                    title = "🆕 *Fresh 2025 Twitter Accounts*"
                else:
                    cat_to_fetch = current_category or "normal"
                    products = await ProductTypes.get_products_by_category(cat_to_fetch)
                    category_display = cat_to_fetch.title()
                    title = f"🛍️ *{category_display} Accounts*"

                if not products:
                    reply_markup = InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back to Categories",
                                    callback_data="back_categories",
                                )
                            ]
                        ]
                    )
                    no_product_message = "🤷‍♂️ No products found in this category."
                    if update.callback_query:
                        await update.callback_query.edit_message_text(
                            no_product_message, reply_markup=reply_markup
                        )
                    elif update.message:
                        await update.message.reply_text(
                            no_product_message, reply_markup=reply_markup
                        )
                    return

                stock_tasks = []
                for product in products:
                    task = ProductTypes.get_stock_count_for_product(product.id)
                    stock_tasks.append((product, task))

                all_products = []
                all_stock = []
                for product, task in stock_tasks:
                    count = await task
                    all_products.append(product)
                    all_stock.append(count)

                self.products = all_products
                products_per_page = 5
                total_products = len(all_products)
                total_pages = ceil(total_products / products_per_page)

                if self.current_page >= total_pages:
                    self.current_page = max(0, total_pages - 1)
                start_idx = self.current_page * products_per_page
                end_idx = min(start_idx + products_per_page, total_products)
                page_products = all_products[start_idx:end_idx]
                page_stock = all_stock[start_idx:end_idx]

                product_displays = []
                keyboard = []
                for i, (product, count) in enumerate(zip(page_products, page_stock)):
                    is_fresh = (
                        hasattr(product.attributes, "fresh")
                        and product.attributes.fresh
                    )
                    display_title = product.title
                    if (
                        is_fresh
                        and "fresh" not in display_title.lower()
                        and "2025" not in display_title.lower()
                    ):
                        display_title = f"🆕 Fresh 2025 - {display_title}"
                    if count > 10:
                        stock_indicator = "✅ In Stock"
                    elif count > 0:
                        stock_indicator = f"⚠️ Low Stock ({count})"
                    else:
                        stock_indicator = "❌ Out of Stock"
                    display = f"*{i+1 + start_idx}. {display_title}*\n"
                    display += f"💰 Price: ${product.price:.2f}  |  {stock_indicator}\n"
                    attributes_list = []
                    if product.attributes.range:
                        attributes_list.append(
                            f"👥 {product.attributes.range[0]}-{product.attributes.range[1]}"
                        )
                    if product.attributes.fully_verified:
                        attributes_list.append("✅ Fully Verified")
                    elif product.attributes.unverified:
                        attributes_list.append("✉️ Email Verified")
                    elif product.attributes.mixed:
                        attributes_list.append("🔄 Mixed Verification")
                    if product.attributes.mail_access:
                        attributes_list.append("📧 Email Access Included")
                    if attributes_list:
                        display += f"`{' | '.join(attributes_list)}`\n"
                    product_displays.append(display)
                    button_label = f"Buy {self._get_short_title(product.title)}"
                    if (
                        is_fresh
                        and "fresh" not in button_label.lower()
                        and "2025" not in button_label.lower()
                    ):
                        button_label = f"Buy 🆕 {self._get_short_title(product.title)}"
                    if count > 0:
                        keyboard.append(
                            [
                                InlineKeyboardButton(
                                    button_label, callback_data=f"purchase_{product.id}"
                                )
                            ]
                        )
                    else:
                        keyboard.append(
                            [InlineKeyboardButton("Sold Out", callback_data="noop")]
                        )
                nav_row = []
                if self.current_page > 0:
                    nav_row.append(
                        InlineKeyboardButton("◀️ Prev", callback_data="browse_prev")
                    )
                if total_pages > 1:
                    nav_row.append(
                        InlineKeyboardButton(
                            f"Page {self.current_page + 1}/{total_pages}",
                            callback_data="page_info",
                        )
                    )
                if self.current_page < total_pages - 1:
                    nav_row.append(
                        InlineKeyboardButton("Next ▶️", callback_data="browse_next")
                    )
                if nav_row:
                    keyboard.append(nav_row)
                keyboard.append(
                    [
                        InlineKeyboardButton(
                            "🔙 Back to Categories", callback_data="back_categories"
                        ),
                        InlineKeyboardButton(
                            "🔄 Refresh", callback_data="refresh_products"
                        ),
                    ]
                )
                products_text = "\n\n".join(product_displays)
                message_text = f"{title}\n\n{products_text}"
                reply_markup = InlineKeyboardMarkup(keyboard)
                if update.callback_query:
                    try:
                        if self._compare_message_content(
                            update.callback_query.message, message_text, reply_markup
                        ):
                            await update.callback_query.answer(
                                "✅ Already up to date", show_alert=False
                            )
                        else:
                            await update.callback_query.edit_message_text(
                                message_text,
                                reply_markup=reply_markup,
                                parse_mode="Markdown",
                            )
                    except BadRequest as e:
                        if "message is not modified" in str(e).lower():
                            await update.callback_query.answer(
                                "✅ Already up to date", show_alert=False
                            )
                        else:
                            self.debug.log(
                                f"Error editing message in show_products: {e}"
                            )
                            await update.callback_query.answer(
                                "Error updating display", show_alert=True
                            )
                            if context:
                                try:
                                    await context.bot.send_message(
                                        chat_id=update.effective_chat.id,
                                        text=message_text,
                                        reply_markup=reply_markup,
                                        parse_mode="Markdown",
                                    )
                                except Exception as send_error:
                                    self.debug.log(
                                        f"Fallback send message failed: {send_error}"
                                    )
                elif update.message:
                    await update.message.reply_text(
                        message_text, reply_markup=reply_markup, parse_mode="Markdown"
                    )

        except Exception as e:
            self.debug.log(f"Error in show_products: {e}\n{traceback.format_exc()}")
            error_text = "❌ Error loading products. Please try again later."
            try:
                if update.callback_query:
                    await update.callback_query.edit_message_text(error_text)
                elif update.message:
                    await update.message.reply_text(error_text)
            except Exception as final_error:
                self.debug.log(f"Error reporting show_products error: {final_error}")
                if update.callback_query:
                    await update.callback_query.answer(
                        "Critical error loading products", show_alert=True
                    )

    def _compare_message_content(self, message, new_text, new_markup):
        """Helper to compare existing message content with new content."""
        if not message:
            return False

        current_text = (
            message.text_markdown if hasattr(message, "text_markdown") else message.text
        )
        current_markup = message.reply_markup

        has_current_markup = (
            current_markup
            and hasattr(current_markup, "inline_keyboard")
            and current_markup.inline_keyboard
        )
        has_new_markup = (
            new_markup
            and hasattr(new_markup, "inline_keyboard")
            and new_markup.inline_keyboard
        )

        if current_text != new_text:
            return False

        if not has_current_markup and not has_new_markup:
            return True

        if has_current_markup != has_new_markup:
            return False

        return self._compare_markups(current_markup, new_markup)

    async def handle_purchase(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        user_id = update.effective_user.id

        try:
            if not query.data.startswith("purchase_"):
                await query.edit_message_text("❌ Invalid purchase request")
                return

            # Extract the full product ID after 'purchase_'
            product_id = query.data[len("purchase_") :]

            product = await ProductTypes.get_product_by_id(product_id)
            if not product:
                await query.edit_message_text(
                    "❌ Product not found",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back", callback_data="back_to_products"
                                )
                            ]
                        ]
                    ),
                )
                return

            available_count = await ProductTypes.get_stock_count_for_product(product_id)

            if available_count == 0:
                await query.edit_message_text(
                    "Sorry, this product is currently out of stock. Please try again later or choose another product.",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back", callback_data="back_to_products"
                                )
                            ]
                        ]
                    ),
                )
                return

            context.user_data["selected_product"] = product
            context.user_data["product_attrs"] = product.attributes
            context.user_data["product_title"] = product.title
            context.user_data["product_price"] = product.price
            context.user_data["product_id"] = product.id

            email = await self.database.get_customer_email(user_id)
            if not email:
                await query.edit_message_text(
                    "🔒 You need to be logged in to make a purchase.\n"
                    "Please use /login first.",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back", callback_data="back_to_products"
                                )
                            ]
                        ]
                    ),
                )
                return

            context.user_data["email"] = email

            display_title = product.title
            if (
                hasattr(product.attributes, "fresh")
                and product.attributes.fresh
                and "fresh" not in display_title.lower()
                and "2025" not in display_title.lower()
            ):
                display_title = f"🆕 Fresh 2025 - {display_title}"

            attributes_text = ""
            if hasattr(product.attributes, "fresh") and product.attributes.fresh:
                attributes_text += "🆕 Fresh 2025 Account\n"
            if product.attributes.mail_access:
                attributes_text += "📧 Email Access Included\n"
            if product.attributes.fully_verified:
                attributes_text += "✅ Fully Verified\n"
            if attributes_text:
                attributes_text = f"\n{attributes_text}"

            prompt = await query.edit_message_text(
                f"🛍️ *{display_title}*\n\n"
                f"💰 Price: ${product.price:.2f}\n"
                f"📦 Stock: {available_count} accounts{attributes_text}\n\n"
                "Enter quantity (number):",
                parse_mode="Markdown",
            )

            context.user_data["prompt_message_id"] = prompt.message_id

            context.user_data["state"] = "waiting_for_quantity"

        except Exception as e:
            self.debug.log(f"Purchase error: {str(e)}")
            await query.edit_message_text(
                "❌ Error processing purchase",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "🔙 Back", callback_data="back_to_products"
                            )
                        ]
                    ]
                ),
            )

    async def handle_gateway(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle payment gateway selection with optimized code"""
        query = update.callback_query
        await query.answer()
        user_id = update.effective_user.id

        try:
            if query.data == "cancel_payment":

                keys_to_clear = [
                    k
                    for k in context.user_data.keys()
                    if k.startswith(
                        (
                            "selected_product",
                            "product_",
                            "email",
                            "quantity",
                            "payment_",
                        )
                    )
                ]

                for k in keys_to_clear:
                    context.user_data.pop(k, None)

                try:
                    await query.message.delete()
                except Exception as e:
                    self.debug.log(f"Failed to delete message: {e}")

                    try:
                        await query.edit_message_text("❌ Payment cancelled")
                    except Exception:
                        pass
                return

            if not context.user_data.get("selected_product"):
                await query.edit_message_text(
                    "❌ Your session has expired.\n" "Please start your purchase again."
                )
                return

            if query.data.startswith("coupon_"):
                choice = query.data.split("_")[1]
                if choice == "yes":
                    await query.edit_message_text("Please enter your coupon code:")
                    context.user_data["state"] = "waiting_for_coupon"
                    return
                elif choice == "no":
                    await self.prompt_gateway(update, context)
                    return

            elif not query.data.startswith("network_"):
                await query.edit_message_text("❌ Invalid payment selection")
                return

            await query.edit_message_text("⚙️ Creating Invoice..")

            product = context.user_data.get("selected_product")
            quantity = context.user_data.get("quantity", 1)
            email = context.user_data.get("email")

            order_uuid = str(uuid.uuid4())

            if not all([product, quantity, email]):
                self.debug.log(
                    f"Missing payment data for user {user_id}: {context.user_data}"
                )
                await query.edit_message_text(
                    "❌ Session data is incomplete.\nPlease start your purchase again."
                )
                for key in list(context.user_data.keys()):
                    if key.startswith(
                        (
                            "selected_product",
                            "product_",
                            "email",
                            "quantity",
                            "payment_",
                        )
                    ):
                        context.user_data.pop(key, None)
                return

            network = query.data.replace("network_", "").upper()
            coupon_code = context.user_data.get("coupon_code")
            coupon_discount = context.user_data.get("coupon_discount")

            # Determine base USD price
            if product.attributes.product_type == Types.MSTATS:
                accounts = await self.database.get_accounts_by_product_id(product.id, quantity)
                if accounts:
                    usd_price = sum([self.main.get_mstats_static_price(acc) for acc in accounts])
                else:
                    self.debug.log(f"No accounts found for MSTATS product ID {product.id} during pricing. Defaulting to YAML price.")
                    usd_price = float(product.price) * quantity 
            else: # For "normal" products from YAML and other non-MSTATS types
                usd_price = float(product.price) * quantity

            # Apply coupon discount
            if coupon_code and coupon_discount:
                usd_price = round(usd_price * (1 - float(coupon_discount) / 100), 2)
            
            if usd_price <= 0 and not (product.attributes.product_type == Types.MSTATS and not accounts): # Allow MSTATS to be 0 if no accounts found and that's intended
                self.debug.log(f"Calculated price for {product.title} is {usd_price:.2f} (Product type: {product.attributes.product_type}). Aborting payment.")
                await query.edit_message_text(
                    f"⚠️ Calculated price for {product.title} is ${usd_price:.2f}. This seems incorrect. Please contact support or try again."
                )
                return

            try:
                await self.database.create_order(
                    user_id=user_id,
                    product_id=product.id,
                    quantity=quantity,
                    total_amount=usd_price,
                    uuid=order_uuid,
                    payment_currency=network,
                )
                user = update.effective_user
                username = (
                    f"@{user.username}" if user.username else f"{user.first_name} {user.last_name or ''}"
                )
                is_fresh = (
                    hasattr(product.attributes, "fresh") and product.attributes.fresh
                )
                webhook_title = "🛒 New Bot Order Created"
                if is_fresh:
                    webhook_title = "🆕 New Fresh 2025 Account Order"
                discord_fields = [
                    {"name": "Order UUID", "value": order_uuid, "inline": True},
                    {"name": "User", "value": username, "inline": True},
                    {"name": "User ID", "value": str(user_id), "inline": True},
                    {"name": "Product", "value": product.title, "inline": True},
                    {"name": "Quantity", "value": str(quantity), "inline": True},
                    {
                        "name": "Total Price",
                        "value": f"${usd_price:.2f}",
                        "inline": True,
                    },
                    {"name": "Payment Method", "value": network, "inline": True},
                    {"name": "Email", "value": email, "inline": False},
                ]
                if is_fresh:
                    discord_fields.append(
                        {
                            "name": "Account Type",
                            "value": "🆕 Fresh 2025",
                            "inline": True,
                        }
                    )
                webhook_color = 0x2ECC71 if is_fresh else 0x3498DB
                await self.send_discord_webhook(
                    title=webhook_title,
                    description="A new order has been created via Telegram bot",
                    color=webhook_color,
                    fields=discord_fields,
                )
                await self.database.update_customer_username(user_id, username)
            except Exception as e:
                self.debug.log(f"Error creating order: {str(e)}")
                await query.edit_message_text(
                    "❌ Error creating order. Please try again."
                )
                return

            if network == "BINANCE" and self.BINANCE_PAY_ENABLED:
                order = await self.create_binance_order(usd_price)
                if not order or "data" not in order:
                    await query.edit_message_text(
                        "❌ Failed to create Binance Pay order"
                    )
                    return
                keyboard = [
                    [
                        InlineKeyboardButton(
                            "Pay with Binance", url=order["data"]["checkoutUrl"]
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "🔄 Check Status",
                            callback_data=f"check_payment_binance_{order['data']['prepayId']}_{order_uuid}",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "💬 Contact Support", url=f"https://t.me/vikingtokens"
                        )
                    ],
                    [InlineKeyboardButton("❌ Cancel", callback_data="cancel_payment")],
                ]
                await query.edit_message_text(
                    f"💰 Amount: *${usd_price:.2f}*\nClick the button below to pay with Binance Pay\nThen click Check Status to confirm your payment",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="Markdown",
                )
                return
            try:
                p_config = PaymentConfig(
                    callback_url=f"{config.WEBHOOK_URL}",
                    order_id=order_uuid,
                    user_id=user_id,
                    product_id=product.id,
                    quantity=quantity,
                )
                processor = PaymentProcessor(p_config, self.database)
                success, payment_data = await processor.create_payment(
                    network, usd_price
                )
                if not success:
                    await query.edit_message_text(f"⚠️ {payment_data}")
                    return
                context.user_data["payment_details"] = payment_data
                invoice_id_safe = html.escape(str(payment_data.invoice_id))
                address_safe = html.escape(str(payment_data.address))
                expected_amount_safe = html.escape(str(payment_data.expected_amount))
                network_safe = html.escape(network)
                price_str = f"{usd_price:.2f}"
                msg = (
                    f"💸 <b>Payment Details</b>\n"
                    f"• <b>Amount (USD):</b> <code>${price_str}</code>\n"
                    f"• <b>Pay:</b> <code>{expected_amount_safe}</code> <b>({network_safe})</b>\n"
                    f"• <b>Invoice ID:</b> <code>{invoice_id_safe}</code>\n"
                    f"• <b>Recipient Address:</b>\n<code>{address_safe}</code>\n"
                    f"\n"
                    f"✅ <b>Automatic Payment Confirmation</b>\n"
                    f"ℹ️ <i>Please send the <b>exact</b> amount to avoid delays.</i>\n"
                )
                if payment_data.qr_code:
                    qr_image = BytesIO(base64.b64decode(payment_data.qr_code))
                    temp_msg = await query.edit_message_text(
                        "⏳ Generating QR Code...", parse_mode="HTML"
                    )
                    keyboard = [
                        [
                            InlineKeyboardButton(
                                "💬 Contact Support", url=f"https://t.me/vikingtokens"
                            )
                        ],
                        [
                            InlineKeyboardButton(
                                "❌ Cancel", callback_data="cancel_payment"
                            )
                        ],
                    ]
                    final_message = None
                    try:
                        final_message = await temp_msg.edit_media(
                            media=InputMediaPhoto(
                                qr_image, caption=msg, parse_mode="HTML"
                            ),
                            reply_markup=InlineKeyboardMarkup(keyboard),
                        )
                    except BadRequest as e:
                        if "message is not modified" in str(e).lower():
                            final_message = temp_msg
                        else:
                            final_message = await temp_msg.edit_text(
                                msg,
                                parse_mode="HTML",
                                reply_markup=InlineKeyboardMarkup(keyboard),
                            )
                    if final_message:
                        await self.database.store_payment_message(
                            order_uuid, final_message.chat_id, final_message.message_id
                        )
                else:
                    keyboard = [
                        [
                            InlineKeyboardButton(
                                "💬 Contact Support", url=f"https://t.me/vikingtokens"
                            )
                        ],
                        [
                            InlineKeyboardButton(
                                "❌ Cancel", callback_data="cancel_payment"
                            )
                        ],
                    ]
                    final_message = await query.edit_message_text(
                        msg,
                        reply_markup=InlineKeyboardMarkup(keyboard),
                        parse_mode="HTML",
                    )
                    if final_message:
                        await self.database.store_payment_message(
                            order_uuid, final_message.chat_id, final_message.message_id
                        )

                for key in list(context.user_data.keys()):
                    if key not in ["payment_details", "email"]:
                        context.user_data.pop(key, None)
                await processor.close()
            except Exception as e:
                traceback.print_exc()
                self.debug.log(f"Crypto payment error: {str(e)}")
                await self.debug.notify_owner(
                    f"Payment gateway error for user {user_id}: {str(e)}"
                )

                for key in list(context.user_data.keys()):
                    if key.startswith(
                        ("selected_product", "product_", "quantity", "payment_")
                    ):
                        context.user_data.pop(key, None)
                await query.edit_message_text(
                    "❌ An error occurred while creating your payment.\n"
                    "Please try your purchase again."
                )

        except Exception as e:
            self.debug.log(f"Payment gateway error for user {user_id}: {str(e)}")
            await self.debug.notify_owner(
                f"Payment gateway error for user {user_id}: {str(e)}"
            )
            traceback.print_exc()

            keys_to_clear = [
                k
                for k in context.user_data.keys()
                if k.startswith(
                    ("selected_product", "product_", "quantity", "payment_")
                )
            ]
            for k in keys_to_clear:
                context.user_data.pop(k, None)

            await query.edit_message_text(
                "❌ An error occurred while creating your payment.\n"
                "Please try your purchase again."
            )

    async def check_binance_payment(self, prepay_id: str, order_uuid: str) -> bool:
        """Check Binance Pay payment status and update order"""
        paid = await self._check_binance_payment_status(prepay_id)

        if paid:
            await self.database.complete_order_by_uuid(order_uuid, prepay_id)
            return True
        return False

    async def _check_binance_payment_status(self, prepay_id: str) -> bool:
        """Check payment status with Binance Pay API"""
        timestamp = int(time.time() * 1000)
        nonce = "".join(random.choices(string.ascii_uppercase + string.digits, k=32))

        payload = {"prepayId": prepay_id}

        payload_str = f"{timestamp}\n{nonce}\n{json.dumps(payload)}\n"
        signature = (
            hmac.new(
                self.binance_secret_key.encode("utf-8"),
                payload_str.encode("utf-8"),
                hashlib.sha512,
            )
            .hexdigest()
            .upper()
        )

        headers = {
            "Content-Type": "application/json",
            "BinancePay-Timestamp": str(timestamp),
            "BinancePay-Nonce": nonce,
            "BinancePay-Certificate-SN": self.binance_api_key,
            "BinancePay-Signature": signature,
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    "https://bpay.binanceapi.com/binancepay/openapi/v2/order/query",
                    headers=headers,
                    json=payload,
                ) as response:
                    result = await response.json()

                    if "data" in result and "status" in result["data"]:

                        return result["data"]["status"] == "PAID"
            return False
        except Exception as e:
            self.debug.log(f"Error checking Binance payment: {e}")
            return False

    async def _send_chat_delivery(
        self,
        context: ContextTypes.DEFAULT_TYPE,
        user_id: int,
        message: str,
        accounts: list,
    ) -> None:
        """Send delivery message and accounts file to user's chat"""
        try:

            await context.bot.send_message(
                chat_id=user_id, text=message, parse_mode="Markdown"
            )

            accounts_text = self._format_accounts_for_file(accounts)

            file_content = BytesIO(accounts_text.encode("utf-8"))
            file_name = f"order_{int(time.time())}.txt"

            await context.bot.send_document(
                chat_id=user_id,
                document=file_content,
                caption="🎉 Here are your accounts!",
                filename=file_name,
            )

        except Exception as e:
            self.debug.log(f"Chat delivery error: {str(e)}")
            raise

    def _format_accounts_for_file(self, accounts: list) -> str:
        keys = ["username", "password", "email", "mailpwd", "ct0", "auth", "backup_code"]
        deliverable, skipped = [], []
        for acc in accounts:
            reasons = []
            for k in keys:
                v = acc.get(k)
                if not v or str(v).strip() in ["", "None", "0"]:
                    reasons.append(f"missing/{k}")
            if acc.get("mailpwd") == "NO_MAIL_PASS":
                reasons.append("mailpwd=NO_MAIL_PASS")
            if reasons:
                skipped.append((acc, reasons))
            else:
                deliverable.append(acc)
        self.debug.log(f"[DELIVERY] Total accounts processed: {len(accounts)}")
        self.debug.log(f"[DELIVERY] Skipped: {len(skipped)} | Deliverable: {len(deliverable)}")
        for acc, reasons in skipped:
            self.debug.log(f"[DELIVERY] Skipped account {acc.get('username','?')}: {', '.join(reasons)}")
        return "\n".join(":".join(str(acc[k]) for k in keys) for acc in deliverable)

    def _format_delivery_message(self, accounts: list, product: Product) -> str:
        """Format delivery message with accounts"""
        return (
            "🎉 *Order Delivered!*\n\n"
            f" Product: {product.title}\n"
            f"📊 Quantity: {len(accounts)}\n\n"
            "✅ Your accounts file is attached below.\n\n"
            "⚠️ *Important:*\n"
            "• Change passwords immediately\n"
            "• Enable 2FA if available\n"
            "• Update email if provided\n\n"
            "Need help? Contact support!"
        )

    async def validate_payment_amount(
        self, expected_amount: float, received_amount: float, currency: str
    ) -> bool:
        """Validate received payment amount against expected amount"""
        tolerance = await self.database.get_payment_tolerance(currency)
        return received_amount >= (expected_amount * tolerance)

    async def update_maximum_stock(self, debug: Debugger) -> None:
        """Update stock quantities for SellApp products efficiently"""
        try:

            all_products = await ProductTypes.list_all_products()

            sellapp_products = self.sellapp.get_all_products()

            if not sellapp_products or not all_products:
                debug.log("No products found")
                return

            product_map = {p.id: p for p in all_products}

            stock_updates = {}
            for product_id, product in product_map.items():
                count = await ProductTypes.get_stock_count_for_product(product_id)
                stock_updates[product_id] = max(count, 1)

            update_tasks = []
            for product in sellapp_products.get("data", []):
                product_id = str(product.get("id"))
                if product_id in stock_updates:
                    product_title = product.get("title", "Unknown Product")
                    debug.log(f"Updating product {product_title} (ID: {product_id})")

                    for variant in product.get("variants", []):
                        variant_id = variant.get("id")
                        variant_title = variant.get("title", "Default Variant")
                        current_max = variant.get("maximum_purchase_quantity", 0)
                        new_max = stock_updates[product_id]

                        debug.log(
                            f"  - Variant {variant_title}: Current max: {current_max}, New max: {new_max}"
                        )

                        if current_max != new_max:
                            update_tasks.append(
                                self.sellapp.update_product_variant(
                                    product_id,
                                    variant_id,
                                    {"maximum_purchase_quantity": new_max},
                                )
                            )

            if update_tasks:
                await asyncio.gather(*update_tasks)
                debug.log(f"Updated stock for {len(update_tasks)} product variants")

        except Exception as e:
            debug.log(f"Error in stock update: {str(e)}")

    async def stock_monitor(self, interval: int = 15):
        """Monitor stock levels and alert when they get low"""
        while True:
            try:

                all_products = await ProductTypes.list_all_products()

                low_stock_products = []
                for product in all_products:
                    try:

                        count = await self.database.get_stock_count_by_product_id(
                            product.id
                        )

                        if count < 1:
                            low_stock_products.append((product.title, count))
                    except Exception as inner_e:

                        self.debug.log(
                            f"Error checking stock for product {product.id}: {inner_e}"
                        )

                if low_stock_products:
                    alert_message = "⚠️ *Low Stock Alert*\n\n"
                    for title, count in low_stock_products:
                        alert_message += f"• {title}: {count} accounts remaining\n"

                    await self.debug.notify_owner(alert_message)

                await asyncio.sleep(interval * 60)

            except Exception as e:

                self.debug.log(f"Critical error in stock monitor: {e}")
                await asyncio.sleep(300)

    async def update_stock_in_description(self, debug: Debugger) -> None:
        """Update product descriptions to include stock information"""
        try:

            all_products = await ProductTypes.list_all_products()

            sellapp_products = self.sellapp.get_all_products()

            if not sellapp_products or not all_products:
                debug.log("No products found")
                return

            product_map = {p.id: p for p in all_products}
            sellapp_map = {str(p["id"]): p for p in sellapp_products.get("data", [])}

            update_tasks = []
            for product_id, product in product_map.items():
                if product_id in sellapp_map:
                    sellapp_product = sellapp_map[product_id]
                    current_desc = sellapp_product.get("description", "")

                    desc_parts = current_desc.split("\n\n**Current Stock:**")
                    base_desc = desc_parts[0]

                    stock_count = await ProductTypes.get_stock_count_for_product(
                        product_id
                    )

                    new_desc = f"{base_desc}\n\n**Current Stock:** {stock_count} accounts available"

                    if new_desc != current_desc:
                        update_tasks.append(
                            self.sellapp.update_product(
                                product_id, {"description": new_desc}
                            )
                        )

            if update_tasks:
                await asyncio.gather(*update_tasks)
                debug.log(f"Updated descriptions for {len(update_tasks)} products")

        except Exception as e:
            debug.log(f"Error updating product descriptions: {str(e)}")

    async def category_handler(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle category selection"""
        try:
            query = update.callback_query
            await query.answer()

            category = query.data.replace("category_", "")

            if category == "basic":

                await self.show_products(update, category="basic")
            else:

                await self.show_products(update, category=category)

        except Exception as e:
            self.debug.log(f"Error in category_handler: {e}")
            await query.edit_message_text(
                "An error occurred while processing your request."
            )

    async def back_categories_handler(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle the back button to return to categories"""
        try:
            query = update.callback_query
            await query.answer()

            await self.show_categories(update, context)

        except Exception as e:
            self.debug.log(f"Error in back_categories_handler: {e}")
            await query.edit_message_text(
                "An error occurred while returning to categories."
            )

    async def range_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle range selection"""
        try:
            query = update.callback_query
            await query.answer()

            follower_range = query.data.replace("range_", "")

            await self.show_products(update, follower_range=follower_range)

        except Exception as e:
            self.debug.log(f"Error in range_handler: {e}")
            await query.edit_message_text(
                "An error occurred while processing your request."
            )

    async def refresh_categories_handler(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle the refresh button in categories view"""
        try:
            query = update.callback_query
            await query.answer("Refreshing categories...")

            ProductTypes.invalidate_stock_cache()
            self.product_cache = []

            async with asyncio.Lock():

                all_products = await ProductTypes.list_all_products()

                stock_counts = {}
                stock_tasks = []
                for product in all_products:
                    task = ProductTypes.get_stock_count_for_product(product.id)
                    stock_tasks.append((product.id, task))

                for product_id, task in stock_tasks:
                    stock_counts[product_id] = await task

                ranges = {}
                fresh_products = []

                for product in all_products:
                    stock = stock_counts.get(product.id, 0)
                    if stock <= 0:
                        continue

                    if product.attributes.fresh:
                        fresh_products.append((product, stock))
                    elif product.attributes.range:
                        range_key = f"{product.attributes.range[0]}-{product.attributes.range[1]}"
                        if range_key not in ranges:
                            ranges[range_key] = []
                        ranges[range_key].append((product, stock))

            keyboard = []

            if fresh_products:
                fresh_count = sum(stock for _, stock in fresh_products)
                keyboard.append(
                    [
                        InlineKeyboardButton(
                            f"🆕 Fresh Accounts 2025 ({fresh_count})",
                            callback_data="category_fresh",
                        )
                    ]
                )

            range_rows = []
            for range_key, products_in_range in sorted(
                ranges.items(), key=lambda x: [int(n) for n in x[0].split("-")]
            ):
                range_count = sum(stock for _, stock in products_in_range)
                if range_count > 0:
                    range_rows.append(
                        InlineKeyboardButton(
                            f"👥 {range_key} Followers ({range_count})",
                            callback_data=f"range_{range_key}",
                        )
                    )

            for i in range(0, len(range_rows), 2):
                row = range_rows[i : i + 2]
                keyboard.append(row)

            keyboard.append(
                [InlineKeyboardButton("🔄 Refresh", callback_data="refresh_categories")]
            )

            message_text = (
                "🛍️ *Product Categories*\n\n"
                "Select a category to browse available accounts:"
            )

            reply_markup = InlineKeyboardMarkup(keyboard)

            try:
                current_message = query.message
                current_text = (
                    current_message.text_markdown
                    if hasattr(current_message, "text_markdown")
                    else current_message.text
                )
                current_markup = current_message.reply_markup

                if current_text == message_text and self._compare_markups(
                    current_markup, reply_markup
                ):

                    await query.answer(
                        "Categories already up to date", show_alert=False
                    )
                    return

                await query.edit_message_text(
                    message_text, reply_markup=reply_markup, parse_mode="Markdown"
                )
            except Exception as edit_error:

                self.debug.log(f"Edit message error in refresh: {edit_error}")
                await query.answer("Refresh completed, but couldn't update display")

        except Exception as e:
            self.debug.log(f"Error in refresh_categories_handler: {e}")
            await query.answer("Error refreshing categories")

    def _compare_markups(self, markup1, markup2):
        """Compare two reply markups to see if they're identical"""
        if markup1 is None or markup2 is None:
            return markup1 is markup2

        if not hasattr(markup1, "inline_keyboard") or not hasattr(
            markup2, "inline_keyboard"
        ):
            return False

        if len(markup1.inline_keyboard) != len(markup2.inline_keyboard):
            return False

        for row1, row2 in zip(markup1.inline_keyboard, markup2.inline_keyboard):
            if len(row1) != len(row2):
                return False

            for btn1, btn2 in zip(row1, row2):
                if btn1.text != btn2.text or btn1.callback_data != btn2.callback_data:
                    return False

        return True

    async def callback_query_handler(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Central handler for shop-related callback queries"""
        query = update.callback_query
        data = query.data

        try:
            if data == "back_categories":
                await query.answer("Returning to categories...")
                await self.show_categories(update, context)
            elif data == "back_to_products":
                await query.answer("Returning to products...")
                await self.back_to_products_handler(update, context)
            elif data == "refresh_categories":

                await self.refresh_categories_handler(update, context)
            elif data.startswith("category_"):
                await query.answer("Loading category...")
                category = data.replace("category_", "")
                await self.show_products(update, category=category)
            elif data.startswith("range_"):
                await query.answer("Loading products...")
                follower_range = data.replace("range_", "")
                await self.show_products(update, follower_range=follower_range)
            elif data == "refresh_products":
                await query.answer("Refreshing products...")

                ProductTypes.invalidate_stock_cache()

                category = context.user_data.get("current_category")
                follower_range = context.user_data.get("current_range")
                await self.show_products(
                    update, category=category, follower_range=follower_range
                )
            elif data.startswith("purchase_"):
                await query.answer("Processing purchase...")
                await self.handle_purchase(update, context)
            elif data in ["browse_next", "browse_prev"]:
                await query.answer("Navigating...")
                await self.paginate_handler(update, context)
            elif data == "page_info":
                await query.answer(f"Page {self.current_page + 1}", show_alert=False)
            elif data == "noop":
                await query.answer(show_alert=False)

        except Exception as e:

            if "message is not modified" in str(e).lower():
                await query.answer("Content already up to date", show_alert=False)
            else:
                self.debug.log(f"Error in callback_query_handler: {str(e)}")
                await query.answer("Error processing request", show_alert=True)

    async def back_to_products_handler(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle the 'Back' button when viewing a product with no stock"""
        try:
            query = update.callback_query
            await query.answer("Going back to products...")

            category = context.user_data.get("current_category")
            follower_range = context.user_data.get("current_range")

            if follower_range:
                await self.show_products(update, follower_range=follower_range)

            elif category:
                await self.show_products(update, category=category)

            else:
                await self.show_categories(update, context)

        except Exception as e:
            self.debug.log(f"Error in back_to_products_handler: {e}")
            await query.edit_message_text(
                "An error occurred while returning to products."
            )

    def _get_short_title(self, full_title: str) -> str:
        """Extract short, meaningful product title for buttons"""

        account_type = ""
        if "Fresh" in full_title:
            account_type = "Fresh"
        elif "Full Verified" in full_title:
            account_type = "Full Verified"
        elif "Email Verified" in full_title:
            account_type = "Email Verified"
        elif "Mixed" in full_title:
            account_type = "Mixed"

        follower_range = ""
        if "0-9" in full_title:
            follower_range = "0-9"
        elif "10-29" in full_title:
            follower_range = "10-29"
        elif "30-99" in full_title:
            follower_range = "30-99"
        elif "100-499" in full_title:
            follower_range = "100-499"
        elif "500-999" in full_title:
            follower_range = "500-999"

        features = []
        if "NFT" in full_title:
            features.append("NFT")
        if "Email Access" in full_title:
            features.append("Email Access")

        if account_type and follower_range:
            return f"{account_type} {follower_range}"
        elif account_type and features:
            return f"{account_type} {' '.join(features)}"
        elif account_type:
            return account_type
        else:

            return (
                full_title.split("(")[0].split("Twitter")[1].strip()
                if "Twitter" in full_title
                else full_title.split(" ")[0]
            )

    async def cmd_orders(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not update.effective_user.id in self.BOT_OWNERS:
            await update.message.reply_text(
                "⛔ This command is only available to bot owners."
            )
            return

        args = context.args

        if not args:
            await update.message.reply_text(
                "Please specify a filter: `/orders all`, `/orders pending`, `/orders completed`, "
                "`/orders void`, `/orders email <email>`, or `/orders user <user_id>`",
                parse_mode="Markdown",
            )
            return

        filter_type = args[0].lower()
        try:
            if filter_type == "all":
                orders = await self.database.get_all_orders()
                await self._display_orders(update, orders, "All")

            elif filter_type in ["pending", "completed", "void"]:
                status = filter_type.capitalize()
                orders = await self.database.get_orders_by_status(status)
                await self._display_orders(update, orders, status)

            elif filter_type == "email" and len(args) > 1:
                email = args[1]
                orders = await self.database.get_orders_by_email(email)
                await self._display_orders(update, orders, f"Email ({email})")

            elif filter_type == "user" and len(args) > 1:
                try:
                    user_id = int(args[1])
                    orders = await self.database.get_orders_by_user_id(user_id)
                    await self._display_orders(update, orders, f"User ({user_id})")
                except ValueError:
                    await update.message.reply_text(
                        "Invalid user ID. Please provide a numeric user ID."
                    )

            else:
                await update.message.reply_text(
                    "Invalid filter. Use `/orders all`, `/orders pending`, etc.",
                    parse_mode="Markdown",
                )

        except Exception as e:
            await update.message.reply_text(f"Error retrieving orders: {str(e)}")

    async def _display_orders(self, update: Update, orders: list, title: str):
        if not orders:
            await update.message.reply_text(f"No {title.lower()} orders found.")
            return

        messages = []
        current_message = f"📋 *{title} Orders*\n\n"

        for order in orders:

            product_title = order.get("product_title", "Unknown Product")
            product_title_escaped = (
                product_title.replace("*", "\\*")
                .replace("_", "\\_")
                .replace("`", "\\`")
            )

            order_text = (
                f"*Order: {order['order_id'][:8]}*\n"
                f"Product: {product_title_escaped}\n"
                f"Status: {order['status']}\n"
                f"Amount: ${order['total_amount']:.2f}\n"
                f"Date: {order['created_at']}\n\n"
            )

            if len(current_message + order_text) > 3000:
                messages.append(current_message)
                current_message = f"📋 *{title} Orders (continued)*\n\n"

            current_message += order_text

        if current_message:
            messages.append(current_message)

        for i, msg in enumerate(messages):
            try:
                if i == 0:
                    await update.message.reply_text(msg, parse_mode="Markdown")
                else:
                    await self.send_msg(update, msg)
            except Exception as e:

                error_msg = str(e)
                if "entity" in error_msg.lower() or "parse" in error_msg.lower():

                    plain_msg = msg.replace("*", "").replace("_", "").replace("`", "")
                    if i == 0:
                        await update.message.reply_text(plain_msg)
                    else:
                        await self.send_msg(update, plain_msg)

    async def cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Handle the /status command for changing order status
        Usage:
        /status <order_id> complete [txid] [amount] - Marks order as completed
        /status <order_id> void - Voids/cancels an order
        /status <order_id> pending - Resets an order to pending status
        /status <order_id> refunded - Marks order as refunded
        """
        if not update.effective_user.id in self.BOT_OWNERS:
            await update.message.reply_text(
                "⛔ This command is only available to bot owners."
            )
            return

        args = context.args

        if len(args) < 2:
            await update.message.reply_text(
                "ℹ️ Usage:\n"
                "/status <order_id> complete [txid] [amount] - Mark as completed\n"
                "/status <order_id> void - Mark as voided/cancelled\n"
                "/status <order_id> pending - Reset to pending status\n"
                "/status <order_id> refunded - Mark as refunded"
            )
            return

        order_id = args[0]
        status_action = args[1].lower()

        try:
            order = await self.database.get_order_by_uuid(order_id)

            if not order:
                await update.message.reply_text(
                    f"❌ Order `{order_id}` not found", parse_mode="Markdown"
                )
                return

            if status_action == "complete":
                txid = args[2] if len(args) > 2 else "manual_completion"
                amount = (
                    float(args[3]) if len(args) > 3 else order.get("total_amount", 0)
                )

                payment_info = {
                    "txid": txid,
                    "amount": amount,
                    "currency": order.get("payment_currency", "MANUAL"),
                    "confirmed_by": update.effective_user.id,
                }

                success = await self.database.mark_order_delivered(
                    order_id, payment_info
                )

                if success:
                    await update.message.reply_text(
                        f"✅ Order `{order_id}` marked as completed",
                        parse_mode="Markdown",
                    )

                    product_id = order.get("product_id")
                    user_id = order.get("user_id")
                    quantity = order.get("quantity", 1)

                    discord_fields = [
                        {"name": "Order ID", "value": order_id, "inline": True},
                        {"name": "User ID", "value": str(user_id), "inline": True},
                        {"name": "Product ID", "value": product_id, "inline": True},
                        {"name": "Quantity", "value": str(quantity), "inline": True},
                        {
                            "name": "Total Amount",
                            "value": f"${order.get('total_amount', 0):.2f}",
                            "inline": True,
                        },
                        {
                            "name": "Payment Method",
                            "value": order.get("payment_currency", "MANUAL"),
                            "inline": True,
                        },
                        {"name": "Transaction ID", "value": txid, "inline": True},
                        {
                            "name": "Completed By",
                            "value": f"Admin ID: {update.effective_user.id}",
                            "inline": True,
                        },
                    ]

                    await self.send_discord_webhook(
                        title="✅ Bot Order Completed",
                        description=f"Order has been marked as completed",
                        color=0x2ECC71,
                        fields=discord_fields,
                    )
                else:
                    await update.message.reply_text(
                        f"❌ Failed to update order `{order_id}` status",
                        parse_mode="Markdown",
                    )

            elif status_action == "void":
                success = await self.database.update_order_status(order_id, "VOID")

                if success:
                    await update.message.reply_text(
                        f"✅ Order `{order_id}` marked as voided/cancelled",
                        parse_mode="Markdown",
                    )

                    discord_fields = [
                        {"name": "Order ID", "value": order_id, "inline": True},
                        {
                            "name": "User ID",
                            "value": str(order.get("user_id")),
                            "inline": True,
                        },
                        {
                            "name": "Product ID",
                            "value": order.get("product_id", "N/A"),
                            "inline": True,
                        },
                        {
                            "name": "Total Amount",
                            "value": f"${order.get('total_amount', 0):.2f}",
                            "inline": True,
                        },
                        {
                            "name": "Payment Method",
                            "value": order.get("payment_currency", "N/A"),
                            "inline": True,
                        },
                        {
                            "name": "Voided By",
                            "value": f"Admin ID: {update.effective_user.id}",
                            "inline": True,
                        },
                    ]

                    await self.send_discord_webhook(
                        title="❌ Order Voided",
                        description="Order has been voided/cancelled",
                        color=0xE74C3C,
                        fields=discord_fields,
                    )
                else:
                    await update.message.reply_text(
                        f"❌ Failed to void order `{order_id}`", parse_mode="Markdown"
                    )

            elif status_action == "pending":
                success = await self.database.update_order_status(order_id, "PENDING")

                if success:
                    await update.message.reply_text(
                        f"✅ Order `{order_id}` reset to pending status",
                        parse_mode="Markdown",
                    )

                    discord_fields = [
                        {"name": "Order ID", "value": order_id, "inline": True},
                        {
                            "name": "User ID",
                            "value": str(order.get("user_id")),
                            "inline": True,
                        },
                        {
                            "name": "Product ID",
                            "value": order.get("product_id", "N/A"),
                            "inline": True,
                        },
                        {
                            "name": "Total Amount",
                            "value": f"${order.get('total_amount', 0):.2f}",
                            "inline": True,
                        },
                        {
                            "name": "Payment Method",
                            "value": order.get("payment_currency", "N/A"),
                            "inline": True,
                        },
                        {
                            "name": "Status Changed By",
                            "value": f"Admin ID: {update.effective_user.id}",
                            "inline": True,
                        },
                    ]

                    await self.send_discord_webhook(
                        title="⏳ Order Set to Pending",
                        description="Order has been reset to pending status",
                        color=0xF39C12,
                        fields=discord_fields,
                    )
                else:
                    await update.message.reply_text(
                        f"❌ Failed to update order `{order_id}` status",
                        parse_mode="Markdown",
                    )

            elif status_action == "refunded":
                success = await self.database.update_order_status(order_id, "REFUNDED")

                if success:
                    await update.message.reply_text(
                        f"✅ Order `{order_id}` marked as refunded",
                        parse_mode="Markdown",
                    )

                    discord_fields = [
                        {"name": "Order ID", "value": order_id, "inline": True},
                        {
                            "name": "User ID",
                            "value": str(order.get("user_id")),
                            "inline": True,
                        },
                        {
                            "name": "Product ID",
                            "value": order.get("product_id", "N/A"),
                            "inline": True,
                        },
                        {
                            "name": "Total Amount",
                            "value": f"${order.get('total_amount', 0):.2f}",
                            "inline": True,
                        },
                        {
                            "name": "Payment Method",
                            "value": order.get("payment_currency", "N/A"),
                            "inline": True,
                        },
                        {
                            "name": "Refunded By",
                            "value": f"Admin ID: {update.effective_user.id}",
                            "inline": True,
                        },
                    ]

                    await self.send_discord_webhook(
                        title="💰 Order Refunded",
                        description="Order has been marked as refunded",
                        color=0x9B59B6,
                        fields=discord_fields,
                    )
                else:
                    await update.message.reply_text(
                        f"❌ Failed to update order `{order_id}` status",
                        parse_mode="Markdown",
                    )
            else:
                await update.message.reply_text(
                    "⚠️ Invalid status action. Use /status for help."
                )

        except Exception as e:
            self.debug.log(f"Error in cmd_status: {str(e)}")
            await update.message.reply_text(f"❌ Error updating order status: {str(e)}")

    async def _format_db_order(self, db_order: dict) -> dict:
        """Format database order to match SellApp structure"""
        product_title = await self.database.get_product_title(db_order["product_id"])
        customer_email = await self.database.get_customer_email(db_order["user_id"])

        product = await ProductTypes.get_product_by_id(db_order["product_id"])
        is_fresh = (
            product
            and hasattr(product.attributes, "fresh")
            and product.attributes.fresh
        )

        if (
            is_fresh
            and product_title
            and "fresh" not in product_title.lower()
            and "2025" not in product_title.lower()
        ):
            product_title = f"🆕 Fresh 2025 - {product_title}"

        return {
            "uniqid": db_order["order_id"],
            "product_title": product_title,
            "total": db_order["total_amount"],
            "status": db_order["status"],
            "customer_email": customer_email,
            "is_fresh": is_fresh,
        }

    async def get_email_orders(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Retrieve and display both SellApp and local orders based on email"""
        existing_email = await self.database.get_customer_email(
            update.effective_user.id
        )

        if existing_email:
            try:

                sellapp_orders = self.sellapp.get_all_orders()
                local_orders = await self.database.get_user_orders(
                    update.effective_user.id
                )

                if (
                    not sellapp_orders or "data" not in sellapp_orders
                ) and not local_orders:
                    await update.message.reply_text("🛍️ You do not have any orders")
                    return ConversationHandler.END

                sellapp_orders = [
                    order
                    for order in sellapp_orders.get("data", [])
                    if order.get("customer_email") == existing_email
                ]

                for order in sellapp_orders:

                    product_title = order.get("product_title", "")
                    if product_title and (
                        "fresh" in product_title.lower() or "2025" in product_title
                    ):
                        order["is_fresh"] = True
                    else:
                        order["is_fresh"] = False

                separator = "〰️" * 8

                fresh_sellapp = sum(1 for o in sellapp_orders if o.get("is_fresh"))

                formatted_local_orders = []
                for order in local_orders:
                    formatted_order = await self._format_db_order(order)
                    formatted_local_orders.append(formatted_order)

                fresh_local = sum(
                    1 for o in formatted_local_orders if o.get("is_fresh")
                )
                total_fresh = fresh_sellapp + fresh_local

                output = ["📊 *Your Orders*\n"]
                if total_fresh > 0:
                    output.append(f"🆕 *Fresh 2025 Accounts*: {total_fresh} orders\n")
                output.append(separator)

                sellapp_section = ["🌐 *SellApp Orders*", separator]
                if sellapp_orders:
                    for order in sellapp_orders:

                        title_display = order["product_title"]
                        if (
                            order.get("is_fresh")
                            and "fresh" not in title_display.lower()
                            and "2025" not in title_display.lower()
                        ):
                            title_display = f"🆕 Fresh 2025 - {title_display}"

                        sellapp_section.append(
                            f"```\n"
                            f"🆔 Order: {order['uniqid']}\n"
                            f"📦 Product: {title_display}\n"
                            f"💰 Total: ${float(order['total']):.2f}\n"
                            f"⚡ Status: {order['status']}\n"
                            f"```\n{separator}"
                        )
                else:
                    sellapp_section.append("No SellApp orders found\n" + separator)

                local_section = ["\n🏪 *Direct Bot Orders*", separator]
                if formatted_local_orders:
                    for order in formatted_local_orders:
                        local_section.append(
                            f"```\n"
                            f"🆔 Order: {order['uniqid']}\n"
                            f"📦 Product: {order['product_title']}\n"
                            f"💰 Total: ${float(order['total']):.2f}\n"
                            f"⚡ Status: {order['status']}\n"
                            f"📅 Date: {order.get('created_at', 'N/A')}\n"
                            f"```\n{separator}"
                        )
                else:
                    local_section.append("No direct bot orders found\n" + separator)

                all_lines = output + sellapp_section + local_section
                chunks = []
                current_chunk = ""
                for line in all_lines:
                    if len(current_chunk) + len(line) + 1 > MAX_MESSAGE_LENGTH:
                        chunks.append(current_chunk)
                        current_chunk = line
                    else:
                        current_chunk = (
                            f"{current_chunk}\n{line}" if current_chunk else line
                        )
                if current_chunk:
                    chunks.append(current_chunk)

                for i, chunk in enumerate(chunks):
                    pagination = (
                        f"\n📑 Page {i+1}/{len(chunks)}" if len(chunks) > 1 else ""
                    )
                    await update.message.reply_text(
                        f"{chunk}{pagination}", parse_mode="Markdown"
                    )

            except Exception as e:
                self.debug.log(f"Error fetching orders: {e}")
                await update.message.reply_text(f"⚠️ Error fetching orders: {str(e)}")

            return ConversationHandler.END
        else:
            context.user_data["state"] = "awaiting_email"
            await update.message.reply_text("📧 Please enter your email")
            return GET_EMAIL

    async def paginate_handler(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle pagination for product browsing"""
        query = update.callback_query
        products_per_page = 5
        total_pages = (len(self.products) + products_per_page - 1) // products_per_page

        if query.data == "browse_prev" and self.current_page > 0:
            self.current_page -= 1
        elif query.data == "browse_next" and self.current_page < total_pages - 1:
            self.current_page += 1

        category = context.user_data.get("current_category")
        follower_range = context.user_data.get("current_range")
        await self.show_products(
            update, category=category, follower_range=follower_range
        )

    async def select_product(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle product selection when user clicks a product button"""
        query = update.callback_query
        await query.answer()

        try:
            product_index = int(query.data.split("_")[1])
            if product_index >= len(self.products):
                await query.edit_message_text("❌ Product not found. Please try again.")
                return

            selected_product = self.products[product_index]
            stock_count = await ProductTypes.get_stock_count_for_product(
                selected_product.id
            )

            if stock_count == 0:
                await query.edit_message_text(
                    f"❌ Sorry, {selected_product.title} is currently out of stock.",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back", callback_data="back_to_products"
                                )
                            ]
                        ]
                    ),
                )
                return

            context.user_data["product_id"] = selected_product.id
            context.user_data["selected_product"] = selected_product
            context.user_data["product_price"] = selected_product.price

            email = await self.database.get_customer_email(update.effective_user.id)
            if not email:
                await query.edit_message_text(
                    "🔒 You need to be logged in to make a purchase.\n"
                    "Please use /login first.",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back", callback_data="back_to_products"
                                )
                            ]
                        ]
                    ),
                )
                return

            context.user_data["email"] = email

            display_title = selected_product.title
            if (
                hasattr(selected_product.attributes, "fresh")
                and selected_product.attributes.fresh
            ):
                if (
                    "fresh" not in display_title.lower()
                    and "2025" not in display_title.lower()
                ):
                    display_title = f"🆕 Fresh 2025 - {display_title}"

            attrs_text = []
            if selected_product.attributes.range:
                attrs_text.append(
                    f"👥 {selected_product.attributes.range[0]}-{selected_product.attributes.range[1]} Followers"
                )
            if selected_product.attributes.mail_access:
                attrs_text.append("📧 Email Access")
            if selected_product.attributes.fresh:
                attrs_text.append("🆕 Fresh 2025")
            elif selected_product.attributes.fully_verified:
                attrs_text.append("✅ Fully Verified")
            elif selected_product.attributes.unverified:
                attrs_text.append("⚠️ Unverified")

            attributes = "\n".join(attrs_text)
            if attributes:
                attributes = f"\n\n{attributes}"

            prompt = await query.edit_message_text(
                f"🛍️ *{display_title}*\n\n"
                f"💰 Price: ${selected_product.price:.2f}\n"
                f"📦 Stock: {stock_count} accounts{attributes}\n\n"
                "Enter quantity (number):",
                parse_mode="Markdown",
            )

            context.user_data["prompt_message_id"] = prompt.message_id
            context.user_data["state"] = "waiting_for_quantity"

        except Exception as e:
            self.debug.log(f"Error in select_product: {str(e)}")
            await query.edit_message_text(
                "❌ Error processing selection",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "🔙 Back", callback_data="back_to_products"
                            )
                        ]
                    ]
                ),
            )

    def _get_follower_ranges(self, products):
        """Extract and group follower ranges from products"""
        ranges = {}
        for product in products:
            if product.attributes.range:
                range_key = (
                    f"{product.attributes.range[0]}-{product.attributes.range[1]}"
                )
                ranges[range_key] = ranges.get(range_key, 0) + 1
        return sorted(ranges.keys(), key=lambda x: [int(n) for n in x.split("-")])

    async def handle_quantity_input(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle quantity input for product purchase"""
        if not update.message or not update.message.text:
            return

        try:
            user_id = update.effective_user.id
            quantity_text = update.message.text.strip()

            try:
                quantity = int(quantity_text)
                if quantity <= 0:
                    await update.message.reply_text("⚠️ Please enter a positive number")
                    return
            except ValueError:
                await update.message.reply_text("⚠️ Please enter a valid number")
                return

            try:
                await update.message.delete()
            except Exception as e:
                self.debug.log(f"Error deleting user message: {e}", send=False)

            prompt_message_id = context.user_data.get("prompt_message_id")
            if prompt_message_id:
                try:
                    await context.bot.delete_message(
                        chat_id=user_id, message_id=prompt_message_id
                    )
                except Exception as e:
                    self.debug.log(f"Error deleting prompt message: {e}", send=False)

            selected_product = context.user_data.get("selected_product")

            if not selected_product:
                await update.message.reply_text(
                    "❌ Session expired. Please start over",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back to Products",
                                    callback_data="back_to_products",
                                )
                            ]
                        ]
                    ),
                )
                return

            stock = await ProductTypes.get_stock_count_for_product(selected_product.id)

            if quantity > stock:
                await update.message.reply_text(
                    f"⚠️ Only {stock} items available.\n"
                    "Please enter a smaller quantity.",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back to Products",
                                    callback_data="back_to_products",
                                )
                            ]
                        ]
                    ),
                )
                return

            context.user_data["quantity"] = quantity
            total_price = selected_product.price * quantity

            display_title = selected_product.title
            if (
                hasattr(selected_product.attributes, "fresh")
                and selected_product.attributes.fresh
            ):
                if (
                    "fresh" not in display_title.lower()
                    and "2025" not in display_title.lower()
                ):
                    display_title = f"🆕 Fresh 2025 - {display_title}"

            attributes = []
            if selected_product.attributes.range:
                attributes.append(
                    f"👥 {selected_product.attributes.range[0]}-{selected_product.attributes.range[1]} Followers"
                )
            if (
                hasattr(selected_product.attributes, "fresh")
                and selected_product.attributes.fresh
            ):
                attributes.append("🆕 Fresh 2025 Account")
            if selected_product.attributes.mail_access:
                attributes.append("📧 Email Access")
            if selected_product.attributes.fully_verified:
                attributes.append("✅ Fully Verified")

            attributes_text = "\n".join(attributes)
            if attributes_text:
                attributes_text = f"\n\n{attributes_text}"

            summary = (
                "🛍️ *Order Summary*\n\n"
                f"📦 Product: {display_title}\n"
                f"📊 Quantity: {quantity}\n"
                f"💰 Price per item: ${selected_product.price:.2f}\n"
                f"💵 Total: ${total_price:.2f}{attributes_text}\n\n"
                "Would you like to use a coupon code?"
            )

            keyboard = [
                [
                    InlineKeyboardButton("Yes", callback_data="coupon_yes"),
                    InlineKeyboardButton("No", callback_data="coupon_no"),
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)

            await update.message.reply_text(
                summary, reply_markup=reply_markup, parse_mode="Markdown"
            )

        except Exception as e:
            self.debug.log(f"Quantity input error: {str(e)}")
            try:
                await update.message.reply_text(
                    "❌ Error processing quantity. Please try again."
                )
            except Exception:
                pass

    async def prompt_gateway(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show payment gateway options to the user"""
        if not context.user_data.get("selected_product"):
            if update.callback_query:
                await update.callback_query.edit_message_text(
                    "❌ Session expired. Please start over."
                )
            else:
                await update.message.reply_text(
                    "❌ Session expired. Please start over."
                )
            return

        product = context.user_data.get("selected_product")
        quantity = context.user_data.get("quantity", 1)

        if not product:
            await update.message.reply_text(
                "❌ Product selection expired. Please start over."
            )
            return

        total_price = float(product.price) * quantity

        coupon_code = context.user_data.get("coupon_code")
        if coupon_code:
            discount = await self.coupon_manager.get_coupon_discount(coupon_code)
            if discount:
                total_price = total_price * (1 - discount / 100)

        display_title = product.title
        if hasattr(product.attributes, "fresh") and product.attributes.fresh:
            if (
                "fresh" not in display_title.lower()
                and "2025" not in display_title.lower()
            ):
                display_title = f"🆕 Fresh 2025 - {display_title}"

        summary = (
            "🛍️ *Payment Selection*\n\n"
            f"📦 Product: {display_title}\n"
            f"📊 Quantity: {quantity}\n"
            f"💰 Total: ${total_price:.2f}\n\n"
            "Please select a payment method:"
        )

        keyboard = []

        if self.BINANCE_PAY_ENABLED:
            keyboard.append(
                [InlineKeyboardButton("Binance Pay", callback_data="network_binance")]
            )

        keyboard.extend(
            [
                [
                    InlineKeyboardButton(
                        "USDT (TRC20)", callback_data="network_usdt_trc20"
                    )
                ],
                [
                    InlineKeyboardButton(
                        "USDT (ERC20)", callback_data="network_usdt_erc20"
                    )
                ],
                [
                    InlineKeyboardButton(
                        "USDT (BEP20)", callback_data="network_usdt_bep20"
                    )
                ],
                [InlineKeyboardButton("Bitcoin (BTC)", callback_data="network_btc")],
                [InlineKeyboardButton("Ethereum (ETH)", callback_data="network_eth")],
                [InlineKeyboardButton("Litecoin (LTC)", callback_data="network_ltc")],
                [
                    InlineKeyboardButton(
                        "💬 Contact Support", url=f"https://t.me/vikingtokens"
                    )
                ],
                [InlineKeyboardButton("❌ Cancel", callback_data="cancel_payment")],
            ]
        )

        reply_markup = InlineKeyboardMarkup(keyboard)

        try:
            if update.callback_query:
                await update.callback_query.edit_message_text(
                    summary, reply_markup=reply_markup, parse_mode="Markdown"
                )
            else:
                await update.message.reply_text(
                    summary, reply_markup=reply_markup, parse_mode="Markdown"
                )
        except Exception as e:
            self.debug.log(f"Error in prompt_gateway: {e}")
            if update.callback_query:
                await update.callback_query.edit_message_text(
                    "❌ Error showing payment options. Please try again."
                )
            else:
                await update.message.reply_text(
                    "❌ Error showing payment options. Please try again."
                )

    async def handle_coupon_input(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle coupon code input from user"""
        if not update.message or not update.message.text:
            return

        try:
            user_id = update.effective_user.id
            coupon_code = update.message.text.strip().upper()

            try:
                await update.message.delete()
            except Exception as e:
                self.debug.log(f"Error deleting coupon message: {e}", send=False)

            selected_product = context.user_data.get("selected_product")
            if not selected_product:
                await update.message.reply_text(
                    "❌ Session expired. Please start over.",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back to Products",
                                    callback_data="back_to_products",
                                )
                            ]
                        ]
                    ),
                )
                return

            discount = await self.coupon_manager.get_coupon_discount(coupon_code)
            if not discount:
                await update.message.reply_text(
                    "❌ Invalid coupon code or coupon has expired.",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "Try Another", callback_data="coupon_yes"
                                ),
                                InlineKeyboardButton("Skip", callback_data="coupon_no"),
                            ]
                        ]
                    ),
                )
                return

            context.user_data["coupon_code"] = coupon_code
            context.user_data["coupon_discount"] = discount

            quantity = context.user_data.get("quantity", 1)
            original_price = selected_product.price * quantity
            discounted_price = original_price * (1 - discount / 100)

            await update.message.reply_text(
                f"✅ Coupon *{coupon_code}* applied!\n\n"
                f"💰 Original Price: ${original_price:.2f}\n"
                f"🔽 Discount: {discount}%\n"
                f"💵 Final Price: ${discounted_price:.2f}\n",
                parse_mode="Markdown",
            )

            context.user_data["state"] = "waiting_for_gateway"
            await self.prompt_gateway(update, context)
            return

        except Exception as e:
            self.debug.log(f"Coupon input error: {str(e)}")
            await update.message.reply_text(
                "❌ Error processing coupon. Please try again.",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "Try Another", callback_data="coupon_yes"
                            ),
                            InlineKeyboardButton("Skip", callback_data="coupon_no"),
                        ]
                    ]
                ),
            )

    async def create_binance_order(self, amount: float, currency: str = "USDT") -> dict:
        """Create a Binance Pay order"""
        timestamp = int(time.time() * 1000)
        nonce = "".join(random.choices(string.ascii_uppercase + string.digits, k=32))

        payload = {
            "env": {"terminalType": "WEB"},
            "merchantTradeNo": f"ORDER_{timestamp}",
            "orderAmount": amount,
            "currency": currency,
            "goods": {
                "goodsType": "01",
                "goodsCategory": "D000",
                "referenceGoodsId": "001",
                "goodsName": "Digital Product",
            },
        }

        payload_str = f"{timestamp}\n{nonce}\n{json.dumps(payload)}\n"
        signature = (
            hmac.new(
                self.binance_secret_key.encode("utf-8"),
                payload_str.encode("utf-8"),
                hashlib.sha512,
            )
            .hexdigest()
            .upper()
        )

        headers = {
            "Content-Type": "application/json",
            "BinancePay-Timestamp": str(timestamp),
            "BinancePay-Nonce": nonce,
            "BinancePay-Certificate-SN": self.binance_api_key,
            "BinancePay-Signature": signature,
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    "https://bpay.binanceapi.com/binancepay/openapi/v2/order",
                    headers=headers,
                    json=payload,
                ) as response:
                    return await response.json()
        except Exception as e:
            self.debug.log(f"Error creating Binance order: {e}")
            return None

    async def send_accounts_to_user(
        self,
        order_id: str,
        user_id: int,
        accounts_text: str,
        quantity: int,
        product_attrs: Optional[ProductAttributes] = None,
    ) -> None:
        """
        Send accounts to a user via Telegram using a temporary client.

        Args:
            order_id: The order ID
            user_id: The Telegram user ID to send the accounts to
            accounts_text: Text containing the account information
            quantity: Number of accounts being delivered
            product_attrs: Optional product attributes to customize the message
        """
        if not accounts_text:
            self.debug.log(f"No accounts to send to user {user_id}")
            return

        product_info = f"🎉 *Your Order is Ready!*\n\n"

        product_info += f"✅ *{quantity} accounts* have been delivered\n"

        product_info += f"📎 Your accounts are attached as a text file\n\n"
        product_info += f"Thank you for your purchase! If you need any assistance, please contact support."

        try:
            async with httpx.AsyncClient(timeout=60.0) as client:

                await client.post(
                    f"https://api.telegram.org/bot{config.TOKEN}/sendMessage",
                    json={
                        "chat_id": user_id,
                        "text": product_info,
                        "parse_mode": "Markdown",
                    },
                )

                filename = f"{order_id}.txt"
                accounts_bytes = accounts_text.encode("utf-8")
                files = {"document": (filename, accounts_bytes, "text/plain")}

                await client.post(
                    f"https://api.telegram.org/bot{config.TOKEN}/sendDocument",
                    data={"chat_id": user_id},
                    files=files,
                )

            self.debug.log(f"Successfully sent {quantity} accounts to user {user_id}")
        except Exception as e:
            error_trace = traceback.format_exc()
            error_msg = (
                f"Failed to send accounts to user {user_id}: {str(e)}\n{error_trace}"
            )
            self.debug.log(error_msg)
            await self.debug.notify_owner(error_msg)

    async def cmd_resend(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Resend order details to users (admin/owner only)"""
        if update.effective_user.id not in self.BOT_OWNERS:
            await update.message.reply_text(
                "❌ This command is only available to bot owners."
            )
            return

        parts = update.message.text.split()
        if len(parts) != 2:
            await update.message.reply_text("⚠️ Usage: /resend <order_id>")
            return

        order_id = parts[1].strip()
        status_message = await update.message.reply_text(
            f"🔍 Looking for order {order_id}..."
        )

        try:

            order = await self.database.get_order_by_uuid(order_id)
            if not order:

                orders = await self.database.get_all_orders()
                order = next((o for o in orders if o["order_id"] == order_id), None)

            if not order:
                await status_message.edit_text(
                    f"❌ Order {order_id} not found in database."
                )
                return

            user_id = order["user_id"]
            if not user_id:
                await status_message.edit_text(
                    f"❌ No user ID associated with order {order_id}."
                )
                return

            tmp_dir = Path("tmp")
            file_path = tmp_dir / f"{order_id}.txt"

            if not file_path.exists():
                await status_message.edit_text(
                    f"❌ File for order {order_id} not found at {file_path}"
                )
                return

            try:
                async with aiofiles.open(file_path, "r", encoding="utf-8") as f:
                    accounts_text = await f.read()
            except Exception as e:
                await status_message.edit_text(
                    f"❌ Failed to read accounts file: {str(e)}"
                )
                return

            if not accounts_text:
                await status_message.edit_text(
                    f"❌ Accounts file is empty for order {order_id}"
                )
                return

            quantity = len(accounts_text.strip().split("\n"))

            product_id = order.get("product_id")
            product_attrs = None
            if product_id:
                product = await ProductTypes.get_product_by_id(product_id)
                if product:
                    product_attrs = product.attributes

            await self.send_accounts_to_user(
                order_id, user_id, accounts_text, quantity, product_attrs
            )

            await status_message.edit_text(
                f"✅ Successfully resent order {order_id} to user ID {user_id}"
            )

            resend_message = (
                f"♻️ *Order Resent*\n\n"
                f"Order ID: `{order_id}`\n"
                f"User ID: `{user_id}`\n"
                f"Accounts: `{quantity}`\n"
                f"Resent by: `{update.effective_user.id}`"
            )
            await self.debug.notify_owner(resend_message)

            if (
                hasattr(config, "DISCORD_WEBHOOK_ENABLED")
                and config.DISCORD_WEBHOOK_ENABLED
            ):
                await self.send_discord_webhook(
                    title="♻️ Order Resent",
                    description=f"Order {order_id} was resent to the customer",
                    color=0xFFA500,
                    fields=[
                        {"name": "Order ID", "value": order_id, "inline": True},
                        {"name": "User ID", "value": str(user_id), "inline": True},
                        {"name": "Accounts", "value": str(quantity), "inline": True},
                        {
                            "name": "Resent by",
                            "value": str(update.effective_user.id),
                            "inline": True,
                        },
                    ],
                )

        except Exception as e:
            error_trace = traceback.format_exc()
            error_msg = f"Error resending order {order_id}: {str(e)}\n{error_trace}"
            self.debug.log(error_msg)
            await self.debug.notify_owner(error_msg)
            await status_message.edit_text(f"❌ Error resending order: {str(e)}")
