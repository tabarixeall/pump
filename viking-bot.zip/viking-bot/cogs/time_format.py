def format_time(seconds: float) -> str:
    """Format seconds into human readable time string"""
    if seconds < 60:
        return f"{seconds:.1f}s"

    minutes = seconds / 60
    if minutes < 60:
        return f"{minutes:.1f}m"

    hours = minutes / 60
    if hours < 24:
        return f"{hours:.1f}h"

    days = hours / 24
    return f"{days:.1f}d"


def format_rate(count: int, seconds: float) -> str:
    """Calculate and format processing rate"""
    if seconds <= 0:
        return "0/s"
    rate = count / seconds
    if rate < 1:
        return f"{rate:.2f}/s"
    if rate < 60:
        return f"{rate:.1f}/s"
    rate_per_min = rate * 60
    return f"{rate_per_min:.0f}/m"
