from telegram.ext import (
    Application,
    CommandHandler,
    ConversationHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
    ContextTypes,
    CallbackContext,
)
from src import db, debugger, cooldown
import os, re, sys, asyncio, warnings, aiohttp, config, aiohttp_socks, tempfile
from telegram import (
    Message,
    Update,
    MessageEntity,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
    ReplyParameters,
    ReplyKeyboardRemove,
)
from src.colors import *

import warnings
import sys
import time
import asyncio

warnings.filterwarnings("ignore")


if sys.platform == "win32" or sys.platform == "win64":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
else:
    asyncio.set_event_loop_policy(asyncio.DefaultEventLoopPolicy())
