from .utils import *
from datetime import datetime
from core.sorter.checker import Check
from core.product_api import RESTAPI
from cogs.decorators import owner
from core.queue_manager import TaskQueueManager
import asyncio


class Uploader:
    def __init__(self, main) -> None:
        self.debug: debugger.Debugger = main.debug
        self.database: db.DatabaseManager = main.database
        self.cooldown: cooldown.Cooldown = main.cooldown
        self.UPLOAD_DIR: str = main.UPLOAD_DIR
        self.BOT_OWNERS: list = main.BOT_OWNERS
        self.checker = None

        self.api = RESTAPI(self.database, self.debug)
        self.queue_manager: TaskQueueManager = main.queue_manager

    async def process_file(self, msg, file_content: bytes) -> None:
        try:
            text_content = file_content.decode("utf-8")
            lines = text_content.splitlines()
            if len(lines) == 0:
                return None

            tokens = list(
                set(tuple(combo.replace(";", ":").split(":")) for combo in lines)
            )
            total = len(tokens)

            status_msg = (
                "📊 *Checker Details*\n"
                f"├ Total Tokens: `{total:,}`\n"
                f"├ Status: `Initializing...`\n"
                f"└ Progress: `0/{total}` (0%)"
            )

            await msg.edit_text(status_msg, parse_mode="Markdown")

            start_time = datetime.now()
            task_id = f"upload_{datetime.now().strftime('%Y%m%d%H%M%S')}"

            await self.queue_manager.set_progress_updater(task_id, msg)

            self.checker = Check(self.database, self.queue_manager, task_id)
            self.checker.tracker.initial_total = total

            await self.queue_manager.add_task(
                task_id, self.checker._execute, tokens, update=False
            )
            await self.queue_manager.queue.join()

            await self.queue_manager.stop_task(task_id)

            end_time = datetime.now()
            duration = end_time - start_time

            tracker_status = await self.checker.tracker.get_status()
            final_details = {
                "followers": tracker_status["followers"],
                "normals": tracker_status["normals"],
                "golds": tracker_status["golds"],
                "blues": tracker_status["blues"],
                "greys": tracker_status["greys"],
                "chars": tracker_status["chars"],
                "blueplus": tracker_status["blueplus"],
                "unverified": tracker_status["unverified"],
                "suspended": tracker_status["suspended"],
                "locked": tracker_status["locked"],
                "failed": tracker_status["failed"],
                "invalids": tracker_status["invalids"],
                "rate_limited": tracker_status["rate_limited"],
                "errors": tracker_status["errors"],
                "mstats": tracker_status["mstats"],
            }

            status_lines = []
            for key, value in final_details.items():
                if isinstance(value, (int, float)) and value > 0:
                    status_lines.append(f"├ {key.title()}: `{value:,}`")

            locked_note = ""
            if final_details.get("locked", 0) > 0:
                locked_note = "\n\n*Note: Locked tokens have been saved to the database. Use /lockeds to retrieve them.*"

            final_msg = (
                f"✅ *Upload Completed*\n"
                f"├ Total Processed: `{self.checker.tracker.current}/{self.checker.initial_total:,}`\n"
                f"{chr(10).join(status_lines) if status_lines else ''}\n"
                f"└ Time Took: {duration.total_seconds():.1f}s"
                f"{locked_note}"
            )
            await msg.reply_text("Checker Completed.")
            await msg.edit_text(final_msg, parse_mode="Markdown")

            return True
        except asyncio.CancelledError:
            pass
        except Exception as e:
            import traceback

            traceback.print_exc()
            self.debug.log(f"Error in process_file: {str(e)}")
            await msg.edit_text("⚠️ An error occurred while processing the file.")
            return False
        finally:
            self.checker = None
            self.queue_manager.set_progress_callback(None)

    async def send_message(self, update, context, text: str, parse_mode="Markdown"):
        await update.message.reply_text(text, parse_mode=parse_mode)

    @owner()
    async def file_handler(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        if update.message.text and config.LOCAL_DOMAIN in update.message.text.lower():
            await self.local_download(update, context, update.message.text)
            return

        if not update.message.document.file_name.endswith(".txt"):
            await self.send_message(update, context, "⚠️ Please upload a TXT file.")
            return

        file = update.message.document
        file_id = file.file_id
        file_size = file.file_size

        if file_size > 20 * 1024 * 1024:
            await self.send_message(
                update,
                context,
                "⚠️ The file size is too large. Please upload a file less than 20MB.\n\nIf you have a large file you can use the internal upload api module.\nContact the developer for more information.",
            )
            return

        msg = await update.message.reply_text("⏳ Loading..")
        self.debug.log(
            f"File received from {update.message.from_user.id}, ID: {file_id}"
        )
        new_file = await context.bot.get_file(file_id)
        file_content = await new_file.download_as_bytearray()
        await msg.edit_text(
            "⏳ Please wait.. removing duplicates and checking the accounts."
        )
        self.debug.log(f"File downloaded: {file_id}")
        asyncio.create_task(self.process_file(msg, file_content))
        context.user_data.clear()

    @owner()
    async def download(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None: ...

    @owner()
    async def instruct(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        msg = (
            "If you have your accounts list, you can send it to bot by just uploading the file via dms and bot will automatically sort out the token formatting for you, it will run a checker on the accounts and save the valid ones.\n\n"
            "If you have a large file, you can use the internal upload api module.\n"
            "As of now, the url is [https://gaszip.app].\n\n"
        )
        await self.send_message(update, context, msg) # NOT USED, THE DOMAIN IS OFFLINE

    @owner()
    async def local_download(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE, message_content: str
    ) -> None:
        file_id = None

        if (
            not message_content.count("/")
            or config.LOCAL_DOMAIN not in message_content.lower()
        ):
            await self.send_message(
                update, context, "⚠️ Please provide a valid internal upload URL."
            )
            return
        else:
            file_id = message_content.split("/")[-1]

        try:
            if not file_id:
                await self.send_message(
                    update, context, "⚠️ Please provide a valid internal upload URL."
                )
                return

            msg = await update.message.reply_text("⏳ Initializing download...")
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{config.FILE_SERVER_URL}/{file_id}", headers={"x-key": "viking"}
                ) as response:
                    if response.status == 200:
                        total_size = int(response.headers.get("content-length", 0))
                        chunk_size = 8192
                        downloaded = 0
                        chunks = []
                        if total_size == 0:
                            await msg.edit_text("⚠️ File content is empty.")
                            return
                        async for chunk in response.content.iter_chunked(chunk_size):
                            chunks.append(chunk)
                            downloaded += len(chunk)

                            if (
                                total_size > 0
                                and downloaded % (total_size // 20) < chunk_size
                            ):
                                progress = (downloaded / total_size) * 100
                                await msg.edit_text(
                                    f"📥 *Downloading File*\n"
                                    f"├ Size: `{total_size/1024/1024:.1f}MB`\n"
                                    f"├ Downloaded: `{downloaded/1024/1024:.1f}MB`\n"
                                    f"└ Progress: `{progress:.1f}%`",
                                    parse_mode="Markdown",
                                )

                        file_content = b"".join(chunks)

                        await msg.edit_text("⏳ Processing file...")
                        asyncio.create_task(self.process_file(msg, file_content))
                    else:
                        await msg.edit_text(
                            "⚠️ Internal file not found or an error occurred."
                        )
                        return
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.debug.log(f"Error in get_file_from_server: {str(e)}")
            pass
            await self.send_message(
                update, context, "⚠️ An error occurred while fetching the file."
            )
        except Exception as e:
            self.debug.log(f"Error in get_file_from_server: {str(e)}")
            await self.send_message(
                update, context, "⚠️ An error occurred while fetching the file."
            )
