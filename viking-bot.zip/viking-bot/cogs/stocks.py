import telegram
from .utils import *
import os, config
from core import client
from datetime import datetime
from io import BytesIO
from core.product_api import RESTAPI
from core.client import change_bulk_pfp_banner
from cogs.decorators import owner
from difflib import get_close_matches
from core.queue_manager import TaskQueueManager
from core.sorter.checker import Check
from src.products import Types
import re
from core.securer_port.tg_securer import TelegramSecurityEnhancer
import asyncio
import random
from time import sleep
import shutil
import traceback
from core.securer_port.secure import SecurityEnhancer
import zipfile
from src.products import ProductTypes

SELL = 1
CONFIRM_CLEAR = 2
CONFIRM_FV = 3

class stocks:
    def __init__(self, main) -> None:
        self.main = main
        self.debug: debugger.Debugger = main.debug
        self.database: db.DatabaseManager = main.database
        self.cooldown: cooldown.Cooldown = main.cooldown
        self.UPLOAD_DIR: str = main.UPLOAD_DIR
        self.BOT_OWNERS: list = main.BOT_OWNERS
        self.config = main.config
        self.queue_manager: TaskQueueManager = main.queue_manager
        self.rest = RESTAPI(self.debug, self.database)
        self.account_types = {
            "mstat": "mstats",
            "mstatss": "mstats",
            "mstats": "mstats",
            "follow": Types.FOLLOWERS,
            "follows": Types.FOLLOWERS,
            "follower": Types.FOLLOWERS,
            "followers": Types.FOLLOWERS,
            "blue": Types.BLUES,
            "blues": Types.BLUES,
            "grey": Types.GREYS,
            "greys": Types.GREYS,
            "gray": Types.GREYS,
            "grays": Types.GREYS,
            "gold": Types.GOLD,
            "golds": Types.GOLD,
            "normal": Types.NORMAL,
            "normals": Types.NORMAL,
            "norm": Types.NORMAL,
            "blueplus": Types.BLUEPLUS,
            "blueplusses": Types.BLUEPLUS,
            "unverified": Types.UNVERIFIED,
            "chars": Types.CHARS,
            "char": Types.CHARS,
            "characters": Types.CHARS,
            "human": "human",
            "nft": "nft",
        }
        self.PRICE = float(config.PRICE_PER_FOLLOWER)
        self.BLUE_STANDARD_PRICE = float(config.PRICE_BLUE)
        self.BLUE_PLUS_STANDARD_PRICE = float(config.PRICE_BLUE_PLUS)
        self.GREY_GOLD_STANDARD_PRICE = float(config.PRICE_GREY_GOLD)
        self.CHAR_STANDARD_PRICE = float(config.PRICE_CHARS)
        self.MSTAT_STANDARD_PRICE = float(getattr(config, "PRICE_MSTATS", 0))

    async def reload_prices(self):
        """Reload prices from config"""
        try:
            self.PRICE = float(config.PRICE_PER_FOLLOWER)
            self.BLUE_STANDARD_PRICE = float(config.PRICE_BLUE)
            self.BLUE_PLUS_STANDARD_PRICE = float(config.PRICE_BLUE_PLUS)
            self.GREY_GOLD_STANDARD_PRICE = float(config.PRICE_GREY_GOLD)
            self.CHAR_STANDARD_PRICE = float(config.PRICE_CHARS)
            self.MSTAT_STANDARD_PRICE = float(getattr(config, "PRICE_MSTATS", 0))
            self.debug.log("Prices reloaded from config")
        except Exception as e:
            self.debug.log(f"Error reloading prices: {e}")

    def safe_convert_followers(self, follower_count):
        try:
            return int(follower_count)
        except (ValueError, TypeError):
            return 1

    async def get_account_type(
        self, input_type: str | list[str], update: Update = None
    ) -> str:
        """Helper method to get standardized account type using fuzzy matching"""
        if isinstance(input_type, list):
            for arg in input_type:
                if arg in self.account_types:
                    return self.account_types[arg]
            return None

        if not input_type:
            return None

        input_str = input_type.lower()

        if input_str in self.account_types:
            return self.account_types[input_str]

        matches = get_close_matches(
            input_str, self.account_types.keys(), n=1, cutoff=0.6
        )
        if matches and update:
            corrected_type = matches[0]
            final_type = self.account_types[corrected_type]
            await update.message.reply_text(
                f"Did you mean *{final_type}*? I'll proceed with that.",
                parse_mode="Markdown",
            )
            return self.account_types[corrected_type]
        return None

    async def post_stock_list(self, update: Update, text: str):
        if text.endswith("\n"):
            text = text[:-1]

        while text:
            if len(text) <= 4096:
                await update.message.reply_text(
                    f"\n{text}\n", parse_mode="Markdown", disable_web_page_preview=True
                )
                break
            else:
                index = text.rfind("\n", 0, 4096)
                if index == -1:
                    index = 4096
                await update.message.reply_text(
                    f"\n{text[:index]}\n",
                    parse_mode="Markdown",
                    disable_web_page_preview=True,
                )
                text = text[index:]

    async def post_accounts(
        self, update: Update, text: str, sell=False, customer_name=None
    ):
        file_content = BytesIO(text.encode("utf-8"))
        file_content.name = (
            customer_name if sell else f"stocks_{datetime.now().strftime('%m_%d')}.txt"
        )

        result = await update.message.reply_document(document=file_content)
        self.debug.log(f"Telegram API response: {result}")

    @owner()
    async def stock_count(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.message.from_user.id
        context.user_data["state"] = "Get Stocks Stats"

        if user_id in self.BOT_OWNERS:
            if not await self.cooldown.check(update.message.from_user.id, "stocks"):
                await update.message.reply_text(
                    config.COOLDOWN_MESSAGE, parse_mode="Markdown"
                )
                return

            followers, blue, grey, gold, normals, blueplus, chars = (
                [],
                [],
                [],
                [],
                [],
                [],
                [],
            )

            custom_range = None
            secured_only = False
            if context.args:
                lowered_args = [a.lower() for a in context.args]
                if "secured" in lowered_args:
                    secured_only = True
            if len(context.args) >= 2 and context.args[0].lower() in [
                "follow",
                "follower",
                "followers",
            ]:
                try:
                    range_arg = context.args[1].lower()
                    if "k" in range_arg:
                        start, end = range_arg.split("-")
                        end = end.replace("k", "000")
                        custom_range = (int(start) * 1000, int(end))
                except (ValueError, IndexError):
                    await update.message.reply_text(
                        "Invalid range format. Examples:\n"
                        "• `/stock follow 1-10k`\n"
                        "• `/stock follow 10-50k`",
                        parse_mode="Markdown",
                    )
                    return
            if context.args and "mstat" in context.args[0].lower():
                mstats_accounts = await self.database.get_mstats_accounts()
                if secured_only:
                    mstats_accounts = [acc for acc in mstats_accounts if acc.get("backup_code") and acc.get("backup_code") not in ["", "None", "0"]]
                if mstats_accounts:
                    text = f"*Mstats Accounts* ({len(mstats_accounts):,})\n\n"
                    verification_groups = {
                        "fv": [], "pv": [], "ev": [], "uv": []
                    }
                    for acc in mstats_accounts:
                        v_type = acc.get("verified", "unknown")
                        if v_type in verification_groups:
                            verification_groups[v_type].append(acc)
                    ranges = [
                        (100, 249),
                        (250, 499),
                        (500, 749),
                        (750, 999)
                    ]
                    for v_type, accounts in verification_groups.items():
                        if accounts:
                            v_label = {
                                "fv": "Fully Verified",
                                "pv": "Phone Verified",
                                "ev": "Email Verified",
                                "uv": "Unverified"
                            }.get(v_type, v_type.upper())
                            text += f"*{v_label} Accounts* ({len(accounts):,})\n"
                            for range_start, range_end in ranges:
                                range_accounts = [
                                    acc for acc in accounts
                                    if acc.get("followers", "").isdigit() 
                                    and range_start <= int(acc["followers"]) <= range_end
                                ]
                                if range_accounts:
                                    text += f"├ {range_start}-{range_end} followers: {len(range_accounts):,}\n"
                                    sorted_accounts = sorted(
                                        range_accounts,
                                        key=lambda x: int(x["followers"]),
                                        reverse=True
                                    )
                                    for acc in sorted_accounts:
                                        text += f"├ `https://x.com/{acc['username']}` | {acc['followers']} | **${self.main.get_mstats_static_price(acc):,.2f}**\n"
                            text += "\n"
                    while text:
                        if len(text) <= 4096:
                            await update.message.reply_text(
                                f"\n{text}\n",
                                parse_mode="Markdown",
                                disable_web_page_preview=True,
                            )
                            break
                        else:
                            index = text.rfind("\n", 0, 4096)
                            if index == -1:
                                index = 4096
                            await update.message.reply_text(
                                f"\n{text[:index]}\n",
                                parse_mode="Markdown",
                                disable_web_page_preview=True,
                            )
                            text = text[index:]
                else:
                    await update.message.reply_text(
                        "⚠️ No mstats accounts found in the stock.",
                        parse_mode="Markdown",
                    )
                return
            if context.args and context.args[0].lower() in ["follow", "follower", "followers"]:
                followers = await self.database.get_follower_accounts()
                if secured_only:
                    followers = [acc for acc in followers if acc.get("backup_code") and acc.get("backup_code") not in ["", "None", "0"]]
            elif not context.args:
                followers = await self.database.get_follower_accounts()
                blue = await self.database.get_blue_accounts()
                grey = await self.database.get_grey_accounts()
                gold = await self.database.get_gold_accounts()
                normals = await self.database.get_normal_accounts()
                blueplus = await self.database.get_blueplus_accounts()
                chars = await self.database.get_chars_accounts()
                mstats = await self.database.get_mstats_accounts()
            elif custom_range:
                followers = await self.database.get_follower_accounts()
                followers = [
                    acc
                    for acc in followers
                    if acc.get("followers", "").isdigit()
                    and custom_range[0] <= int(acc["followers"]) <= custom_range[1]
                ]
            else:
                account_type = await self.get_account_type(context.args[0], update)
                if account_type == Types.FOLLOWERS:
                    followers = await self.database.get_follower_accounts()
                    if secured_only:
                        followers = [acc for acc in followers if acc.get("backup_code") and acc.get("backup_code") not in ["", "None", "0"]]
                elif account_type == Types.BLUES:
                    blue = await self.database.get_blue_accounts()
                elif account_type == Types.GREYS:
                    grey = await self.database.get_grey_accounts()
                elif account_type == Types.GOLD:
                    gold = await self.database.get_gold_accounts()
                elif account_type == Types.NORMAL:
                    normals = await self.database.get_normal_accounts()
                elif account_type == Types.BLUEPLUS:
                    blueplus = await self.database.get_blueplus_accounts()
                elif account_type == Types.CHARS:
                    chars = await self.database.get_chars_accounts()
                elif account_type == Types.MSTATS:
                    mstats = await self.database.get_mstats_accounts()
                else:
                    await update.message.reply_text(
                        "Invalid argument. Please use /stock command to get the stock stats."
                    )
                    return

            __statmsg = await update.message.reply_text(
                "📊 *Listing stocks..*", parse_mode="Markdown"
            )

            message = str()

            if normals:
                total_accounts = len(normals)
                message += f"📊 *Normal Accounts* ({total_accounts})\n\n"
                verification_types = {
                    "fv": "Fully Verified",
                    "pv": "Phone Verified",
                }
                ranges = [
                    (0, 9, "0-9"),
                    (10, 29, "10-29"),
                    (30, 99, "30-99"),
                    (100, 499, "100-499"),
                    (500, 999, "500-999"),
                ]

                verification_totals = {v_type: 0 for v_type in verification_types}

                for v_type, v_display in verification_types.items():
                    v_type_accounts = [
                        acc for acc in normals if acc.get("verified") == v_type
                    ]
                    if v_type_accounts:
                        v_type_total = len(v_type_accounts)
                        verification_totals[v_type] = v_type_total

                        message += f"*{v_display} Accounts* ({v_type_total:,})\n"

                        range_totals = 0
                        for range_start, range_end, range_display in ranges:
                            count = len(
                                [
                                    acc
                                    for acc in v_type_accounts
                                    if acc.get("followers") is None
                                    or (
                                        str(acc["followers"]).isdigit()
                                        and range_start
                                        <= int(acc["followers"])
                                        <= range_end
                                    )
                                ]
                            )
                            if count > 0:
                                range_totals += count
                                message += f"├ {range_display} followers: {count:,}\n"

                        if range_totals != v_type_total:
                            message += f"├ Other: {v_type_total - range_totals:,}\n"

                        message += "\n"

                mixed_accounts = [
                    acc for acc in normals if acc.get("verified") in ["ev", "uv"]
                ]
                mixed_total = len(mixed_accounts)

                if mixed_total > 0:
                    message += f"*Mixed Accounts* (EV + UV) ({mixed_total:,})\n"
                    range_totals = 0
                    for range_start, range_end, range_display in ranges:
                        count = len(
                            [
                                acc
                                for acc in mixed_accounts
                                if acc.get("followers") is None
                                or (
                                    str(acc["followers"]).isdigit()
                                    and range_start
                                    <= int(acc["followers"])
                                    <= range_end
                                )
                            ]
                        )
                        if count > 0:
                            range_totals += count
                            message += f"├ {range_display} followers: {count:,}\n"

                    if range_totals != mixed_total:
                        message += f"├ Other: {mixed_total - range_totals:,}\n"
                    message += "\n"

                total_verified = sum(verification_totals.values()) + mixed_total
                if total_verified != total_accounts:
                    message += f"⚠️ *Note:* {total_accounts - total_verified:,} accounts have unknown verification status\n\n"

            if followers:
                message += f"👥 *Followers Account* ({len(followers)})"
                ranges = [
                    (1, 10000),
                    (10001, 20000),
                    (20001, 50000),
                    (50001, 100000),
                    (100001, float("inf")),
                ]

                valid_followers = [
                    acc
                    for acc in followers
                    if acc.get("followers")
                    and str(acc["followers"]).isdigit()
                    and int(acc["followers"]) > 0
                ]

                for range_start, range_end in ranges:
                    range_accounts = [
                        acc
                        for acc in valid_followers
                        if range_start <= int(acc["followers"]) <= range_end
                    ]

                    if range_accounts:
                        sorted_accounts = sorted(
                            range_accounts,
                            key=lambda x: int(x["followers"]),
                            reverse=True,
                        )
                        range_label = (
                            f"{range_start:,}-{range_end:,}"
                            if range_end != float("inf")
                            else f"{range_start:,}+"
                        )
                        message += f"\n*{range_label} Followers:*\n"
                        message += (
                            "\n".join(
                                [
                                    f"`https://x.com/{acc['username']}` | {acc['followers']} | **${int(acc['followers']) * self.PRICE:,.2f}**"
                                    for acc in sorted_accounts
                                ]
                            )
                            + "\n"
                        )

            if blue:
                message += f"\n🔵 *Blue Account* ({len(blue)})\n"
                ranges = [
                    (1, 10000),
                    (10001, 20000),
                    (20001, 50000),
                    (50001, 100000),
                    (100001, float("inf")),
                ]

                valid_blue = [
                    acc
                    for acc in blue
                    if acc.get("followers")
                    and str(acc["followers"]).isdigit()
                    and int(acc["followers"]) > 0
                ]

                for range_start, range_end in ranges:
                    range_accounts = [
                        acc
                        for acc in valid_blue
                        if range_start <= int(acc["followers"]) <= range_end
                    ]

                    if range_accounts:
                        sorted_accounts = sorted(
                            range_accounts,
                            key=lambda x: int(x["followers"]),
                            reverse=True,
                        )
                        range_label = (
                            f"{range_start:,}-{range_end:,}"
                            if range_end != float("inf")
                            else f"{range_start:,}+"
                        )
                        message += f"\n*{range_label} Followers:*\n"
                        message += (
                            "\n".join(
                                [
                                    f"`https://x.com/{acc['username']}` | {acc['followers']} | **${self.BLUE_STANDARD_PRICE + (int(acc['followers']) * self.PRICE if int(acc['followers']) >= 1000 else 0):,.2f}**"
                                    for acc in sorted_accounts
                                ]
                            )
                            + "\n"
                        )

            if blueplus:
                message += f"\n🔵 *Blue Plus Account* ({len(blueplus)})\n"
                ranges = [
                    (1, 10000),
                    (10001, 20000),
                    (20001, 50000),
                    (50001, 100000),
                    (100001, float("inf")),
                ]

                valid_blueplus = [
                    acc
                    for acc in blueplus
                    if acc.get("followers")
                    and str(acc["followers"]).isdigit()
                    and int(acc["followers"]) > 0
                ]

                for range_start, range_end in ranges:
                    range_accounts = [
                        acc
                        for acc in valid_blueplus
                        if range_start <= int(acc["followers"]) <= range_end
                    ]

                    if range_accounts:
                        sorted_accounts = sorted(
                            range_accounts,
                            key=lambda x: int(x["followers"]),
                            reverse=True,
                        )
                        range_label = (
                            f"{range_start:,}-{range_end:,}"
                            if range_end != float("inf")
                            else f"{range_start:,}+"
                        )
                        message += f"\n*{range_label} Followers:*\n"
                        message += (
                            "\n".join(
                                [
                                    f"`https://x.com/{acc['username']}` | {acc['followers']} | **${self.BLUE_PLUS_STANDARD_PRICE + (int(acc['followers']) * self.PRICE if int(acc['followers']) >= 1000 else 0):,.2f}**"
                                    for acc in sorted_accounts
                                ]
                            )
                            + "\n"
                        )

            if grey:
                message += f"\n⚫ *Grey Account* ({len(grey)})\n"
                ranges = [
                    (1, 10000),
                    (10001, 20000),
                    (20001, 50000),
                    (50001, 100000),
                    (100001, float("inf")),
                ]

                valid_grey = [
                    acc
                    for acc in grey
                    if acc.get("followers")
                    and str(acc["followers"]).isdigit()
                    and int(acc["followers"]) > 0
                ]

                for range_start, range_end in ranges:
                    range_accounts = [
                        acc
                        for acc in valid_grey
                        if range_start <= int(acc["followers"]) <= range_end
                    ]

                    if range_accounts:
                        sorted_accounts = sorted(
                            range_accounts,
                            key=lambda x: int(x["followers"]),
                            reverse=True,
                        )
                        range_label = (
                            f"{range_start:,}-{range_end:,}"
                            if range_end != float("inf")
                            else f"{range_start:,}+"
                        )
                        message += f"\n*{range_label} Followers:*\n"
                        message += (
                            "\n".join(
                                [
                                    f"`https://x.com/{acc['username']}` | {acc['followers']} | **${self.GREY_GOLD_STANDARD_PRICE + (int(acc['followers']) * self.PRICE if int(acc['followers']) >= 1000 else 0):,.2f}**"
                                    for acc in sorted_accounts
                                ]
                            )
                            + "\n"
                        )

            if gold:
                message += f"\n🟡 *Gold Account* ({len(gold)})\n"
                ranges = [
                    (1, 10000),
                    (10001, 20000),
                    (20001, 50000),
                    (50001, 100000),
                    (100001, float("inf")),
                ]

                valid_gold = [
                    acc
                    for acc in gold
                    if acc.get("followers")
                    and str(acc["followers"]).isdigit()
                    and int(acc["followers"]) > 0
                ]

                for range_start, range_end in ranges:
                    range_accounts = [
                        acc
                        for acc in valid_gold
                        if range_start <= int(acc["followers"]) <= range_end
                    ]

                    if range_accounts:
                        sorted_accounts = sorted(
                            range_accounts,
                            key=lambda x: int(x["followers"]),
                            reverse=True,
                        )
                        range_label = (
                            f"{range_start:,}-{range_end:,}"
                            if range_end != float("inf")
                            else f"{range_start:,}+"
                        )
                        message += f"\n*{range_label} Followers:*\n"
                        message += (
                            "\n".join(
                                [
                                    f"`https://x.com/{acc['username']}` | {acc['followers']} | **${self.GREY_GOLD_STANDARD_PRICE + (int(acc['followers']) * self.PRICE if int(acc['followers']) >= 1000 else 0):,.2f}**"
                                    for acc in sorted_accounts
                                ]
                            )
                            + "\n"
                        )

            if chars:
                message += f"\n🎯 *Chars Account* ({len(chars)})\n"
                valid_chars = [
                    acc
                    for acc in chars
                    if acc.get("followers") and str(acc["followers"]).isdigit()
                ]

                if valid_chars:
                    sorted_accounts = sorted(
                        valid_chars, key=lambda x: len(x["username"])
                    )
                    message += (
                        "\n".join(
                            [
                                f"`https://x.com/{acc['username']}` | {acc['followers']} | **${self.CHAR_STANDARD_PRICE + (float(acc['followers']) * self.PRICE):,.2f}**"
                                for acc in sorted_accounts
                            ]
                        )
                        + "\n"
                    )

            if not message:
                message = "⚠️ No accounts found in the stock."

            await __statmsg.delete()

            await self.post_stock_list(update, message)

            context.user_data["state"] = None
            return

    @owner()
    async def getstock(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        try:
            if not await self.cooldown.check(update.message.from_user.id, "getstock"):
                await update.message.reply_text(
                    config.COOLDOWN_MESSAGE, parse_mode="Markdown"
                )
                return

            if not context.args:
                await update.message.reply_text(
                    "⚠️ Usage: `/getstock <type> [options]`\n\n"
                    "*Account Types:*\n"
                    "• `normal` - Normal accounts\n"
                    "• `blue` - Blue verified accounts\n"
                    "• `blueplus` - Blue Plus accounts\n"
                    "• `grey` - Grey verified accounts\n"
                    "• `gold` - Gold verified accounts\n"
                    "• `follower` - Follower accounts\n"
                    "• `chars` - Character accounts\n"
                    "• `all` - All account types\n\n"
                    "*Options:*\n"
                    "• `0-9`, `10-29`, etc - Follower range\n"
                    "• `fv` - Fully verified accounts (normal only)\n"
                    "• `ev` - Email verified accounts (normal only)\n"
                    "• `pv` - Phone verified accounts (normal only)\n"
                    "• `uv` - Unverified accounts (normal only)\n"
                    "• `ma` - Mail access accounts\n"
                    "• `mixed` - Mixed verification accounts (UV+EV)\n"
                    "• `<number>` - Limit number of accounts\n\n"
                    "*Examples:*\n"
                    "• `/getstock normal 0-9 fv` - FV normal accounts with 0-9 followers\n"
                    "• `/getstock normal mixed 0-9` - Mixed verification accounts with 0-9 followers\n"
                    "• `/getstock blue ma` - Blue accounts with mail access\n"
                    "• `/getstock follower 100` - 100 follower accounts\n"
                    "• `/getstock chars` - All character accounts\n"
                    "• `/getstock all` - All accounts from all types",
                    parse_mode="Markdown",
                )
                return

            self.debug.log(f"Getting stock for input type: {context.args[0]}")

            account_type = context.args[0].lower()

            if account_type == "all":
                self.debug.log("Getting all account types")
                all_accounts = []

                account_types = [
                    "normal",
                    "blue",
                    "grey",
                    "gold",
                    "follower",
                    "blueplus",
                    "chars",
                    "mstats",
                ]
                all_accounts = [
                    acc
                    for acc_type in account_types
                    for acc in await getattr(
                        self.database, f"get_{acc_type}_accounts"
                    )()
                ]

                self.debug.log(f"Total accounts: {len(all_accounts)}")
                accounts = all_accounts
            else:

                account_type = await self.get_account_type(account_type)
                self.debug.log(f"Resolved account type: {account_type}")

                if not account_type:
                    await update.message.reply_text(
                        "Invalid account type. Use /getstock for usage info."
                    )
                    return

                method_name = f"get_{account_type}_accounts"
                self.debug.log(f"Calling database method: {method_name}")
                accounts = await getattr(self.database, method_name)()
                self.debug.log(f"Found {len(accounts)} accounts")

            if not accounts:
                await update.message.reply_text(f"No accounts found in database.")
                return

            filters = {
                "quantity": None,
                "verification": None,
                "mail_access": False,
                "range_min": None,
                "range_max": None,
                "secured": False,
            }

            for arg in context.args[1:]:
                arg = arg.lower().strip()

                if "-" in arg:
                    try:
                        min_val, max_val = map(int, arg.split("-"))
                        filters["range_min"] = min(min_val, max_val)
                        filters["range_max"] = max(min_val, max_val)
                    except ValueError:
                        pass
                elif arg in ["fv", "ev", "pv", "uv", "mixed"]:
                    filters["verification"] = arg
                elif arg == "ma":
                    filters["mail_access"] = True
                elif arg.isdigit():
                    filters["quantity"] = int(arg)
                elif arg.lower() == "secured":
                    filters["secured"] = True

            msg = await update.message.reply_text("⏳ Fetching accounts..")

            filtered_accounts = accounts.copy()

            if (account_type in ["normal", "all", "mstats"]) and filters["verification"]:
                if filters["verification"] == "mixed":
                    filtered_accounts = [
                        acc
                        for acc in filtered_accounts
                        if acc.get("verified", "").lower() in ["uv", "ev"]
                    ]
                else:
                    filtered_accounts = [
                        acc
                        for acc in filtered_accounts
                        if acc.get("verified", "").lower() == filters["verification"]
                    ]

            if filters["range_min"] is not None and filters["range_max"] is not None:
                filtered_accounts = [
                    acc
                    for acc in filtered_accounts
                    if (
                        acc.get("followers", "").isdigit()
                        and filters["range_min"]
                        <= int(acc["followers"])
                        <= filters["range_max"]
                    )
                ]

            if filters["mail_access"]:
                filtered_accounts = [
                    acc for acc in filtered_accounts if acc.get("mailpwd")
                ]

            if filters["quantity"] and filters["quantity"] > 0:
                filtered_accounts = filtered_accounts[: filters["quantity"]]

            if filters.get("secured"):
                filtered_accounts = [acc for acc in filtered_accounts if acc.get("backup_code") and acc.get("backup_code") not in ["", "None", "0"]]

            if not filtered_accounts:
                await msg.edit_text("No accounts match the specified criteria.")
                return

            desired_keys = [
                "username",
                "password",
                "email",
                "mailpwd",
                "ct0",
                "auth",
                "backup_code",
            ]

            timenow = datetime.now().strftime("%Y_%m_%d_%H_%M")
            content = "\n".join(
                ":".join(str(acc.get(key, "")) for key in desired_keys if acc.get(key))
                for acc in filtered_accounts
            )

            file_content = BytesIO(content.encode("utf-8"))
            file_name = f"{account_type}_accounts_{timenow}.txt"
            file_content.name = file_name

            await msg.edit_text(f"✅ Found {len(filtered_accounts)} matching accounts")
            await update.message.reply_document(document=file_content)

        except Exception as e:
            self.debug.log(f"Error in getstock: {str(e)}")
            await update.message.reply_text(
                "An error occurred while processing your request."
            )
            return

    @owner()
    async def sell(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.message.from_user.id not in self.BOT_OWNERS:
            context.user_data.clear()
            return ConversationHandler.END

        if not await self.cooldown.check(update.message.from_user.id, "sell"):
            context.user_data.clear()
            return await send_reply(config.COOLDOWN_MESSAGE)

        context.user_data.clear()
        context.user_data.update(
            {
                "state": "Sell Stocks",
                "account_type": None,
                "change_pfp": False,
                "customer_name": None,
                "quantity": None,
                "verification": None,
                "mail_access": False,
                "range": (1, 9),
                "secured": False,
            }
        )

        invalid_usage_message = (
            "How to use the /sell command? See the examples below:\n\n"
            "**For normal/unverified accounts:**\n"
            "∙ `/sell 0-9 1000 John`\n"
            "∙ `/sell 0-9 ma 1000 John`\n"
            "∙ `/sell 0-9 uv 1000 John`\n"
            "∙ `/sell 0-9 fv 1000 John`\n"
            "∙ `/sell 0-9 mixed 1000 John`\n"
            "∙ `/sell mstats John`\n\n"
            "**For other accounts:**\n"
            "∙ `/sell follow pfp John`\n"
            "∙ `/sell blue pfp John`\n"
            "∙ `/sell grey pfp John`\n"
            "∙ `/sell gold pfp John`\n"
            "When using the command for other accounts or mstats, the bot will prompt you to send a message containing the profile links.\n"
            "For mstats, only accounts with 100-999 followers will be considered.\n"
            "To check the current stock, use /stock.\n\n"
            "**Important Notes:**\n"
            "- Quantity specification is only supported for normal accounts (except mstats).\n"
            "- Changing profile pictures (PFPs) is a complex task that may take some time, so please be patient.\n"
            "- You can paste profile links in one message or across multiple messages — it doesn't matter.\n"
            "- The bot will automatically extract the URLs from your message and process them accordingly.\n"
            "- The bot will verify if these accounts exist in your stock.\n"
            "- If successful, it will update the passwords, remove the accounts from the database, and send you a file with the updated account credentials.\n"
        )

        def safe_convert_followers(follower_count):
            try:
                return int(follower_count)
            except (ValueError, TypeError):
                return 1

        def reset_user_data():
            context.user_data.update(
                {
                    "state": None,
                    "account_type": None,
                    "change_pfp": False,
                    "customer_name": None,
                    "quantity": None,
                    "verification": None,
                    "mail_access": False,
                    "range": (
                        1,
                        9,
                    ),  # TODO: Change this to default range which is None and None means all
                    "secured": False,
                }
            )

        async def send_reply(message, end_conversation=True):
            await update.message.reply_text(message, parse_mode="Markdown")
            if end_conversation:
                return ConversationHandler.END

        if update.message.from_user.id not in self.BOT_OWNERS:
            return

        if not await self.cooldown.check(update.message.from_user.id, "sell"):
            return await send_reply(config.COOLDOWN_MESSAGE)

        reset_user_data()
        context.user_data["state"] = "Sell Stocks"

        if not context.args:
            return await send_reply(invalid_usage_message)

        account_type = await self.get_account_type(context.args[0], update)
        if not account_type and context.args and "-" in context.args[0]:
            account_type = Types.NORMAL
            context.user_data["account_type"] = account_type

        if not account_type:
            return await send_reply(invalid_usage_message)

        context.user_data["account_type"] = account_type

        if account_type == Types.NORMAL:
            if context.args and context.args[0].lower() == "mstats":
                context.args.pop(0)
                context.user_data.update(
                    {
                        "range": (100, 999),
                        "is_mstats": True,
                        "quantity": None,
                        "verification": None,
                        "mail_access": False,
                        "customer_name": None,
                        "secured": False,
                    }
                )
                if len(context.args) < 1:
                    await update.message.reply_text(
                        "Missing customer name. Format: /sell mstats <customer_name>"
                    )
                    return ConversationHandler.END
                context.user_data["customer_name"] = context.args[-1]
                await update.message.reply_text(
                    f"🗣️ Customer Name: {context.user_data['customer_name']}\nPlease send the account links for mstats (100-999 followers, FV/PV/EV/UV).\n/cancel to abort.",
                    parse_mode="Markdown",
                )
                return SELL

            context.user_data.update(
                {
                    "range": (0, float("inf")),
                    "is_mstats": False,
                    "quantity": None,
                    "verification": None,
                    "mail_access": False,
                    "customer_name": None,
                    "secured": False,
                }
            )

            full_text = " ".join(context.args)
            name_match = re.search(r'"([^"]+)"', full_text)

            if name_match:
                context.user_data["customer_name"] = name_match.group(1)
                context.args = [
                    arg
                    for arg in context.args
                    if arg not in [f'"{context.user_data["customer_name"]}"']
                ]

            for value in context.args[:]:
                if value == "pfp":
                    context.user_data["change_pfp"] = (
                        False if config.CHANGE_PFP_ON_CHECK_NORMALS else True
                    )
                    context.args.remove(value)
                elif value in ["ma", "ea"]:
                    context.user_data["mail_access"] = True
                    context.args.remove(value)
                elif value == "secured":
                    context.user_data["mail_access"] = True
                    context.user_data["secured"] = True
                    context.args.remove(value)
                elif value in ["fv", "ev", "pv", "uv", "mixed"]:
                    context.user_data["verification"] = value
                    context.args.remove(value)
                elif "-" in value:
                    try:
                        range1, range2 = map(int, value.split("-"))
                        context.user_data["range"] = (
                            min(range1, range2),
                            max(range1, range2),
                        )
                        context.args.remove(value)
                    except ValueError:
                        await update.message.reply_text(
                            "Invalid range format. Example: 0-9"
                        )
                        return ConversationHandler.END
                elif value.isnumeric():
                    quantity = int(value)
                    if quantity < 1:
                        await update.message.reply_text(
                            "Quantity must be greater than 0"
                        )
                        return ConversationHandler.END
                    context.user_data["quantity"] = quantity
                    context.args.remove(value)
                elif not name_match and value.isalpha():
                    context.user_data["customer_name"] = value
                    context.args.remove(value)

            # After parsing, apply secured filter if needed
            if context.user_data.get("secured"):
                def is_secured(acc):
                    backup_code = acc.get("backup_code", "")
                    mailpwd = acc.get("mailpwd", "")
                    return (
                        mailpwd
                        and mailpwd not in ["NO_MAIL_PASS", "", "None"]
                        and backup_code
                        and backup_code not in ["", "None", "0"]
                        and backup_code.isalnum()
                        and 8 <= len(backup_code) <= 16
                    )
                filter_func = is_secured
            else:
                def filter_func(acc):
                    mailpwd = acc.get("mailpwd", "")
                    return (
                        (not context.user_data["mail_access"] or (mailpwd and mailpwd not in ["NO_MAIL_PASS", "", "None"]))
                    )

            current_stock = await getattr(
                self.database, f"get_{context.user_data['account_type']}_accounts"
            )()
            filtered_stock = [
                acc
                for acc in current_stock
                if (
                    (
                        context.user_data["range"][0]
                        <= safe_convert_followers(acc.get("followers", 0))
                        <= context.user_data["range"][1]
                    )
                    and (
                        not context.user_data.get("verification")
                        or (
                            context.user_data["verification"] == acc.get("verified")
                        )
                        or (
                            context.user_data["verification"] == "mixed"
                            and acc.get("verified") in ["uv", "ev"]
                        )
                    )
                    and filter_func(acc)
                )
            ]

        else:

            if len(context.args) < 2:
                await update.message.reply_text(
                    "Missing customer name. Format: /sell <type> [pfp] <customer_name>"
                )
                return ConversationHandler.END

            context.user_data["customer_name"] = context.args[-1]
            if "pfp" in context.args[1:-1]:
                context.user_data["change_pfp"] = True

            await update.message.reply_text(
                f"🗣️ Customer Name: {context.user_data['customer_name']}\nPlease send the account links now.\n/cancel to abort.",
                parse_mode="Markdown",
            )
            return SELL

        try:
            total_required = context.user_data["quantity"]
            total_changed = 0
            changed_accounts = []
            removed_accounts = set()
            failed_accounts = set()
            retries = 0
            MAX_RETRIES = 10

            msg = await update.message.reply_text(
                f"⏳ Starting password change process..."
            )

            available_stock = len(filtered_stock)
            if available_stock < total_required:
                await msg.edit_text(
                    f"❌ Insufficient stock!\n"
                    f"Requested: {total_required}\n"
                    f"Available: {available_stock}\n\n"
                    f"Use /stock to check current inventory."
                )
                reset_user_data()
                return ConversationHandler.END

            import random

            progress_emojis = ["⏳", "🔄", "🕒", "🌀", "⏱️", "⏰", "⌛", "🔁", "🔃", "🛠️"]
            last_emoji = None

            import asyncio

            flood_control_hit = False

            while total_changed < total_required and retries < MAX_RETRIES:

                emoji = random.choice(progress_emojis)

                if last_emoji and len(progress_emojis) > 1:
                    while emoji == last_emoji:
                        emoji = random.choice(progress_emojis)
                last_emoji = emoji

                processed_auths = {c["auth"] for c in changed_accounts if c.get("auth")}

                available_accounts = [
                    acc
                    for acc in filtered_stock
                    if acc.get("auth")
                    and acc["auth"] not in failed_accounts
                    and acc["auth"] not in processed_auths
                ]

                if not available_accounts:
                    self.debug.log("No more available accounts to process")
                    break

                current_batch = available_accounts[: total_required - total_changed]

                if not current_batch:
                    self.debug.log("Empty batch, no more accounts to process")
                    break

                try:
                    new_changed = await client.bulk_change_password(
                        context.user_data["account_type"],
                        current_batch,
                        context.user_data["change_pfp"],
                    )

                    successful_auths = (
                        {acc["auth"] for acc in new_changed} if new_changed else set()
                    )
                    batch_auths = {acc["auth"] for acc in current_batch}
                    failed_auths = batch_auths - successful_auths
                    failed_accounts.update(failed_auths)

                    if new_changed:
                        await asyncio.gather(
                            *[
                                self.database.remove_account(
                                    context.user_data["account_type"], acc["username"]
                                )
                                for acc in new_changed
                            ]
                        )
                        removed_accounts.update(acc["username"] for acc in new_changed)

                        existing_auths = {acc["auth"] for acc in changed_accounts}
                        unique_new_changed = [
                            acc
                            for acc in new_changed
                            if acc.get("auth") and acc["auth"] not in existing_auths
                        ]
                        changed_accounts.extend(unique_new_changed)

                        total_changed = len(changed_accounts)

                        new_text = f"{emoji} Changed passwords for {total_changed}/{total_required} accounts..."
                        await msg.edit_text(new_text)
                        retries = 0
                    else:

                        new_text = f"{emoji} Changed passwords for {total_changed}/{total_required} accounts..."
                        await msg.edit_text(new_text)
                        retries += 1
                        self.debug.log(
                            f"No accounts changed in this batch (attempt {retries}/{MAX_RETRIES})"
                        )

                except Exception as e:
                    error_msg = str(e).lower()
                    self.debug.log(
                        f"Error in password change batch: {str(e)}", send=False
                    )

                    if "flood control exceeded" in error_msg or "retry in" in error_msg:

                        wait_seconds = 35
                        match = re.search(r"retry in (\d+) seconds", error_msg)
                        if match:
                            wait_seconds = int(match.group(1))
                        self.debug.log(
                            f"[SELL] Flood control triggered. Waiting for {wait_seconds} seconds before retrying."
                        )

                        flood_control_hit = True
                        break
                    else:
                        retries += 1

                        emoji = random.choice(progress_emojis)
                        if last_emoji and len(progress_emojis) > 1:
                            while emoji == last_emoji:
                                emoji = random.choice(progress_emojis)
                        last_emoji = emoji
                        new_text = f"{emoji} Changed passwords for {total_changed}/{total_required} accounts..."
                        try:
                            await msg.edit_text(new_text)
                        except Exception:
                            pass
                    continue

            if changed_accounts:
                ignored_key_names = ["year", "followers", "following"]
                accounts_text = "\n".join(
                    ":".join(
                        str(acc[key])
                        for key in acc
                        if acc[key]
                        and acc[key] not in ["pv", "fv", "ev", "uv"]
                        and key not in ignored_key_names
                    )
                    for acc in changed_accounts
                )

                if total_changed < total_required:
                    await update.message.reply_text(
                        f"⚠️ *Partial Delivery: Ran out of stock*\n"
                        f"Could only fulfill {total_changed} out of the requested {total_required} accounts matching the criteria.\n"
                        f"The remaining stock was exhausted during processing attempts.",
                        parse_mode="Markdown",
                    )

                await msg.edit_text(
                    f"✅ Successfully changed {len(changed_accounts)}/{total_required} passwords"
                )

                file_name = self._generate_safe_filename(
                    changed_accounts, account_type, context.user_data
                )
                await self.post_accounts(
                    update, accounts_text, sell=True, customer_name=file_name
                )
            elif total_required > 0:
                await msg.edit_text(
                    f"❌ Failed to change passwords for any accounts. This might be due to stock issues or processing errors."
                )

            reset_user_data()
            return ConversationHandler.END

        except Exception as e:
            self.debug.log(f"Critical error in sell: {str(e)}")
            if changed_accounts:
                accounts_text = "\n".join(
                    ":".join(
                        str(acc[key])
                        for key in acc
                        if acc[key] and acc[key] not in ["pv", "fv", "ev", "uv"]
                    )
                    for acc in changed_accounts
                )
                await msg.edit_text(
                    f"⚠️ Process interrupted but got {len(changed_accounts)} accounts"
                )
                await self.post_accounts(
                    update,
                    accounts_text,
                    sell=True,
                    customer_name=context.user_data["customer_name"],
                )
            else:
                await msg.edit_text(
                    "❌ An error occurred and no accounts were processed"
                )

            reset_user_data()
            return ConversationHandler.END

    def _extract_valid_usernames(self, text: str) -> set:

        x_com_usernames = {
            m.group(1).lower()
            for m in re.finditer(r"x\.com/([a-zA-Z0-9_]{1,15})", text)
        }

        words = re.split(r"[\s,;]+", text)
        plain_usernames = {
            word.lower()
            for word in words
            if re.match(r"^[a-zA-Z0-9_]{1,15}$", word) and not word.isdigit()
        }

        at_usernames = {
            m.group(1).lower() for m in re.finditer(r"@([a-zA-Z0-9_]{1,15})", text)
        }

        return x_com_usernames.union(plain_usernames).union(at_usernames)

    async def handle_sell(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        try:
            account_type = context.user_data.get("account_type")
            if not account_type or not update.message.text:
                context.user_data.clear()
                await update.message.reply_text(
                    "Invalid stock type or no message found. Please use /sell command to sell stocks."
                )
                return ConversationHandler.END

            usernames = self._extract_valid_usernames(update.message.text)

            if not usernames:
                await update.message.reply_text(
                    "No usernames found in the message.\n```example:\nx.com/username1\nx.com/username2\nx.com/username3```"
                )
                return ConversationHandler.END

            usernames_set = {u.lower() for u in usernames}  # Convert to lowercase set

            if "mstat" in account_type:
                fetched_accounts = await self.database.get_mstats_accounts()
            else:
                fetched_accounts = await getattr(
                    self.database, f"get_{account_type}_accounts"
                )()

            # Make initial lookup case-insensitive
            selling_accounts = [acc for acc in fetched_accounts if acc["username"].lower() in usernames_set]

            # fallback: if not found, check all stocks
            if not selling_accounts:
                fallback_types = ["follower", "blue", "grey", "gold", "blueplus", "chars", "normal", "mstats"]
                found = False
                for t in fallback_types:
                    if t == account_type:
                        continue
                    alt_accounts = await getattr(self.database, f"get_{t}_accounts")()
                    # Make fallback lookup case-insensitive
                    alt_selling = [acc for acc in alt_accounts if acc["username"].lower() in usernames_set]
                    if alt_selling:
                        account_type = t
                        selling_accounts = alt_selling
                        found = True
                        break
                if not found:
                    await update.message.reply_text(
                        "The provided accounts could not be fetched using the filters and the given category, or any other stock.\nPlease recheck stock with /stock command and use the correct filters to sell accounts."
                    )
                    return ConversationHandler.END
                context.user_data["account_type"] = account_type

            # Make username comparisons case-insensitive
            valid_usernames = {acc["username"].lower() for acc in selling_accounts}
            invalid_users = [user for user in usernames if user.lower() not in valid_usernames]

            total_accounts = len(usernames)
            msg = await update.message.reply_text(
                f"⏳ Changing passwords for {len(selling_accounts)} {account_type} stocks.."
            )

            changed_accounts = []
            failed_accounts = set()

            batch_size = 100
            for i in range(0, len(selling_accounts), batch_size):
                batch = [
                    acc
                    for acc in selling_accounts[i : i + batch_size]
                    if acc["auth"] not in failed_accounts
                ]
                if not batch:
                    continue

                batch_result = await client.bulk_change_password(
                    account_type, batch, context.user_data["change_pfp"]
                )

                if batch_result:
                    successful_auths = {acc["auth"] for acc in batch_result}
                    batch_auths = {acc["auth"] for acc in batch}
                    failed_auths = batch_auths - successful_auths
                    failed_accounts.update(failed_auths)

                    existing_auths = {acc["auth"] for acc in changed_accounts}
                    unique_batch_result = [
                        acc
                        for acc in batch_result
                        if acc.get("auth") and acc["auth"] not in existing_auths
                    ]
                    changed_accounts.extend(unique_batch_result)

                    await msg.edit_text(
                        f"⏳ Changed passwords for {len(changed_accounts)}/{len(selling_accounts)} accounts..."
                    )

            if not changed_accounts:
                await msg.edit_text(
                    "⚠️ No accounts were processed successfully.\nIt's possible that the account's password was incorrect and could not be changed, or the account may have already been sold previously using /getstock or the manual selling method. Please try again."
                )
                return ConversationHandler.END

            # Make username comparisons case-insensitive
            changed_usernames = {acc["username"].lower() for acc in changed_accounts}
            error_accounts = [
                acc
                for acc in selling_accounts
                if acc["username"].lower() not in changed_usernames
            ]
            accounts = "\n".join(
                ":".join(
                    str(acc[key])
                    for key in acc
                    if acc[key] and acc[key] not in ["pv", "fv", "ev", "uv"]
                )
                for acc in changed_accounts
            )

            file_name = self._generate_safe_filename(
                changed_accounts, account_type, context.user_data
            )

            await asyncio.gather(
                *[
                    self.database.remove_account(account_type, acc["username"])
                    for acc in changed_accounts
                ]
            )

            status_message = [
                f"✅ Passwords changed for {len(changed_accounts)} {account_type} stocks",
                f"\nℹ️ Summary:",
                f"• Total accounts submitted: {total_accounts}",
                f"• Successfully changed: {len(changed_accounts)}",
            ]

            if invalid_users:
                status_message.append(f"• Invalid/Not in stock: {len(invalid_users)}")
                status_message.append(f"  └ {', '.join(invalid_users)}")

            if error_accounts:
                status_message.append(f"• Failed to change: {len(error_accounts)}")
                status_message.append(
                    f"  └ {', '.join(acc['username'] for acc in error_accounts)}"
                )
                status_message.append(
                    f"  (These accounts have been saved to the locked tokens database)"
                )

            await msg.edit_text("\n".join(status_message))
            await self.post_accounts(
                update, accounts, sell=True, customer_name=file_name
            )

            if invalid_users:
                try:
                    account_types = [
                        "follower",
                        "blue",
                        "grey",
                        "gold",
                        "blueplus",
                        "chars",
                        "mstats"  
                    ]

                    all_accounts = {}
                    found_in_other_stocks = set()

                    for t in account_types:
                        try:
                            method = getattr(self.database, f"get_{t}_accounts")
                            if method:
                                accounts = await method()
                                matching_accounts = [
                                    acc
                                    for acc in accounts
                                    if acc["username"].lower() in invalid_users
                                ]
                                if matching_accounts:
                                    all_accounts[t] = matching_accounts
                                    found_in_other_stocks.update(
                                        acc["username"] for acc in matching_accounts
                                    )
                        except Exception as e:
                            self.debug.log(f"Error fetching {t} accounts: {str(e)}")
                            all_accounts[t] = []

                    total_invalid_price = 0
                    invalid_details = []
                    not_in_stock = set(invalid_users) - found_in_other_stocks

                    if found_in_other_stocks:
                        invalid_details.append(
                            "\n💫 *Found in other stock categories:*"
                        )

                        for acc_type, accounts in all_accounts.items():
                            for acc in accounts:
                                try:
                                    followers = (
                                        int(acc.get("followers", 0))
                                        if acc.get("followers", "").isdigit()
                                        else 0
                                    )

                                    if acc_type == "follower":
                                        price = followers * self.PRICE
                                        invalid_details.append(
                                            f"`x.com/{acc['username']}` ({acc_type}): {followers:,} followers = ${price:,.2f}"
                                        )
                                    elif acc_type == "blue":
                                        price = self.BLUE_STANDARD_PRICE
                                        if followers >= 1000:
                                            price += followers * self.PRICE
                                            invalid_details.append(
                                                f"`x.com/{acc['username']}` ({acc_type}): ${self.BLUE_STANDARD_PRICE} + {followers:,} followers = ${price:,.2f}"
                                            )
                                        else:
                                            invalid_details.append(
                                                f"`x.com/{acc['username']}` ({acc_type}): Standard price = ${price:,.2f}"
                                            )
                                    elif acc_type == "blueplus":
                                        price = self.BLUE_PLUS_STANDARD_PRICE
                                        if followers >= 1000:
                                            price += followers * self.PRICE
                                            invalid_details.append(
                                                f"`x.com/{acc['username']}` ({acc_type}): ${self.BLUE_PLUS_STANDARD_PRICE} + {followers:,} followers = ${price:,.2f}"
                                            )
                                        else:
                                            invalid_details.append(
                                                f"`x.com/{acc['username']}` ({acc_type}): Standard price = ${price:,.2f}"
                                            )
                                    else:
                                        if acc_type == "chars":
                                            price = self.CHAR_STANDARD_PRICE
                                        else:
                                            price = self.GREY_GOLD_STANDARD_PRICE
                                        if followers >= 1000:
                                            price += followers * self.PRICE
                                            invalid_details.append(
                                                f"`x.com/{acc['username']}` ({acc_type}): ${price - (followers * self.PRICE):,.2f} + {followers:,} followers = ${price:,.2f}"
                                            )
                                        else:
                                            invalid_details.append(
                                                f"`x.com/{acc['username']}` ({acc_type}): Standard price = ${price:,.2f}"
                                            )

                                    total_invalid_price += price

                                except Exception as e:
                                    self.debug.log(
                                        f"Error processing account {acc['username']}: {str(e)}"
                                    )
                                    invalid_details.append(
                                        f"`x.com/{acc['username']}`: Error calculating price"
                                    )

                    if not_in_stock:
                        invalid_details.append(
                            "\n❌ *Not found in any stock category:*"
                        )
                        invalid_details.append(
                            ", ".join(f"`{username}`" for username in not_in_stock)
                        )

                    if invalid_details:
                        try:
                            summary = [
                                "📊 *Invalid/Not In Stock Accounts Summary:*",
                            ]

                            if found_in_other_stocks:
                                summary.extend(
                                    [
                                        f"\n💰 Base prices:",
                                        f"• Follower accounts: ${self.PRICE:,.4f} per follower",
                                        f"• Blue accounts: ${self.BLUE_STANDARD_PRICE:,.2f} + followers pricing if >1000",
                                        f"• Blue Plus accounts: ${self.BLUE_PLUS_STANDARD_PRICE:,.2f} + followers pricing if >1000",
                                        f"• Grey/Gold accounts: ${self.GREY_GOLD_STANDARD_PRICE:,.2f} + followers pricing if >1000",
                                        f"• Character accounts: ${self.CHAR_STANDARD_PRICE:,.2f} + followers pricing if >1000",
                                    ]
                                )

                            summary.extend(invalid_details)

                            if found_in_other_stocks:
                                summary.append(
                                    f"\n💵 *Total price for accounts in other categories: ${total_invalid_price:,.2f}*"
                                )

                            await update.message.reply_text(
                                "\n".join(summary), parse_mode="Markdown"
                            )
                        except Exception as e:
                            self.debug.log(
                                f"Error sending invalid accounts summary: {str(e)}"
                            )
                            await update.message.reply_text(
                                "⚠️ Error generating invalid accounts pricing summary",
                                parse_mode="Markdown",
                            )

                except Exception as e:
                    self.debug.log(
                        f"Error in invalid accounts pricing calculation: {str(e)}"
                    )
                    await update.message.reply_text(
                        "⚠️ Error calculating prices for invalid accounts",
                        parse_mode="Markdown",
                    )

            context.user_data.clear()
            return ConversationHandler.END

        except Exception as e:
            context.user_data.clear()
            self.debug.log(f"Error in handle_sell: {str(e)}")
            await update.message.reply_text(
                "An error occurred while processing your request. Please try again."
            )
            return ConversationHandler.END

    @owner()
    async def change(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        self.debug.log(f"/change called with args: {context.args}")
        if not await self.cooldown.check(update.message.from_user.id, "banner"):
            self.debug.log("Cooldown active for /change")
            await update.message.reply_text(
                config.COOLDOWN_MESSAGE, parse_mode="Markdown"
            )
            return
        if not context.args or "help" in [arg.lower() for arg in context.args]:
            self.debug.log("/change help requested or no args")
            help_text = (
                "⚠️ Usage: `/change <pfp|banner|secured> <type> [options]`\n\n"
                "*Account Types:*\n"
                "• `normal` - Normal accounts\n"
                "• `blue` - Blue verified accounts\n"
                "• `blueplus` - Blue Plus accounts\n"
                "• `grey` - Grey verified accounts\n"
                "• `gold` - Gold verified accounts\n"
                "• `follower` - Follower accounts\n"
                "• `chars` - Character accounts\n"
                "• `mstats` - Mstats accounts (100-999 followers)\n"
                "• `human` - Human PFPs\n"
                "• `nft` - NFT PFPs\n\n"
                "*Options:*\n"
                "• `0-9`, `10-29`, etc - Follower range\n"
                "• `fv` - Fully verified accounts (normal only)\n"
                "• `ev` - Email verified accounts (normal only)\n"
                "• `pv` - Phone verified accounts (normal only)\n"
                "• `uv` - Unverified accounts (normal only)\n"
                "• `ma` - Mail access accounts\n"
                "• `mixed` - Mixed verification accounts (UV+EV)\n"
                "• `<number>` - Limit number of accounts\n\n"
                "*Examples:*\n"
                "• `/change pfp normal 0-9 fv` - Change PFP for FV normal accounts with 0-9 followers\n"
                "• `/change banner normal mixed 0-9` - Change banner for mixed verification accounts with 0-9 followers\n"
                "• `/change pfp blue ma` - Change PFP for blue accounts with mail access\n"
                "• `/change pfp banner follower 100` - Change PFP and banner for 100 follower accounts\n"
                "• `/change secured normal 0-9` - Change PFP and banner for secured normal accounts with 0-9 followers\n"
                "• `/change human` - Upload ZIP file with human PFPs\n"
                "• `/change nft` - Upload ZIP file with NFT PFPs\n"
                "• `/change normal human` - Use human PFPs for normal accounts\n"
                "• `/change blue nft` - Use NFT PFPs for blue accounts"
            )
            await update.message.reply_text(help_text, parse_mode="Markdown")
            return
        try:
            self.debug.log(f"/change parsing args: {context.args}")
            pfp_type = None
            if len(context.args) >= 2 and context.args[1].lower() in ["human", "nft"]:
                pfp_type = context.args[1].lower()
                context.args.pop(1)
            elif len(context.args) >= 3 and context.args[2].lower() in ["human", "nft"]:
                pfp_type = context.args[2].lower()
                context.args.pop(2)

            if context.args[0].lower() in ["human", "nft"]:
                pfp_type = context.args[0].lower()
                await update.message.reply_text(
                    f"Please upload a ZIP file containing {pfp_type} profile pictures."
                )
                return await self.process_zip_upload(update, pfp_type)

            is_secured = "secured" in [arg.lower() for arg in context.args]
            if is_secured:
                context.args = [arg for arg in context.args if arg.lower() != "secured"]
                change_pfp = True
                change_banner = True
            else:
                change_pfp = (
                    any(arg.startswith("pfp") for arg in context.args)
                    or pfp_type is not None
                )
                change_banner = any(arg.startswith("banner") for arg in context.args)

            filtered_args = [
                arg
                for arg in context.args
                if not arg.startswith("pfp") and not arg.startswith("banner")
            ]

            if not filtered_args:
                await update.message.reply_text(
                    "⚠️ No account type provided. Use `/change help` for usage information.",
                    parse_mode="Markdown",
                )
                return

            account_type = await self.get_account_type(filtered_args[0], update)
            if not account_type:
                await update.message.reply_text(
                    "Invalid account type. Please use `/change help` for usage information.",
                    parse_mode="Markdown",
                )
                return

            filtered_args = filtered_args[1:]

            msg = await update.message.reply_text(
                f"⏳ Retrieving {account_type} accounts..."
            )
            accounts = await getattr(self.database, f"get_{account_type}_accounts")()
            self.debug.log(f"/change fetched {len(accounts)} accounts")

            if not accounts:
                await msg.edit_text(f"No {account_type} accounts found.")
                return

            filters = {
                "verification": None,
                "mail_access": False,
                "range_min": None,
                "range_max": None,
                "quantity": None,
                "secured": False,
            }

            for arg in filtered_args:
                arg = arg.lower().strip()

                if "-" in arg:
                    try:
                        min_val, max_val = map(int, arg.split("-"))
                        filters["range_min"] = min(min_val, max_val)
                        filters["range_max"] = max(min_val, max_val)
                    except ValueError:
                        pass
                elif arg in ["fv", "ev", "pv", "uv", "mixed"]:
                    filters["verification"] = arg
                elif arg == "ma":
                    filters["mail_access"] = True
                elif arg.isdigit():
                    filters["quantity"] = int(arg)
                elif arg.lower() == "secured":
                    filters["secured"] = True

            filtered_accounts = accounts.copy()

            if account_type == "normal" and filters["verification"]:
                if filters["verification"] == "mixed":
                    filtered_accounts = [
                        acc
                        for acc in filtered_accounts
                        if acc.get("verified", "").lower() in ["uv", "ev"]
                    ]
                else:
                    filtered_accounts = [
                        acc
                        for acc in filtered_accounts
                        if acc.get("verified", "").lower() == filters["verification"]
                    ]

            if filters["range_min"] is not None and filters["range_max"] is not None:
                filtered_accounts = [
                    acc
                    for acc in filtered_accounts
                    if (
                        acc.get("followers", "").isdigit()
                        and filters["range_min"]
                        <= int(acc["followers"])
                        <= filters["range_max"]
                    )
                ]

            if filters["mail_access"]:
                filtered_accounts = [
                    acc for acc in filtered_accounts if acc.get("mailpwd")
                ]

            if filters["quantity"] and filters["quantity"] > 0:
                filtered_accounts = filtered_accounts[: filters["quantity"]]

            if filters.get("secured"):
                filtered_accounts = [acc for acc in filtered_accounts if acc.get("backup_code") and acc.get("backup_code") not in ["", "None", "0"]]

            if not filtered_accounts:
                await msg.edit_text("No accounts match the specified criteria.")
                return

            if not change_pfp and not change_banner:
                change_pfp = True

            filter_desc = []
            if filters["range_min"] is not None:
                filter_desc.append(
                    f"{filters['range_min']}-{filters['range_max']} followers"
                )
            if filters["verification"]:
                filter_desc.append(f"{filters['verification']} verification")
            if filters["mail_access"]:
                filter_desc.append("mail access")
            if filters["quantity"]:
                filter_desc.append(f"limited to {filters['quantity']}")
            if pfp_type:
                filter_desc.append(f"using {pfp_type} PFPs")
            if filters.get("secured"):
                filter_desc.append("secured accounts only")

            filter_text = f" ({', '.join(filter_desc)})" if filter_desc else ""

            update_type = (
                "pfp + banner"
                if change_pfp and change_banner
                else "pfp" if change_pfp else "banner"
            )

            await msg.edit_text(
                f"⏳ Updating {update_type} for {len(filtered_accounts)}/{len(accounts)} {account_type} accounts{filter_text}..."
            )
            self.debug.log(f"/change filters: {filters}")
            self.debug.log(f"/change filtered to {len(filtered_accounts)} accounts")
            self.debug.log(f"/change queuing update for {len(filtered_accounts)} accounts: pfp={change_pfp}, banner={change_banner}, pfp_type={pfp_type}")
            asyncio.create_task(
                change_bulk_pfp_banner(
                    filtered_accounts,
                    change_pfp=change_pfp,
                    change_banner=change_banner,
                    pfp_type=pfp_type,
                )
            )
            self.debug.log(f"/change task queued")
            await msg.edit_text(
                f"✅ Profile updater queued for {len(filtered_accounts)} {account_type} accounts{filter_text}."
            )
        except Exception as e:
            self.debug.log(f"Error in change: {str(e)}")
            await self.debug.notify_owner(f"Error in pfp+banner change: {str(e)}")
            await update.message.reply_text(
                "Exception with this command, please try again later."
            )
            return

    @owner()
    async def updatestock(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        db_path, backup_dir = "database/production.db", "database/backups"
        os.makedirs(backup_dir, exist_ok=True)
        backup_path = os.path.join(
            backup_dir, f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        )
        if os.path.exists(db_path):
            shutil.copy2(db_path, backup_path)

        msg = await update.message.reply_text(
            "⏳ Validating request and preparing accounts..."
        )

        if not context.args:
            await msg.edit_text(
                "⚠️ Usage: `/update <type> [options]`\n\n"
                "*Account Types:*\n"
                "• `normal` - Normal accounts\n"
                "• `blue` - Blue verified accounts\n"
                "• `blueplus` - Blue Plus accounts\n"
                "• `grey` - Grey verified accounts\n"
                "• `gold` - Gold verified accounts\n"
                "• `follower` - Follower accounts\n"
                "• `chars` - Character accounts\n"
                "• `mstats` - Mstats accounts (100-999 followers)\n"
                "• `all` - All account types\n\n"
                "*Options:*\n"
                "• `0-9`, `10-29`, etc - Follower range\n"
                "• `fv` - Fully verified accounts (normal only)\n"
                "• `ev` - Email verified accounts (normal only)\n"
                "• `pv` - Phone verified accounts (normal only)\n"
                "• `uv` - Unverified accounts (normal only)\n"
                "• `ma` - Mail access accounts\n"
                "• `mixed` - Mixed verification accounts (UV+EV)\n"
                "• `<number>` - Limit number of accounts\n\n"
                "*Examples:*\n"
                "• `/update normal 0-9 fv` - FV normal accounts with 0-9 followers\n"
                "• `/update normal mixed 0-9` - Mixed verification accounts with 0-9 followers\n"
                "• `/update blue ma` - Blue accounts with mail access\n"
                "• `/update follower 100` - 100 follower accounts\n"
                "• `/update chars` - All character accounts\n"
                "• `/update all` - All accounts from all types",
                parse_mode="Markdown",
            )
            return

        account_type_arg = context.args[0].lower()
        is_all_types = account_type_arg == "all"

        accounts_to_process = []
        actual_account_type_for_filter = None

        if is_all_types:
            account_types_to_fetch = [
                "normal",
                "blue",
                "grey",
                "gold",
                "follower",
                "blueplus",
                "chars",
                "mstats",
            ]
            for acc_type in account_types_to_fetch:
                try:
                    accounts_to_process.extend(
                        await getattr(self.database, f"get_{acc_type}_accounts")()
                    )
                except Exception as e:
                    self.debug.log(f"Error fetching {acc_type} for /update all: {e}")
            actual_account_type_for_filter = "all"
        else:
            resolved_account_type = await self.get_account_type(
                account_type_arg, update
            )
            if not resolved_account_type:
                await msg.edit_text("Invalid account type. Use /update for usage info.")
                return
            try:
                accounts_to_process = await getattr(
                    self.database, f"get_{resolved_account_type}_accounts"
                )()
                actual_account_type_for_filter = resolved_account_type
            except Exception as e:
                await msg.edit_text(
                    f"Error fetching {resolved_account_type} accounts: {str(e)}"
                )
                self.debug.log(f"Error fetching {resolved_account_type} accounts: {e}")
                return

        if not accounts_to_process:
            await msg.edit_text(
                "⚠️ No accounts to update based on initial type selection."
            )
            return

        filters = {
            "quantity": None,
            "verification": None,
            "mail_access": False,
            "range_min": None,
            "range_max": None,
            "secured": False,
        }
        for arg in context.args[1:]:
            arg = arg.lower().strip()
            if "-" in arg:
                try:
                    min_val, max_val = map(int, arg.split("-"))
                    filters["range_min"] = min(min_val, max_val)
                    filters["range_max"] = max(min_val, max_val)
                except ValueError:
                    pass
            elif arg in ["fv", "ev", "pv", "uv", "mixed"]:
                filters["verification"] = arg
            elif arg == "ma":
                filters["mail_access"] = True
            elif arg.isdigit():
                filters["quantity"] = int(arg)
            elif arg.lower() == "secured":
                filters["secured"] = True

        filtered_accounts = accounts_to_process.copy()
        if (
            actual_account_type_for_filter == "normal"
            or actual_account_type_for_filter == "all"
        ) and filters["verification"]:
            if filters["verification"] == "mixed":
                filtered_accounts = [
                    acc
                    for acc in filtered_accounts
                    if acc.get("verified", "").lower() in ["uv", "ev"]
                ]
            else:
                filtered_accounts = [
                    acc
                    for acc in filtered_accounts
                    if acc.get("verified", "").lower() == filters["verification"]
                ]

        if filters["range_min"] is not None and filters["range_max"] is not None:
            filtered_accounts = [
                acc
                for acc in filtered_accounts
                if (
                    str(acc.get("followers", "")).isdigit()
                    and filters["range_min"]
                    <= int(acc["followers"])
                    <= filters["range_max"]
                )
            ]

        if filters["mail_access"]:
            filtered_accounts = [acc for acc in filtered_accounts if acc.get("mailpwd")]

        if filters["quantity"] and filters["quantity"] > 0:
            filtered_accounts = filtered_accounts[: filters["quantity"]]

        if filters.get("secured"):
            filtered_accounts = [acc for acc in filtered_accounts if acc.get("backup_code") and acc.get("backup_code") not in ["", "None", "0"]]

        if not filtered_accounts:
            await msg.edit_text(
                "No accounts match the specified criteria after filtering."
            )
            return

        def dict_to_token(acc):
            return (
                acc.get("username", ""),
                acc.get("password", ""),
                acc.get("email", ""),
                acc.get("mailpwd", ""),
                acc.get("ct0", ""),
                acc.get("auth", ""),
                acc.get("followers", ""),
                acc.get("following", ""),
                acc.get("year", ""),
                acc.get("backup_code", ""),
                acc.get("verified", ""),
            )

        tokens = [dict_to_token(acc) for acc in filtered_accounts if acc.get("auth")]
        initial_total = len(tokens)
        task_id = f"update_stock_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        await msg.edit_text(
            f"⏳ Stock update task for {initial_total} accounts queued ({task_id}). Progress will be shown below."
        )
        asyncio.create_task(
            self._run_actual_updatestock(
                update, context, msg, tokens, task_id, initial_total
            )
        )

    async def _run_actual_updatestock(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        msg: telegram.Message,
        filtered_accounts: list,
        task_id: str,
        initial_total: int,
    ):
        try:
            await self.queue_manager.set_progress_updater(task_id, msg)

            checker_instance = Check(self.database, self.queue_manager, task_id)
            tracker = getattr(checker_instance, "tracker", None)
            if tracker is not None:
                tracker.initial_total = initial_total
            else:
                self.debug.log(
                    f"Warning: checker_instance for task {task_id} does not have a tracker or it is None."
                )

            start_time = datetime.now()
            await self.queue_manager.add_task(
                task_id, checker_instance._execute, filtered_accounts, update=True
            )

            task_status = await self.queue_manager.await_task_completion(
                task_id, timeout=3600
            )

            end_time = datetime.now()
            duration = end_time - start_time

            processed_count = 0
            status_lines = []

            if tracker is not None:
                try:
                    tracker_status = await tracker.get_status()
                    processed_count = tracker_status.get(
                        "current", getattr(tracker, "current", 0)
                    )

                    final_details_keys = [
                        "followers",
                        "normals",
                        "golds",
                        "blues",
                        "greys",
                        "chars",
                        "blueplus",
                        "unverified",
                        "suspended",
                        "locked",
                        "failed",
                        "invalids",
                        "rate_limited",
                        "errors",
                        "mstats",
                    ]
                    final_details = {
                        k: tracker_status[k]
                        for k in final_details_keys
                        if tracker_status.get(k, 0) > 0
                    }
                    for k, v in final_details.items():
                        status_lines.append(f"├ {k.title()}: `{v:,}`")
                except Exception as e:
                    self.debug.log(
                        f"Error getting tracker status for task {task_id}: {e}"
                    )
                    status_lines.append("├ Error retrieving final statistics.")
            else:
                status_lines.append("├ Tracker not available for final statistics.")

            status_str = (
                task_status.title() if isinstance(task_status, str) else "Unknown"
            )
            final_msg_text = (
                f"✅ *Stock Update Task {task_id} Concluded*\n"
                f"├ Status: {status_str}\n"
                f"├ Total Processed: `{processed_count}/{initial_total:,}`\n"
            )
            if status_lines:
                final_msg_text += "\n".join(status_lines) + "\n"
            final_msg_text += f"└ Time Took: {duration.total_seconds():.1f}s"

            await msg.edit_text(final_msg_text, parse_mode="Markdown")
            await update.message.reply_text(
                f"✅ Stock update for {initial_total} accounts completed successfully.",
                parse_mode="Markdown",
            )

        except asyncio.TimeoutError:
            self.debug.log(
                f"_run_actual_updatestock for task {task_id} timed out overall."
            )
            await msg.edit_text(
                f"⌛ Stock update task {task_id} timed out after 1 hour.",
                parse_mode="Markdown",
            )
        except Exception as e:
            self.debug.log(
                f"Error in _run_actual_updatestock for task {task_id}: {str(e)}\n{traceback.format_exc()}"
            )
            try:
                await msg.edit_text(
                    f"❌ Stock update task {task_id} failed critically: {str(e)}",
                    parse_mode="Markdown",
                )
            except Exception as e_edit:
                self.debug.log(
                    f"Failed to edit message for critical error in task {task_id}: {e_edit}"
                )
            await self.debug.notify_owner(
                f"Critical error in _run_actual_updatestock task {task_id}: {str(e)}"
            )
        finally:
            await self.queue_manager.stop_task(task_id)

    @owner()
    async def update_fvs(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        return await update.message.reply_text("This command is disabled for now.")

        msg = await update.message.reply_text("⏳ Updating FV verified accounts..")
        accounts = await self.database.get_normal_accounts()
        fv_accounts = [acc for acc in accounts if acc.get("verified") == "fv"]

        if not fv_accounts:
            await msg.edit_text("⚠️ No FV verified accounts found in database.")
            return

        BATCH_SIZE = 50
        account_batches = [
            fv_accounts[i : i + BATCH_SIZE]
            for i in range(0, len(fv_accounts), BATCH_SIZE)
        ]
        total_updated = 0

        for batch_num, batch in enumerate(account_batches, 1):
            await msg.edit_text(
                f"⏳ Processing batch {batch_num}/{len(account_batches)}..."
            )

            try:
                # result_task = asyncio.create_task(bulk_change_email("normals", batch))
                updated_batch = await asyncio.wait_for(result_task, timeout=60)

                if updated_batch:
                    await self.database.bulk_insert_normal_accounts(updated_batch)
                    total_updated += len(updated_batch)

            except asyncio.TimeoutError:
                continue
            except Exception as e:
                self.debug.log(f"Batch {batch_num} failed: {str(e)}")
                continue

            await msg.edit_text(
                f"⏳ Progress: {total_updated}/{len(fv_accounts)} accounts updated..."
            )

        if not total_updated:
            await msg.edit_text(
                "⚠️ No accounts were updated, the issue might be with the accounts.\nTry again later with a different batch."
            )
            return

        await msg.edit_text(
            f"✅ Completed! Updated {total_updated}/{len(fv_accounts)} FV verified accounts."
        )

    @owner()
    async def clearstock(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not await self.cooldown.check(update.message.from_user.id, "clear"):
            await update.message.reply_text(
                config.COOLDOWN_MESSAGE, parse_mode="Markdown"
            )
            return

        if not context.args:
            await update.message.reply_text(
                "No account type provided with `/clear` command.\nUsage: `/clear <account_type>`",
                parse_mode="Markdown",
            )
            return ConversationHandler.END

        account_type = await self.get_account_type(context.args[0], update)
        if not account_type:
            await update.message.reply_text(
                "Invalid account type. Please use one of the following: followers, blue, grey, gold, normal, unverified, chars."
            )
            return ConversationHandler.END

        context.user_data["clear_type"] = account_type

        await update.message.reply_text(
            f"⚠️ *WARNING*: Are you sure you want to clear all {account_type} accounts?\n"
            "This action cannot be undone!\n\n"
            "Type `confirm` to proceed or `cancel` to abort.",
            parse_mode="Markdown",
        )

        return CONFIRM_CLEAR

    async def handle_clear_confirmation(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        response = update.message.text.lower()
        account_type = context.user_data.get("clear_type")

        if response == "confirm":
            await self.database.clear(account_type)
            self.debug.log(f"Stock database has been cleared for {account_type}")
            await update.message.reply_text(
                f"✅ {account_type} database has been cleared."
            )
        else:
            await update.message.reply_text("⚠️ Clear operation cancelled.")

        if "clear_type" in context.user_data:
            del context.user_data["clear_type"]

        return ConversationHandler.END

    @owner()
    async def getfv(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Get all FV verified accounts and send as a text document"""
        try:
            if not await self.cooldown.check(update.message.from_user.id, "getfv"):
                await update.message.reply_text(
                    config.COOLDOWN_MESSAGE, parse_mode="Markdown"
                )
                return

            await update.message.reply_text(
                "⚠️ *WARNING*: This action will remove the FV accounts from the database.\n"
                "Type `confirm` to proceed or `cancel` to abort.",
                parse_mode="Markdown",
            )
            return CONFIRM_FV

        except Exception as e:
            self.debug.log(f"Error in getfv: {str(e)}")
            await update.message.reply_text(
                "An error occurred while fetching FV verified accounts."
            )

    async def handle_fv_confirmation(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        response = update.message.text.lower()

        if response != "confirm":
            await update.message.reply_text("⚠️ Operation cancelled.")
            return ConversationHandler.END

        try:
            msg = await update.message.reply_text(
                "⏳ *Fetching FV verified accounts...*", parse_mode="Markdown"
            )

            accounts = await self.database.get_normal_accounts()
            fv_accounts = [acc for acc in accounts if acc.get("verified") == "fv"]

            if not fv_accounts:
                await msg.edit_text("⚠️ No FV verified accounts found in database.")
                return ConversationHandler.END

            timenow = datetime.now().strftime("%Y_%m_%d_%H_%M")
            content = "\n".join(
                [
                    ":".join(
                        str(acc[key])
                        for key in acc
                        if acc[key] and acc[key] not in ["pv", "fv", "ev", "uv"]
                    )
                    for acc in fv_accounts
                ]
            )

            file_content = BytesIO(content.encode("utf-8"))
            file_content.name = f"fv_accounts_{timenow}.txt"

            for acc in fv_accounts:
                await self.database.remove_account("normal", acc["username"])

            await msg.delete()
            await update.message.reply_document(document=file_content)

        except Exception as e:
            self.debug.log(f"Error in handle_fv_confirmation: {str(e)}")
            await update.message.reply_text(
                "An error occurred while processing FV verified accounts."
            )

        return ConversationHandler.END

    @owner()
    async def calc_price(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Calculate total price of accounts based on URLs"""
        if not await self.cooldown.check(update.message.from_user.id, "calcprice"):
            await update.message.reply_text(
                config.COOLDOWN_MESSAGE, parse_mode="Markdown"
            )
            return

        if not context.args:
            message = (
                "Please provide usernames in any format:\n\n"
                "*Examples:*\n"
                "```\n"
                "/calcprice username1 username2 username3\n"
                "/calcprice x.com/username1, x.com/username2\n"
                "/calcprice @username1 @username2\n"
                "```"
            )
            await update.message.reply_text(message, parse_mode="Markdown")
            return

        msg = await update.message.reply_text(
            "⏳ Calculating price for selected accounts..."
        )

        usernames = set(
            u.lower() for u in self._extract_valid_usernames(" ".join(context.args))
        )

        if not usernames:
            await msg.edit_text("⚠️ No valid usernames found in the message.")
            return

        account_types = ["follower", "blue", "grey", "gold", "blueplus", "chars", "normal", "mstats"]
        all_accounts = {}
        for acc_type in account_types:
            accounts = await getattr(self.database, f"get_{acc_type}_accounts")()
            all_accounts[acc_type] = [
                acc for acc in accounts if acc["username"].lower() in usernames
            ]

        if not any(all_accounts.values()):
            await msg.edit_text("⚠️ No accounts found in database.")
            return

        total_price = 0
        account_details = []
        found_accounts = set(
            acc["username"].lower()
            for accounts in all_accounts.values()
            for acc in accounts
        )
        not_found = [
            u for u in usernames if u not in found_accounts and not str(u).isdigit()
        ]

        for acc_type, accounts in all_accounts.items():
            for acc in accounts:
                followers = (
                    int(acc.get("followers", 0))
                    if acc.get("followers", "").isdigit()
                    else 0
                )

                if acc_type == "follower":
                    price = followers * self.PRICE
                    account_details.append(
                        f"`x.com/{acc['username']}` ({acc_type}): {followers:,} followers = ${price:,.2f}"
                    )
                elif acc_type == "normal":
                    price = self.main.get_mstats_static_price(acc)
                    account_details.append(
                        f"`x.com/{acc['username']}` ({acc_type}): ${price:,.2f}"
                    )
                elif acc_type == "mstats":
                    price = self.main.get_mstats_static_price(acc)
                    account_details.append(
                        f"`x.com/{acc['username']}` ({acc_type}): {acc.get('verified','').upper()} | {followers:,} followers = ${price:,.2f}"
                    )
                elif acc_type == "blue":
                    price = self.BLUE_STANDARD_PRICE
                    if followers >= 1000:
                        price += followers * self.PRICE
                        account_details.append(
                            f"`x.com/{acc['username']}` ({acc_type}): ${self.BLUE_STANDARD_PRICE} + {followers:,} followers = ${price:,.2f}"
                        )
                    else:
                        account_details.append(
                            f"`x.com/{acc['username']}` ({acc_type}): Standard price = ${price:,.2f}"
                        )
                elif acc_type == "blueplus":
                    price = self.BLUE_PLUS_STANDARD_PRICE
                    if followers >= 1000:
                        price += followers * self.PRICE
                        account_details.append(
                            f"`x.com/{acc['username']}` ({acc_type}): ${self.BLUE_PLUS_STANDARD_PRICE} + {followers:,} followers = ${price:,.2f}"
                        )
                    else:
                        account_details.append(
                            f"`x.com/{acc['username']}` ({acc_type}): Standard price = ${price:,.2f}"
                        )
                else:
                    if acc_type == "chars":
                        price = self.CHAR_STANDARD_PRICE
                    else:
                        price = self.GREY_GOLD_STANDARD_PRICE
                    if followers >= 1000:
                        price += followers * self.PRICE
                        account_details.append(
                            f"`x.com/{acc['username']}` ({acc_type}): ${price - (followers * self.PRICE):,.2f} + {followers:,} followers = ${price:,.2f}"
                        )
                    else:
                        account_details.append(
                            f"`x.com/{acc['username']}` ({acc_type}): Standard price = ${price:,.2f}"
                        )

                total_price += price

        message = [
            "✅ *Price Calculation*\n",
            f"💰 Base prices:",
            f"• Follower accounts: ${self.PRICE:,.4f} per follower",
            f"• Blue accounts: ${self.BLUE_STANDARD_PRICE:,.2f} + followers pricing if >1000",
            f"• Blue Plus accounts: ${self.BLUE_PLUS_STANDARD_PRICE:,.2f} + followers pricing if >1000",
            f"• Grey/Gold accounts: ${self.GREY_GOLD_STANDARD_PRICE:,.2f} + followers pricing if >1000",
            f"• Character accounts: ${self.CHAR_STANDARD_PRICE:,.2f} + followers pricing if >1000\n",
            f"💵 Total price: ${total_price:,.2f}\n",
        ]

        if account_details:
            message.append("*Account Breakdown:*")
            message.extend(account_details)

        if not_found:
            message.append("\n⚠️ *Not found in stock:*")
            message.append(", ".join(f"`{u}`" for u in not_found))

        await msg.delete()
        await self.post_stock_list(update, "\n".join(message))

    def _generate_safe_filename(self, changed_accounts, account_type, user_data):
        """Generate a safe filename for Telegram attachments with relevant details"""
        parts = [
            str(len(changed_accounts)),
            account_type,
            (
                user_data.get("verification", "").upper()
                if account_type == "normal" and user_data.get("verification")
                else None
            ),
            (
                f"{user_data['range'][0]}-{user_data['range'][1]}f"
                if user_data.get("range")
                else None
            ),
            "ma" if user_data.get("mail_access") else None,
            (
                re.sub(r"[^\w\-_]", "_", user_data.get("customer_name", ""))
                if user_data.get("customer_name")
                else None
            ),
            datetime.now().strftime("%d-%m"),
        ]

        filename = "_".join(filter(None, parts))
        filename = re.sub(r'[<>:"/\\|?*]', "_", filename)
        return filename[:64] + ".txt"

    @owner()
    async def get_locked_tokens(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        if not await self.cooldown.check(update.message.from_user.id, "lockeds"):
            await update.message.reply_text(
                config.COOLDOWN_MESSAGE, parse_mode="Markdown"
            )
            return

        if "help" in context.args:
            help_text = (
                "Locked Command Help:\n"
                "/lockeds - Fetches all locked tokens and removes them from the database\n"
                "/lockeds 10 - Fetches the 10 most recent locked tokens and removes them\n"
                "/lockeds keep - Fetches all locked tokens but keeps them in the database\n"
                "/lockeds 10 keep - Fetches the 10 most recent locked tokens but keeps them"
            )
            await update.message.reply_text(help_text)
            return

        msg = await update.message.reply_text(
            "⏳ *Fetching locked tokens...*", parse_mode="Markdown"
        )
        try:
            limit = (
                int(context.args[0])
                if (context.args and context.args[0].isdigit())
                else 0
            )

            keep_tokens = any(arg.lower() in ["keep", "k"] for arg in context.args)

            locked_tokens = await self.database.get_locked_tokens(
                limit=limit, remove_after_fetch=not keep_tokens
            )

            if not locked_tokens:
                await msg.edit_text("⚠️ No locked tokens found in database.")
                return

            formatted_tokens = await self.format_locked_tokens(locked_tokens)

            if not formatted_tokens:
                await msg.edit_text("⚠️ No valid locked tokens found in database.")
                return

            content = "\n".join(formatted_tokens)
            timenow = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
            file_content = BytesIO(content.encode("utf-8"))
            file_content.name = f"locked_tokens_{timenow}.txt"

            await msg.delete()
            await update.message.reply_document(
                document=file_content,
                caption=f"📄 Found {len(formatted_tokens)} locked tokens"
                + (
                    f" (kept in database)"
                    if keep_tokens
                    else f" (removed from database)"
                ),
            )
        except Exception as e:
            self.debug.log(f"Error in get_locked_tokens: {str(e)}")
            await msg.edit_text(f"❌ An error occurred: {str(e)}")

    async def format_locked_tokens(self, tokens: list[dict]) -> list[str]:
        fields = ["username", "password", "email", "mailpwd", "ct0", "auth_token"]

        return [
            ":".join(
                str(token.get(field, "") or "").strip()
                for field in fields
                if token.get(field)
            )
            for token in tokens
        ]

    @owner()
    async def get_trash_accounts(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        if not await self.cooldown.check(update.message.from_user.id, "trash"):
            await update.message.reply_text(
                config.COOLDOWN_MESSAGE, parse_mode="Markdown"
            )
            return

        if "help" in context.args:
            help_text = (
                "Trash Command Help:\n"
                "/trash - Fetches all trash accounts and removes them from the database\n"
                "/trash 10 - Fetches the 10 most recent trash accounts and removes them\n"
                "/trash keep - Fetches all trash accounts but keeps them in the database\n"
                "/trash 10 keep - Fetches the 10 most recent trash accounts but keeps them"
            )
            await update.message.reply_text(help_text)
            return

        msg = await update.message.reply_text(
            "⏳ *Fetching trash accounts...*", parse_mode="Markdown"
        )
        try:
            limit = (
                int(context.args[0])
                if (context.args and context.args[0].isdigit())
                else 0
            )
            keep_accounts = any(arg.lower() in ["keep", "k"] for arg in context.args)
            trash_accounts = await self.database.fetch_trash_accounts(
                limit=limit, remove_after_fetch=not keep_accounts
            )
            if not trash_accounts:
                await msg.edit_text("⚠️ No trash accounts found in database.")
                return
            fields = ["username", "password", "email", "mailpwd", "ct0", "auth"]
            formatted = [
                ":".join(
                    str(acc.get(f, "") or "").strip() for f in fields if acc.get(f)
                )
                for acc in trash_accounts
            ]
            if not formatted:
                await msg.edit_text("⚠️ No valid trash accounts found in database.")
                return
            content = "\n".join(formatted)
            from datetime import datetime

            timenow = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
            from io import BytesIO

            file_content = BytesIO(content.encode("utf-8"))
            file_content.name = f"trash_accounts_{timenow}.txt"
            await msg.delete()
            await update.message.reply_document(
                document=file_content,
                caption=f"📄 Found {len(formatted)} trash accounts"
                + (
                    f" (kept in database)"
                    if keep_accounts
                    else f" (removed from database)"
                ),
            )
        except Exception as e:
            self.debug.log(f"Error in get_trash_accounts: {str(e)}")
            await msg.edit_text(f"❌ An error occurred: {str(e)}")

    @owner()
    async def secure(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if context.args and context.args[0].lower() == "check":

            def is_valid_backup_code(value):
                return bool(value)

            def has_mailpwd(acc):
                return bool(acc.get("mailpwd"))

            types = [
                ("normal", "Normal"),
                ("follower", "Follower"),
                ("blue", "Blue"),
                ("blueplus", "Blue Plus"),
                ("grey", "Grey"),
                ("gold", "Gold"),
                ("chars", "Chars"),
            ]
            results = []
            for t, label in types:
                accounts = await getattr(self.database, f"get_{t}_accounts")()
                total = len(accounts)
                secured = sum(
                    1
                    for acc in accounts
                    if is_valid_backup_code(acc.get("backup_code"))
                )
                not_secured = total - secured
                mailpwd_count = sum(1 for acc in accounts if has_mailpwd(acc))
                results.append(
                    f"{label}: {secured}/{total} secured, {not_secured} not secured, {mailpwd_count} with mailpwd"
                )
            await update.message.reply_text("\n".join(results), parse_mode="Markdown")
            return

        if not await self.cooldown.check(update.message.from_user.id, "secure"):
            await update.message.reply_text(
                config.COOLDOWN_MESSAGE, parse_mode="Markdown"
            )
            return

        usage_message = (
            "🔐 *Account Security Enhancement*\n\n"
            "*Command Format:*\n"
            "`/secure <type> <security> [filters] [options]`\n\n"
            "*1️⃣ Account Types:*\n"
            "• `normal` - Normal accounts\n"
            "• `blue` - Blue verified accounts\n"
            "• `blueplus` - Blue Plus accounts\n"
            "• `grey` - Grey verified accounts\n"
            "• `gold` - Gold verified accounts\n"
            "• `follower` - Follower accounts\n"
            "• `chars` - Character accounts\n"
            "• `mstats` - Mstats accounts (100-999 followers)\n\n"
            "*2️⃣ Security Options (at least one required):*\n"
            "• `password` - Change account passwords\n"
            "• `email` - Change account emails\n"
            "• `2fa` - Enable 2FA protection\n\n"
            "*3️⃣ Filter Options (optional):*\n"
            "• `0-9`, `10-29`, `30-99` - Follower ranges\n"
            "• `fv` - Fully verified (normal only)\n"
            "• `ev` - Email verified (normal only)\n"
            "• `pv` - Phone verified (normal only)\n"
            "• `uv` - Unverified (normal only)\n"
            "• `mixed` - Mixed verification (normal only)\n"
            "• `ma` - Mail access required\n\n"
            "*4️⃣ Additional Options (optional):*\n"
            "• `threads=N` - Number of threads (default: 5)\n"
            "• `length=N` - Password length (default: 12)\n"
            "• `limit=N` - Process N accounts only\n\n"
            "*📝 Examples:*\n"
            "1. Secure normal accounts with 0-9 followers:\n"
            "   `/secure normal password 0-9 fv`\n\n"
            "2. Change email and add 2FA for blue accounts:\n"
            "   `/secure blue email 2fa ma threads=5`\n\n"
            "3. Full security for follower accounts:\n"
            "   `/secure follower password email 2fa 10-99`\n\n"
            "*⚠️ Notes:*\n"
            "• Verification filters only work with normal accounts\n"
            "• At least one security option is required\n"
            "• Already secured accounts will be skipped\n"
            "• Failed accounts will be saved to a file"
        )

        if not context.args:
            await update.message.reply_text(usage_message, parse_mode="Markdown")
            return

        account_type = await self.get_account_type(context.args[0], update)
        if not account_type:
            await update.message.reply_text(
                "Invalid account type. Please use one of the supported account types.",
                parse_mode="Markdown",
            )
            return

        enable_password = "password" in context.args[1:]
        enable_email = "email" in context.args[1:]
        enable_2fa = "2fa" in context.args[1:]

        threads = 5
        password_length = 12
        limit = 0
        follower_range = None
        verification = None
        mail_access = False

        for arg in context.args[1:]:
            if arg.startswith("threads="):
                try:
                    threads = int(arg.split("=")[1])
                except (ValueError, IndexError):
                    pass
            elif arg.startswith("length="):
                try:
                    password_length = int(arg.split("=")[1])
                except (ValueError, IndexError):
                    pass
            elif arg.startswith("limit="):
                try:
                    limit = int(arg.split("=")[1])
                except (ValueError, IndexError):
                    pass
            elif "-" in arg and all(part.isdigit() for part in arg.split("-")):
                try:
                    range_start, range_end = map(int, arg.split("-"))
                    follower_range = (range_start, range_end)
                except ValueError:
                    await update.message.reply_text(
                        "Invalid follower range format. Example: 0-9",
                        parse_mode="Markdown",
                    )
                    return
            elif arg in ["fv", "ev", "pv", "uv", "mixed"]:
                verification = arg
            elif arg == "ma":
                mail_access = True

        if not any([enable_password, enable_email, enable_2fa]):
            await update.message.reply_text(
                "⚠️ You must select at least one security option: password, email, or 2fa.",
                parse_mode="Markdown",
            )
            return

        msg = await update.message.reply_text(
            f"🔍 Preparing to enhance security for {account_type} accounts...",
            parse_mode="Markdown",
        )

        asyncio.create_task(
            self._run_security_enhancement(
                msg=msg,
                account_type=account_type,
                enable_password=enable_password,
                enable_email=enable_email,
                enable_2fa=enable_2fa,
                password_length=password_length,
                threads=threads,
                limit=limit,
                follower_range=follower_range,
                verification=verification,
                mail_access=mail_access,
                update=update,
            )
        )

        await msg.edit_text(
            f"🔒 Security enhancement for {account_type} accounts has been started as a background task.\n"
            f"• Password Change: {'✅' if enable_password else '❌'}\n"
            f"• Email Change: {'✅' if enable_email else '❌'}\n"
            f"• 2FA Setup: {'✅' if enable_2fa else '❌'}\n"
            f"• Threads: {threads}\n"
            f"• Password Length: {password_length}\n"
            + (
                f"• Follower Range: {follower_range[0]}-{follower_range[1]}\n"
                if follower_range
                else ""
            )
            + (f"• Verification: {verification}\n" if verification else "")
            + (
                f"• Mail Access: {'✅' if mail_access else '❌'}\n"
                if mail_access
                else ""
            )
            + f"\n⏳ Processing in background. You can continue using other commands.",
            parse_mode="Markdown",
        )

    async def _run_security_enhancement(
        self,
        msg,
        account_type,
        enable_password,
        enable_email,
        enable_2fa,
        password_length,
        threads,
        limit,
        follower_range,
        verification,
        mail_access,
        update,
    ):
        """Run the security enhancement process as a non-blocking background task"""
        enhancer = TelegramSecurityEnhancer(
            db_manager=self.database, account_type=account_type
        )
        enhancer.enable_password_change = enable_password
        enhancer.enable_email_change = enable_email
        enhancer.enable_2fa = enable_2fa
        enhancer.password_length = password_length

        enhancer.set_filters(
            follower_range=follower_range,
            verification=verification,
            mail_access=mail_access,
        )

        stop_progress = asyncio.Event()
        progress_task = None

        try:
            await enhancer.load_unsecured_accounts(limit)

            if not enhancer.tokens:
                await msg.edit_text(
                    f"⚠️ No unsecured {account_type} accounts found matching your criteria.",
                    parse_mode="Markdown",
                )
                return

            await update.message.reply_text(
                f"We have {len(enhancer.tokens)} {account_type} accounts to process, if this message seems stuck after the progress bar has reached 100%, it means that there are some accounts that are still awaiting for mail code."
            )

            await msg.edit_text(
                f"🔒 Processing {len(enhancer.tokens)} {account_type} accounts with:\n"
                f"• Password Change: {'✅' if enable_password else '❌'}\n"
                f"• Email Change: {'✅' if enable_email else '❌'}\n"
                f"• 2FA Setup: {'✅' if enable_2fa else '❌'}\n"
                f"• Threads: {threads}\n"
                f"• Password Length: {password_length}\n"
                + (
                    f"• Follower Range: {follower_range[0]}-{follower_range[1]}\n"
                    if follower_range
                    else ""
                )
                + (f"• Verification: {verification}\n" if verification else "")
                + (
                    f"• Mail Access: {'✅' if mail_access else '❌'}\n"
                    if mail_access
                    else ""
                )
                + f"\n⏳ Processing in background...",
                parse_mode="Markdown",
            )

            filters_dict = {
                "follower_range": follower_range,
                "verification": verification,
                "mail_access": mail_access,
            }
            options_dict = {"threads": threads, "password_length": password_length}

            progress_task = asyncio.create_task(
                enhancer.run_progress_updater(
                    msg, filters=filters_dict, options=options_dict
                )
            )

            start_time = datetime.now()
            success, failed, skipped, filtered_out = await enhancer.process_accounts(
                threads=threads
            )
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()

            success_rate = (
                (success / len(enhancer.tokens) * 100) if enhancer.tokens else 0
            )

            if enhancer.failed_accounts:
                failed_content = "\n".join(
                    [
                        ":".join(
                            str(acc.get(field, ""))
                            for field in [
                                "username",
                                "password",
                                "email",
                                "mailpwd",
                                "ct0",
                                "auth",
                                "backup_code",
                            ]
                            if acc.get(field)
                        )
                        for acc in enhancer.failed_accounts
                    ]
                )
                file_content = BytesIO(failed_content.encode("utf-8"))
                file_content.name = f"failed_{account_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                await update.message.reply_document(
                    document=file_content,
                    caption=f"⚠️ {len(enhancer.failed_accounts)} accounts failed to enhance",
                )

            if enhancer.skipped_accounts:
                skipped_content = "\n".join(
                    [
                        ":".join(
                            str(acc.get(field, ""))
                            for field in [
                                "username",
                                "password",
                                "email",
                                "mailpwd",
                                "ct0",
                                "auth",
                                "backup_code",
                            ]
                            if acc.get(field)
                        )
                        for acc in enhancer.skipped_accounts
                    ]
                )
                file_content = BytesIO(skipped_content.encode("utf-8"))
                file_content.name = f"skipped_{account_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                await update.message.reply_document(
                    document=file_content,
                    caption=f"⚠️ {len(enhancer.skipped_accounts)} accounts skipped",
                )

        except Exception as e:
            import traceback

            error_msg = f"Error during security enhancement: {str(e)}\\n{traceback.format_exc()}"
            self.debug.log(error_msg)
            await msg.edit_text(
                f"❌ Security enhancement failed: {str(e)}\\nPlease check logs for details.",
                parse_mode="Markdown",
            )

        finally:

            stop_progress.set()
            if progress_task and not progress_task.done():
                try:

                    await asyncio.wait_for(progress_task, timeout=10.0)
                except asyncio.TimeoutError:
                    self.debug.log("Progress updater task timed out during shutdown.")
                    progress_task.cancel()
                except Exception as final_e:
                    self.debug.log(f"Error while waiting for progress task: {final_e}")

    async def process_zip_upload(self, update: Update, pfp_type: str) -> bool:
        if (
            not update.message.document
            or not update.message.document.file_name.endswith(".zip")
        ):
            await update.message.reply_text(
                "Please upload a ZIP file containing images."
            )
            return False

        target_dir = config.PFPS_HUMAN if pfp_type == "human" else config.PFPS_NFT
        os.makedirs(target_dir, exist_ok=True)

        file = await update.message.document.get_file()
        zip_path = os.path.join(self.UPLOAD_DIR, f"{pfp_type}_upload.zip")

        try:
            await file.download_to_drive(zip_path)

            with zipfile.ZipFile(zip_path, "r") as zip_ref:
                for file in zip_ref.namelist():
                    if file.lower().endswith((".png", ".jpg", ".jpeg", ".gif")):
                        zip_ref.extract(file, target_dir)

            os.remove(zip_path)
            return True

        except Exception as e:
            self.debug.log(f"Error processing zip file: {str(e)}")
            await update.message.reply_text(
                "Error processing the ZIP file. Please try again."
            )
            if os.path.exists(zip_path):
                os.remove(zip_path)
            return False

    async def process_zip_banner_upload(self, update: Update) -> bool:
        if (
            not update.message.document
            or not update.message.document.file_name.endswith(".zip")
        ):
            await update.message.reply_text(
                "Please upload a ZIP file containing images."
            )
            return False
        target_dir = config.BANNERS
        os.makedirs(target_dir, exist_ok=True)
        file = await update.message.document.get_file()
        zip_path = os.path.join(self.UPLOAD_DIR, "banner_upload.zip")
        try:
            await file.download_to_drive(zip_path)
            with zipfile.ZipFile(zip_path, "r") as zip_ref:
                images = [
                    f
                    for f in zip_ref.namelist()
                    if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif"))
                    and not f.endswith("/")
                ]
                [
                    open(os.path.join(target_dir, os.path.basename(f)), "wb").write(
                        zip_ref.read(f)
                    )
                    for f in images
                ]
            os.remove(zip_path)
            return True
        except Exception as e:
            self.debug.log(f"Error processing zip file: {str(e)}")
            await update.message.reply_text(
                "Error processing the ZIP file. Please try again."
            )
            if os.path.exists(zip_path):
                os.remove(zip_path)
            return False

    @owner()
    async def secured_check(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Check secured accounts with filters similar to getstock"""
        try:
            if not await self.cooldown.check(update.message.from_user.id, "secured"):
                await update.message.reply_text(
                    config.COOLDOWN_MESSAGE, parse_mode="Markdown"
                )
                return

            if not context.args:
                await update.message.reply_text(
                    "⚠️ Usage: `/secured <type> [options]`\n\n"
                    "*Account Types:*\n"
                    "• `normal` - Normal accounts\n"
                    "• `blue` - Blue verified accounts\n"
                    "• `blueplus` - Blue Plus accounts\n"
                    "• `grey` - Grey verified accounts\n"
                    "• `gold` - Gold verified accounts\n"
                    "• `follower` - Follower accounts\n"
                    "• `chars` - Character accounts\n"
                    "• `all` - All account types\n\n"
                    "*Options:*\n"
                    "• `0-9`, `10-29`, etc - Follower range\n"
                    "• `fv` - Fully verified accounts (normal only)\n"
                    "• `ev` - Email verified accounts (normal only)\n"
                    "• `pv` - Phone verified accounts (normal only)\n"
                    "• `uv` - Unverified accounts (normal only)\n"
                    "• `ma` - Mail access accounts\n"
                    "• `mixed` - Mixed verification accounts (UV+EV)\n\n"
                    "*Examples:*\n"
                    "• `/secured normal 0-9 fv` - FV secured normal accounts with 0-9 followers\n"
                    "• `/secured normal mixed 0-9` - Mixed secured accounts with 0-9 followers\n"
                    "• `/secured blue ma` - Secured blue accounts with mail access\n"
                    "• `/secured follower` - All secured follower accounts\n"
                    "• `/secured all` - All secured accounts from all types",
                    parse_mode="Markdown",
                )
                return

            account_type_arg = context.args[0].lower()
            is_all_types = account_type_arg == "all"

            accounts_to_process = []
            actual_account_type_for_filter = None

            msg = await update.message.reply_text("⏳ Fetching secured accounts...")

            if is_all_types:
                account_types_to_fetch = [
                    "normal",
                    "blue",
                    "grey",
                    "gold",
                    "follower",
                    "blueplus",
                    "chars",
                    "mstats",
                ]
                for acc_type in account_types_to_fetch:
                    try:
                        accounts = await getattr(
                            self.database, f"get_{acc_type}_accounts"
                        )()
                        secured_accounts = [
                            acc for acc in accounts if acc.get("backup_code")
                        ]
                        for acc in secured_accounts:
                            acc["type"] = acc_type
                        accounts_to_process.extend(secured_accounts)
                    except Exception as e:
                        self.debug.log(
                            f"Error fetching {acc_type} for /secured all: {e}"
                        )
                actual_account_type_for_filter = "all"
            else:
                resolved_account_type = await self.get_account_type(
                    account_type_arg, update
                )
                if not resolved_account_type:
                    await msg.edit_text(
                        "Invalid account type. Use /secured for usage info."
                    )
                    return
                try:
                    accounts = await getattr(
                        self.database, f"get_{resolved_account_type}_accounts"
                    )()
                    accounts_to_process = [
                        acc for acc in accounts if acc.get("backup_code")
                    ]
                    for acc in accounts_to_process:
                        acc["type"] = resolved_account_type
                    actual_account_type_for_filter = resolved_account_type
                except Exception as e:
                    await msg.edit_text(
                        f"Error fetching {resolved_account_type} accounts: {str(e)}"
                    )
                    self.debug.log(
                        f"Error fetching {resolved_account_type} accounts: {e}"
                    )
                    return

            if not accounts_to_process:
                await msg.edit_text(
                    f"⚠️ No secured accounts found for {account_type_arg}."
                )
                return

            filters = {
                "verification": None,
                "mail_access": False,
                "range_min": None,
                "range_max": None,
                "secured": False,
            }
            for arg in context.args[1:]:
                arg = arg.lower().strip()
                if "-" in arg:
                    try:
                        min_val, max_val = map(int, arg.split("-"))
                        filters["range_min"] = min(min_val, max_val)
                        filters["range_max"] = max(min_val, max_val)
                    except ValueError:
                        pass
                elif arg in ["fv", "ev", "pv", "uv", "mixed"]:

                    filters["verification"] = arg
                elif arg == "ma":
                    filters["mail_access"] = True
                elif arg.lower() == "secured":
                    filters["secured"] = True

            filtered_accounts = accounts_to_process.copy()

            if filters["verification"]:
                if filters["verification"] == "mixed":
                    filtered_accounts = [
                        acc
                        for acc in filtered_accounts
                        if (
                            actual_account_type_for_filter == "all"
                            and acc.get("type") == "normal"
                            and acc.get("verified", "").lower() in ["uv", "ev"]
                        )
                        or (
                            actual_account_type_for_filter == "normal"
                            and acc.get("verified", "").lower() in ["uv", "ev"]
                        )
                    ]
                else:
                    filtered_accounts = [
                        acc
                        for acc in filtered_accounts
                        if (
                            actual_account_type_for_filter == "all"
                            and acc.get("type") == "normal"
                            and acc.get("verified", "").lower()
                            == filters["verification"]
                        )
                        or (
                            actual_account_type_for_filter == "normal"
                            and acc.get("verified", "").lower()
                            == filters["verification"]
                        )
                    ]

            if filters["range_min"] is not None and filters["range_max"] is not None:
                filtered_accounts = [
                    acc
                    for acc in filtered_accounts
                    if (
                        str(acc.get("followers", "")).isdigit()
                        and filters["range_min"]
                        <= int(acc["followers"])
                        <= filters["range_max"]
                    )
                ]

            if filters["mail_access"]:
                filtered_accounts = [
                    acc for acc in filtered_accounts if acc.get("mailpwd")
                ]

            if filters.get("secured"):
                filtered_accounts = [acc for acc in filtered_accounts if acc.get("backup_code") and acc.get("backup_code") not in ["", "None", "0"]]

            if not filtered_accounts:
                await msg.edit_text("No secured accounts match the specified criteria.")
                return

            message = []

            filter_desc = []
            if filters["range_min"] is not None:
                filter_desc.append(
                    f"{filters['range_min']}-{filters['range_max']} followers"
                )
            if filters["verification"]:
                filter_desc.append(f"{filters['verification']} verification")
            if filters["mail_access"]:
                filter_desc.append("mail access")

            filter_text = f" ({', '.join(filter_desc)})" if filter_desc else ""

            if is_all_types:
                message.append(f"🔒 *Secured Accounts Statistics{filter_text}*\n")

                type_counts = {}
                for acc in filtered_accounts:
                    acc_type = acc.get("type", "unknown")
                    type_counts[acc_type] = type_counts.get(acc_type, 0) + 1

                message.append(
                    f"📊 *Total Secured Accounts: {len(filtered_accounts):,}*\n"
                )

                for acc_type, count in sorted(
                    type_counts.items(), key=lambda x: x[1], reverse=True
                ):
                    message.append(f"*{acc_type.title()} Accounts: {count:,}*")

                    type_accounts = [
                        acc for acc in filtered_accounts if acc.get("type") == acc_type
                    ]

                    if acc_type == "normal":
                        verification_counts = {}
                        for acc in type_accounts:
                            v_type = acc.get("verified", "unknown")
                            verification_counts[v_type] = (
                                verification_counts.get(v_type, 0) + 1
                            )

                        for v_type, v_count in sorted(
                            verification_counts.items(),
                            key=lambda x: x[1],
                            reverse=True,
                        ):
                            if v_type in ["fv", "pv", "ev", "uv"]:
                                v_label = {
                                    "fv": "Fully Verified",
                                    "pv": "Phone Verified",
                                    "ev": "Email Verified",
                                    "uv": "Unverified",
                                }.get(v_type, v_type)
                                message.append(f"├ {v_label}: {v_count:,}")

                    ranges = [
                        (0, 9),
                        (10, 29),
                        (30, 99),
                        (100, 499),
                        (500, 999),
                        (1000, 4999),
                        (5000, 9999),
                        (10000, float("inf")),
                    ]
                    range_counts = {}

                    for acc in type_accounts:
                        followers = (
                            int(acc.get("followers", 0))
                            if str(acc.get("followers", "")).isdigit()
                            else 0
                        )
                        for start, end in ranges:
                            if start <= followers <= end:
                                range_label = (
                                    f"{start}-{end}"
                                    if end != float("inf")
                                    else f"{start}+"
                                )
                                range_counts[range_label] = (
                                    range_counts.get(range_label, 0) + 1
                                )
                                break

                    for range_label, count in sorted(
                        range_counts.items(),
                        key=lambda x: (
                            int(x[0].split("-")[0])
                            if "-" in x[0]
                            else int(x[0].replace("+", ""))
                        ),
                    ):
                        if count > 0:
                            message.append(f"├ {range_label} followers: {count:,}")

                    mail_access_count = sum(
                        1 for acc in type_accounts if acc.get("mailpwd")
                    )
                    if mail_access_count > 0:
                        message.append(f"├ With mail access: {mail_access_count:,}")

                    message.append("")
            else:

                message.append(
                    f"🔒 *{actual_account_type_for_filter.title()} Secured Accounts{filter_text}*\n"
                )
                message.append(f"📊 *Total: {len(filtered_accounts):,}*\n")

                if actual_account_type_for_filter == "normal":
                    verification_counts = {}
                    for acc in filtered_accounts:
                        v_type = acc.get("verified", "unknown")
                        verification_counts[v_type] = (
                            verification_counts.get(v_type, 0) + 1
                        )

                    message.append("*Verification Breakdown:*")
                    for v_type, v_count in sorted(
                        verification_counts.items(), key=lambda x: x[1], reverse=True
                    ):
                        if v_type in ["fv", "pv", "ev", "uv"]:
                            v_label = {
                                "fv": "Fully Verified",
                                "pv": "Phone Verified",
                                "ev": "Email Verified",
                                "uv": "Unverified",
                            }.get(v_type, v_type)
                            message.append(f"├ {v_label}: {v_count:,}")
                    message.append("")

                ranges = [
                    (0, 9),
                    (10, 29),
                    (30, 99),
                    (100, 499),
                    (500, 999),
                    (1000, 4999),
                    (5000, 9999),
                    (10000, float("inf")),
                ]
                range_counts = {}

                for acc in filtered_accounts:
                    followers = (
                        int(acc.get("followers", 0))
                        if str(acc.get("followers", "")).isdigit()
                        else 0
                    )
                    for start, end in ranges:
                        if start <= followers <= end:
                            range_label = (
                                f"{start}-{end}" if end != float("inf") else f"{start}+"
                            )
                            range_counts[range_label] = (
                                range_counts.get(range_label, 0) + 1
                            )
                            break

                message.append("*Follower Breakdown:*")
                for range_label, count in sorted(
                    range_counts.items(),
                    key=lambda x: (
                        int(x[0].split("-")[0])
                        if "-" in x[0]
                        else int(x[0].replace("+", ""))
                    ),
                ):
                    if count > 0:
                        message.append(f"├ {range_label} followers: {count:,}")

                mail_access_count = sum(
                    1 for acc in filtered_accounts if acc.get("mailpwd")
                )
                no_mail_access_count = len(filtered_accounts) - mail_access_count

                message.append("\n*Mail Access:*")
                message.append(f"├ With mail access: {mail_access_count:,}")
                message.append(f"├ Without mail access: {no_mail_access_count:,}")

            await self.post_stock_list(update, "\n".join(message))

        except Exception as e:
            self.debug.log(f"Error in secured_check: {str(e)}")
            await update.message.reply_text(f"An error occurred: {str(e)}")
            return

    @owner()
    async def unsecured_check(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Check unsecured accounts (without backup codes) with filters similar to secured_check"""
        try:
            if not await self.cooldown.check(update.message.from_user.id, "unsecured"):
                await update.message.reply_text(
                    config.COOLDOWN_MESSAGE, parse_mode="Markdown"
                )
                return

            if not context.args:
                await update.message.reply_text(
                    "⚠️ Usage: `/unsecured <type> [options]`\n\n"
                    "*Account Types:*\n"
                    "• `normal` - Normal accounts\n"
                    "• `blue` - Blue verified accounts\n"
                    "• `blueplus` - Blue Plus accounts\n"
                    "• `grey` - Grey verified accounts\n"
                    "• `gold` - Gold verified accounts\n"
                    "• `follower` - Follower accounts\n"
                    "• `chars` - Character accounts\n"
                    "• `mstats` - Mstats accounts (100-999 followers)\n"
                    "• `all` - All account types\n\n"
                    "*Options:*\n"
                    "• `0-9`, `10-29`, etc - Follower range\n"
                    "• `fv` - Fully verified accounts (normal only)\n"
                    "• `ev` - Email verified accounts (normal only)\n"
                    "• `pv` - Phone verified accounts (normal only)\n"
                    "• `uv` - Unverified accounts (normal only)\n"
                    "• `ma` - Mail access accounts\n"
                    "• `mixed` - Mixed verification accounts (UV+EV)\n\n"
                    "*Examples:*\n"
                    "• `/unsecured normal 0-9 fv` - FV unsecured normal accounts with 0-9 followers\n"
                    "• `/unsecured normal mixed 0-9` - Mixed unsecured accounts with 0-9 followers\n"
                    "• `/unsecured blue ma` - Unsecured blue accounts with mail access\n"
                    "• `/unsecured follower` - All unsecured follower accounts\n"
                    "• `/unsecured mstats` - All unsecured mstats accounts\n"
                    "• `/unsecured all` - All unsecured accounts from all types",
                    parse_mode="Markdown",
                )
                return
            account_type_arg = context.args[0].lower()
            is_all_types = account_type_arg == "all"

            accounts_to_process = []
            actual_account_type_for_filter = None

            msg = await update.message.reply_text("⏳ Fetching unsecured accounts...")

            if is_all_types:
                account_types_to_fetch = [
                    "normal",
                    "blue",
                    "grey",
                    "gold",
                    "follower",
                    "blueplus",
                    "chars",
                    "mstats",
                ]
                for acc_type in account_types_to_fetch:
                    try:
                        accounts = await getattr(
                            self.database, f"get_{acc_type}_accounts"
                        )()
                        unsecured_accounts = [
                            acc for acc in accounts if not acc.get("backup_code")
                        ]
                        for acc in unsecured_accounts:
                            acc["type"] = acc_type
                        accounts_to_process.extend(unsecured_accounts)
                    except Exception as e:
                        self.debug.log(
                            f"Error fetching {acc_type} for /unsecured all: {e}"
                        )
                actual_account_type_for_filter = "all"
            else:
                resolved_account_type = await self.get_account_type(
                    account_type_arg, update
                )
                if not resolved_account_type:
                    await msg.edit_text(
                        "Invalid account type. Use /unsecured for usage info."
                    )
                    return
                try:
                    accounts = await getattr(
                        self.database, f"get_{resolved_account_type}_accounts"
                    )()
                    accounts_to_process = [
                        acc for acc in accounts if not acc.get("backup_code")
                    ]
                    for acc in accounts_to_process:
                        acc["type"] = resolved_account_type
                    actual_account_type_for_filter = resolved_account_type
                except Exception as e:
                    await msg.edit_text(
                        f"Error fetching {resolved_account_type} accounts: {str(e)}"
                    )
                    self.debug.log(
                        f"Error fetching {resolved_account_type} accounts: {e}"
                    )
                    return

            if not accounts_to_process:
                await msg.edit_text(
                    f"⚠️ No unsecured accounts found for {account_type_arg}."
                )
                return

            filters = {
                "verification": None,
                "mail_access": False,
                "range_min": None,
                "range_max": None,
                "secured": False,
            }
            for arg in context.args[1:]:
                arg = arg.lower().strip()
                if "-" in arg:
                    try:
                        min_val, max_val = map(int, arg.split("-"))
                        filters["range_min"] = min(min_val, max_val)
                        filters["range_max"] = max(min_val, max_val)
                    except ValueError:
                        pass
                elif arg in ["fv", "ev", "pv", "uv", "mixed"]:

                    filters["verification"] = arg
                elif arg == "ma":
                    filters["mail_access"] = True
                elif arg.lower() == "secured":
                    filters["secured"] = True

            filtered_accounts = accounts_to_process.copy()

            if filters["verification"]:
                if filters["verification"] == "mixed":
                    filtered_accounts = [
                        acc
                        for acc in filtered_accounts
                        if (
                            actual_account_type_for_filter == "all"
                            and acc.get("type") == "normal"
                            and acc.get("verified", "").lower() in ["uv", "ev"]
                        )
                        or (
                            actual_account_type_for_filter == "normal"
                            and acc.get("verified", "").lower() in ["uv", "ev"]
                        )
                    ]
                else:
                    filtered_accounts = [
                        acc
                        for acc in filtered_accounts
                        if (
                            actual_account_type_for_filter == "all"
                            and acc.get("type") == "normal"
                            and acc.get("verified", "").lower()
                            == filters["verification"]
                        )
                        or (
                            actual_account_type_for_filter == "normal"
                            and acc.get("verified", "").lower()
                            == filters["verification"]
                        )
                    ]

            if filters["range_min"] is not None and filters["range_max"] is not None:
                filtered_accounts = [
                    acc
                    for acc in filtered_accounts
                    if (
                        str(acc.get("followers", "")).isdigit()
                        and filters["range_min"]
                        <= int(acc["followers"])
                        <= filters["range_max"]
                    )
                ]

            if filters["mail_access"]:
                filtered_accounts = [
                    acc for acc in filtered_accounts if acc.get("mailpwd")
                ]

            if filters.get("secured"):
                filtered_accounts = [acc for acc in filtered_accounts if acc.get("backup_code") and acc.get("backup_code") not in ["", "None", "0"]]

            if not filtered_accounts:
                await msg.edit_text(
                    "No unsecured accounts match the specified criteria."
                )
                return

            message = []

            filter_desc = []
            if filters["range_min"] is not None:
                filter_desc.append(
                    f"{filters['range_min']}-{filters['range_max']} followers"
                )
            if filters["verification"]:
                filter_desc.append(f"{filters['verification']} verification")
            if filters["mail_access"]:
                filter_desc.append("mail access")

            filter_text = f" ({', '.join(filter_desc)})" if filter_desc else ""

            if is_all_types:
                message.append(f"⚠️ *Unsecured Accounts Statistics{filter_text}*\n")

                type_counts = {}
                for acc in filtered_accounts:
                    acc_type = acc.get("type", "unknown")
                    type_counts[acc_type] = type_counts.get(acc_type, 0) + 1

                message.append(
                    f"📊 *Total Unsecured Accounts: {len(filtered_accounts):,}*\n"
                )

                for acc_type, count in sorted(
                    type_counts.items(), key=lambda x: x[1], reverse=True
                ):
                    message.append(f"*{acc_type.title()} Accounts: {count:,}*")

                    type_accounts = [
                        acc for acc in filtered_accounts if acc.get("type") == acc_type
                    ]

                    if acc_type == "normal":
                        verification_counts = {}
                        for acc in type_accounts:
                            v_type = acc.get("verified", "unknown")
                            verification_counts[v_type] = (
                                verification_counts.get(v_type, 0) + 1
                            )

                        for v_type, v_count in sorted(
                            verification_counts.items(),
                            key=lambda x: x[1],
                            reverse=True,
                        ):
                            if v_type in ["fv", "pv", "ev", "uv"]:
                                v_label = {
                                    "fv": "Fully Verified",
                                    "pv": "Phone Verified",
                                    "ev": "Email Verified",
                                    "uv": "Unverified",
                                }.get(v_type, v_type)
                                message.append(f"├ {v_label}: {v_count:,}")

                    ranges = [
                        (0, 9),
                        (10, 29),
                        (30, 99),
                        (100, 499),
                        (500, 999),
                        (1000, 4999),
                        (5000, 9999),
                        (10000, float("inf")),
                    ]
                    range_counts = {}

                    for acc in type_accounts:
                        followers = (
                            int(acc.get("followers", 0))
                            if str(acc.get("followers", "")).isdigit()
                            else 0
                        )
                        for start, end in ranges:
                            if start <= followers <= end:
                                range_label = (
                                    f"{start}-{end}"
                                    if end != float("inf")
                                    else f"{start}+"
                                )
                                range_counts[range_label] = (
                                    range_counts.get(range_label, 0) + 1
                                )
                                break

                    for range_label, count in sorted(
                        range_counts.items(),
                        key=lambda x: (
                            int(x[0].split("-")[0])
                            if "-" in x[0]
                            else int(x[0].replace("+", ""))
                        ),
                    ):
                        if count > 0:
                            message.append(f"├ {range_label} followers: {count:,}")

                    mail_access_count = sum(
                        1 for acc in type_accounts if acc.get("mailpwd")
                    )
                    if mail_access_count > 0:
                        message.append(f"├ With mail access: {mail_access_count:,}")

                    message.append("")
            else:

                message.append(
                    f"⚠️ *{actual_account_type_for_filter.title()} Unsecured Accounts{filter_text}*\n"
                )
                message.append(f"📊 *Total: {len(filtered_accounts):,}*\n")

                if actual_account_type_for_filter == "normal":
                    verification_counts = {}
                    for acc in filtered_accounts:
                        v_type = acc.get("verified", "unknown")
                        verification_counts[v_type] = (
                            verification_counts.get(v_type, 0) + 1
                        )

                    message.append("*Verification Breakdown:*")
                    for v_type, v_count in sorted(
                        verification_counts.items(), key=lambda x: x[1], reverse=True
                    ):
                        if v_type in ["fv", "pv", "ev", "uv"]:
                            v_label = {
                                "fv": "Fully Verified",
                                "pv": "Phone Verified",
                                "ev": "Email Verified",
                                "uv": "Unverified",
                            }.get(v_type, v_type)
                            message.append(f"├ {v_label}: {v_count:,}")
                    message.append("")

                ranges = [
                    (0, 9),
                    (10, 29),
                    (30, 99),
                    (100, 499),
                    (500, 999),
                    (1000, 4999),
                    (5000, 9999),
                    (10000, float("inf")),
                ]
                range_counts = {}

                for acc in filtered_accounts:
                    followers = (
                        int(acc.get("followers", 0))
                        if str(acc.get("followers", "")).isdigit()
                        else 0
                    )
                    for start, end in ranges:
                        if start <= followers <= end:
                            range_label = (
                                f"{start}-{end}" if end != float("inf") else f"{start}+"
                            )
                            range_counts[range_label] = (
                                range_counts.get(range_label, 0) + 1
                            )
                            break

                message.append("*Follower Breakdown:*")
                for range_label, count in sorted(
                    range_counts.items(),
                    key=lambda x: (
                        int(x[0].split("-")[0])
                        if "-" in x[0]
                        else int(x[0].replace("+", ""))
                    ),
                ):
                    if count > 0:
                        message.append(f"├ {range_label} followers: {count:,}")

                mail_access_count = sum(
                    1 for acc in filtered_accounts if acc.get("mailpwd")
                )
                no_mail_access_count = len(filtered_accounts) - mail_access_count

                message.append("\n*Mail Access:*")
                message.append(f"├ With mail access: {mail_access_count:,}")
                message.append(f"├ Without mail access: {no_mail_access_count:,}")

            await self.post_stock_list(update, "\n".join(message))

        except Exception as e:
            self.debug.log(f"Error in unsecured_check: {str(e)}")
            await update.message.reply_text(f"An error occurred: {str(e)}")
            return

    @owner()
    async def migrate_mstats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Migrate normal accounts to mstats accounts based on criteria"""
        if not await self.cooldown.check(update.message.from_user.id, "migrate"):
            await update.message.reply_text(
                config.COOLDOWN_MESSAGE, parse_mode="Markdown"
            )
            return

        msg = await update.message.reply_text(
            "⏳ Starting migration of normal accounts to mstats...",
            parse_mode="Markdown"
        )

        try:
            migrated_count = await self.database.migrate_normal_to_mstats()
            
            if migrated_count > 0:
                await msg.edit_text(
                    f"✅ Successfully migrated {migrated_count} accounts to mstats category.\n"
                    f"Criteria:\n"
                    f"• Follower count: 100-999\n"
                    f"• Verification status: FV, PV, EV, UV\n\n"
                    f"Use /stock mstats to view the migrated accounts.",
                    parse_mode="Markdown"
                )
            else:
                await msg.edit_text(
                    "⚠️ No accounts found matching mstats criteria:\n"
                    "• Follower count: 100-999\n"
                    "• Verification status: FV, PV, EV, UV",
                    parse_mode="Markdown"
                )
        except Exception as e:
            self.debug.log(f"Error during mstats migration: {str(e)}")
            await msg.edit_text(
                f"❌ Error during migration: {str(e)}",
                parse_mode="Markdown"
            )

    @owner()
    async def testsell(self, update, context):
        if len(context.args) < 4:
            await update.message.reply_text(
                "Usage: /testsell <type> <verification> <range> <quantity>\n"
                "Example: /testsell normal mixed 0-9 2"
            )
            return

        account_type = context.args[0].lower()
        verification = context.args[1].lower()
        range_str = context.args[2]
        try:
            quantity = int(context.args[3])
        except ValueError:
            await update.message.reply_text("Quantity must be a number.")
            return

        # Build product attributes (reuse your existing logic if possible)
        from src.products import ProductTypes
        products = await ProductTypes.list_all_products()
        # Find matching product
        product = None
        for p in products:
            if (
                p.attributes.product_type == account_type
                and getattr(p.attributes, verification, False)
                and p.attributes.range
                and f"{p.attributes.range[0]}-{p.attributes.range[1]}" == range_str
            ):
                product = p
                break

        if not product:
            await update.message.reply_text("❌ No matching product found.")
            return

        available = await ProductTypes.get_stock_count_for_product(product.id)
        if available < quantity:
            await update.message.reply_text(f"❌ Only {available} accounts available for this product.")
            return

        accounts = await db.get_accounts_by_product_attributes(product.attributes, quantity)
        if not accounts:
            await update.message.reply_text("❌ No accounts available for delivery.")
            return

        # Format accounts for delivery
        keys = ["username", "password", "email", "mailpwd", "ct0", "auth", "backup_code"]
        accounts_text = "\n".join(":".join(str(acc.get(k, "")) for k in keys) for acc in accounts)

        await send_accounts_to_user(
            order_id=f"TESTSELL-{product.id}-{update.effective_user.id}",
            user_id=update.effective_user.id,
            accounts_text=accounts_text,
            quantity=len(accounts),
            product_attrs=product.attributes,
        )
        await update.message.reply_text(
            f"✅ Test delivery of {len(accounts)} accounts for {account_type} {verification} {range_str} complete."
        )

