from functools import wraps
from telegram import Update
import config


def owner():
    def decorator(func):
        @wraps(func)
        async def wrapped(instance, update: Update, context, *args, **kwargs):
            if update.effective_user.id not in config.OWNERS:
                if update.message:
                    await update.message.reply_text(
                        config.UNAUTHORIZED_MESSAGE, parse_mode="Markdown"
                    )
                return
            return await func(instance, update, context, *args, **kwargs)

        return wrapped

    return decorator
