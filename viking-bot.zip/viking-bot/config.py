MAINTENANCE = False
TOKEN = "7788435262:AAE9Oj2zFbDUDY6o_MkPM7mwgIt3tk6u1kA"
PFPS = "database/pfps"
BANNERS = "database/banners"
PFPS_HUMAN = "database/pfps/human"
PFPS_NFT = "database/pfps/nft"
UPLOAD_DIR = "tmp"
DEBUG_CHANNEL = -1002656860358
NOTIFY_USER = "5219505880"
DEBUGGER_BOT_TOKENS = [
    "6576338367:AAG99U4-sWcKdvCyq7ImQLJs5df6qcdLU2Y",
    "7571439697:AAFLhHeAqWNUMdbPmjF8LId7eTvolhFiEEI",
    "8006803496:AAGYEKeSYD6hbS2Hg4ycpan1FFALmsygCok",
    "7457978700:AAEJQ8v-wF9W5zaXLdS74sQkAMR5tduG0f0",
    "7618756327:AAGBmJglI9L_TDB3GholAfnGWo8uPYlorZQ",
    "7457978700:AAEJQ8v-wF9W5zaXLdS74sQkAMR5tduG0f0",
    "7648509465:AAE2duMBtPpE8knvQPMtHgU6Y86B7yytO1Q",
    "8070178932:AAFua9lKQe39E0JqiwMq-FuEwwwIsd-0qZc",
    "7252338973:AAFhMC-gO8wd7TrfFiNZsuXmBKBm-3GUcdg",
]
DEBUG_WEBHOOK = False
COOLDOWN = 5

SHOP_ID = 56247

OWNERS = [5219505880, 6179477260, 6142769360, 7811423772, 6643893560]
UNAUTHORIZED_MESSAGE = "*Sorry, you're not allowed to access this function.*"
COOLDOWN_MESSAGE = "*You're doing that too often.*\nPlease wait a few seconds before using this command again."

PRICE_PER_FOLLOWER = 0.0085
PRICE_BLUE = 35.0
PRICE_BLUE_PLUS = 45.0
PRICE_GREY_GOLD = 4000.0
PRICE_CHARS = 40.0
PRICE_MSTATS = 5.0

SELL_APP_API_KEY = 'hxwOp1jev3FkllW7wHfAZhVbt4R78yEBYNiV7xLd0505048c'
SELF_API = "http://localhost:3030"
CRACKER_API = "http://localhost:5010"
FILE_SERVER_URL = "http://localhost:1337/download"

# updated → using your VPS IP:
WEBHOOK_URL = "https://vkapi.nextearth.store/callback"


DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1381875758770819102/mtJGNtAl1kdKQSar7bdB2kyRAEHbvfpqgynoWZMa5UrGPWC81xwT7fru8m3ox9W7i1fP"
DISCORD_WEBHOOK_ENABLED = True
LOCAL_DOMAIN = "gaszip.app"
THREADS = 500
CHANGE_PFP_ON_CHECK_NORMALS = False

BINANCE_PAY_ENABLED = False

BINANCE_API_KEY = "xxxx"
BINANCE_SECRET_KEY = "xxxx"
BINANCE_MERCHANT_ID = "xxxx"

PAYMENT_TIMEOUT = 30
CLEANUP_INTERVAL = 60

PAYMENT_TOLERANCE = {
    "BTC": 0.95,
    "USDT_TRC20": 0.99,
    "USDT_ERC20": 0.95,
    "USDT_BEP20": 0.97,
    "DEFAULT": 0.98,
}

CRYPTO_ADDRESSES = {
    "BTC": "bc1qnc5cjlyqtl6ceeehcyjd3qz7m05lmvy70uckd5",
    "ETH": "0x135414D403e82139dcCD4b281A0c3e0FE5761029",
    "LTC": "MLUEAvUN84EyMatUbcb3zxLQ3MYJjWf6et",
    "USDT_TRC20": "TLDuoGDH7Ve5RUu2vatDsonowT3t7NrV9M",
    "USDT_ERC20": "0x135414D403e82139dcCD4b281A0c3e0FE5761029",
    "USDT_BEP20": "0x8BCa0807bEb2218219E5F64c818Ee0351B201272",
}

# updated → fast confirmations for testing:
CONFIRMATIONS_REQUIRED = {
    "BTC": 1,
    "LTC": 1,
    "ETH": 1,
    "USDT_TRC20": 1,
    "USDT_ERC20": 1,
    "USDT_BEP20": 1,
    "DEFAULT": 1,
}

from cogs.decorators import owner
