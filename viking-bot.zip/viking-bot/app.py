from fastapi import FastAPI, Request, HTTPException, Header
from fastapi.responses import JSONResponse, PlainTextResponse
from typing import List, Optional, Union, Dict, Any, Set
from datetime import datetime
import json
import asyncio
from src.db import DatabaseManager
from src.products import ProductAttributes, ProductTypes
import httpx
import config
import uvicorn
import traceback
import requests
import aiofiles
from pathlib import Path
from core.client import bulk_change_password
from src.products import Types
from src.debugger import Debugger
import socket
from cogs.stocks import stocks
from telegram.ext import CommandHandler

OWNER = [5219505880, 7811423772]
fastapi_app = FastAPI()
db: DatabaseManager | None = None
debug = Debugger()

ALLOWED_IPS = ["51.77.105.132", "135.125.112.47"]  # NOT USED FOR NOW


def mark_as_voided(invoice_id):
    url = f"https://sell.app/api/v2/invoices/{invoice_id}/mark-voided"

    payload = ""
    headers = {
        "Content-Type": "application/json",
        "accept": "application/json",
        "Authorization": "Bearer rSc8Kg5C6OAVVPFfBj4cOoeECAMG9kdBCNpuZ8wg20678543",
    }

    try:
        response = requests.request("PATCH", url, data=payload, headers=headers)
        if response.status_code == 200:
            print(f"Invoice {invoice_id} marked as voided")
        else:
            print(
                f"Failed to mark invoice {invoice_id} as voided: Status {response.status_code}, Response: {response.text}"
            )
    except Exception as e:
        print(f"Failed to mark invoice {invoice_id} as voided: {str(e)}")


async def send_telegram_message(message: str, parse_mode: str = "Markdown") -> None:
    """Send a message to Telegram using a temporary client"""
    async with httpx.AsyncClient(timeout=30.0) as client:
        for owner in OWNER:
            try:
                await client.post(
                    f"https://api.telegram.org/bot{config.TOKEN}/sendMessage",
                    json={"chat_id": owner, "text": message, "parse_mode": parse_mode},
                )
            except Exception as e:
                debug.log(f"Error sending message to owner {owner}: {e}")


async def send_discord_webhook(
    title: str, description: str, color: int = 0x5865F2, fields: list = []
) -> None:
    """Send a message to Discord webhook using a temporary client"""
    if not config.DISCORD_WEBHOOK_ENABLED or not config.DISCORD_WEBHOOK_URL:
        return

    embed = {
        "title": title,
        "description": description,
        "color": color,
        "timestamp": datetime.now().isoformat(),
    }

    if fields:
        embed["fields"] = fields

    payload = {"embeds": [embed]}

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            await client.post(
                config.DISCORD_WEBHOOK_URL,
                json=payload,
                headers={"Content-Type": "application/json"},
            )
    except Exception as e:
        debug.log(f"Error sending Discord webhook: {str(e)}")


async def init_app(database: DatabaseManager = None):  # type: ignore
    """Initialize FastAPI app with database instance"""
    global db
    if database:
        print("✓ Using provided database instance")
        db = database
    else:
        print("✓ Creating new database instance")
        db = DatabaseManager()
    return fastapi_app


def is_port_available(port: int, host: str = "localhost") -> bool:
    """Check if a port is available on the given host."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind((host, port))
            return True
        except OSError:
            return False


async def find_available_port(start_port: int = 7070, max_attempts: int = 10) -> int:
    """Find an available port starting from start_port."""
    port = start_port
    for _ in range(max_attempts):
        if is_port_available(port):
            return port
        port += 1
    raise RuntimeError(
        f"Could not find an available port after {max_attempts} attempts"
    )


async def run_fastapi(host: str = "localhost", port: int = 7070):
    """Run FastAPI server using uvicorn with automatic port selection"""
    try:
        uvicorn_config = uvicorn.Config(
            "app:fastapi_app",
            host=host,
            port=port,
            log_level="info",
            loop="asyncio",
            reload=False,
        )
        server = uvicorn.Server(uvicorn_config)
        await server.serve()
    except Exception as e:
        print(f"Failed to start server: {str(e)}")
        print(
            "Please try running with administrator privileges or use a different port"
        )
        return JSONResponse(
            content={"status": "error", "message": str(e)}, status_code=400
        )


def log_webhook_data(event_type: str, data: Dict[str, Any]) -> None:
    print(f"\n{'='*50}")
    print(f"Webhook Event: {event_type}")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print(f"{'='*50}\n")


async def fetch_product_title(product_id: str, query_params: dict) -> str:
    """
    Fetch and return the product title for a given product_id.
    If the query parameters include 'product_title', immediately use it.
    Otherwise, try to fetch from SellApp and cache it; if that fails, use the DB cache.
    """
    if query_params.get("product_title"):
        return query_params["product_title"]
    try:
        sellapp_product = SellApp(config.SELL_APP_API_KEY).get_product(product_id)
        if sellapp_product and "data" in sellapp_product:
            product_title = sellapp_product["data"].get("title", "Product")
            await db.cache_product_title(product_id, product_title)
            return product_title
    except Exception as e:
        debug.log(f"Error fetching product title from SellApp for {product_id}: {e}")
    return await db.get_product_title(product_id)


def format_timestamp(timestamp: str) -> str:
    """Convert ISO timestamp to a more readable format"""
    try:
        dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    except:
        return timestamp


async def handle_feedback(data: Dict[str, Any]) -> Dict[str, Any]:
    log_webhook_data("feedback", data)
    feedback_data = data.get("data", {})

    message = (
        "⭐ *New Feedback Received!*\n\n"
        f"Rating: {'⭐' * feedback_data.get('rating', 0)}\n"
        f"Type: `{feedback_data.get('feedback', 'N/A')}`\n"
        f"Message: `{feedback_data.get('message', 'No message')}`\n\n"
        f"Store ID: `{feedback_data.get('store_id')}`\n"
        f"Invoice ID: `{feedback_data.get('invoice_id')}`\n"
        f"Time: `{format_timestamp(feedback_data.get('created_at', 'N/A'))}`"
    )

    await send_telegram_message(message)

    return {
        "status": "success",
        "feedback": {
            "id": feedback_data.get("id"),
            "rating": feedback_data.get("rating"),
            "message": feedback_data.get("message"),
            "type": feedback_data.get("feedback"),
            "store_id": feedback_data.get("store_id"),
            "invoice_id": feedback_data.get("invoice_id"),
            "created_at": format_timestamp(feedback_data.get("created_at")),
        },
    }


async def handle_order(data: Dict[str, Any]) -> Dict[str, Any]:
    log_webhook_data("order", data)
    order_data = data.get("data", {})
    payment = order_data.get("payment", {})
    status = order_data.get("status", {}).get("status", {})

    customer_info = order_data.get("customer_information", {})
    product_variants = order_data.get("product_variants", [])

    order = {
        "id": order_data.get("id"),
        "store_id": order_data.get("store_id"),
        "subtotal": payment.get("subtotal", {}).get("total", {}).get("inclusive"),
        "currency": payment.get("subtotal", {}).get("currency"),
        "status": status.get("status"),
        "created_at": format_timestamp(order_data.get("created_at")),
        "updated_at": format_timestamp(order_data.get("updated_at")),
    }

    if data.get("event") == "order.created":
        await db.add_sellapp_order(order["id"], "PENDING")

        message = (
            "🛍️ *New Sell.App Order!*\n\n"
            f"🔖 Order ID: `{order['id']}`\n"
            f"📊 Status: `{order['status']}`\n\n"
            "👤 *Customer Details:*\n"
            f"📧 Email: `{customer_info.get('email', 'N/A')}`\n"
            f"🌍 Location: `{customer_info.get('location', 'N/A')}, {customer_info.get('country', 'N/A')}`\n"
            f"🌐 IP: `{customer_info.get('ip', 'N/A')}`\n\n"
            "🛒 *Products:*\n"
        )

        for variant in product_variants:
            quantity = variant.get("quantity", 0)

            message += (
                f"📦 {variant.get('product_title', 'Unknown Product')}\n"
                f"   • Quantity: {quantity}\n"
                f"   • Variant: {variant.get('variant_title', 'Default')}\n"
            )

        await send_telegram_message(message)

        discord_fields = [
            {"name": "Order ID", "value": order["id"], "inline": True},
            {"name": "Status", "value": order["status"], "inline": True},
            {
                "name": "Amount",
                "value": f"{order['subtotal']} {order['currency']}",
                "inline": True,
            },
            {
                "name": "Customer Email",
                "value": customer_info.get("email", "N/A"),
                "inline": True,
            },
            {
                "name": "Location",
                "value": f"{customer_info.get('location', 'N/A')}, {customer_info.get('country', 'N/A')}",
                "inline": True,
            },
            {
                "name": "IP Address",
                "value": customer_info.get("ip", "N/A"),
                "inline": True,
            },
        ]

        products_info = ""
        for variant in product_variants:
            products_info += f"• {variant.get('product_title', 'Unknown Product')} x {variant.get('quantity', 0)} ({variant.get('variant_title', 'Default')})\n"

        discord_fields.append(
            {
                "name": "Products",
                "value": products_info if products_info else "N/A",
                "inline": False,
            }
        )

        await send_discord_webhook(
            title="🛍️ New Sell.App Order",
            description=f"New order received from Sell.App on {order['created_at']}",
            color=0x3498DB,
            fields=discord_fields,
        )

    elif data.get("event") == "order.completed":
        message = (
            "✅ *Order Completed!*\n\n"
            f"🔖 Order ID: `{order['id']}`\n"
            f"📊 Status: `{order['status']}`\n\n"
            "👤 *Customer Details:*\n"
            f"📧 Email: `{customer_info.get('email', 'N/A')}`\n"
            f"🌍 Location: `{customer_info.get('location', 'N/A')}, {customer_info.get('country', 'N/A')}`\n"
            f"🌐 IP: `{customer_info.get('ip', 'N/A')}`\n\n"
            "🛒 *Products:*\n"
        )

        for variant in product_variants:
            message += (
                f"📦 {variant.get('product_title', 'Unknown Product')}\n"
                f"   • Quantity: {variant.get('quantity', 0)}\n"
                f"   • Variant: {variant.get('variant_title', 'Default')}\n"
                f"{variant.get('invoice_payment', {}).get('payment_details', {}).get('unit_price', '0')}\n\n"
            )

        await send_telegram_message(message)

        discord_fields = [
            {"name": "Order ID", "value": order["id"], "inline": True},
            {"name": "Status", "value": order["status"], "inline": True},
            {
                "name": "Amount",
                "value": f"{order['subtotal']} {order['currency']}",
                "inline": True,
            },
            {
                "name": "Customer Email",
                "value": customer_info.get("email", "N/A"),
                "inline": True,
            },
            {
                "name": "Location",
                "value": f"{customer_info.get('location', 'N/A')}, {customer_info.get('country', 'N/A')}",
                "inline": True,
            },
            {
                "name": "IP Address",
                "value": customer_info.get("ip", "N/A"),
                "inline": True,
            },
        ]

        products_info = ""
        for variant in product_variants:
            products_info += f"• {variant.get('product_title', 'Unknown Product')} x {variant.get('quantity', 0)} ({variant.get('variant_title', 'Default')})\n"

        discord_fields.append(
            {
                "name": "Products",
                "value": products_info if products_info else "N/A",
                "inline": False,
            }
        )

        await send_discord_webhook(
            title="✅ Order Completed",
            description=f"Order completed on {order['updated_at']}",
            color=0x2ECC71,
            fields=discord_fields,
        )

    print(
        f"Order {order['id']} {data.get('event').split('.')[1]} "
        f"for store {order['store_id']}"
    )
    return {"status": "success", "order": order}


def handle_product(data: Dict[str, Any]) -> Dict[str, Any]:
    log_webhook_data("product", data)
    product_data = data.get("data", {})
    return {
        "status": "success",
        "product": {"id": product_data.get("id"), "name": product_data.get("name")},
    }


async def handle_ticket_message(data: Dict[str, Any]) -> Dict[str, Any]:
    log_webhook_data("ticket_message", data)
    message_data = data.get("data", {})
    ticket_data = message_data.get("ticket", {})

    message = (
        "🎫 *New Support Ticket Message*\n\n"
        f"Title: `{ticket_data.get('title', 'N/A')}`\n"
        f"From: `{message_data.get('author', 'Unknown')}`\n"
        f"Email: `{ticket_data.get('customer', {}).get('email', 'N/A')}`\n"
        f"Status: `{ticket_data.get('status', 'N/A')}`\n"
        f"Message: `{message_data.get('content', 'No content')}`\n"
        f"Time: `{format_timestamp(message_data.get('created_at', 'N/A'))}`"
    )

    await send_telegram_message(message)

    return {
        "status": "success",
        "message": {
            "id": message_data.get("id"),
            "ticket_id": message_data.get("ticket_id"),
            "content": message_data.get("content"),
            "author": message_data.get("author"),
            "created_at": format_timestamp(message_data.get("created_at")),
            "ticket_status": ticket_data.get("status"),
        },
    }


def handle_variant(data: Dict[str, Any]) -> Dict[str, Any]:
    log_webhook_data("variant", data)
    variant_data = data.get("data", {})
    return {
        "status": "success",
        "variant": {"id": variant_data.get("id"), "stock": variant_data.get("stock")},
    }


WEBHOOK_HANDLERS = {
    "feedback.created": handle_feedback,
    "order.created": handle_order,
    "order.completed": handle_order,
    "ticket_message.created": handle_ticket_message,
}


@fastapi_app.post("/webhook")
async def handle_webhook(request: Request):
    try:
        data = await request.json()
        event = data.get("event")

        handler = WEBHOOK_HANDLERS.get(event)
        if handler:
            result = await handler(data)
            return JSONResponse(content=result, status_code=200)

        log_webhook_data("unhandled", data)
        return JSONResponse(content={"status": "success"}, status_code=200)

    except Exception as e:
        error_trace = traceback.format_exc()
        print(f"Error processing webhook: {str(e)}\n{error_trace}")
        await debug.notify_owner(f"Error processing webhook: {str(e)}\n{error_trace}")
        return JSONResponse(
            content={"status": "error", "message": str(e)}, status_code=400
        )


@fastapi_app.api_route("/dynamic", methods=["GET", "POST"])
async def dynamic(request: Request):
    """Handle sell.app payment notifications and deliver products"""
    if request.method == "POST":
        try:
            data = await request.json()
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    webhook_url = "https://discord.com/api/webhooks/1354704309203243028/d-KL84aOgikBhCMYpVQp2NsW7fm2vris4r_2i5ly3gHi8RCYWiBaRc8xKpK29nKZi2xe"
                formatted_data = json.dumps(data, indent=2)
                payload = {
                    "content": f"New webhook received:\n```json\n{formatted_data}\n```\nURL: {str(request.url)}"
                }
                await client.post(webhook_url, json=payload)
            except Exception as e:
                debug.log(f"Failed to send Discord webhook: {str(e)}")

            webhook_data = data if isinstance(data, dict) else {}
            invoice_info = webhook_data.get("invoice", {})
            payment_data = invoice_info.get("payment", {})
            status = invoice_info.get("status", {}).get("status", "").upper()
            customer_info = webhook_data.get("customer_information", {})
            listing_info = webhook_data.get("listing", {})

            order_id = invoice_info.get("id")
            customer_email = customer_info.get("email")
            quantity = webhook_data.get("quantity")
            if quantity is None:
                variants = invoice_info.get("product_variants", [])
                quantity = sum(v.get("quantity", 0) for v in variants)

            if quantity == 0:
                debug.log(f"Order {order_id} has zero quantity. Skipping.")
                return PlainTextResponse(
                    content="Order has zero quantity", status_code=200
                )

            product_title = listing_info.get("title", "Unknown Product")
            product_id = listing_info.get("id")

            if not order_id:
                debug.log("Missing order ID in webhook data.")
                return PlainTextResponse(content="Missing order ID", status_code=400)
            if not product_id:
                debug.log(f"Missing product ID in listing for order {order_id}.")
                product_id = request.query_params.get("id")
                if not product_id:
                    return PlainTextResponse(
                        content="Missing product ID", status_code=400
                    )

            if db is None:
                await init_app()

            delivered = await db.is_sellapp_order_delivered(order_id)
            if delivered:
                return PlainTextResponse(
                    content="Order already delivered",
                    status_code=200,
                )

            log_webhook_data(
                "dynamic",
                {
                    "total": payment_data.get("total", {}).get("total_usd"),
                    "id": order_id,
                    "status": status,
                    "quantity": quantity,
                    "additional_info": None,
                    "customer_email": customer_email,
                    "product_id": product_id,
                    "product_title": product_title,
                },
            )

            if status != "COMPLETED":
                debug.log(
                    f"Payment not completed: {status}. Order ID: {order_id}, Customer email: {customer_email}, Quantity: {quantity}"
                )
                return PlainTextResponse(
                    content="Payment not completed",
                    status_code=200,
                )

            product = await ProductTypes.get_product_by_id(product_id)
            if not product:
                await debug.notify_owner(
                    f"Product not found: {product_id} ({product_title}), Order ID: {order_id}, Customer email: {customer_email}"
                )
                debug.log(
                    f"Product not found: {product_id} ({product_title}), Order ID: {order_id}, Customer email: {customer_email}"
                )
                return PlainTextResponse(
                    content=f"Product: {product_id} not found",
                    status_code=404,
                )

            product.title = product_title

            product_attrs = product.attributes
            if not product_attrs:
                await debug.notify_owner(
                    f"Product attributes not found for product {product_id} ({product_title}) in order {order_id}"
                )
                return PlainTextResponse(
                    content="Product attributes not found",
                    status_code=404,
                )

            initial_stock_count = await db.get_stock_count_by_product_attributes(
                product_attrs
            )
            if initial_stock_count < quantity:
                fresh = getattr(product_attrs, "fresh", False)
                product_description = f"{product_attrs.product_type.capitalize()}"
                if fresh:
                    product_description = f"Fresh (2025) {product_description}"

                notification_message = (
                    f"⚠️ *Initial Stock Alert for Order {order_id}*\n\n"
                    f"Product: `{product.title}` ({product_id})\n"
                    f"Product Type: `{product_description}`\n"
                    f"Requested Quantity: `{quantity}`\n"
                    f"Available: `{initial_stock_count}`\n\n"
                    "Order cannot be fulfilled. Please restock immediately!"
                )
                asyncio.create_task(send_telegram_message(notification_message))
                try:
                    mark_as_voided(order_id)
                    debug.log(
                        f"Voided order {order_id} due to insufficient initial stock ({initial_stock_count} < {quantity})"
                    )
                except Exception as e:
                    debug.log(
                        f"Failed attempt to mark invoice {order_id} as voided during initial stock check: {str(e)}"
                    )

                return PlainTextResponse(
                    content="Insufficient stock to fulfill order. Please contact support.",
                    status_code=200,
                )

            accounts = await db.get_accounts_by_product_attributes(product_attrs, limit=0)
            debug.log(f"[DEBUG] Delivery SQL: Fetching accounts for product {product_attrs} - Found {len(accounts)} accounts.")
            if accounts:
                debug.log(f"[DEBUG] Sample fetched accounts: {accounts[:3]}")
            changed_accounts = []
            failed_accounts = set()
            attempt_counter = 0
            accounts_to_try_this_iteration = list(accounts)
            MAX_ATTEMPTS = 30
            # Ensure order_id and user_id are always defined
            order_id = order.get('order_id') if isinstance(order, dict) else None
            user_id = order.get('user_id') if isinstance(order, dict) else None
            while len(changed_accounts) < quantity and attempt_counter < MAX_ATTEMPTS:
                attempt_counter += 1
                debug.log(
                    f"Order {order_id}: Processing attempt {attempt_counter}. Delivered: {len(changed_accounts)}/{quantity}."
                )
                needed_quantity = quantity - len(changed_accounts)
                if needed_quantity <= 0:
                    break
                made_progress_this_iteration = False
                current_batch_for_processing = []
                if attempt_counter > 1 or not accounts_to_try_this_iteration:
                    debug.log(
                        f"Order {order_id}: Attempt {attempt_counter}: Fetching more accounts. Need {needed_quantity}."
                    )
                    successful_auths_so_far_set = {
                        acc["auth"] for acc in changed_accounts if acc.get("auth")
                    }
                    auth_tokens_to_exclude_from_db = failed_accounts.union(
                        successful_auths_so_far_set
                    )
                    fetch_quantity = max(20, min(needed_quantity + 10, 50))
                    debug.log(
                        f"Order {order_id}: Attempting to fetch {fetch_quantity} fresh accounts, excluding {len(auth_tokens_to_exclude_from_db)} known failed/success auths from DB query."
                    )
                    product_type_str = getattr(
                        product_attrs, "product_type", "unknown_type"
                    ).lower()
                    if not isinstance(product_type_str, str) or not product_type_str:
                        product_type_str = "unknown_type"
                    stock_ok, newly_fetched_accounts = await check_available_stock(
                        product_attrs,
                        product_type_str,
                        fetch_quantity,
                        auth_tokens_to_exclude=list(auth_tokens_to_exclude_from_db),
                    )
                    debug.log(f"Order {order_id}: DB fetch returned {len(newly_fetched_accounts)} accounts.")
                    existing_auths_in_pool = {
                        acc["auth"]
                        for acc in accounts_to_try_this_iteration
                        if acc.get("auth")
                    }
                    unique_newly_fetched = [
                        acc
                        for acc in newly_fetched_accounts
                        if acc.get("auth")
                        and acc["auth"] not in existing_auths_in_pool
                        and acc["auth"] not in auth_tokens_to_exclude_from_db
                    ]
                    if unique_newly_fetched:
                        accounts_to_try_this_iteration.extend(unique_newly_fetched)
                        debug.log(
                            f"Order {order_id}: Added {len(unique_newly_fetched)} unique accounts to try pool. New pool size: {len(accounts_to_try_this_iteration)}."
                        )
                        made_progress_this_iteration = True
                    else:
                        debug.log(
                            f"Order {order_id}: Newly fetched accounts were already in pool/excluded or had no auth token."
                        )
                    current_batch_for_processing = [
                        acc
                        for acc in accounts_to_try_this_iteration
                        if acc.get("auth")
                        and acc["auth"] not in failed_accounts
                        and acc["auth"]
                        not in {
                            ca.get("auth") for ca in changed_accounts if ca.get("auth")
                        }
                    ][:needed_quantity]
                    if not current_batch_for_processing:
                        debug.log(
                            f"Order {order_id}: No more accounts to try, breaking loop."
                        )
                        break
                else:
                    made_progress_this_iteration = True
                    debug.log(
                        f"Order {order_id}: Attempt {attempt_counter}: Processing {len(current_batch_for_processing)} accounts."
                    )
                    batch_size = 50
                    accounts_changed_in_this_step = 0
                    product_type = product_attrs.product_type.lower()
                    successful_auths_in_iteration_so_far = {
                        ca.get("auth") for ca in changed_accounts
                    }
                    for i in range(0, len(current_batch_for_processing), batch_size):
                        sub_batch = current_batch_for_processing[i : i + batch_size]
                        if not sub_batch:
                            continue
                        debug.log(f"Order {order_id}: Processing sub_batch of {len(sub_batch)} accounts.")
                        sub_batch_result = await bulk_change_password(
                            product_type, sub_batch
                        )
                        for idx, acc in enumerate(sub_batch):
                            changed = sub_batch_result[idx] if idx < len(sub_batch_result) else None
                            if changed:
                                debug.log(f"Order {order_id}: Password change SUCCESS for {acc.get('username', 'unknown')}")
                                changed_accounts.append(acc)
                                accounts_changed_in_this_step += 1
                            else:
                                debug.log(f"Order {order_id}: Password change FAIL for {acc.get('username', 'unknown')}")
                                failed_accounts.add(acc["auth"])
                        attempted_auths_in_sub = {
                            s_acc.get("auth")
                            for s_acc in sub_batch
                            if s_acc.get("auth")
                        }
                        failed_accounts.update(attempted_auths_in_sub)
                    if accounts_changed_in_this_step > 0:
                        debug.log(
                            f"Order {order_id}: Attempt {attempt_counter}: Successfully changed {accounts_changed_in_this_step} passwords. Total: {len(changed_accounts)}/{quantity}"
                        )
                    else:
                        debug.log(
                            f"Order {order_id}: Attempt {attempt_counter}: No passwords changed in this step ({len(current_batch_for_processing)} attempted)."
                        )
            if not changed_accounts:
                customer_email_val = None
                username_val = None
                try:
                    if user_id:
                        customer_email_val = await db.get_customer_email(user_id)
                        username_val = await db.get_customer_username(user_id)
                        if not username_val:
                            # fallback to @user_id
                            username_val = f"@{user_id}"
                except Exception as e:
                    debug.log(f"Failed to fetch customer email/username for webhook: {e}")
                debug.log(f"Order {order_id}: Failed to deliver any accounts after {MAX_ATTEMPTS} attempts. Marking as paid but failed delivery.")
                await debug.notify_owner(
                    f"❌ *Order {order_id} Payment Received but Delivery Failed*\nNo valid accounts could be delivered after {MAX_ATTEMPTS} attempts. Please check stock and logs."
                )
                await send_discord_webhook(
                    title="❌ Order Paid but Delivery Failed",
                    description=f"Order {order_id} was paid but no accounts could be delivered after {MAX_ATTEMPTS} attempts.",
                    color=0xE74C3C,
                    fields=[
                        {"name": "Order ID", "value": order_id or 'N/A', "inline": True},
                        {"name": "Product", "value": product.title, "inline": True},
                        {"name": "Quantity Requested", "value": str(quantity), "inline": True},
                        {"name": "Accounts Delivered", "value": "0", "inline": True},
                        {"name": "Customer Email", "value": customer_email_val or "N/A", "inline": True},
                        {"name": "Product Type", "value": product_attrs.product_type, "inline": True},
                        {"name": "User", "value": username_val or 'N/A', "inline": True},
                        {"name": "User ID", "value": str(user_id) if user_id else 'N/A', "inline": True},
                    ],
                )
                # Notify client on Telegram (edit payment message if possible)
                try:
                    payment_msg = await db.get_payment_message(order_id)
                    if payment_msg:
                        chat_id, message_id = payment_msg
                        try:
                            await update_telegram_payment_message_on_failure(chat_id, message_id, order_id, failure_reason="delivery_failed")
                        except Exception as edit_exc:
                            debug.log(f"Order {order_id}: Telegram edit failed ({edit_exc}), sending new message to user {user_id}.")
                            await bot.send_message(
                                user_id,
                                f"❌ We could not deliver your order automatically. Please forward your Order ID ({order_id}) and payment TXID to support for manual confirmation."
                            )
                    else:
                        await bot.send_message(
                            user_id,
                            f"❌ We could not deliver your order automatically. Please forward your Order ID ({order_id}) and payment TXID to support for manual confirmation."
                        )
                except Exception as e:
                    debug.log(f"Failed to notify client {user_id} about failed delivery: {e}")
                await db.mark_sellapp_order_delivered(order_id)
                return PlainTextResponse(
                    content=f"Order paid but no valid accounts could be delivered after {MAX_ATTEMPTS} attempts.",
                    status_code=200,
                )

            final_delivered_count = len(changed_accounts)
            debug.log(f"Password change process completed for order {order['order_id']}.")
            debug.log(f"Requested quantity: {quantity}")
            debug.log(f"Successfully delivered: {final_delivered_count}")
            debug.log(
                f"Total failed/attempted and not delivered: {len(failed_accounts) + len(changed_accounts) - final_delivered_count}"
            )

            ignored_key_names = ["year", "followers", "following", "verification"]
            accounts_text = "\n".join(
                ":".join(
                    str(acc[k])
                    for k in acc
                    if acc[k]
                    and k not in ignored_key_names
                    and acc[k] not in ["pv", "fv", "ev", "uv"]
                )
                for acc in changed_accounts
            )

            user_id = order["user_id"]
            file_path = await save_order_to_file(order['order_id'], accounts_text)

            await send_accounts_to_user(
                order_id=order['order_id'],
                user_id=user_id,
                accounts_text=accounts_text,
                quantity=len(changed_accounts),
                product_attrs=product_attrs,
            )
            await db.mark_order_delivered(
                order['order_id'],
                payment_info={
                    "amount": request.query_params.get("total_amount"),
                    "txid": request.query_params.get("txid_out"),
                    "currency": request.query_params.get("payment_currency"),
                },
            )

            if db:
                try:
                    await db.delete_payment_message(order['order_id'])
                    debug.log(
                        f"Order {order['order_id']} (Bot Order): Deleted payment message details from DB after successful delivery."
                    )
                except Exception as db_exc:
                    debug.log(
                        f"Order {order['order_id']} (Bot Order): Failed to delete payment message details from DB after success: {str(db_exc)}"
                    )

            changed_usernames = {acc["username"] for acc in changed_accounts}
            await asyncio.gather(
                *[
                    db.remove_account(username=acc["username"])
                    for acc in accounts
                    if acc["username"] in changed_usernames
                ]
            )
            debug.log(
                f"Successfully delivered {len(changed_accounts)} accounts for order {order['order_id']} and saved to {file_path}"
            )

            payment_currency = request.query_params.get(
                "payment_currency", "Unknown"
            )
            payment_amount = request.query_params.get("total_amount", "0")

            discord_fields = [
                {"name": "Order ID", "value": order['order_id'], "inline": True},
                {
                    "name": "Payment Method",
                    "value": payment_currency,
                    "inline": True,
                },
                {
                    "name": "Amount",
                    "value": f"{payment_amount} {payment_currency}",
                    "inline": True,
                },
                {"name": "Product", "value": product.title, "inline": True},
                {
                    "name": "Quantity",
                    "value": str(order['quantity']),
                    "inline": True,
                },
                {
                    "name": "Accounts Delivered",
                    "value": str(len(changed_accounts)),
                    "inline": True,
                },
                {"name": "User ID", "value": str(user_id), "inline": True},
                {
                    "name": "Customer Email",
                    "value": await db.get_customer_email(user_id) or "N/A",
                    "inline": True,
                },
            ]

            if hasattr(product_attrs, "fresh") and product_attrs.fresh:
                discord_fields.append(
                    {
                        "name": "Account Type",
                        "value": "🆕 Fresh Accounts (2025)",
                        "inline": True,
                    }
                )

            discord_fields.append(
                {
                    "name": "Transaction ID",
                    "value": request.query_params.get("txid_out") if request.query_params.get("txid_out") else "N/A",
                    "inline": False,
                }
            )

            await send_discord_webhook(
                title="💰 Payment Successful",
                description=f"Payment received and order delivered successfully",
                color=0x2ECC71,
                fields=discord_fields,
            )

        except Exception as e:
            error_trace = traceback.format_exc()
            print(f"Error processing sell.app payment: {error_trace}")
            await debug.notify_owner(
                f"Error processing sell.app payment: {error_trace}"
            )
            return PlainTextResponse(
                content="An error occurred during delivery, please contact support with your order id.",
                status_code=200,
            )
    await debug.notify_owner(f"Method not allowed: {request.method}")
    return PlainTextResponse(
        content="Method not allowed",
        status_code=405,
    )


async def save_order_to_file(order_id: str, accounts_text: str) -> str:
    """Save order content to a file in the tmp directory"""

    tmp_dir = Path("tmp")

    file_path = tmp_dir / f"{order_id}.txt"

    async with aiofiles.open(file_path, "a+", encoding="utf-8") as f:
        await f.write(accounts_text)

    debug.log(f"Order content saved to file: {file_path}")
    return str(file_path)


@fastapi_app.api_route("/callback", methods=["GET", "POST"])
async def callback(request: Request):
    """Handle CryptAPI payment callbacks"""
    if db is None:
        await init_app()

    if request.method == "POST":
        data = await request.json()
    else:
        data = dict(request.query_params)

    print(f"Callback data: {json.dumps(data, indent=2)}")

    invoice_uuid = request.query_params.get("order_id")
    payment_status = data.get("result", "").lower()
    txid_out = data.get("txid_out")
    await debug.notify_owner(
        f"Invoice UUID: {invoice_uuid} | Payment status: {payment_status}"
    )

    if not invoice_uuid:
        debug.log(f"No invoice UUID found in callback data for order {data}")
        await debug.notify_owner(f"No invoice UUID found in callback data\n{data}")
        return PlainTextResponse("ok", status_code=200)

    order = await db.get_order_by_uuid(invoice_uuid)
    if not order:
        debug.log(f"Order not found for UUID {invoice_uuid}\n{data}")
        await debug.notify_owner(f"Order not found for UUID {invoice_uuid}\n{data}")
        return PlainTextResponse("ok", status_code=200)

    quantity = order.get('quantity') if isinstance(order, dict) and order.get('quantity') else None
    if not quantity:
        try:
            quantity = int(request.query_params.get('quantity', 1))
        except Exception:
            quantity = 1

    if payment_status in ["paid", "confirmed", "completed", "sent"]:
        try:
            if order["status"] == "completed":
                debug.log(f"Order {order['order_id']} already completed")
                await debug.notify_owner(f"Order {order['order_id']} already completed")
                return PlainTextResponse("ok", status_code=200)

            debug.log(
                f"Processing payment for order {order['order_id']} with status {payment_status}"
            )

            product = await ProductTypes.get_product_by_id(order["product_id"])
            if not product:
                debug.log(f"Product not found for order {order['order_id']}")
                await debug.notify_owner(
                    f"Product not found for order {order['order_id']}"
                )
                return PlainTextResponse("ok", status_code=200)
            debug.log(f"Product fetched for order {order['order_id']}: {product}")

            try:
                product_title = product.title
                debug.log(
                    f"Product title determined from SellApp: {product_title} for order {order['order_id']}"
                )
            except Exception as e:
                error_trace = traceback.format_exc()
                debug.log(f"Error fetching product title: {e}\n{error_trace}")
                product["title"] = product.title
                debug.log(
                    f"Product title retrieved from cache after error: {product.title} for order {order['order_id']}"
                )

            product_attrs = product.attributes
            if not product_attrs:
                debug.log(f"Product attributes not found for order {order['order_id']}")
                await debug.notify_owner(
                    f"Product attributes not found for order {order['order_id']}"
                )
                return PlainTextResponse("ok", status_code=200)
            debug.log(
                f"Product attributes for order {order['order_id']}: {product_attrs}"
            )

            product_type = product_attrs.product_type.lower()

            type_to_accounts = {
                "normal": db.get_normal_accounts,
                "blue": db.get_blue_accounts,
                "gold": db.get_gold_accounts,
                "grey": db.get_grey_accounts,
                "blueplus": db.get_blueplus_accounts,
                "chars": db.get_chars_accounts,
                "mstats": db.get_mstats_accounts,
            }

            get_accounts_func = type_to_accounts.get(product_type)
            if not get_accounts_func:
                debug.log(
                    f"Invalid product type: {product_type} for order {order['order_id']}"
                )
                await debug.notify_owner(
                    f"Invalid product type: {product_type} for order {order['order_id']}"
                )
                return PlainTextResponse("ok", status_code=200)

            available_count = await ProductTypes.get_stock_count_for_product(
                product_attrs
            )
            if available_count < quantity:
                fresh = getattr(product_attrs, "fresh", False)
                product_description = f"{product_attrs.product_type.capitalize()}"
                if fresh:
                    product_description = f"Fresh (2025) {product_description}"

                notification_message = (
                    f"⚠️ *URGENT: Stock Shortage Alert*\n\n"
                    f"🏷️ Product: `{product_title}`\n"
                    f"📊 Type: `{product_description}`\n"
                    f"🔍 Details: `{product_attrs.range or 'N/A'}`\n"
                    f"✅ Verification: `{'Full' if product_attrs.fully_verified else 'Basic'}`\n"
                    f"📧 Mail Access: `{'Yes' if product_attrs.mail_access else 'No'}`\n"
                    f"🔄 Mixed: `{'Yes' if product_attrs.mixed else 'No'}`\n\n"
                    f"📦 Requested: `{quantity}`\n"
                    f"📉 Available: `{available_count}`\n"
                    f"⚠️ Shortage: `{quantity - available_count}`\n\n"
                )
                asyncio.create_task(send_telegram_message(notification_message))
                debug.log(
                    f"No accounts matching criteria for order {order['order_id']}"
                )
                await debug.notify_owner(
                    f"No accounts matching criteria for order {order['order_id']}"
                )
                return PlainTextResponse("ok", status_code=200)

            # Fetch all matching accounts for delivery (no limit)
            accounts = await db.get_accounts_by_product_attributes(product_attrs, limit=0)
            debug.log(f"[DEBUG] Delivery SQL: Fetching accounts for product {product_attrs} - Found {len(accounts)} accounts.")
            if accounts:
                debug.log(f"[DEBUG] Sample fetched accounts: {accounts[:3]}")
            changed_accounts = []
            failed_accounts = set()
            attempt_counter = 0
            accounts_to_try_this_iteration = list(accounts)
            MAX_ATTEMPTS = 30
            # Ensure order_id and user_id are always defined
            order_id = order.get('order_id') if isinstance(order, dict) else None
            user_id = order.get('user_id') if isinstance(order, dict) else None
            while len(changed_accounts) < quantity and attempt_counter < MAX_ATTEMPTS:
                attempt_counter += 1
                debug.log(
                    f"Order {order_id}: Processing attempt {attempt_counter}. Delivered: {len(changed_accounts)}/{quantity}."
                )
                needed_quantity = quantity - len(changed_accounts)
                if needed_quantity <= 0:
                    break
                made_progress_this_iteration = False
                current_batch_for_processing = []
                if attempt_counter > 1 or not accounts_to_try_this_iteration:
                    debug.log(
                        f"Order {order_id}: Attempt {attempt_counter}: Fetching more accounts. Need {needed_quantity}."
                    )
                    successful_auths_so_far_set = {
                        acc["auth"] for acc in changed_accounts if acc.get("auth")
                    }
                    auth_tokens_to_exclude_from_db = failed_accounts.union(
                        successful_auths_so_far_set
                    )
                    fetch_quantity = max(20, min(needed_quantity + 10, 50))
                    debug.log(
                        f"Order {order_id}: Attempting to fetch {fetch_quantity} fresh accounts, excluding {len(auth_tokens_to_exclude_from_db)} known failed/success auths from DB query."
                    )
                    product_type_str = getattr(
                        product_attrs, "product_type", "unknown_type"
                    ).lower()
                    if not isinstance(product_type_str, str) or not product_type_str:
                        product_type_str = "unknown_type"
                    stock_ok, newly_fetched_accounts = await check_available_stock(
                        product_attrs,
                        product_type_str,
                        fetch_quantity,
                        auth_tokens_to_exclude=list(auth_tokens_to_exclude_from_db),
                    )
                    debug.log(f"Order {order_id}: DB fetch returned {len(newly_fetched_accounts)} accounts.")
                    existing_auths_in_pool = {
                        acc["auth"]
                        for acc in accounts_to_try_this_iteration
                        if acc.get("auth")
                    }
                    unique_newly_fetched = [
                        acc
                        for acc in newly_fetched_accounts
                        if acc.get("auth")
                        and acc["auth"] not in existing_auths_in_pool
                        and acc["auth"] not in auth_tokens_to_exclude_from_db
                    ]
                    if unique_newly_fetched:
                        accounts_to_try_this_iteration.extend(unique_newly_fetched)
                        debug.log(
                            f"Order {order_id}: Added {len(unique_newly_fetched)} unique accounts to try pool. New pool size: {len(accounts_to_try_this_iteration)}."
                        )
                        made_progress_this_iteration = True
                    else:
                        debug.log(
                            f"Order {order_id}: Newly fetched accounts were already in pool/excluded or had no auth token."
                        )
                    current_batch_for_processing = [
                        acc
                        for acc in accounts_to_try_this_iteration
                        if acc.get("auth")
                        and acc["auth"] not in failed_accounts
                        and acc["auth"]
                        not in {
                            ca.get("auth") for ca in changed_accounts if ca.get("auth")
                        }
                    ][:needed_quantity]
                    if not current_batch_for_processing:
                        debug.log(
                            f"Order {order_id}: No more accounts to try, breaking loop."
                        )
                        break
                else:
                    made_progress_this_iteration = True
                    debug.log(
                        f"Order {order_id}: Attempt {attempt_counter}: Processing {len(current_batch_for_processing)} accounts."
                    )
                    batch_size = 50
                    accounts_changed_in_this_step = 0
                    product_type = product_attrs.product_type.lower()
                    successful_auths_in_iteration_so_far = {
                        ca.get("auth") for ca in changed_accounts
                    }
                    for i in range(0, len(current_batch_for_processing), batch_size):
                        sub_batch = current_batch_for_processing[i : i + batch_size]
                        if not sub_batch:
                            continue
                        debug.log(f"Order {order_id}: Processing sub_batch of {len(sub_batch)} accounts.")
                        sub_batch_result = await bulk_change_password(
                            product_type, sub_batch
                        )
                        for idx, acc in enumerate(sub_batch):
                            changed = sub_batch_result[idx] if idx < len(sub_batch_result) else None
                            if changed:
                                debug.log(f"Order {order_id}: Password change SUCCESS for {acc.get('username', 'unknown')}")
                                changed_accounts.append(acc)
                                accounts_changed_in_this_step += 1
                            else:
                                debug.log(f"Order {order_id}: Password change FAIL for {acc.get('username', 'unknown')}")
                                failed_accounts.add(acc["auth"])
                        attempted_auths_in_sub = {
                            s_acc.get("auth")
                            for s_acc in sub_batch
                            if s_acc.get("auth")
                        }
                        failed_accounts.update(attempted_auths_in_sub)
                    if accounts_changed_in_this_step > 0:
                        debug.log(
                            f"Order {order_id}: Attempt {attempt_counter}: Successfully changed {accounts_changed_in_this_step} passwords. Total: {len(changed_accounts)}/{quantity}"
                        )
                    else:
                        debug.log(
                            f"Order {order_id}: Attempt {attempt_counter}: No passwords changed in this step ({len(current_batch_for_processing)} attempted)."
                        )
            if not changed_accounts:
                customer_email_val = None
                username_val = None
                try:
                    if user_id:
                        customer_email_val = await db.get_customer_email(user_id)
                        username_val = await db.get_customer_username(user_id)
                        if not username_val:
                            # fallback to @user_id
                            username_val = f"@{user_id}"
                except Exception as e:
                    debug.log(f"Failed to fetch customer email/username for webhook: {e}")
                debug.log(f"Order {order_id}: Failed to deliver any accounts after {MAX_ATTEMPTS} attempts. Marking as paid but failed delivery.")
                await debug.notify_owner(
                    f"❌ *Order {order_id} Payment Received but Delivery Failed*\nNo valid accounts could be delivered after {MAX_ATTEMPTS} attempts. Please check stock and logs."
                )
                await send_discord_webhook(
                    title="❌ Order Paid but Delivery Failed",
                    description=f"Order {order_id} was paid but no accounts could be delivered after {MAX_ATTEMPTS} attempts.",
                    color=0xE74C3C,
                    fields=[
                        {"name": "Order ID", "value": order_id or 'N/A', "inline": True},
                        {"name": "Product", "value": product.title, "inline": True},
                        {"name": "Quantity Requested", "value": str(quantity), "inline": True},
                        {"name": "Accounts Delivered", "value": "0", "inline": True},
                        {"name": "Customer Email", "value": customer_email_val or "N/A", "inline": True},
                        {"name": "Product Type", "value": product_attrs.product_type, "inline": True},
                        {"name": "User", "value": username_val or 'N/A', "inline": True},
                        {"name": "User ID", "value": str(user_id) if user_id else 'N/A', "inline": True},
                    ],
                )
                # Notify client on Telegram (edit payment message if possible)
                try:
                    payment_msg = await db.get_payment_message(order_id)
                    if payment_msg:
                        chat_id, message_id = payment_msg
                        try:
                            await update_telegram_payment_message_on_failure(chat_id, message_id, order_id, failure_reason="delivery_failed")
                        except Exception as edit_exc:
                            debug.log(f"Order {order_id}: Telegram edit failed ({edit_exc}), sending new message to user {user_id}.")
                            await bot.send_message(
                                user_id,
                                f"❌ We could not deliver your order automatically. Please forward your Order ID ({order_id}) and payment TXID to support for manual confirmation."
                            )
                    else:
                        await bot.send_message(
                            user_id,
                            f"❌ We could not deliver your order automatically. Please forward your Order ID ({order_id}) and payment TXID to support for manual confirmation."
                        )
                except Exception as e:
                    debug.log(f"Failed to notify client {user_id} about failed delivery: {e}")
                await db.mark_sellapp_order_delivered(order_id)
                return PlainTextResponse(
                    content=f"Order paid but no valid accounts could be delivered after {MAX_ATTEMPTS} attempts.",
                    status_code=200,
                )

            final_delivered_count = len(changed_accounts)
            debug.log(f"Password change process completed for order {order['order_id']}.")
            debug.log(f"Requested quantity: {quantity}")
            debug.log(f"Successfully delivered: {final_delivered_count}")
            debug.log(
                f"Total failed/attempted and not delivered: {len(failed_accounts) + len(changed_accounts) - final_delivered_count}"
            )

            ignored_key_names = ["year", "followers", "following", "verification"]
            accounts_text = "\n".join(
                ":".join(
                    str(acc[k])
                    for k in acc
                    if acc[k]
                    and k not in ignored_key_names
                    and acc[k] not in ["pv", "fv", "ev", "uv"]
                )
                for acc in changed_accounts
            )

            user_id = order["user_id"]
            file_path = await save_order_to_file(order['order_id'], accounts_text)

            await send_accounts_to_user(
                order_id=order['order_id'],
                user_id=user_id,
                accounts_text=accounts_text,
                quantity=len(changed_accounts),
                product_attrs=product_attrs,
            )
            await db.mark_order_delivered(
                order['order_id'],
                payment_info={
                    "amount": request.query_params.get("total_amount"),
                    "txid": txid_out,
                    "currency": request.query_params.get("payment_currency"),
                },
            )

            if db:
                try:
                    await db.delete_payment_message(order['order_id'])
                    debug.log(
                        f"Order {order['order_id']} (Bot Order): Deleted payment message details from DB after successful delivery."
                    )
                except Exception as db_exc:
                    debug.log(
                        f"Order {order['order_id']} (Bot Order): Failed to delete payment message details from DB after success: {str(db_exc)}"
                    )

            changed_usernames = {acc["username"] for acc in changed_accounts}
            await asyncio.gather(
                *[
                    db.remove_account(username=acc["username"])
                    for acc in accounts
                    if acc["username"] in changed_usernames
                ]
            )
            debug.log(
                f"Successfully delivered {len(changed_accounts)} accounts for order {order['order_id']} and saved to {file_path}"
            )

            payment_currency = request.query_params.get(
                "payment_currency", "Unknown"
            )
            payment_amount = request.query_params.get("total_amount", "0")

            discord_fields = [
                {"name": "Order ID", "value": order['order_id'], "inline": True},
                {
                    "name": "Payment Method",
                    "value": payment_currency,
                    "inline": True,
                },
                {
                    "name": "Amount",
                    "value": f"{payment_amount} {payment_currency}",
                    "inline": True,
                },
                {"name": "Product", "value": product.title, "inline": True},
                {
                    "name": "Quantity",
                    "value": str(order['quantity']),
                    "inline": True,
                },
                {
                    "name": "Accounts Delivered",
                    "value": str(len(changed_accounts)),
                    "inline": True,
                },
                {"name": "User ID", "value": str(user_id), "inline": True},
                {
                    "name": "Customer Email",
                    "value": await db.get_customer_email(user_id) or "N/A",
                    "inline": True,
                },
            ]

            if hasattr(product_attrs, "fresh") and product_attrs.fresh:
                discord_fields.append(
                    {
                        "name": "Account Type",
                        "value": "🆕 Fresh Accounts (2025)",
                        "inline": True,
                    }
                )

            discord_fields.append(
                {
                    "name": "Transaction ID",
                    "value": txid_out if txid_out else "N/A",
                    "inline": False,
                }
            )

            await send_discord_webhook(
                title="💰 Payment Successful",
                description=f"Payment received and order delivered successfully",
                color=0x2ECC71,
                fields=discord_fields,
            )

        except Exception as e:
            error_trace = traceback.format_exc()
            print(f"Delivery error: {e}\n{error_trace}")
            await debug.notify_owner(f"Delivery error: {e}\n{error_trace}")
            return PlainTextResponse("ok", status_code=200)

    elif payment_status in ["pending", "unpaid"]:
        await db.update_order_status(invoice_uuid, "pending")
        print(f"Payment pending for order {order['order_id']}")
        await debug.notify_owner(f"Payment pending for order {order['order_id']}")
        return PlainTextResponse("ok", status_code=200)

    else:
        print(f"Payment failed for order {order['order_id']}")
        await debug.notify_owner(f"Payment failed for order {order['order_id']}")
        return PlainTextResponse("ok", status_code=200)


@fastapi_app.on_event("startup")
async def startup():
    global db
    if db is None:
        print("Creating database instance for FastAPI")
        db = DatabaseManager()
    await db.connect()


@fastapi_app.on_event("shutdown")
async def shutdown():
    if db:
        await db.disconnect()


async def check_available_stock(
    product_attrs: Any,
    product_type: str,
    requested_quantity: int,
    auth_tokens_to_exclude: Optional[Union[List[str], Set[str]]] = None,
) -> tuple[bool, List[Dict[str, Any]]]:
    """
    Check if sufficient stock is available and return filtered accounts if needed.
    Uses the efficient count method first before fetching actual accounts.
    Args:
        product_attrs: Product attributes to filter by.
        product_type: The type of the product.
        requested_quantity: The number of accounts requested.
        auth_tokens_to_exclude: Optional list or set of auth tokens to exclude.
    """

    auth_tokens_list: Optional[List[str]] = None
    if isinstance(auth_tokens_to_exclude, set):
        auth_tokens_list = list(auth_tokens_to_exclude)
    elif isinstance(auth_tokens_to_exclude, list):
        auth_tokens_list = auth_tokens_to_exclude

    available_count = await db.get_stock_count_by_product_attributes(
        product_attrs, auth_tokens_to_exclude=auth_tokens_list
    )
    fresh = product_attrs.fresh if hasattr(product_attrs, "fresh") else False

    if available_count < requested_quantity:
        product_description = f"{product_type.capitalize()}"
        if fresh:
            product_description = f"Fresh (2025) {product_description}"

        notification_message = (
            f"⚠️ *Stock Alert*\n\n"
            f"Product Type: `{product_description}`\n"
            f"Requested Quantity: `{requested_quantity}`\n"
            f"Available: `{available_count}`\n\n"
            "Please restock immediately!"
        )
        asyncio.create_task(send_telegram_message(notification_message))

        filtered = await db.get_accounts_by_product_attributes(
            product_attrs,
            limit=requested_quantity,
            auth_tokens_to_exclude=auth_tokens_list,
        )
        return False, filtered

    filtered = await db.get_accounts_by_product_attributes(
        product_attrs, requested_quantity, auth_tokens_to_exclude=auth_tokens_list
    )
    return True, filtered


async def get_filtered_accounts(
    product_attrs: Any, limit: int = 0
) -> List[Dict[str, Any]]:
    """Get filtered accounts directly from database"""
    return await db.get_accounts_by_product_attributes(product_attrs, limit)


async def send_accounts_to_user(
    order_id: str, user_id: int, accounts_text: str, quantity: int, product_attrs=None
) -> None:
    """
    Send accounts to a user via Telegram using a temporary client.

    Args:
        order_id: The order ID
        user_id: The Telegram user ID to send the accounts to
        accounts_text: Text containing the account information
        quantity: Number of accounts being delivered
        product_attrs: Optional product attributes to customize the message
    """
    if not accounts_text:
        debug.log(f"No accounts to send to user {user_id}")
        return

    is_fresh = product_attrs and hasattr(product_attrs, "fresh") and product_attrs.fresh

    product_info = f"🎉 *Your Order is Ready!*\n\n"

    if is_fresh:
        product_info += f"✅ *{quantity} Fresh Accounts (2025)* have been delivered\n"
    else:
        product_info += f"✅ *{quantity} accounts* have been delivered\n"

    if is_fresh:
        product_info += f"🆕 These are newly created accounts from 2025\n"

    original_quantity = 0
    try:
        order = await db.fetch_one(
            "SELECT quantity FROM orders WHERE order_id = ?", (order_id,)
        )
        if order and order.get("quantity"):
            original_quantity = int(order.get("quantity"))
    except Exception as e:
        debug.log(f"Error fetching original order quantity: {e}")

    if original_quantity > quantity:
        product_info += f"\n⚠️ *Partial Delivery Notice*\n"
        product_info += f"We were able to deliver {quantity} out of {original_quantity} ordered accounts.\n"
        product_info += f"Please contact @vikingtokens for assistance with the remaining accounts.\n"

    product_info += f"📎 Your accounts are attached as a text file\n\n"
    product_info += f"Thank you for your purchase! If you need any assistance, please contact support."

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:

            await client.post(
                f"https://api.telegram.org/bot{config.TOKEN}/sendMessage",
                json={
                    "chat_id": user_id,
                    "text": product_info,
                    "parse_mode": "Markdown",
                },
            )

            filename = (
                f"fresh_2025_accounts_{order_id}.txt" if is_fresh else f"{order_id}.txt"
            )
            accounts_bytes = accounts_text.encode("utf-8")
            files = {"document": (filename, accounts_bytes, "text/plain")}

            await client.post(
                f"https://api.telegram.org/bot{config.TOKEN}/sendDocument",
                data={"chat_id": user_id},
                files=files,
            )

        account_type = "fresh (2025)" if is_fresh else "normal"
        debug.log(
            f"Successfully sent {quantity} {account_type} accounts to user {user_id}"
        )
    except Exception as e:
        error_trace = traceback.format_exc()
        error_msg = (
            f"Failed to send accounts to user {user_id}: {str(e)}\n{error_trace}"
        )
        debug.log(error_msg)
        await debug.notify_owner(error_msg)


@fastapi_app.post("/insert_account/{account_type}")
async def insert_account_endpoint(
    account_type: str, request: Request, x_password: str = Header(None)
):
    try:
        data = await request.json()
        if not isinstance(data, dict):
            return JSONResponse(
                content={"status": "error", "message": "Invalid JSON format"},
                status_code=400,
            )
        if not x_password or x_password != "viking":
            return JSONResponse(
                content={
                    "status": "error",
                    "message": "Invalid or missing X-Password header",
                },
                status_code=401,
            )
        safe_data = {k: (v if v is not None else "") for k, v in data.items()}
        insert_methods = {
            "normal": db.insert_normal_account,
            "follower": db.insert_follower_account,
            "blue": db.insert_blue_verified_account,
            "grey": db.insert_grey_verified_account,
            "gold": db.insert_gold_verified_account,
            "blueplus": db.insert_blueplus_account,
            "chars": db.insert_chars_account,
            "mstats": db.insert_mstats_account,
        }
        method = insert_methods.get(account_type.lower())
        if not method:
            return JSONResponse(
                content={"status": "error", "message": "Invalid account type"},
                status_code=400,
            )
        field_order = [
            "username",
            "password",
            "email",
            "mailpwd",
            "ct0",
            "auth",
            "followers",
            "following",
            "year",
            "backup_code",
            "verified",
        ]
        capture = tuple(safe_data.get(f, "") for f in field_order)
        await method(capture)
        return JSONResponse(content={"status": "success"}, status_code=200)
    except Exception as e:
        return JSONResponse(
            content={"status": "error", "message": str(e)}, status_code=500
        )


async def update_telegram_payment_message_on_failure(
    chat_id: int,
    message_id: int,
    order_id: str,
    failure_reason: str = "delivery_failed",
    partial_info: dict = None,
):
    """
    Updates a specific Telegram message to inform the user about an order failure or partial delivery.
    Removes inline keyboard from the message.

    Args:
        chat_id: Telegram chat ID
        message_id: Message ID to edit
        order_id: Order identifier
        failure_reason: Reason for failure/update ("delivery_failed", "voided_insufficient_stock", "partial_delivery")
        partial_info: Dictionary containing partial delivery details (delivered and total quantities)
    """
    if not chat_id or not message_id:
        debug.log(
            f"Order {order_id}: No chat_id or message_id provided to update Telegram payment status message."
        )
        return

    bot_token = getattr(config, "TOKEN", None)
    if not bot_token:
        debug.log(
            f"Order {order_id}: Telegram BOT_TOKEN not configured. Cannot update message."
        )
        return

    text_content = ""
    if failure_reason == "delivery_failed":
        text_content = (
            f"⚠️ *Order {order_id} Failed*\n\n"
            "We encountered an issue processing your order after payment. "
            "The delivery of accounts could not be completed as expected.\n\n"
            "Please contact @vikingtokens with your Order ID for assistance. "
            "We apologize for any inconvenience."
        )
    elif failure_reason == "voided_insufficient_stock":
        text_content = (
            f"⚠️ *Order {order_id} Voided*\n\n"
            "Unfortunately, due to an unexpected stock issue that arose after your payment, "
            "we were unable to fulfill your order. Your order has been voided.\n\n"
            "Please contact @vikingtokens with your Order ID for assistance. "
            "We apologize for any inconvenience."
        )
    elif failure_reason == "partial_delivery" and partial_info:
        text_content = (
            f"⚠️ *Order {order_id} - Partial Delivery*\n\n"
            f"We have delivered {partial_info['delivered']} out of {partial_info['total']} ordered accounts.\n\n"
            "Please contact @vikingtokens with your Order ID for assistance with the remaining accounts.\n"
            "We apologize for any inconvenience."
        )
    else:
        text_content = (
            f"⚠️ *Order {order_id} Issue*\n\n"
            "There was an issue with completing your order post-payment. \n\n"
            "Please contact @vikingtokens with your Order ID for assistance. "
            "We apologize for any inconvenience."
        )

    empty_keyboard = {"inline_keyboard": []}

    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text_content,
        "parse_mode": "Markdown",
        "reply_markup": json.dumps(empty_keyboard),
    }

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            url = f"https://api.telegram.org/bot{bot_token}/editMessageText"
            response = await client.post(url, json=payload)

            if response.is_success:
                response_data = response.json()
                if response_data.get("ok"):
                    debug.log(
                        f"Order {order_id}: Successfully updated payment status message in chat {chat_id}, message {message_id}."
                    )
                else:
                    debug.log(
                        f"Order {order_id}: Telegram API error while updating message. Status: {response.status_code}, Response: {response_data}"
                    )
            else:
                debug.log(
                    f"Order {order_id}: HTTP error {response.status_code} while updating Telegram message. Response: {response.text}"
                )

    except Exception as e:
        debug.log(
            f"Order {order_id}: Exception calling Telegram API to update payment message: {str(e)}"
        )

    global db
    if db:
        try:
            await db.delete_payment_message(order_id)
            debug.log(
                f"Order {order_id}: Deleted payment message details from DB after attempting update."
            )
        except Exception as db_exc:
            debug.log(
                f"Order {order_id}: Failed to delete payment message details from DB: {str(db_exc)}"
            )


if __name__ == "__main__":
    print("\n" + "=" * 50)
    print("🚀 Starting FastAPI Server")
    print("=" * 50)
    print("\n📝 Available endpoints:")
    print("   • POST /webhook  - Handle webhook events")
    print("   • POST /dynamic  - Handle sell.app payments")
    print("   • POST /callback - Handle CryptAPI callbacks")
    print("\n🔧 Server Configuration:")
    print("   • Mode: Production")
    print("   • Host: localhost")
    print("   • Port: Starting with 7070 (will auto-select if busy)")
    print("=" * 50 + "\n")

    try:
        asyncio.run(init_app(db))
        asyncio.run(run_fastapi(host="localhost"))
    except KeyboardInterrupt:
        print("\n⚠️ Server shutdown requested")
    except Exception as e:
        print(f"\n❌ Server error: {str(e)}")
    finally:
        print("\n" + "=" * 50)
        print("Server stopped")
        print("=" * 50)
