import asyncio
import time
import logging
from typing import Optional
from telegram import Message

logger = logging.getLogger(__name__)


class TelegramProgressUpdater:
    def __init__(self, message: Message, update_interval: float = 5.0):
        self.message = message
        self.update_interval = update_interval
        self._task = None
        self._last_text = ""
        self._last_update = 0
        self._lock = asyncio.Lock()
        self._progress = {"current": 0, "total": 0, "status": {}}
        self._running = False
        self._update_lock = asyncio.Lock()
        self._status_cache = {}
        self._error_count = 0
        self._max_errors = 3

    async def start(self):
        self._running = True
        self._task = asyncio.create_task(self._update_loop())
        return self

    async def stop(self):
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def update(self, *, current: int, total: int, **status):
        """Thread-safe status update"""
        async with self._update_lock:
            self._progress["current"] = min(current, total)
            self._progress["total"] = total

            for key, value in status.items():
                if value > 0:
                    self._progress["status"][key] = value

    def _format_progress(self) -> str:
        current = self._progress["current"]
        total = max(self._progress["total"], 1)

        processed = sum(
            self._progress["status"].get(key, 0)
            for key in [
                "normals",
                "blues",
                "greys",
                "golds",
                "followers",
                "chars",
                "invalids",
                "mstats",
                "suspended",
                "locked",
                "unverified",
                "failed",
                "rate_limited",
                "errors",
            ]
        )

        is_completed = not self._running and processed >= total

        lines = ["📊 *Progress Update*"]
        lines.append(
            f"├ Status: `{'Completed' if is_completed else 'Processing...'}`\n"
            f"└ Progress: `{processed:,}/{total:,}` ({(processed/total*100):.1f}%)"
        )

        status_details = {k: v for k, v in self._progress["status"].items() if v > 0}
        if status_details:
            lines.append("\n*Status Details:*")
            for key in [
                "invalids",
                "suspended",
                "locked",
                "normals",
                "blues",
                "blueplus",
                "greys",
                "golds",
                "chars",
                "mstats",
                "followers",
                "unverified",
                "failed",
                "rate_limited",
                "errors",
            ]:
                if value := status_details.get(key, 0):
                    lines.append(f"├ {key.title()}: `{value:,}`")

        return "\n".join(lines)

    async def _update_loop(self):
        while self._running:
            try:
                new_text = self._format_progress()
                now = time.time()

                if (
                    new_text != self._last_text
                    and now - self._last_update >= self.update_interval
                ):
                    try:
                        await self.message.edit_text(new_text, parse_mode="Markdown")
                        self._last_text = new_text
                        self._last_update = now
                        self._error_count = 0
                    except Exception as e:
                        if "message is not modified" not in str(e).lower():
                            self._error_count += 1
                            logger.error(f"Failed to update message: {e}")
                            if self._error_count >= self._max_errors:
                                logger.error("Too many update errors, stopping updater")
                                break

            except asyncio.CancelledError:
                break
            except Exception as e:
                self._error_count += 1
                logger.error(f"Error in update loop: {e}")
                if self._error_count >= self._max_errors:
                    break

            await asyncio.sleep(self.update_interval)
