import httpx
import os
import config
import aiofiles
from src.db import DatabaseManager
from src.debugger import Debugger


class RESTAPI:
    def __init__(self, db: DatabaseManager, debug: Debugger):
        self.base_url = config.SELF_API
        self.session = httpx.AsyncClient()
        self.debug = debug
        self.db = db
        self.hash_file = os.path.join(config.UPLOAD_DIR, "hashes.txt")
        self.session.params = {"authorization": config.TOKEN}

    async def find_latest_valids(self, country: str) -> bytes | int | None:
        try:
            response = await self.session.get(
                url=f"{config.CRACKER_API}/fetch-valids", params={"country": country}
            )
            if response.status_code == 200:
                file_hash = response.headers.get("X-FileHash")
                async with aiofiles.open(self.hash_file, "r+") as f:
                    if file_hash in await f.read():
                        return 200
                    else:
                        await f.write(f"{file_hash}\n")
                file = await response.read()
                return file
            return None
        except Exception as e:
            self.debug.log(f"Failed to fetch valids: {e}")
            return None
