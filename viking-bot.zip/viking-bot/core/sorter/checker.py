from cogs.utils import *
import httpx
import asyncio
import config
from datetime import datetime
from dataclasses import dataclass

from .libs.constants import *
from .libs.auth import auth, get_ct0
from core.queue_manager import TaskQueueManager
from .libs.utils import get_capture
from .libs.event import client_event, fetch_user_info, premium_plus
from src import debugger

debug = debugger.Debugger()


TOKEN_TYPES = ("fv", "pv", "ev", "uv")
MIN_USERNAME_LENGTH = 4
MIN_FOLLOWERS_COUNT = 1000


@dataclass
class CheckerResults:
    followers: int = 0
    normals: int = 0
    golds: int = 0
    blues: int = 0
    greys: int = 0
    suspended: int = 0
    locked: int = 0
    failed: int = 0
    invalids: int = 0
    rate_limited: int = 0
    errors: int = 0
    current: int = 0
    unverified: int = 0
    chars: int = 0
    mstats: int = 0


class AtomicCounter:
    """Thread-safe counter for tracking progress"""

    def __init__(self):
        self._value = 0
        self._lock = asyncio.Lock()

    async def increment(self, amount=1):
        async with self._lock:
            self._value += amount
            return self._value

    async def get(self):
        async with self._lock:
            return self._value

    async def set(self, value):
        async with self._lock:
            self._value = value
            return self._value

    def __gt__(self, other):
        return self._value > other

    def __lt__(self, other):
        return self._value < other

    def __eq__(self, other):
        return self._value == other

    def __int__(self):
        return self._value

    def __str__(self):
        return str(self._value)

    def __repr__(self):
        return str(self._value)


class Tracker:
    def __init__(self):
        self.current = AtomicCounter()
        self.total = AtomicCounter()
        self.processed = set()
        self.hits = AtomicCounter()
        self.blueplus = AtomicCounter()
        self.chars = AtomicCounter()
        self.locked = AtomicCounter()
        self.failed = AtomicCounter()
        self.invalids = AtomicCounter()
        self.suspended = AtomicCounter()
        self.rate_limited = AtomicCounter()
        self.blues = AtomicCounter()
        self.normals = AtomicCounter()
        self.golds = AtomicCounter()
        self.followers = AtomicCounter()
        self.greys = AtomicCounter()
        self.remaining = AtomicCounter()
        self.retries = AtomicCounter()
        self.errors = AtomicCounter()
        self.cpm = AtomicCounter()
        self.unverified = AtomicCounter()
        self.mstats = AtomicCounter()

    async def increment(self, counter_name: str, amount: int = 1):
        counter = getattr(self, counter_name)
        if isinstance(counter, AtomicCounter):
            return await counter.increment(amount)
        return 0

    async def get_value(self, counter_name: str) -> int:
        counter = getattr(self, counter_name)
        if isinstance(counter, AtomicCounter):
            return await counter.get()
        return 0

    async def get_status(self) -> dict:
        """Get current numerical values for all counters"""
        status = {}
        for name, value in self.__dict__.items():
            if isinstance(value, AtomicCounter):
                status[name] = await value.get()
            elif name != "processed":
                status[name] = value
        return status


class Check:
    def __init__(self, database, queue_manager: TaskQueueManager, task_id: str) -> None:
        self.db: db.DatabaseManager = database
        self.queue_manager = queue_manager
        self.task_id = task_id
        self.verified = lambda data: (
            "fv"
            if 'email_verified":true' in data and 'phone_number_verified":true' in data
            else (
                "ev"
                if 'email_verified":true' in data
                else ("pv" if 'phone_number_verified":true' in data else "uv")
            )
        )
        self.tracker = Tracker()
        self.hits = []
        self.normals = []
        self.chars = []
        self.update = False
        self.lock = asyncio.Lock()
        self.tokens = []
        self.max_retries = 3
        self.initial_total = 0
        self.is_running = False
        self.processed_accounts = set()
        self.progress_details = {
            "followers": 0,
            "normals": 0,
            "golds": 0,
            "blues": 0,
            "greys": 0,
            "blueplus": 0,
            "unverified": 0,
            "suspended": 0,
            "locked": 0,
            "failed": 0,
            "invalids": 0,
            "rate_limited": 0,
            "errors": 0,
            "chars": 0,
        }
        self.progress_update_interval = 1.0
        self._last_progress_update = 0
        self.timeout = httpx.Timeout(120.0, connect=60.0)
        self.update_interval = 5
        self.max_consecutive_failures = 5
        self.consecutive_failures = 0

    async def _init_tracker(self) -> None:
        """Initialize tracker with default values"""
        await self.tracker.total.set(self.initial_total)
        await self.tracker.current.set(0)
        await self.tracker.remaining.set(self.initial_total)
        self.tracker.processed.clear()

    def _get_results(self) -> CheckerResults:
        """Get current checker results"""
        return CheckerResults(
            followers=self.tracker.followers,
            normals=self.tracker.normals,
            golds=self.tracker.golds,
            blues=self.tracker.blues,
            greys=self.tracker.greys,
            suspended=self.tracker.suspended,
            locked=self.tracker.locked,
            failed=self.tracker.failed,
            invalids=self.tracker.invalids,
            rate_limited=self.tracker.rate_limited,
            errors=self.tracker.errors,
            current=self.tracker.current,
            unverified=self.tracker.unverified,
            chars=self.tracker.chars,
            mstats=self.tracker.mstats,
        )

    async def _update_progress(self):
        """Update progress through queue manager"""
        now = time.time()
        if now - self._last_progress_update >= self.progress_update_interval:
            status = await self.tracker.get_status()

            details = {
                k: v
                for k, v in status.items()
                if k not in ["current", "total", "processed"] and v > 0
            }

            await self.queue_manager.update_progress(
                task_id=self.task_id,
                current=len(self.tracker.processed),
                total=self.initial_total,
                details=details,
            )
            self._last_progress_update = now

    async def login(self) -> None:
        while True:
            if self.consecutive_failures >= self.max_consecutive_failures:
                debug.log("Too many consecutive failures, stopping login process")
                break

            try:
                if not self.tokens or not self.is_running:
                    break

                account = None
                async with self.lock:
                    if not self.tokens:
                        break
                    account = self.tokens.pop(0)

                    account_id = hash(str(account))
                    if account_id in self.tracker.processed:
                        continue

                    if not isinstance(account, (tuple, list)) or len(account) < 2:
                        await self.tracker.failed.increment()
                        debug.log(f"{GG}Invalid account format{W} > {Y}{account[0]}{W}")
                        continue

                    self.tracker.processed.add(account_id)

                try:
                    async with httpx.AsyncClient(
                        timeout=self.timeout, http2=False
                    ) as client:
                        async with self.lock:
                            await self.tracker.current.increment()
                        resp = None
                        max_retries = self.max_retries

                        capture = await get_capture(account)

                        if not capture:
                            await self.tracker.failed.increment()
                            if self.update:
                                await self.db.remove_account(username=account[0])
                            debug.log(f"{GG}Invalid capture{W} > ({Y}{account}{W})")
                            await self.queue_manager.update_progress(
                                task_id=self.task_id,
                                current=min(
                                    await self.tracker.current.get(), self.initial_total
                                ),
                                total=self.initial_total,
                                details={"failed": await self.tracker.failed.get()},
                            )
                            continue

                        (
                            username,
                            password,
                            email,
                            email_pass,
                            ct0,
                            auth_token,
                            followers,
                            following,
                            year,
                            backup_code,
                        ) = capture
                        headers, cookies = auth(ct0, auth_token)

                        if not ct0 or not auth_token:
                            await self.tracker.invalids.increment()
                            # This indicates we have a problem with the account or ct0 is missing or format is invalid, simply dont remove the account
                            debug.log(
                                f"{GG}Invalid account auth, ct0{W} > {Y}{account[0]}@{auth_token}{W}"
                            )
                            await self.queue_manager.update_progress(
                                task_id=self.task_id,
                                current=await self.tracker.current.get(),
                                total=self.initial_total,
                                details={"invalids": await self.tracker.invalids.get()},
                            )
                            continue

                        async def handle_response(response: httpx.Response) -> bool:
                            nonlocal headers, cookies, ct0, auth_token

                            response_text = str(response.text).lower()

                            invalid_indicators = [
                                "could not authenticate you",
                                "authorization: invalid",
                                "token is invalid",
                                "token has expired",
                                "authorization failed",
                            ]

                            locked_indicators = [
                                "temporarily locked",
                                "account has been locked",
                                "locked under twitter rules",
                                "your account is locked",
                            ]

                            suspended_indicators = [
                                "suspended",
                                "account has been suspended",
                            ]

                            if any(
                                indicator in response_text
                                for indicator in invalid_indicators
                            ):
                                await self.tracker.invalids.increment()
                                if self.update:
                                    await self.db.remove_account(
                                        username=account[0], auth_token=auth_token
                                    )
                                debug.log(
                                    f"{GG}Invalid account auth{W} > {Y}{account[0]}@{auth_token}{W}",
                                    send=False,
                                )
                                await self.queue_manager.update_progress(
                                    task_id=self.task_id,
                                    current=await self.tracker.current.get(),
                                    total=self.initial_total,
                                    details={
                                        "invalids": await self.tracker.invalids.get()
                                    },
                                )
                                return False

                            elif any(
                                indicator in response_text
                                for indicator in locked_indicators
                            ):
                                await self.tracker.locked.increment()
                                await self.db.add_locked_token(
                                    await get_capture(account), source="checker"
                                )
                                if self.update:
                                    await self.db.remove_account(
                                        username=account[0], auth_token=auth_token
                                    )
                                debug.log(
                                    f"{C1}Locked Account{W} > {Y}{account[0]}@{auth_token}{W}",
                                    send=False,
                                )
                                await self.queue_manager.update_progress(
                                    task_id=self.task_id,
                                    current=await self.tracker.current.get(),
                                    total=self.initial_total,
                                    details={"locked": await self.tracker.locked.get()},
                                )
                                return False

                            elif any(
                                indicator in response_text
                                for indicator in suspended_indicators
                            ):
                                await self.tracker.suspended.increment()
                                if self.update:
                                    await self.db.remove_account(
                                        username=account[0], auth_token=auth_token
                                    )
                                debug.log(
                                    f"{C1}Suspended Account{W} > {Y}{account[0]}@{auth_token}{W}",
                                    send=False,
                                )
                                await self.queue_manager.update_progress(
                                    task_id=self.task_id,
                                    current=await self.tracker.current.get(),
                                    total=self.initial_total,
                                    details={
                                        "suspended": await self.tracker.suspended.get()
                                    },
                                )
                                return False

                            status_code = response.status_code
                            await self.tracker.remaining.increment(-1)
                            try:
                                resp_text = response.text
                                if resp_text:
                                    try:
                                        resp = response.json()
                                    except Exception as e:
                                        if "Connection closed" in resp_text:
                                            debug.log(
                                                f"Connection closed for {account[0]}@{auth_token}, attempt {retry_count}",
                                                send=False,
                                            )
                                            await asyncio.sleep(1)
                                            return retry_count < max_retries
                                        debug.log(f"Error reading response body")
                                        return False
                            except Exception as e:
                                if "Connection closed" in str(e):
                                    debug.log(
                                        f"Connection closed for {account[0]}@{auth_token}, attempt {retry_count}",
                                        send=False,
                                    )
                                    await asyncio.sleep(1)
                                    return retry_count < max_retries
                                debug.log(f"Response error: {e}")
                                return False

                            if status_code == 429:
                                await self.tracker.rate_limited.increment()
                                debug.log(
                                    f"{GG}Rate limited{W} > {Y}{account[0]}@{auth_token}{W}"
                                )
                                await self.queue_manager.update_progress(
                                    task_id=self.task_id,
                                    current=await self.tracker.current.get(),
                                    total=self.initial_total,
                                    details={
                                        "rate_limited": await self.tracker.rate_limited.get()
                                    },
                                )
                                return False

                            elif resp_text or response.is_success:
                                if (
                                    "This request requires a matching csrf cookie and header."
                                    in resp_text
                                ):
                                    debug.log(
                                        f"{GG}ct0 Invalid, retrying with{W} > {Y}{account[0]}@{auth_token}{W}",
                                        send=False,
                                    )
                                    await self.tracker.retries.increment()
                                    ct0, auth_token = await get_ct0(auth_token)
                                    if not ct0 or not auth_token:
                                        await self.tracker.failed.increment()
                                        debug.log(
                                            f"{GG}failed to get ct0{W} > {Y}{account[0]}@{auth_token}{W}",
                                            send=False,
                                        )
                                        await self.queue_manager.update_progress(
                                            task_id=self.task_id,
                                            current=await self.tracker.current.get(),
                                            total=self.initial_total,
                                            details={
                                                "invalids": await self.tracker.invalids.get()
                                            },
                                        )
                                        return False
                                    headers, cookies = auth(ct0, auth_token)
                                    await self.tracker.retries.increment()
                                    return True

                                elif "this account is temporarily locked." in resp_text:
                                    await self.tracker.locked.increment()

                                    await self.db.add_locked_token(
                                        await get_capture(account), source="checker"
                                    )

                                    if self.update:
                                        await self.db.remove_account(
                                            username=account[0], auth_token=auth_token
                                        )

                                    debug.log(
                                        f"{C1}Locked Account{W} > {Y}{account[0]}@{auth_token}{W}",
                                        send=False,
                                    )
                                    await self.queue_manager.update_progress(
                                        task_id=self.task_id,
                                        current=await self.tracker.current.get(),
                                        total=self.initial_total,
                                        details={
                                            "locked": await self.tracker.locked.get()
                                        },
                                    )
                                    return False

                                elif "suspended" in resp_text:
                                    await self.tracker.suspended.increment()
                                    debug.log(
                                        f"{C1}Suspended Account{W} > {Y}{account[0]}@{auth_token}{W}",
                                        send=False,
                                    )
                                    if self.update:
                                        await self.db.remove_account(
                                            username=account[0], auth_token=auth_token
                                        )
                                    await self.queue_manager.update_progress(
                                        task_id=self.task_id,
                                        current=await self.tracker.current.get(),
                                        total=self.initial_total,
                                        details={
                                            "suspended": await self.tracker.suspended.get()
                                        },
                                    )
                                    return False
                                elif "Could not authenticate you" in resp_text:
                                    await self.tracker.invalids.increment()
                                    if self.update:
                                        await self.db.remove_account(
                                            username=account[0], auth_token=auth_token
                                        )
                                    debug.log(
                                        f"{GG}Invalid account auth{W} > {Y}{account[0]}@{auth_token}{W}",
                                        send=False,
                                    )
                                    await self.queue_manager.update_progress(
                                        task_id=self.task_id,
                                        current=await self.tracker.current.get(),
                                        total=self.initial_total,
                                        details={
                                            "invalids": await self.tracker.invalids.get()
                                        },
                                    )
                                    return False

                                elif status_code == 401:
                                    await self.tracker.invalids.increment()
                                    if self.update:
                                        await self.db.remove_account(
                                            username=account[0], auth_token=auth_token
                                        )
                                    debug.log(
                                        f"{GG}Invalid account auth (401){W} > {Y}{account[0]}@{auth_token}{W}",
                                        send=False,
                                    )
                                    await self.queue_manager.update_progress(
                                        task_id=self.task_id,
                                        current=await self.tracker.current.get(),
                                        total=self.initial_total,
                                        details={
                                            "invalids": await self.tracker.invalids.get()
                                        },
                                    )
                                    return False
                                else:
                                    await self.tracker.hits.increment()
                                    response = await fetch_user_info(
                                        auth_token, ct0, client
                                    )
                                    if not response or response == 401:
                                        if response == 401:
                                            await self.tracker.invalids.increment()
                                            if self.update:
                                                await self.db.remove_account(
                                                    username=account[0],
                                                    auth_token=auth_token,
                                                )
                                            debug.log(
                                                f"{GG}Invalid account auth{W} > {Y}{account[0]}@{auth_token}{W}",
                                                send=False,
                                            )
                                            await self.queue_manager.update_progress(
                                                task_id=self.task_id,
                                                current=await self.tracker.current.get(),
                                                total=self.initial_total,
                                                details={
                                                    "invalids": await self.tracker.invalids.get()
                                                },
                                            )
                                            return False
                                        else:
                                            await self.tracker.failed.increment()
                                            debug.log(
                                                f"{GG}Failed to fetch user data{W} > {Y}{account[0]}@{auth_token}{W}",
                                                send=False,
                                            )
                                            await self.queue_manager.update_progress(
                                                task_id=self.task_id,
                                                current=await self.tracker.current.get(),
                                                total=self.initial_total,
                                                details={
                                                    "failed": await self.tracker.failed.get()
                                                },
                                            )
                                            return False

                                    if response.status_code == 200:
                                        try:
                                            resp = response.json()
                                        except Exception as e:
                                            debug.log(
                                                f"Error reading response body: {e}",
                                                send=False,
                                            )
                                            await self.queue_manager.update_progress(
                                                task_id=self.task_id,
                                                current=await self.tracker.current.get(),
                                                total=self.initial_total,
                                                details={
                                                    "errors": await self.tracker.errors.increment()
                                                },
                                            )
                                            return False

                                        if resp:
                                            user_data = None
                                            user_info = (
                                                resp.get("data", {})
                                                .get("viewer", {})
                                                .get("user_results", {})
                                                .get("result", {})
                                            )

                                            if not user_info:
                                                if (
                                                    "this account is temporarily locked"
                                                    in str(resp).lower()
                                                ):
                                                    await self.tracker.locked.increment()

                                                    capture_data = await get_capture(
                                                        account
                                                    )
                                                    await self.db.add_locked_token(
                                                        capture_data, source="checker"
                                                    )
                                                    debug.log(
                                                        f"{C1}Locked Account{W} > {Y}{account[0]}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    if self.update:
                                                        await self.db.remove_account(
                                                            username=account[0],
                                                            auth_token=auth_token,
                                                        )
                                                    await self.queue_manager.update_progress(
                                                        task_id=self.task_id,
                                                        current=await self.tracker.current.get(),
                                                        total=self.initial_total,
                                                        details={
                                                            "locked": await self.tracker.locked.get()
                                                        },
                                                    )
                                                    return False
                                                elif (
                                                    "Your account is suspended and is not permitted to access this feature."
                                                    in str(resp)
                                                ):
                                                    await self.tracker.suspended.increment()
                                                    debug.log(
                                                        f"{C1}Suspended Account{W} > {Y}{account[0]}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    if self.update:
                                                        await self.db.remove_account(
                                                            username=account[0],
                                                            auth_token=auth_token,
                                                        )
                                                    await self.queue_manager.update_progress(
                                                        task_id=self.task_id,
                                                        current=await self.tracker.current.get(),
                                                        total=self.initial_total,
                                                        details={
                                                            "suspended": await self.tracker.suspended.get()
                                                        },
                                                    )
                                                    return False
                                                elif (
                                                    "This request requires a matching csrf cookie and header."
                                                    in str(resp)
                                                ):
                                                    debug.log(
                                                        f"{GG}ct0 Invalid, retrying with{W} > {Y}{account[0]}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    await self.tracker.retries.increment()
                                                    ct0, auth_token = await get_ct0(
                                                        auth_token
                                                    )
                                                    if not ct0 or not auth_token:
                                                        await self.tracker.failed.increment()
                                                        debug.log(
                                                            f"{GG}failed to get ct0{W} > {Y}{account[0]}@{auth_token}{W}",
                                                            send=False,
                                                        )
                                                        await self.queue_manager.update_progress(
                                                            task_id=self.task_id,
                                                            current=await self.tracker.current.get(),
                                                            total=self.initial_total,
                                                            details={
                                                                "failed": await self.tracker.failed.get()
                                                            },
                                                        )
                                                        return False
                                                    headers, cookies = auth(
                                                        ct0, auth_token
                                                    )
                                                    await self.tracker.retries.increment()
                                                    return True
                                                else:
                                                    await self.tracker.failed.increment()
                                                    debug.log(
                                                        f"{GG}Failed to fetch user data{W} > {Y}{account[0]}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    await self.queue_manager.update_progress(
                                                        task_id=self.task_id,
                                                        current=await self.tracker.current.get(),
                                                        total=self.initial_total,
                                                        details={
                                                            "failed": await self.tracker.failed.get()
                                                        },
                                                    )
                                                    return False
                                            else:
                                                user_data = user_info
                                            if not user_data:
                                                debug.log(
                                                    f"{GG}No user data found{W} > {Y}{account[0]}@{auth_token}{W}",
                                                    send=False,
                                                )
                                                await self.queue_manager.update_progress(
                                                    task_id=self.task_id,
                                                    current=await self.tracker.current.get(),
                                                    total=self.initial_total,
                                                    details={
                                                        "failed": await self.tracker.failed.get()
                                                    },
                                                )
                                                return False

                                            else:
                                                created_at = user_data.get(
                                                    "legacy", {}
                                                ).get("created_at", "")
                                                followings = user_data.get(
                                                    "legacy", {}
                                                ).get("friends_count", False)
                                                follow_count = user_data.get(
                                                    "legacy", {}
                                                ).get("followers_count", 0)
                                                year = datetime.strptime(
                                                    created_at,
                                                    "%a %b %d %H:%M:%S %z %Y",
                                                ).year
                                                blue_verified = user_data.get(
                                                    "is_blue_verified", False
                                                )
                                                grey_verified = (
                                                    user_data.get("legacy", {}).get(
                                                        "verified_type", ""
                                                    )
                                                    == "Government"
                                                )
                                                gold_verified = (
                                                    user_data.get("legacy", {}).get(
                                                        "verified_type", ""
                                                    )
                                                    == "Business"
                                                )

                                            email_phone = await client.get(
                                                EMAIL_PHONE_INFO_URL, headers=headers
                                            )
                                            data = email_phone.text

                                            verified = self.verified(data)
                                            if not follow_count:
                                                follow_count = 0
                                            if not followings:
                                                followings = 0

                                            capture = (
                                                username,
                                                password,
                                                email,
                                                email_pass,
                                                ct0,
                                                auth_token,
                                                follow_count,
                                                followings,
                                                year,
                                                backup_code,
                                                verified,
                                            )

                                            async with self.lock:
                                                self.hits.append(capture)
                                                await self.tracker.remaining.increment(
                                                    -1
                                                )

                                                if username in self.processed_accounts:
                                                    return False
                                                self.processed_accounts.add(username)

                                                account_counted = False
                                                if (
                                                    gold_verified
                                                    and not account_counted
                                                ):
                                                    target_table = (
                                                        "gold_verified_accounts"
                                                    )
                                                    if self.update:
                                                        await self.handle_account_status(
                                                            username, capture, user_data
                                                        )
                                                    else:
                                                        await self.db.remove_account_from_conflicting_tables(
                                                            username,
                                                            target_table,
                                                            insert=True,
                                                            capture=capture,
                                                        )
                                                    await self.tracker.golds.increment()
                                                    debug.log(
                                                        f"{G3}Gold verified > {Y}{username}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    await self.queue_manager.update_progress(
                                                        task_id=self.task_id,
                                                        current=await self.tracker.current.get(),
                                                        total=self.initial_total,
                                                        details={"golds": 1},
                                                    )
                                                    account_counted = True

                                                elif (
                                                    grey_verified
                                                    and not account_counted
                                                ):
                                                    target_table = (
                                                        "grey_verified_accounts"
                                                    )
                                                    if self.update:
                                                        await self.handle_account_status(
                                                            username, capture, user_data
                                                        )
                                                    else:
                                                        await self.db.remove_account_from_conflicting_tables(
                                                            username,
                                                            target_table,
                                                            insert=True,
                                                            capture=capture,
                                                        )
                                                    await self.tracker.greys.increment()
                                                    debug.log(
                                                        f"{G2}Grey Verified > {Y}{username}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    await self.queue_manager.update_progress(
                                                        task_id=self.task_id,
                                                        current=await self.tracker.current.get(),
                                                        total=self.initial_total,
                                                        details={"greys": 1},
                                                    )
                                                    account_counted = True

                                                elif (
                                                    blue_verified
                                                    and not account_counted
                                                ):
                                                    is_plus = await premium_plus(
                                                        auth_token, ct0
                                                    )
                                                    if is_plus:
                                                        target_table = (
                                                            "blueplus_accounts"
                                                        )
                                                        if self.update:
                                                            await self.handle_account_status(
                                                                username,
                                                                capture,
                                                                user_data,
                                                            )
                                                        else:
                                                            await self.db.remove_account_from_conflicting_tables(
                                                                username,
                                                                target_table,
                                                                insert=True,
                                                                capture=capture,
                                                            )

                                                        await self.tracker.blueplus.increment()
                                                        debug.log(
                                                            f"{C1}Blue+ Verified > {Y}{username}@{auth_token}{W}",
                                                            send=False,
                                                        )
                                                        await self.queue_manager.update_progress(
                                                            task_id=self.task_id,
                                                            current=await self.tracker.current.get(),
                                                            total=self.initial_total,
                                                            details={"blueplus": 1},
                                                        )
                                                    else:
                                                        target_table = (
                                                            "blue_verified_accounts"
                                                        )
                                                        if self.update:
                                                            await self.handle_account_status(
                                                                username,
                                                                capture,
                                                                user_data,
                                                            )
                                                        else:
                                                            await self.db.remove_account_from_conflicting_tables(
                                                                username,
                                                                target_table,
                                                                insert=True,
                                                                capture=capture,
                                                            )

                                                        await self.tracker.blues.increment()
                                                        debug.log(
                                                            f"{C1}Blue Verified > {Y}{username}@{auth_token}{W}",
                                                            send=False,
                                                        )
                                                        await self.queue_manager.update_progress(
                                                            task_id=self.task_id,
                                                            current=await self.tracker.current.get(),
                                                            total=self.initial_total,
                                                            details={"blues": 1},
                                                        )
                                                    account_counted = True

                                                elif (
                                                    len(username) <= MIN_USERNAME_LENGTH
                                                    and not account_counted
                                                ):
                                                    target_table = "chars_accounts"
                                                    if self.update:
                                                        await self.handle_account_status(
                                                            username, capture, user_data
                                                        )
                                                    else:
                                                        await self.db.remove_account_from_conflicting_tables(
                                                            username,
                                                            target_table,
                                                            insert=True,
                                                            capture=capture,
                                                        )
                                                    await self.tracker.chars.increment()
                                                    debug.log(
                                                        f"{GG}Chars Account > {Y}{username}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    await self.queue_manager.update_progress(
                                                        task_id=self.task_id,
                                                        current=await self.tracker.current.get(),
                                                        total=self.initial_total,
                                                        details={"chars": 1},
                                                    )
                                                    account_counted = True

                                                elif (
                                                    follow_count >= MIN_FOLLOWERS_COUNT
                                                    and not account_counted
                                                ):
                                                    target_table = "follower_accounts"
                                                    if self.update:
                                                        await self.handle_account_status(
                                                            username, capture, user_data
                                                        )
                                                    else:
                                                        await self.db.remove_account_from_conflicting_tables(
                                                            username,
                                                            target_table,
                                                            insert=True,
                                                            capture=capture,
                                                        )
                                                    await self.tracker.followers.increment()
                                                    debug.log(
                                                        f"{G}Followers account > {Y}{username}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    await self.queue_manager.update_progress(
                                                        task_id=self.task_id,
                                                        current=await self.tracker.current.get(),
                                                        total=self.initial_total,
                                                        details={"followers": 1},
                                                    )
                                                    account_counted = True
                                                elif (
                                                    follow_count >= 100 and follow_count <= 999
                                                    and verified in ["fv", "pv", "ev", "uv"]
                                                    and not account_counted
                                                ):
                                                    target_table = "mstats_accounts"
                                                    if self.update:
                                                        await self.handle_account_status(
                                                            username, capture, user_data
                                                        )
                                                    else:
                                                        await self.db.remove_account_from_conflicting_tables(
                                                            username,
                                                            target_table,
                                                            insert=True,
                                                            capture=capture,
                                                        )

                                                    await self.tracker.mstats.increment()
                                                    debug.log(
                                                        f"{G}MStats account > {Y}{username}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    await self.queue_manager.update_progress(
                                                        task_id=self.task_id,
                                                        current=await self.tracker.current.get(),
                                                        total=self.initial_total,
                                                        details={"mstats": 1},
                                                    )
                                                    account_counted = True
                                                elif (
                                                    verified == "uv"
                                                    and not account_counted
                                                ):
                                                    target_table = "normals"
                                                    if self.update:
                                                        await self.handle_account_status(
                                                            username, capture, user_data
                                                        )
                                                    else:
                                                        await self.db.remove_account_from_conflicting_tables(
                                                            username,
                                                            target_table,
                                                            insert=True,
                                                            capture=capture,
                                                        )

                                                    await self.tracker.unverified.increment()
                                                    debug.log(
                                                        f"{GG}Unverified Token > {Y}{username}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    await self.queue_manager.update_progress(
                                                        task_id=self.task_id,
                                                        current=await self.tracker.current.get(),
                                                        total=self.initial_total,
                                                        details={"unverified": 1},
                                                    )
                                                    account_counted = True

                                                elif not account_counted:
                                                    target_table = "normals"
                                                    if self.update:
                                                        await self.handle_account_status(
                                                            username, capture, user_data
                                                        )
                                                    else:
                                                        await self.db.remove_account_from_conflicting_tables(
                                                            username,
                                                            target_table,
                                                            insert=True,
                                                            capture=capture,
                                                        )

                                                    await self.tracker.normals.increment()
                                                    debug.log(
                                                        f"{G}Normal Account > {Y}{username}@{auth_token}{W}",
                                                        send=False,
                                                    )
                                                    await self.queue_manager.update_progress(
                                                        task_id=self.task_id,
                                                        current=await self.tracker.current.get(),
                                                        total=self.initial_total,
                                                        details={"normals": 1},
                                                    )

                                            return False

                            else:
                                await self.tracker.remaining.increment(-1)
                                debug.log(
                                    f"{GG}Token failed with status {Y}{status_code}{W}: {Y}{account[0]}@{auth_token}{W}",
                                    send=True,
                                )
                                await self.queue_manager.update_progress(
                                    task_id=self.task_id,
                                    current=await self.tracker.current.get(),
                                    total=self.initial_total,
                                    details={"failed": await self.tracker.failed.get()},
                                )
                                return False

                        retry_count = 0
                        error_occurred = False
                        while True:
                            try:
                                response = await client_event(
                                    auth_token=auth_token, ct0=ct0
                                )
                                if not response:
                                    await self.tracker.failed.increment()
                                    await self.queue_manager.update_progress(
                                        task_id=self.task_id,
                                        current=await self.tracker.current.get(),
                                        total=self.initial_total,
                                        details={
                                            "failed": await self.tracker.failed.get()
                                        },
                                    )
                                    break
                                if response:
                                    retry_count += 1
                                    if await handle_response(response):
                                        continue
                                    else:
                                        break
                            except httpx.HTTPStatusError as e:
                                if "Connection closed" in str(e):
                                    retry_count += 1
                                    if retry_count < max_retries:
                                        await asyncio.sleep(1)
                                        continue
                                debug.log(
                                    f"HTTP Client Error for {account[0]}@{auth_token}: {e}",
                                    send=False,
                                )
                                if retry_count < max_retries:
                                    error_occurred = True
                                    continue
                                break
                            except asyncio.TimeoutError:
                                debug.log(
                                    f"Request timed out for {account[0]}@{auth_token}",
                                    send=False,
                                )
                                if retry_count < max_retries:
                                    error_occurred = True
                                    continue
                                break
                            except Exception as e:
                                retry_count += 1
                                if retry_count < max_retries:
                                    await asyncio.sleep(1)
                                    import traceback

                                    traceback.print_exc()
                                    debug.log(
                                        f"{GG}Exception: {Y}{e}{W}, account: {Y}{account[0]}@{auth_token}{W}",
                                        send=False,
                                    )
                                    error_occurred = True
                                    continue
                                break
                        if error_occurred and retry_count >= max_retries:
                            await self.tracker.errors.increment()
                            await self.queue_manager.update_progress(
                                task_id=self.task_id,
                                current=await self.tracker.current.get(),
                                total=self.initial_total,
                                details={"errors": await self.tracker.errors.get()},
                            )

                except asyncio.TimeoutError:
                    await self.tracker.failed.increment()
                    debug.log(f"Request timeout for {account[0]}@{auth_token}")
                    continue
                except Exception as e:
                    await self.tracker.errors.increment()
                    debug.log(f"Account processing error for {account[0]}: {e}")
                    continue

                self.consecutive_failures = 0
                await self._update_progress()

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.consecutive_failures += 1
                debug.log(f"Login error (attempt {self.consecutive_failures}): {e}")
                if self.consecutive_failures >= self.max_consecutive_failures:
                    debug.log("Too many consecutive failures, stopping login process")
                    break
                await asyncio.sleep(1)
                await self._update_progress()
                continue

    async def _track_result(self, category: str):
        """Atomic tracking of results"""
        async with self.lock:
            await self.tracker.increment(category)
            current = min(await self.tracker.current.get(), self.initial_total)
            details = await self.tracker.get_status()
            filtered_details = {
                k: v
                for k, v in details.items()
                if k not in ["current", "total"] and v > 0
            }
            await self.queue_manager.update_progress(
                task_id=self.task_id,
                current=current,
                total=self.initial_total,
                details=filtered_details,
            )

    async def _execute(
        self, tokens: list, update: bool = False, task_id: str = None
    ) -> CheckerResults:
        self.processed_accounts.clear()
        try:
            self.is_running = True
            self.start_time = datetime.now()
            self.update = update
            self.tokens = list(set(tokens))
            self.initial_total = len(self.tokens)
            await self._init_tracker()
            await self.tracker.current.set(0)
            threads = min(config.THREADS, len(self.tokens))
            try:
                tasks = [asyncio.create_task(self.login()) for _ in range(threads)]
                await asyncio.gather(*tasks, return_exceptions=True)
            except Exception as e:
                debug.log(f"Error managing threads: {str(e)}")
                if threads > 100:
                    threads = 100
                    tasks = [asyncio.create_task(self.login()) for _ in range(threads)]
                    await asyncio.gather(*tasks, return_exceptions=True)
            await self._update_progress()
        finally:
            self.is_running = False
            status = await self.tracker.get_status()
            filtered_status = {
                k: status[k]
                for k in [
                    "followers",
                    "normals",
                    "golds",
                    "blues",
                    "greys",
                    "suspended",
                    "locked",
                    "failed",
                    "invalids",
                    "rate_limited",
                    "errors",
                    "current",
                    "unverified",
                    "chars",
                ]
                if k in status
            }
            return CheckerResults(**filtered_status)

    async def update_progress(self, task_id, current, total, details):
        async with self.lock:
            self.tracker.current = current
            self.tracker.total = total
            if details:
                for key, value in details.items():
                    if key in self.progress_details:
                        self.progress_details[key] += value
                await self.queue_manager.update_progress(
                    task_id=task_id,
                    current=current,
                    total=total,
                    details={k: v for k, v in self.progress_details.items() if v > 0},
                )

    def stop(self):
        """Gracefully stop the checker"""
        self.is_running = False

    async def find_latest_valids(self, country: str) -> bytes:
        return bytes("This function is not available for use.", "utf-8")

    async def handle_account_status(
        self, username: str, capture: tuple, user_data: dict
    ) -> None:
        if self.update:
            current_table = await self.db.get_account_current_table(username)
            if not current_table:
                return

            gold_verified = (
                user_data.get("legacy", {}).get("verified_type", "") == "Business"
            )
            grey_verified = (
                user_data.get("legacy", {}).get("verified_type", "") == "Government"
            )
            blue_verified = user_data.get("is_blue_verified", False)
            is_plus = (
                await premium_plus(capture[5], capture[4]) if blue_verified else False
            )
            follow_count = int(user_data.get("legacy", {}).get("followers_count", 0))
            username_length = len(username)

            # Robust mstats logic: always assign 100-999 followers to mstats_accounts if not special
            if grey_verified:
                target_table = "grey_verified_accounts"
            elif gold_verified:
                target_table = "gold_verified_accounts"
            elif blue_verified and is_plus:
                target_table = "blueplus_accounts"
            elif blue_verified:
                target_table = "blue_verified_accounts"
            elif follow_count >= MIN_FOLLOWERS_COUNT:
                target_table = "follower_accounts"
            elif username_length <= MIN_USERNAME_LENGTH:
                target_table = "chars_accounts"
            elif (
                user_data.get("followers")
                and str(user_data["followers"]).isdigit()
                and 100 <= int(user_data["followers"]) <= 999
            ):
                target_table = "mstats_accounts"
            else:
                target_table = "normals"

            await self.db.remove_account_from_conflicting_tables(username, target_table)
            new_current_table = await self.db.get_account_current_table(username)
            if new_current_table == target_table:
                debug.log(
                    f"{username} remains in {target_table} after cleaning duplicates",
                    send=False,
                )
            elif new_current_table != target_table:
                try:
                    await self.db.transition_account(
                        new_current_table, target_table, username, capture
                    )
                    debug.log(
                        f"Transitioned {username} from {new_current_table} to {target_table}",
                        send=False,
                    )
                except Exception as e:
                    debug.log(f"Failed to transition {username}: {e}", send=False)
