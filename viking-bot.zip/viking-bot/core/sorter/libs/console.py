import logging

G = "\u001b[38;5;84m"
W = "\u001b[0m"
Y = "\u001b[38;5;220m"
P = "\u001b[38;5;206m"
R = "\u001b[38;5;197m"
GG = "\u001b[38;5;245m"
WW = "\u001b[38;5;255m"
C = "\u001b[36;1m"
G1 = "\u001b[38;5;119m"
G2 = "\u001b[38;5;155m"
G3 = "\u001b[38;5;157m"
G4 = "\u001b[38;5;192m"
C1 = "\u001b[38;5;195"

logging.basicConfig(
    level=logging.CRITICAL,
    format=" \x1b[38;5;238m%(asctime)s\u001b[0m: %(message)s\u001b[0m",
    datefmt="%H:%M:%S",
)

DEFAULT_SPACE = 15


def calculate_space(message_length: int) -> str:
    total_space = DEFAULT_SPACE - message_length
    return " " * total_space


def prompt(arg: str, type_: str = str):
    print(
        f" {WW}{arg}{G3}:{W} ",
        end=WW,
    )

    while True:
        value = input()
        if value == "" or value is None:
            return prompt(arg, type_)

        if type_ == str:
            return value
        else:
            try:
                return type_(value)
            except ValueError:
                print(f"Invalid input. Please enter a valid {type_.__name__}.")


def log(level: int, message: str, substr: str = None):
    """
    Levels:
    1: Info
    2: Error
    3: Exception
    4: Warning
    """
    color = ""
    if level == 1:
        color = "\x1b[38;5;10m"
    elif level == 2:
        color = "\x1b[38;5;216m"
    elif level == 3:
        color = "\x1b[38;5;9m"
    elif level == 4:
        color = "\x1b[38;5;229m"

    space = calculate_space(len(message))
    if substr:
        logging.critical(
            f"{color}{message}{space}\x1b[38;5;231m →\u001b[0m \x1b[38;5;239m{substr}\u001b[0m"
        )
    else:
        logging.critical(f"{color}{message}{space}")
