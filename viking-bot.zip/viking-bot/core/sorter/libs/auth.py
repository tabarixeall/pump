import aiohttp
import logging
import random
import asyncio
from .constants import AUTHORIZATION


def auth(ct0: str, auth_token: str) -> tuple:
    chrome = random.randint(110, 128)
    headers = {
        "sec-ch-ua": f'"Chromium";v="{chrome}", "Not;A=Brand";v="24", "Google Chrome";v="{chrome}"',
        "x-twitter-client-language": "en",
        "x-csrf-token": ct0,
        "sec-ch-ua-mobile": "?0",
        "authorization": AUTHORIZATION,
        "user-agent": f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome}.0.0.0 Safari/537.36",
        "accept": "*/*",
        "x-twitter-auth-type": "OAuth2Session",
        "x-twitter-active-user": "yes",
        "sec-ch-ua-platform": '"macOS"',
        "origin": "https://x.com",
        "sec-fetch-site": "same-site",
        "sec-fetch-mode": "cors",
        "sec-fetch-dest": "empty",
        "referer": "https://x.com/",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "en-US,en;q=0.9",
        "cookie": f"auth_token={auth_token}; ct0={ct0}",
    }

    return headers, {"auth_token": auth_token, "ct0": ct0}


async def get_ct0(
    auth_token: str, max_retries: int = 3, initial_delay: float = 1.0
) -> tuple:
    attempt = 0
    delay = initial_delay

    while attempt < max_retries:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url="https://x.com/i/api/fleets/v1/avatar_content",
                    headers={
                        "accept": "*/*",
                        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
                        "Authorization": AUTHORIZATION,
                        "cookie": f"auth_token={auth_token}",
                    },
                    cookies={"auth_token": auth_token},
                    ssl=False,
                ) as ct0:
                    if "ct0" in ct0.cookies:
                        return (ct0.cookies["ct0"].value, auth_token)
                    else:
                        return None, None

        except Exception as e:
            attempt += 1
            if attempt == max_retries:
                logging.error(
                    f"ct0 Error after {max_retries} retries, ({auth_token}) {e}"
                )
                return None, None

            logging.warning(
                f"ct0 Error on attempt {attempt}, retrying in {delay}s... ({auth_token}) {e}"
            )
            await asyncio.sleep(delay)
            delay *= 2
