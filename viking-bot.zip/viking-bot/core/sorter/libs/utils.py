import aiofiles
import logging
from .auth import get_ct0


async def get_capture(account: tuple) -> tuple:
    default = (None,) * 10
    (
        username,
        password,
        email,
        email_pass,
        ct0,
        auth_token,
        followers,
        following,
        year,
        backup_code,
    ) = default

    is_verification = lambda x: x in ("fv", "ev", "pv", "uv")
    safe_convert = lambda x: (
        int(x) if x is not None and str(x).strip().isdigit() else None
    )

    def extract_year_from_backup(value):
        if isinstance(value, str) and value.isdigit() and len(value) >= 4:
            potential_year = int(value[:4])
            if 1900 <= potential_year <= 2100:
                return potential_year, value[4:] if len(value) > 4 else None
        return None, value

    match len(account):
        case 1:
            auth_token = account[0]
            ct0, auth_token = await get_ct0(auth_token)
            if not ct0 or not auth_token:
                return None
        case 2:
            ct0, auth_token = account
        case 4:
            if "@" in str(account[0]):
                email, password, ct0, auth_token = account
            else:
                username, password, ct0, auth_token = account
        case 5:

            if "@" in str(account[2]):
                username, password, email, ct0, auth_token = account

            elif len(str(account[2])) > 25:
                username, password, ct0, auth_token, backup_code = account
            else:

                username, password, email, ct0, auth_token = account
        case 6:

            if len(str(account[3])) > 25 and len(str(account[4])) > 25:

                username, password, email, ct0, auth_token, backup_code = account
                email_pass = "NO_MAIL_PASS"
            elif len(str(account[3])) > 25:

                username, password, email, ct0, auth_token, backup_code = account
                email_pass = "NO_MAIL_PASS"
            elif len(str(account[4])) > 25:

                username, password, email, email_pass, ct0, auth_token = account
            else:

                username, password, email, email_pass, ct0, auth_token = account
        case 7:

            if "@" in str(account[2]):

                username, password, email, email_pass, ct0, auth_token, backup_code = (
                    account
                )
            elif len(str(account[2])) > 25:

                username, password, ct0, auth_token, followers, following, year = (
                    account
                )
                email = None
                email_pass = None
            else:

                username, password, email, email_pass, ct0, auth_token, backup_code = (
                    account
                )

            if backup_code and isinstance(backup_code, str):
                extracted_year, extracted_backup = extract_year_from_backup(
                    str(backup_code)
                )
                if extracted_year:
                    year = extracted_year
                    backup_code = extracted_backup
        case 8:
            username, password, email, ct0, auth_token, followers, following, year = (
                account
            )
            extracted_year, extracted_backup = extract_year_from_backup(str(year))
            if extracted_year:
                year = extracted_year
                backup_code = extracted_backup
            else:
                backup_code = year
                year = None
        case 9:

            if len(str(account[3])) > 25:
                (
                    username,
                    password,
                    email,
                    ct0,
                    auth_token,
                    followers,
                    following,
                    year,
                    backup_code,
                ) = account
                extracted_year, extracted_backup = extract_year_from_backup(str(year))
                if extracted_year:
                    year = extracted_year
                    if not backup_code:
                        backup_code = extracted_backup
                elif not is_verification(backup_code):

                    pass
            else:

                (
                    username,
                    password,
                    email,
                    email_pass,
                    ct0,
                    auth_token,
                    followers,
                    following,
                    year,
                ) = account

                extracted_year, extracted_backup = extract_year_from_backup(str(year))
                if extracted_year:
                    year = extracted_year
                    backup_code = extracted_backup
        case 10:

            (
                username,
                password,
                email,
                email_pass,
                ct0,
                auth_token,
                followers,
                following,
                year,
                backup_code,
            ) = account
        case 11:

            (
                username,
                password,
                email,
                email_pass,
                ct0,
                auth_token,
                followers,
                following,
                year,
                backup_code,
                _,
            ) = account

        case _:

            if len(account) > 0:

                auth_token = account[-1] if len(account) % 2 == 1 else None
                ct0 = account[-2] if len(account) >= 2 else None

                if len(account) >= 3:
                    username = account[0]
                if len(account) >= 4:
                    password = account[1]
                if len(account) >= 5:
                    email = account[2]
                if len(account) >= 6:
                    email_pass = account[3]
                if len(account) >= 7:
                    backup_code = (
                        account[-3] if not is_verification(account[-1]) else account[-2]
                    )

    followers = safe_convert(followers)
    following = safe_convert(following)
    year = safe_convert(year)

    return (
        username,
        password,
        email,
        email_pass,
        ct0,
        auth_token,
        followers,
        following,
        year,
        backup_code,
    )
