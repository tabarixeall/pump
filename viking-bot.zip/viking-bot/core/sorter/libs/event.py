import asyncio
import httpx
from typing import Optional
from src import debugger

debug = debugger.Debugger()


async def get_ct0(auth_token: str, client: httpx.AsyncClient) -> Optional[str]:
    url = "https://x.com/i/api/fleets/v1/avatar_content"
    headers = {
        "cookie": f"auth_token={auth_token}",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    }

    retries = 3
    for attempt in range(retries):
        try:
            response = await client.get(url, headers=headers)
            ct0 = response.cookies.get("ct0")
            if ct0:
                debug.log(f"ct0 cookie found for {auth_token}")
                return ct0

            debug.log(f"ct0 cookie not found in response cookies")

        except Exception as e:
            debug.log(f"Error getting ct0 (attempt {attempt + 1}/{retries}): {str(e)}")
            if attempt == retries - 1:
                break
            await asyncio.sleep(1)

    return None


async def client_event(auth_token: str, ct0: str) -> Optional[httpx.Response]:
    url = "https://x.com/i/api/2/notifications/all/last_seen_cursor.json"

    headers = {
        "authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
        "content-type": "application/x-www-form-urlencoded",
        "sec-ch-ua": '"Chromium";v="136", "Brave";v="136", "Not.A/Brand";v="99"',
        "sec-ch-ua-arch": '"x86"',
        "sec-ch-ua-bitness": '"64"',
        "sec-ch-ua-full-version-list": '"Chromium";v="136.0.0.0", "Brave";v="136.0.0.0", "Not.A/Brand";v="99.0.0.0"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-model": '""',
        "sec-ch-ua-platform": '"Windows"',
        "sec-ch-ua-platform-version": '"19.0.0"',
        "x-client-transaction-id": "qZdKsTeAf0qn5Cwk9XMWuxLpcaf2i+6uz6eryBntoNjqTYs8IAzW3lvOq2eCKLUBs9TEZapzemjAAtr/yUKdCa0ljzQHqg",
        "x-csrf-token": ct0,
        "x-twitter-active-user": "yes",
        "x-twitter-auth-type": "OAuth2Session",
        "x-twitter-client-language": "en",
        "Referer": "https://x.com/notifications",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "cookie": f"auth_token={auth_token}; ct0={ct0}; lang=en;",
    }

    body = "cursor=DAABDAABCgABAAAAALSpGfEIAAIAAAABCAADSQ3bEQgABKymnxIACwACAAAAC0FaWkp3d3NaZFF3AAA"

    retries = 10
    for attempt in range(retries):
        try:
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.post(url, headers=headers, content=body)

                if response.status_code == 429:
                    debug.log(f"Rate limited, retrying... ({attempt + 1}/{retries})")
                    await asyncio.sleep(2)
                    continue

                elif not response.content:
                    debug.log(
                        f"No content in response for {auth_token}, retrying... ({attempt + 1}/{retries})"
                    )
                    await asyncio.sleep(1)
                    continue

                return response

        except (httpx.HTTPError, asyncio.TimeoutError) as e:
            if attempt < retries - 1:
                debug.log(
                    f"Connection error ({type(e).__name__}), retrying... ({attempt + 1}/{retries})"
                )
                await asyncio.sleep(1)
                continue
            else:
                debug.log(f"Connection failed after {retries} attempts: {str(e)}")
                return None


async def fetch_user_info(
    auth_token: str, ct0: str = None, client: httpx.AsyncClient = None
) -> httpx.Response:

    if not ct0:
        ct0 = await get_ct0(auth_token, client)

    url = "https://api.x.com/graphql/HC-1ZetsBT1HKVUOvnLE8Q/Viewer"

    query = {
        "variables": '{"withCommunitiesMemberships":true}',
        "features": '{"rweb_tipjar_consumption_enabled":true,"responsive_web_graphql_exclude_directive_enabled":true,"verified_phone_label_enabled":false,"creator_subscriptions_tweet_preview_api_enabled":true,"responsive_web_graphql_skip_user_profile_image_extensions_enabled":false,"responsive_web_graphql_timeline_navigation_enabled":true}',
        "fieldToggles": '{"isDelegate":false,"withAuxiliaryUserLabels":false}',
    }

    headers = {
        "host": "api.x.com",
        "connection": "keep-alive",
        "sec-ch-ua": '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"',
        "x-twitter-client-language": "en",
        "x-csrf-token": f"{ct0}",
        "sec-ch-ua-mobile": "?0",
        "authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "content-type": "application/json",
        "x-client-transaction-id": "kA/YmwTNLLfnNsv+qQtsjoV6txMO2jhVR3+0KPxAjgf/+FPaLGb27baPdkL/a7JePFwhC5JFPsHVkV2M7NejMi9nn9uNkw",
        "x-twitter-active-user": "yes",
        "sec-ch-ua-platform": '"macOS"',
        "accept": "*/*",
        "origin": "https://x.com",
        "sec-fetch-site": "same-site",
        "sec-fetch-mode": "cors",
        "sec-fetch-dest": "empty",
        "referer": "https://x.com/",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "en-US,en;q=0.9",
    }

    retries = 10
    for attempt in range(retries):
        try:
            response = await client.get(
                url,
                headers=headers,
                params=query,
                cookies={"auth_token": auth_token, "ct0": ct0},
            )
            if response.status_code == 200 and response.content:
                return response
            elif (
                "This request requires a matching csrf cookie and header."
                in response.text
            ):
                new_ct0 = response.cookies.get("ct0")
                if new_ct0:
                    debug.log(f"Updating ct0 cookie to {new_ct0}", send=False)
                    return await fetch_user_info(auth_token, new_ct0, client)
                else:
                    debug.log("ct0 cookie not found in response cookies")
                    return None
            elif response.status_code == 401:
                return 401
            return None
        except (httpx.HTTPError, asyncio.TimeoutError) as e:
            if attempt < retries - 1:
                debug.log(
                    f"Connection error ({type(e).__name__}), retrying... ({attempt + 1}/{retries})"
                )
                continue
            else:
                debug.log(f"Connection failed after {retries} attempts: {str(e)}")
                return None


async def premium_plus(auth_token: str, ct0: str) -> bool:
    url = "https://x.com/i/api/graphql/I5Al47wpRsKQ2gp0W749Yw/ListProductSubscriptions?variables=%7B%7D"

    if not ct0:
        ct0 = await get_ct0(auth_token)

    headers = {
        "host": "x.com",
        "connection": "keep-alive",
        "sec-ch-ua-platform": '"macOS"',
        "authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
        "x-csrf-token": ct0,
        "sec-ch-ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        "x-twitter-client-language": "en",
        "sec-ch-ua-mobile": "?0",
        "x-twitter-active-user": "yes",
        "x-twitter-auth-type": "OAuth2Session",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "content-type": "application/json",
        "accept": "*/*",
        "sec-fetch-site": "same-origin",
        "sec-fetch-mode": "cors",
        "sec-fetch-dest": "empty",
        "referer": "https://x.com/settings/subscription/manage",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "en-US,en;q=0.9",
        "cookie": f"auth_token={auth_token}; ct0={ct0};",
    }

    async with httpx.AsyncClient(http2=False) as client:
        retries = 0
        while retries <= 3:
            try:
                response = await client.get(url, headers=headers)
                if response.status_code == 200:
                    if "premium-plus" in response.text:
                        return True
                    elif "rate limited" in response.text:
                        retries += 1
                        await asyncio.sleep(1)
                        continue
                    else:
                        return False
                elif response.status_code == 401:
                    debug.log(
                        f"Unauthorized request: {response.text}, for premium_plus",
                        send=False,
                    )
                    return False
            except httpx.HTTPStatusError:
                pass
            retries += 1
            await asyncio.sleep(1)
        return False
