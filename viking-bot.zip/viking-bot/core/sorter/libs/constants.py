import os
import config
import logging
from aiohttp_socks import ProxyConnector as conn


logging.getLogger("httpx").setLevel(logging.ERROR)

AUTHORIZATION = "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"
EMAIL_PHONE_INFO_URL = (
    "https://api.x.com/1.1/users/email_phone_info.json?include_pending_email=true"
)
UPDATE_PROFILE = "https://api.x.com/1.1/account/update_profile.json"
CLIENT_EVENT = "https://api.x.com/1.1/jot/client_event.json"
USER_INFO = (
    "https://x.com/i/api/graphql/k5XapwcSikNsEsILW5FvgA/UserByScreenName"
    "?variables=%7B%22screen_name%22%3A%22{username}%22%2C%22withSafetyModeUserFields%22%3Atrue%7D"
    "&features=%7B%22hidden_profile_likes_enabled%22%3Atrue%2C%22hidden_profile_subscriptions_enabled%22%3Atrue%2C"
    "responsive_web_graphql_exclude_directive_enabled%22%3Atrue%2C%22verified_phone_label_enabled%22%3Afalse%2C"
    "subscriptions_verification_info_is_identity_verified_enabled%22%3Atrue%2C%22subscriptions_verification_info_verified_since_enabled%22%3Atrue%2C"
    "highlights_tweets_tab_ui_enabled%22%3Atrue%2C%22responsive_web_twitter_article_notes_tab_enabled%22%3Atrue%2C"
    "creator_subscriptions_tweet_preview_api_enabled%22%3Atrue%2C%22responsive_web_graphql_skip_user_profile_image_extensions_enabled%22%3Afalse%2C"
    "responsive_web_graphql_timeline_navigation_enabled%22%3Atrue%7D&fieldToggles=%7B%22withAuxiliaryUserLabels%22%3Afalse%7D"
)
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
VERIFIED_KEY = "verified"
UNVERIFIED_KEY = "unverified"
GOLD_KEY = "gold"
GREY_KEY = "grey"
BLUE_KEY = "blue"
ALL_KEY = "all"
SUCCESS_KEY = "200"

G = "\u001b[38;5;84m"
W = "\u001b[0m"
Y = "\u001b[38;5;220m"
P = "\u001b[38;5;206m"
R = "\u001b[38;5;197m"
GG = "\u001b[38;5;245m"
WW = "\u001b[38;5;255m"
C = "\u001b[36;1m"
G1 = "\u001b[38;5;119m"
G2 = "\u001b[38;5;155m"
G3 = "\u001b[38;5;157m"
G4 = "\u001b[38;5;192m"
C1 = "\u001b[38;5;195m"
