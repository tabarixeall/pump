import httpx
import re
import asyncio
import logging

logging.getLogger("httpx").setLevel(logging.CRITICAL)
from core.sorter.libs.console import log


class FirstMail:
    def __init__(self, api_key: str = None):
        self.client = httpx.AsyncClient(timeout=25.0)
        self.message_url = "https://api.firstmail.ltd/v1/market/get/message"
        self.api_key = api_key or "bd775840-85b6-45b1-b146-0ef488896b80"

    async def get_email(self) -> tuple[str, str] | None:
        """
        Generate a new IMAP email address and password
        """

        url = "https://api.firstmail.ltd/v1/market/buy/mail?type=3"

        headers = {"accept": "application/json", "X-API-KEY": self.api_key}

        retries = 10
        while retries > 0:
            try:
                response = await self.client.get(url, headers=headers)

                if response.is_success:
                    js = response.json()
                    if js["error"]:
                        log(2, "FirstMail error", js["message"])
                        return None

                    login = js["login"]
                    try:
                        email, password = login.split(":")
                        return email, password
                    except ValueError:
                        log(2, "FirstMail error", login)
            except Exception as e:
                log(2, f"FirstMail request error", str(e))
            retries -= 1
            if retries > 0:
                await asyncio.sleep(2)

        return None

    async def get_latest_message(self, username: str, password: str) -> str | None:
        msg = None
        timeout = 30
        wait_time = 2
        while not msg:
            if timeout <= 0:
                log(4, "Email timeout", username)
                return None
            timeout -= wait_time
            response = await self.client.get(
                self.message_url,
                params={"username": username, "password": password},
                headers={"accept": "application/json", "X-API-KEY": self.api_key},
            )
            if not response.is_success:
                return None
            js = response.json()
            if js["has_message"]:
                msg = js["subject"]
            await asyncio.sleep(wait_time)
        return msg

    async def get_code(self, username, password) -> str:
        retries = 25
        while retries > 0:
            email_message = await self.get_latest_message(username, password)
            if email_message is None:
                log(4, f"No email message received", username)
                await asyncio.sleep(5)
                retries -= 1
                continue

            match = re.search(r"\b\d{6}\b", email_message)
            if match:
                log(1, f"Got code: {match.group(0)}")
                return match.group(0)
            else:
                await asyncio.sleep(5)
                retries -= 1
        return None


if __name__ == "__main__":

    mail = FirstMail()
    print(asyncio.run(mail.get_email()))
