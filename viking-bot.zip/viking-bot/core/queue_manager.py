import asyncio
from typing import Callable, Optional, Any
from datetime import datetime
import traceback
from .progress_updater import TelegramProgressUpdater
from telegram import Message
from src import debugger


class TaskQueueManager:
    def __init__(self, max_concurrent: int = 5):
        self.queue = asyncio.Queue()
        self.active_tasks = {}
        self.max_concurrent = max_concurrent
        self.semaphore = asyncio.Semaphore(max_concurrent)
        self.progress_callback = None
        self.processing = False
        self.tasks = {}
        self.lock = asyncio.Lock()
        self._progress_updaters = {}
        self._update_lock = asyncio.Lock()
        self.debug = debugger.Debugger()

    def set_progress_callback(self, callback: Callable):
        self.progress_callback = callback

    async def add_task(self, task_id: str, coro: Callable, *args, **kwargs):
        async with self.lock:
            if task_id in self.active_tasks:
                task_info = self.active_tasks[task_id]

                if (
                    task_info.get("status") in ["running", "pending_execution"]
                    and task_info.get("task")
                    and not task_info["task"].done()
                ):
                    self.debug.log(
                        f"Warning: Task {task_id} is being re-added while its previous instance might still be active."
                    )

            await self.queue.put((task_id, coro, args, kwargs))
            if not self.processing:
                self.processing = True
                asyncio.create_task(self.process_queue())

    async def process_queue(self):
        while True:
            try:
                task_id, coro, args, kwargs = await self.queue.get()
                completion_event = asyncio.Event()
                task_instance = None

                async with self.semaphore:
                    try:

                        self.active_tasks[task_id] = {
                            "task": None,
                            "start_time": datetime.now(),
                            "status": "pending_execution",
                            "completion_event": completion_event,
                        }

                        task_instance = asyncio.create_task(coro(*args, **kwargs))
                        self.active_tasks[task_id]["task"] = task_instance
                        self.active_tasks[task_id]["status"] = "running"

                        await task_instance

                        self.active_tasks[task_id]["status"] = "completed"
                    except asyncio.CancelledError:
                        if task_id in self.active_tasks:
                            self.active_tasks[task_id]["status"] = "cancelled"

                    except Exception as e:
                        if task_id in self.active_tasks:
                            self.active_tasks[task_id]["status"] = f"failed: {str(e)}"
                        self.debug.log(
                            f"Task {task_id} failed with exception: {traceback.format_exc()}"
                        )
                    finally:
                        if task_id in self.active_tasks:
                            self.active_tasks[task_id]["completion_event"].set()
                        self.queue.task_done()
            except asyncio.CancelledError:
                self.debug.log(
                    "TaskQueueManager.process_queue itself was cancelled. Exiting loop."
                )
                self.processing = False
                break
            except Exception as e:

                self.debug.log(
                    f"Critical error in TaskQueueManager.process_queue loop: {e}\n{traceback.format_exc()}"
                )
                await asyncio.sleep(1)
                continue
        self.processing = False

    async def await_task_completion(
        self, task_id: str, timeout: Optional[float] = None
    ):
        """Waits for a specific task to complete or fail."""
        start_time = datetime.now()
        while True:
            task_info = self.active_tasks.get(task_id)
            if task_info and "completion_event" in task_info:
                try:
                    await asyncio.wait_for(
                        task_info["completion_event"].wait(), timeout=timeout
                    )
                    return task_info.get("status", "unknown_completed")
                except asyncio.TimeoutError:
                    self.debug.log(f"Timeout waiting for task {task_id} to complete.")
                    return "timeout"

            if task_info and task_info.get("status") not in [
                "running",
                "pending_execution",
            ]:
                self.debug.log(
                    f"Task {task_id} found in terminal state '{task_info['status']}' while awaiting completion event."
                )
                return task_info["status"]

            if (
                timeout is not None
                and (datetime.now() - start_time).total_seconds() > timeout
            ):
                self.debug.log(f"Overall timeout polling for task {task_id} info.")
                return "timeout_polling"

            await asyncio.sleep(0.1)

    async def stop_task(self, task_id: str):
        """Stop a running task and its progress updater."""
        if task_id in self._progress_updaters:
            updater = self._progress_updaters.pop(task_id, None)
            if updater:
                await updater.stop()

        task_info = self.active_tasks.get(task_id)
        if task_info and "task" in task_info and task_info["task"] is not None:
            task_instance = task_info["task"]
            if not task_instance.done():

                task_instance.cancel()
                try:

                    await asyncio.wait_for(
                        task_info["completion_event"].wait(), timeout=5.0
                    )
                except asyncio.TimeoutError:
                    self.debug.log(
                        f"Timeout waiting for task {task_id} to finalize after cancellation."
                    )
                except asyncio.CancelledError:
                    pass

            if (
                "completion_event" in task_info
                and not task_info["completion_event"].is_set()
            ):
                task_info["completion_event"].set()

    def get_task_status(self, task_id: str) -> Optional[dict]:
        return self.active_tasks.get(task_id)

    def get_active_tasks(self) -> dict:
        return {k: v for k, v in self.active_tasks.items() if v["status"] == "running"}

    async def set_progress_updater(self, task_id: str, message: Message):
        """Set a progress updater for a task"""
        if task_id in self._progress_updaters:
            old_updater = self._progress_updaters.pop(task_id, None)
            if old_updater:
                await old_updater.stop()

        new_updater = TelegramProgressUpdater(message)
        await new_updater.start()
        self._progress_updaters[task_id] = new_updater

    async def update_progress(
        self,
        task_id: str = None,
        current: int = None,
        total: int = None,
        details: dict = None,
        **kwargs,
    ):
        """Thread-safe progress update with status accumulation"""
        async with self._update_lock:

            if kwargs:
                task_id = kwargs.get("task_id", task_id)
                current = kwargs.get("current", current)
                total = kwargs.get("total", total)
                details = kwargs.get("details", details)

            if task_id in self._progress_updaters:
                current = min(current, total)

                if task_id not in self.tasks:
                    self.tasks[task_id] = {"status": {}}

                if details:

                    for key, value in details.items():
                        if value > self.tasks[task_id]["status"].get(key, 0):
                            self.tasks[task_id]["status"][key] = value

                    await self._progress_updaters[task_id].update(
                        current=current, total=total, **self.tasks[task_id]["status"]
                    )

            if self.progress_callback:
                await self.progress_callback(
                    task_id,
                    current,
                    total,
                    self.tasks.get(task_id, {}).get("status", {}),
                )
