"""
Telegram Bot adaptation for SecurityEnhancer
"""

from typing import Dict, List, Tuple, Optional, Union, Any
import asyncio
from core.securer_port.secure import SecurityEnhancer
from src.debugger import Debugger
from datetime import datetime

debug = Debugger()


class TelegramSecurityEnhancer(SecurityEnhancer):
    """
    Extended version of SecurityEnhancer for Telegram bot usage.
    Maintains lists of failed and skipped accounts for reporting.
    """

    def __init__(self, db_manager=None, account_type="normal") -> None:
        super().__init__(db_manager, account_type)
        self.failed_accounts = []
        self.skipped_accounts = []
        self.filtered_count = 0
        self.already_secured_count = 0
        self.start_time: Optional[datetime] = None

    def format_progress_message(self, filters=None, options=None):
        from datetime import datetime

        percentage = (
            (self.attempted_count / self.total_accounts * 100)
            if self.total_accounts
            else 0
        )
        spinner = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        spin_char = spinner[self.attempted_count % len(spinner)]

        elapsed_time_str = "00:00:00"
        if self.start_time:
            elapsed_delta = datetime.now() - self.start_time
            total_seconds = int(elapsed_delta.total_seconds())
            hours, remainder = divmod(total_seconds, 3600)
            minutes, seconds = divmod(remainder, 60)
            elapsed_time_str = f"{hours:02}:{minutes:02}:{seconds:02}"

        needs_email_count = sum(
            1
            for acc in self.skipped_accounts
            if acc.get("skip_reason")
            and "needs_email_for_2fa" in acc.get("skip_reason")
        )
        success_count = self.calculate_success_count()

        bar_length = 20
        filled_length = int(percentage / 100 * bar_length)
        progress_bar = "█" * filled_length + "░" * (bar_length - filled_length)

        msg = (
            f"<b>🔒 SECURITY ENHANCEMENT PROGRESS 🔒</b>\n\n"
            f"⏳ {progress_bar} {percentage:.1f}%\n"
            f"• Processed: {self.attempted_count}/{self.total_accounts}\n"
            f"• Elapsed: {elapsed_time_str}\n\n"
            f"<b>✅ SUCCESS</b>\n"
            f"• Successfully Secured: {success_count}\n\n"
            f"<b>⚠️ ISSUES</b>\n"
            f"• Failed: {self.failed_count}\n"
            f"• Wrong Password: {self.wrong_password_count}\n"
            f"• Failed 2FA: {self.failed_2fa_count}\n"
            f"• Skipped: {self.skipped_count}\n"
            f"• Needs Email: {needs_email_count}\n\n"
            f"<b>ℹ️ OTHER</b>\n"
            f"• Already Secured: {self.already_secured_count}\n"
            f"• Filtered Out: {self.filtered_count - self.already_secured_count}\n"
            f"• Mail Skips: {self.email_skips_count}\n"
        )

        if filters:
            msg += "\n\n<b>🔍 FILTERS APPLIED</b>"
            if filters.get("follower_range"):
                msg += f"\n• Followers: {filters['follower_range'][0]}-{filters['follower_range'][1]}"
            if filters.get("verification"):
                msg += f"\n• Verification: {filters['verification']}"
            if filters.get("mail_access"):
                msg += f"\n• Mail Access: Required"

        if options:
            msg += "\n\n<b>⚙️ OPTIONS</b>"
            for k, v in options.items():
                msg += f"\n• {k}: {'Enabled' if v else 'Disabled'}"

        return msg

    async def run_progress_updater(self, msg, filters=None, options=None):
        last_message = ""
        import random
        import re

        while True:
            try:
                current_message = self.format_progress_message(
                    filters=filters, options=options
                )
                if current_message != last_message:
                    try:
                        await asyncio.wait_for(
                            msg.edit_text(current_message, parse_mode="HTML"), timeout=3
                        )
                        last_message = current_message
                    except Exception as e:
                        error_str = str(e).lower()
                        if "message is not modified" in error_str:
                            pass
                        elif "flood control exceeded" in error_str:
                            retry_seconds_match = re.search(
                                r"retry in (\d+) seconds", error_str
                            )
                            if retry_seconds_match:
                                retry_seconds = int(retry_seconds_match.group(1))
                                await asyncio.sleep(min(retry_seconds, 300))
                            else:
                                await asyncio.sleep(60)
                        else:
                            debug.log(
                                f"Error updating message: {error_str}", send=False
                            )
            except Exception as e:
                debug.log(f"Error updating progress: {str(e)}", send=False)

            if self.total_accounts > 0 and self.attempted_count >= self.total_accounts:
                if self.finished_count >= self.total_accounts:
                    break
                elif self.attempted_count > self.total_accounts + 10:
                    debug.log(
                        "Progress updater detected anomaly in counts, stopping",
                        send=False,
                    )
                    break

            await asyncio.sleep(random.uniform(3.0, 5.0))

        final_message = self.format_progress_message(filters=filters, options=options)
        final_message = final_message.replace(
            "<b>🔒 SECURITY ENHANCEMENT PROGRESS 🔒</b>",
            "<b>🔒 SECURITY ENHANCEMENT COMPLETE 🔒</b>",
        )
        try:
            await msg.edit_text(final_message, parse_mode="HTML")
        except Exception as e:
            debug.log(f"Error sending final message: {str(e)}", send=False)

    def calculate_success_count(self):
        """Calculate success count based on accounts that are neither failed nor skipped"""
        return self.success_count
