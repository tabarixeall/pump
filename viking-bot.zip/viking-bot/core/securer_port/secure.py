from typing import Dict, List, Tuple, Optional, Union, Any
import asyncio
import warnings
import aiofiles
import aiohttp
import secrets
import string
from src import twitter
from src.debugger import Debugger
from src.db import DatabaseManager
import re

warnings.filterwarnings("ignore", module="asyncio")

debugger = Debugger()


class SecurityEnhancer:
    def __init__(
        self, db_manager: DatabaseManager, account_type: str = "normal"
    ) -> None:
        self.tokens: List[str] = []
        self.token_lock: asyncio.Lock = asyncio.Lock()
        self.results_lock: asyncio.Lock = asyncio.Lock()
        self.accounts: Dict[int, Dict[str, Any]] = {}
        self.total_accounts: int = 0
        self.attempted_count: int = 0
        self.finished_count: int = 0
        self.success_count: int = 0
        self.failed_count: int = 0
        self.skipped_count: int = 0
        self.wrong_password_count: int = 0
        self.email_skips_count: int = 0
        self.failed_2fa_count: int = 0
        self.failed_2fa_wrong_pass_count: int = 0
        self.title_update_running: bool = False
        self.password_length: int = 12
        self.enable_password_change: bool = False
        self.enable_email_change: bool = False
        self.enable_2fa: bool = False
        self.db_manager = db_manager
        self.account_type = account_type
        self.filters = {}

    def set_filters(
        self,
        follower_range: tuple = None,
        verification: str = None,
        mail_access: bool = False,
    ) -> None:
        """
        Set filtering options for account selection

        Args:
            follower_range: Tuple of (min, max) follower counts
            verification: Verification type ('fv', 'ev', 'pv', 'uv', 'mixed')
            mail_access: Whether account needs mail access
        """
        self.filters = {}
        if follower_range:
            self.filters["range"] = follower_range
        if verification:
            self.filters["verification"] = verification
        if mail_access:
            self.filters["mail_access"] = True

        # Special handling for mstats accounts
        if self.account_type == "mstats":
            # Override follower range for mstats accounts
            self.filters["range"] = (100, 999)
            # Allow all verification types for mstats
            if verification not in ["fv", "pv", "ev", "uv", "mixed"]:
                self.filters["verification"] = None

    async def load_unsecured_accounts(self, limit: int = 0) -> None:
        """Load unsecured accounts from database with filters"""
        if not self.db_manager:
            debugger.log("No database manager available")
            return

        # Special handling for mstats accounts
        if self.account_type == "mstats" and not self.filters.get("range"):
            self.filters["range"] = (100, 999)

        accounts = await self.db_manager.get_unsecured_accounts(
            self.account_type, filters=self.filters, limit=limit
        )
        self.tokens = accounts

        filter_desc = []
        if "range" in self.filters:
            min_f, max_f = self.filters["range"]
            filter_desc.append(f"followers {min_f}-{max_f}")
        if "verification" in self.filters:
            filter_desc.append(f"verification={self.filters['verification']}")
        if self.filters.get("mail_access"):
            filter_desc.append("mail_access=True")

        debugger.log(
            f"Loaded {len(accounts)} unsecured accounts for security enhancement"
            + (f" (filters: {', '.join(filter_desc)})" if filter_desc else "")
        )
        if accounts:
            sample = accounts[0]
            debugger.log(
                f"Sample account - Username: {sample.get('username')}, Has backup: {'backup_code' in sample and bool(sample['backup_code'])}",
                send=False,
            )
            debugger.log(
                f"Sample backup code value: '{sample.get('backup_code', 'None')}'",
                send=False,
            )

    async def get_ct0(self, auth_token: str) -> tuple:
        debugger.log("Fetching ct0 token")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url="https://x.com/i/api/fleets/v1/avatar_content",
                    headers={
                        "accept": "*/*",
                        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                        "Authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
                        "cookie": f"auth_token={auth_token}",
                    },
                    cookies={"auth_token": auth_token},
                    ssl=False,
                ) as ct0:
                    if "ct0" in ct0.cookies:
                        return (ct0.cookies["ct0"].value, auth_token)
                    else:
                        return None, None

        except Exception as e:
            debugger.log(f"Failed to get ct0: {e}")
            return None, None

    async def save(self, account: Dict[str, Any]) -> None:
        """Save secured account back to database"""
        self.success_count += 1
        self.finished_count += 1
        debugger.log(
            f"Account secured successfully: {account.get('username', 'unknown')}",
            send=False,
        )

    def generate_password(self, length: int = 12) -> str:
        return secrets.token_hex(length)

    async def change_password_security(
        self, client: twitter.Client, account: Dict[str, Any], new_password: str
    ) -> Union[bool, str]:
        try:

            password_changed = await asyncio.wait_for(
                client.change_password(new_password), timeout=60.0
            )
            if password_changed:
                account["password"] = new_password
                account["auth_token"] = client.account.auth_token
                account["ct0"] = client.account.ct0 or account["ct0"]
                debugger.log(
                    f"Password changed {client.account.auth_token}", send=False
                )

                if self.db_manager:
                    try:
                        await self.db_manager.change_password(
                            table=self.account_type,
                            username=client.account.username,
                            new_password=new_password,
                            ct0=client.account.ct0,
                            auth_token=client.account.auth_token,
                        )
                        debugger.log(
                            f"Password updated in database {client.account.auth_token}",
                            send=False,
                        )
                    except Exception as db_err:
                        debugger.log(
                            f"Failed to update password in database immediately: {db_err}",
                            client.account.auth_token,
                            send=False,
                        )

                return True
            else:
                debugger.log(
                    f"Failed to change password {client.account.auth_token}", send=False
                )
                return False
        except asyncio.TimeoutError:
            debugger.log(
                f"Password change timed out {client.account.auth_token}", send=False
            )
            return False
        except (twitter.errors.AccountSuspended, twitter.errors.AccountLocked) as e:
            debugger.log(
                f"Account locked/suspended during password change: {type(e).__name__} {client.account.auth_token}",
                send=False,
            )
            return "locked"
        except twitter.errors.BadAccountToken as e:
            debugger.log(
                f"Invalid account token during password change {client.account.auth_token}",
                send=False,
            )
            return "unauthorized"
        except Exception as e:
            if "already used this password" in str(e).lower():
                debugger.log(
                    f"Password already used, skipping {client.account.auth_token}",
                    send=False,
                )
                return "skip"
            debugger.log(
                f"Password change error: {str(e)} {client.account.auth_token}",
                send=False,
            )
            return False

    async def change_email_security(
        self, client: twitter.Client, account: Dict[str, Any]
    ) -> Union[bool, str]:
        try:
            email_result = await asyncio.wait_for(client.change_email(), timeout=500.0)
            if email_result is True:
                account["email"] = client.account.email
                account["mailpwd"] = client.account.email_pass
                account["auth_token"] = client.account.auth_token
                if self.db_manager:
                    try:
                        await self.db_manager.update_email(
                            table=self.account_type,
                            username=client.account.username,
                            new_email=client.account.email,
                            new_mailpwd=client.account.email_pass,
                            auth_token=client.account.auth_token,
                        )
                        debugger.log(
                            f"Email updated in database {client.account.auth_token}",
                            send=False,
                        )
                    except Exception as db_err:
                        debugger.log(
                            f"Failed to update email in database immediately: {db_err}",
                            client.account.auth_token,
                            send=False,
                        )
                return True
            if isinstance(email_result, str):
                if "locked" in email_result:
                    debugger.log(
                        f"Account locked {client.account.auth_token}", send=False
                    )
                    return "locked"
                if "suspended" in email_result:
                    debugger.log(
                        f"Account suspended {client.account.auth_token}", send=False
                    )
                    return "suspended"
                if "unauthorized" in email_result:
                    debugger.log(
                        f"Invalid auth token {client.account.auth_token}", send=False
                    )
                    return "unauthorized"
                if "skip" in email_result:
                    debugger.log(
                        f"Email change skipped {client.account.auth_token}", send=False
                    )
                    return "skip"
                if email_result == "verification_required":
                    debugger.log(
                        f"Email change requires verification, skipping {client.account.auth_token}",
                        send=False,
                    )
                    return "skip"
                if (
                    "verify" in email_result.lower()
                    or "verification" in email_result.lower()
                ):
                    debugger.log(
                        f"Email change requires verification {client.account.auth_token}",
                        send=False,
                    )
                    return "skip"
                debugger.log(
                    f"Email change issue: {email_result} {client.account.auth_token}",
                    send=False,
                )
                return False
            if email_result is None:
                debugger.log(
                    f"No email generated by email service {client.account.auth_token}",
                    send=False,
                )
                return "skip"
            debugger.log(
                f"Email change unknown error {client.account.auth_token} | {email_result}",
                send=False,
            )
            return False
        except asyncio.TimeoutError:
            debugger.log(
                f"Email change timed out {client.account.auth_token}", send=False
            )
            return False
        except Exception as e:
            if "NoneType" in str(e) and "response" in str(e):
                debugger.log(
                    f"Invalid auth token for email change {client.account.auth_token}",
                    send=False,
                )
                return "unauthorized"
            if "already used this email" in str(e).lower():
                debugger.log(
                    f"Email already used, skipping {client.account.auth_token}",
                    send=False,
                )
                return True
            if (
                "verify it's you" in str(e).lower()
                or "verification code" in str(e).lower()
                or "verify your identity" in str(e).lower()
            ):
                debugger.log(
                    f"Twitter requires verification for email change, skipping {client.account.auth_token}",
                    send=False,
                )
                return "skip"
            debugger.log(
                f"Email change error: {str(e)} {client.account.auth_token}", send=False
            )
            return False

    async def enable_2fa_security(
        self, client: twitter.Client, account: Dict[str, Any]
    ) -> Union[bool, str]:
        try:
            if client.account.totp_secret:
                debugger.log(
                    f"2FA already enabled (client data), skipping {client.account.auth_token}",
                    send=False,
                )
                return True

            if account.get("backup_code"):
                backup_code = account.get("backup_code")
                if (
                    isinstance(backup_code, str)
                    and len(backup_code) >= 16
                    and len(backup_code) <= 32
                    and backup_code.upper() == backup_code
                    and backup_code.isalnum()
                ):
                    debugger.log(
                        f"Account already has 2FA {client.account.auth_token}",
                        send=False,
                    )
                    return True

            if not account.get("email") and not client.account.email:
                debugger.log(
                    f"Account has no email, needs email to be added {client.account.auth_token}",
                    send=False,
                )
                return "needs_email"

            enable_2fa = await asyncio.wait_for(client.enable_totp(), timeout=360.0)
            if isinstance(enable_2fa, bool) and enable_2fa or enable_2fa is None:
                backup_code = client.account.backup_code
                debugger.log(
                    f"2FA Enabled with backup code: {backup_code}... {client.account.username} - {client.account.auth_token}",
                    send=False,
                )

                account["backup_code"] = backup_code
                account["ct0"] = client.account.ct0

                if self.db_manager:
                    try:
                        await self.db_manager.update_2fa(
                            table=self.account_type,
                            username=client.account.username,
                            backup_code=backup_code,
                            ct0=client.account.ct0,
                        )
                        debugger.log(
                            f"2FA updated in database {client.account.auth_token}",
                            send=False,
                        )
                    except Exception as db_err:
                        debugger.log(
                            f"Failed to update 2FA in database immediately: {db_err}",
                            client.account.auth_token,
                            send=False,
                        )

                return True
            else:
                debugger.log(
                    f"Failed to enable 2FA {client.account.username} - {client.account.auth_token}",
                    send=False,
                )
                return False
        except asyncio.TimeoutError:
            debugger.log(
                f"2FA enablement timed out {client.account.auth_token}", send=False
            )
            return False
        except (
            twitter.errors.AccountSuspended,
            twitter.errors.AccountLocked,
            twitter.errors.AccountConsentLocked,
        ) as e:
            debugger.log(
                f"Account locked/suspended during 2FA enablement: {type(e).__name__} {client.account.auth_token}",
                send=False,
            )
            return "locked"
        except twitter.errors.BadAccountToken as e:
            debugger.log(
                f"Invalid account token during 2FA enablement {client.account.auth_token}",
                send=False,
            )
            return "unauthorized"
        except ValueError as e:
            if "Email verification required" in str(e):
                debugger.log(
                    f"Twitter requires email verification for 2FA setup, skipping account {client.account.auth_token}",
                    send=False,
                )
                return "skip"
            debugger.log(
                f"ValueError during 2FA enablement: {str(e)} {client.account.auth_token}",
                send=False,
            )
            return False
        except Exception as e:
            if "2fa is already enabled" in str(e).lower():
                debugger.log(
                    f"2FA already enabled, skipping {client.account.auth_token}",
                    send=False,
                )
                return True
            if "email" in str(e).lower() and "required" in str(e).lower():
                debugger.log(
                    f"Account has no email, needs email to be added {client.account.auth_token}",
                    send=False,
                )
                return "needs_email"
            if (
                "verify it's you" in str(e).lower()
                or "verification code" in str(e).lower()
                or "verify your identity" in str(e).lower()
                or "TwoFactorEnrollmentVerifyConfirmedEmailBeginSubtask" in str(e)
            ):
                debugger.log(
                    f"Twitter requires email verification for 2FA: {str(e)} - skipping {client.account.auth_token}",
                    send=False,
                )
                return "skip"
            if "wrong password" in str(e).lower():
                async with self.results_lock:
                    self.wrong_password_count += 1
                debugger.log(
                    f"Wrong password during 2FA enablement for {client.account.auth_token}",
                    send=False,
                )
                return "wrong_password"
            subtask_match = re.search(r"(TwoFactor\w+Subtask)", str(e))
            if subtask_match:
                debugger.log(
                    f"2FA subtask issue: {subtask_match.group(1)} - skipping {client.account.auth_token}",
                    send=False,
                )
                return False
            debugger.log(
                f"2FA enablement error {client.account.auth_token}: {str(e)}",
                send=False,
            )
            return False

    async def parse_account_token(self, token_data) -> Dict[str, Any]:
        """Parse token data into a standardized account dictionary format"""
        if isinstance(token_data, dict):
            return {
                "username": token_data.get("username", ""),
                "password": token_data.get("password", ""),
                "email": token_data.get("email", ""),
                "mailpwd": token_data.get("mailpwd", ""),
                "ct0": token_data.get("ct0", ""),
                "auth_token": token_data.get("auth", token_data.get("auth_token", "")),
                "followers": token_data.get("followers", ""),
                "following": token_data.get("following", ""),
                "year": token_data.get("year", ""),
                "backup_code": token_data.get(
                    "backup_code", token_data.get("totp_secret", "")
                ),
                "verified": token_data.get("verified", ""),
            }

        parts = str(token_data).strip().split(":")
        if len(parts) < 2:
            return None

        default = (None,) * 10
        (
            username,
            password,
            email,
            email_pass,
            ct0,
            auth_token,
            followers,
            following,
            year,
            backup_code,
        ) = default
        verified = None

        is_verification = lambda x: x in ("fv", "ev", "pv", "uv")
        safe_convert = lambda x: (
            int(x) if x is not None and str(x).strip().isdigit() else None
        )

        def extract_year_from_backup(value):
            if isinstance(value, str) and value.isdigit() and len(value) >= 4:
                potential_year = int(value[:4])
                if 1900 <= potential_year <= 2100:
                    return potential_year, value[4:] if len(value) > 4 else None
            return None, value

        def is_valid_backup_code(value):
            """Check if a value looks like a valid backup code"""
            if not value or not isinstance(value, str):
                return False
            if 16 <= len(value) <= 32 and value.upper() == value and value.isalnum():
                return True
            return False

        match len(parts):
            case 1:
                auth_token = parts[0]
                return None
            case 2:
                auth_token, password = parts
                ct0 = await self.get_ct0(auth_token)
            case 4:
                username, password, ct0, auth_token = parts
            case 5:
                username, password, email, ct0, auth_token = parts
            case 6:
                username, password, email, email_pass, ct0, auth_token = parts
            case 7:
                username, password, email, ct0, auth_token, followers, year = parts
                if is_valid_backup_code(year):
                    backup_code = year
                    year = None
                else:
                    extracted_year, extracted_backup = extract_year_from_backup(
                        str(year)
                    )
                    if extracted_year:
                        year = extracted_year
                        backup_code = extracted_backup
                    else:
                        backup_code = year
                        year = None
            case 8:
                (
                    username,
                    password,
                    email,
                    ct0,
                    auth_token,
                    followers,
                    following,
                    year,
                ) = parts
                if is_valid_backup_code(year):
                    backup_code = year
                    year = None
                else:
                    extracted_year, extracted_backup = extract_year_from_backup(
                        str(year)
                    )
                    if extracted_year:
                        year = extracted_year
                        backup_code = extracted_backup
                    else:
                        backup_code = year
                        year = None
            case 9:
                if len(parts[3]) > 25:
                    (
                        username,
                        password,
                        email,
                        ct0,
                        auth_token,
                        followers,
                        following,
                        year,
                        verification_level,
                    ) = parts
                    potential_backup = next(
                        (
                            p
                            for p in [verification_level, year]
                            if is_valid_backup_code(p)
                        ),
                        None,
                    )
                    if potential_backup:
                        backup_code = potential_backup
                        if potential_backup == verification_level:
                            verification_level = None
                        else:
                            year = None
                    else:
                        extracted_year, extracted_backup = extract_year_from_backup(
                            str(year)
                        )
                        if extracted_year:
                            year = extracted_year
                            backup_code = extracted_backup
                        elif not is_verification(verification_level):
                            backup_code = verification_level
                            verification_level = None
                else:
                    (
                        username,
                        password,
                        email,
                        email_pass,
                        ct0,
                        auth_token,
                        followers,
                        following,
                        year,
                    ) = parts
                    if is_valid_backup_code(year):
                        backup_code = year
                        year = None
            case 10:
                (
                    username,
                    password,
                    email,
                    email_pass,
                    ct0,
                    auth_token,
                    followers,
                    following,
                    year,
                    backup_code,
                ) = parts
            case 11:
                (
                    username,
                    password,
                    email,
                    email_pass,
                    ct0,
                    auth_token,
                    followers,
                    following,
                    year,
                    backup_code,
                    verified,
                ) = parts
            case _:
                if len(parts) > 9:
                    username = parts[0] if parts[0] else None
                    password = parts[1] if parts[1] else None
                    email = parts[2] if parts[2] else None

                    for i, part in enumerate(parts[3:], 3):
                        if part and len(part) > 25:
                            if not auth_token:
                                auth_token = part
                            elif not ct0 and len(part) < 50:
                                ct0 = part

                    for part in parts[6:]:
                        if is_valid_backup_code(part):
                            backup_code = part
                            break

        return {
            "username": username,
            "password": password,
            "email": email,
            "mailpwd": email_pass,
            "ct0": ct0,
            "auth_token": auth_token,
            "followers": followers,
            "following": following,
            "year": year,
            "backup_code": backup_code,
            "verified": verified,
        }

    async def process_accounts(self, threads: int = 1) -> Tuple[int, int, int, int]:
        self.attempted_count = 0
        self.finished_count = 0
        self.success_count = 0
        self.failed_count = 0
        self.skipped_count = 0
        self.total_accounts = len(self.tokens)
        debugger.log(
            f"enhancing security for {self.total_accounts} accounts with {threads} concurrent workers"
        )
        tasks = [asyncio.create_task(self.worker_task()) for _ in range(threads)]
        if tasks:
            await asyncio.gather(*tasks)
        debugger.log(
            f"operation completed: {self.success_count} accounts secured, {self.failed_count} failed, {self.skipped_count} skipped"
        )
        return (
            self.success_count,
            self.failed_count,
            self.skipped_count,
            getattr(self, "filtered_count", 0),
        )

    async def worker_task_single(self) -> None:
        """Process a single account from the token pool"""
        try:
            account = None

            async with self.token_lock:
                if not self.tokens:
                    debugger.log("No accounts to process", send=True)
                    return
                token_data = self.tokens.pop()
                debugger.log(
                    f"Processing account {token_data} ({self.attempted_count}/{self.total_accounts})",
                    send=False,
                )
                self.attempted_count += 1

            account = await self.parse_account_token(token_data)

            if account is None:
                async with self.results_lock:
                    debugger.log(
                        f"Account data is None {token_data} ({self.finished_count}/{self.total_accounts})",
                        send=False,
                    )
                    self.finished_count += 1
                return

            if not all(account.get(key) for key in ["auth_token", "ct0"]):
                debugger.log(
                    f"Invalid Account Auth Token {account.get('auth_token', 'unknown')}",
                    send=False,
                )
                await self.save_failed(account, "validation", "missing_tokens")
                return

            if not account.get("password"):
                debugger.log(f"Missing password {account.get('auth_token', 'unknown')}")
                await self.save_failed(account, "validation", "missing_password")
                return

            backup_code = account.get("backup_code")
            has_valid_backup_code = False

            if backup_code:
                has_valid_backup_code = True

            acc = twitter.Account(
                auth_token=account["auth_token"],
                ct0=account["ct0"],
                password=account["password"],
                totp_secret=backup_code,
                backup_code=backup_code,
                email_pass=account.get("mailpwd"),
            )
            client = twitter.Client(
                account=acc,
                wait_on_rate_limit=True,
                update_account_info_on_startup=False,
            )

            if client.account.backup_code and not backup_code:
                account["backup_code"] = client.account.backup_code
                has_valid_backup_code = True
                debugger.log(
                    f"Retrieved existing backup code from API: {client.account.backup_code[:5]}... {client.account.auth_token}",
                    send=False,
                )

            new_password = self.generate_password(self.password_length)
            modified = False
            skipped = False
            skip_reason = ""

            should_change_email = False
            if self.enable_email_change:
                mailpwd = account.get("mailpwd", "")
                if (
                    mailpwd
                    and mailpwd != "NO_MAIL_PASS"
                    and mailpwd != "None"
                    and mailpwd != ""
                ):
                    async with self.results_lock:
                        self.email_skips_count += 1
                    debugger.log(
                        f"Skipping email change for {account.get('username', 'unknown')} - already has mail access (mailpwd present)",
                        send=False,
                    )
                    should_change_email = False
                else:
                    should_change_email = True
                    debugger.log(
                        f"Email change needed for {account.get('username', 'unknown')} - no valid mailpwd found",
                        send=False,
                    )

            email_success = False
            if should_change_email:
                email_result = await self.change_email_security(client, account)
                if email_result in ("locked", "suspended", "unauthorized"):
                    await self.save_failed(account, "email", email_result)
                    return
                elif email_result == "skip":
                    skipped = True
                    skip_reason = "email_change_skipped"
                elif email_result is True:
                    email_success = True
                    modified = True

            should_enable_2fa = False
            if self.enable_2fa and not has_valid_backup_code:
                should_enable_2fa = True

            fa_success = False
            if should_enable_2fa:
                fa_result = await self.enable_2fa_security(client, account)
                if fa_result is True:
                    fa_success = True
                    modified = True
                    account["backup_code"] = client.account.backup_code
                    has_valid_backup_code = True
                elif fa_result == "wrong_password":
                    await self.save_failed(account, "2fa", "wrong_password")
                    return
                elif fa_result in ("locked", "unauthorized"):
                    await self.save_failed(account, "2fa", fa_result)
                    return
                elif fa_result == "needs_email":
                    debugger.log(
                        f"Account {account.get('username')} needs email to enable 2FA {client.account.auth_token}",
                        send=False,
                    )
                    skipped = True
                    skip_reason = (
                        "needs_email_for_2fa"
                        if not skip_reason
                        else skip_reason + ",needs_email_for_2fa"
                    )
                elif fa_result == "skip":
                    skipped = True
                    skip_reason = (
                        "2fa_skipped"
                        if not skip_reason
                        else skip_reason + ",2fa_skipped"
                    )
                else:
                    await self.save_failed(account, "2fa", "unknown_error")
                    return
            elif self.enable_2fa and has_valid_backup_code:
                debugger.log(
                    f"2FA already configured (valid backup code present) {client.account.auth_token}",
                    send=False,
                )
                fa_success = True
                modified = True

            pass_success = False
            if (
                self.enable_password_change
                and (email_success or fa_success)
                and account["password"] != new_password
            ):
                pass_result = await self.change_password_security(
                    client, account, new_password
                )
                if pass_result in ("locked", "unauthorized"):
                    await self.save_failed(account, "password", pass_result)
                    return
                elif pass_result == "skip":
                    skipped = True
                    skip_reason = (
                        "password_change_skipped"
                        if not skip_reason
                        else skip_reason + ",password_change_skipped"
                    )
                elif pass_result is True:
                    pass_success = True
                    modified = True

            protection_success = False
            if pass_success:
                try:
                    protection_result = await asyncio.wait_for(
                        client.enable_protection(), timeout=60.0
                    )
                    if protection_result:
                        debugger.log(
                            f"Password reset protection enabled {client.account.auth_token}",
                            send=False,
                        )
                        protection_success = True
                    else:
                        debugger.log(
                            f"Failed to enable password reset protection {client.account.auth_token}",
                            send=False,
                        )
                except asyncio.TimeoutError:
                    debugger.log(
                        f"Password reset protection enable timed out {client.account.auth_token}",
                        send=False,
                    )
                except Exception as e:
                    if (
                        hasattr(e, "response")
                        and hasattr(e.response, "status")
                        and e.response.status == 403
                    ):
                        if (
                            hasattr(e.response, "text")
                            and "suspended" in e.response.text
                        ):
                            await self.save_skipped(account, "suspended")
                            return
                    debugger.log(
                        f"Error enabling password reset protection: {str(e)} {client.account.auth_token}",
                        send=False,
                    )

            if client.account.backup_code:
                account["backup_code"] = client.account.backup_code
                debugger.log(
                    f"Backup code saved for account {account.get('username', 'unknown')}",
                    send=False,
                )

            if protection_success:
                debugger.log(
                    f"Account {account.get('username', 'unknown')} saved with protection enabled",
                    send=False,
                )
                await self.save(account)
            elif modified:
                debugger.log(
                    f"Account {account.get('username', 'unknown')} saved with modifications",
                    send=False,
                )
                await self.save(account)
            elif skipped:
                debugger.log(
                    f"Account {account.get('username', 'unknown')} skipped for reason: {skip_reason}",
                    send=False,
                )
                await self.save_skipped(account, skip_reason)
            elif not any(
                [self.enable_email_change, self.enable_password_change, self.enable_2fa]
            ):
                debugger.log(
                    f"Account {account.get('username', 'unknown')} saved without security changes (none enabled)",
                    send=False,
                )
                await self.save(account)
            else:
                debugger.log(
                    f"Account {account.get('username', 'unknown')} failed security enhancement",
                    send=False,
                )
                await self.save_failed(account, "security", skip_reason)

            debugger.log(
                f"Processed account {account.get('username', 'unknown')} - {self.attempted_count}/{self.total_accounts}",
                send=False,
            )
        except Exception as exc:
            if (
                hasattr(exc, "response")
                and hasattr(exc.response, "status")
                and exc.response.status == 403
            ):
                if hasattr(exc.response, "text") and "suspended" in exc.response.text:
                    await self.save_skipped(account, "suspended")
                    return
            debugger.log(
                f"Unexpected error {getattr(account, 'auth_token', 'unknown') if account else 'unknown'} - {str(exc)}",
                send=False,
            )
            if account:
                await self.save_failed(account, "security", str(exc))
            else:
                async with self.results_lock:
                    self.finished_count += 1

    async def worker_task(self) -> None:
        while self.tokens:
            await self.worker_task_single()

    async def save_skipped(self, account: Dict[str, Any], reason: str = "") -> None:
        self.skipped_count += 1
        self.finished_count += 1
        debugger.log(
            f"Account skipped: {account.get('username', 'unknown')} - Reason: {reason}",
            send=False,
        )

    async def save_failed(
        self, account: Dict[str, Any], stage: str = None, reason: str = None
    ) -> None:
        self.failed_count += 1
        self.finished_count += 1
        if stage == "2fa" and reason == "wrong_password":
            self.failed_2fa_wrong_pass_count += 1
        elif stage == "2fa":
            self.failed_2fa_count += 1
        debugger.log(
            f"Account failed security enhancement: {account.get('username', 'unknown')}{f' during {stage}' if stage else ''}{f' ({reason})' if reason else ''}",
            send=False,
        )
