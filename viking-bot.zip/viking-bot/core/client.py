import asyncio
from datetime import datetime
import os
import re
import secrets
import random
from flask import request
import httpx
import aiofiles
from typing import List, Dict, Tuple, Optional
import hashlib
import config
from os import path
from src.debugger import Debugger
from src.db import DatabaseManager
from core.errors import AccountError

G = "\u001b[38;5;84m"
W = "\u001b[0m"
Y = "\u001b[38;5;220m"
P = "\u001b[38;5;206m"
R = "\u001b[38;5;197m"
GG = "\u001b[38;5;245m"
WW = "\u001b[38;5;255m"
C = "\u001b[36;1m"
G1 = "\u001b[38;5;119m"
G2 = "\u001b[38;5;155m"
G3 = "\u001b[38;5;157m"
G4 = "\u001b[38;5;192m"
C1 = "\u001b[38;5;195m"

debug = Debugger()
database = DatabaseManager()

GLOBAL_SEMAPHORE = asyncio.Semaphore(150)


PFP_IMAGES = []
BANNER_IMAGES = []


def initialize_image_cache():
    global PFP_IMAGES, BANNER_IMAGES

    if os.path.exists(config.BANNERS):
        BANNER_IMAGES = [
            f
            for f in os.listdir(config.BANNERS)
            if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif"))
        ]


initialize_image_cache()


class TwitterAccount:
    def __init__(
        self,
        auth_token: str,
        ct0: str = None,
        password: str = None,
        account_info: dict = None,
    ) -> None:
        self.auth_token = auth_token
        self.ct0 = ct0
        self.password = password
        self.account_info = account_info
        self.ct0_retries = 0
        self._client = None
        self._last_error = None

    @property
    def client(self):
        if not self._client:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(10, read=30),
                http2=False,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
                    "Authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
                },
                cookies={"auth_token": self.auth_token, "ct0": self.ct0},
            )
        return self._client

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._client:
            await self._client.aclose()

    def _headers(self, referer: str = None) -> Dict[str, str]:
        return {
            "host": "upload.x.com",
            "connection": "keep-alive",
            "sec-ch-ua-platform": '"Windows"',
            "authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
            "x-twitter-auth-type": "OAuth2Session",
            "x-csrf-token": self.ct0,
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
            "sec-ch-ua": '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
            "sec-ch-ua-mobile": "?0",
            "accept": "*/*",
            "origin": "https://x.com",
            "sec-fetch-site": "same-site",
            "sec-fetch-mode": "cors",
            "sec-fetch-dest": "empty",
            "referer": referer or "https://x.com/",
            "accept-language": "en-US,en;q=0.9",
        }

    async def get_ct0(self) -> Optional[str]:
        if self.ct0_retries >= 3:
            debug.log(f"⚠️ Max ct0 retries > {self.auth_token}")
            return None
        self.ct0_retries += 1
        try:
            url = "https://x.com/i/api/fleets/v1/avatar_content"
            r = await self.client.get(
                url,
                cookies={"auth_token": self.auth_token},
                headers={
                    "Accept": "*/*",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
                    "Authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
                },
            )
            ct0 = r.cookies.get("ct0")
            if ct0:
                self.client.cookies.set("ct0", ct0)
                self.ct0 = ct0
                return ct0
            debug.log(f"❌ ct0 not found > {self.auth_token}")
        except Exception as e:
            debug.log(f"❌ ct0 error: {str(e)[:50]} > {self.auth_token}")
        return None

    async def _handle_api_response(
        self, response, operation: str, retries: int = 1
    ) -> bool:
        if response.is_success:
            return False
        error_text = response.text.lower() or str(response.status_code)
        self._last_error = error_text
        error_handlers = {
            "your account is suspended": lambda: self._raise_account_error(
                "Suspended", should_remove=True
            ),
            "account is locked": lambda: self._raise_account_error(
                "Locked", is_locked=True, should_remove=True
            ),
            "csrf": lambda: self._retry_ct0(operation, retries),
            "rate limit": lambda: debug.log(f"⏳ Rate limited > {self.auth_token}"),
            "could not authenticate": lambda: self._raise_account_error(
                "Auth failed", should_remove=True
            ),
        }
        for error_key, handler in error_handlers.items():
            if error_key in error_text:
                handler()
                return error_key == "csrf"
        debug.log(
            f"❌ {operation} failed > {self.auth_token}: {error_text[:50]}", send=False
        )
        raise AccountError(f"Operation {operation} failed")

    def _raise_account_error(
        self, message: str, is_locked: bool = False, should_remove: bool = False
    ):
        debug.log(f"⛔️ {message} > {self.auth_token}", send=False)
        raise AccountError(message, is_locked=is_locked, should_remove=should_remove)

    async def _retry_ct0(self, operation: str, retries: int):
        debug.log(f"🔄 Invalid ct0, retrying > {self.auth_token}")
        self.ct0 = await self.get_ct0()
        if not self.ct0:
            raise AccountError("Failed to refresh ct0")
        if retries <= 0:
            raise AccountError(f"Max retries reached for {operation} after ct0 refresh")

    async def change_password(self, new_password: str) -> Tuple[bool, str]:
        if not self.ct0:
            debug.log(f"ct0 token not found, fetching... > {self.auth_token}")
            self.ct0 = await self.get_ct0()
            if not self.ct0:
                debug.log(f"Failed to retrieve ct0 token > {self.auth_token}")
                return False, self.auth_token

        url = "https://x.com/i/api/i/account/change_password.json"
        headers = {
            "connection": "keep-alive",
            "sec-ch-ua-platform": '"macOS"',
            "authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
            "x-csrf-token": self.ct0,
            "sec-ch-ua": '"Brave";v="135", "Not-A.Brand";v="8", "Chromium";v="135"',
            "x-twitter-client-language": "en",
            "sec-ch-ua-mobile": "?0",
            "x-twitter-active-user": "yes",
            "x-client-transaction-id": "PcQWXhDoMXXpLkIJvhwW7Jugy1SpKWm7duRfJ9/hiRYX+Vf2CXxmUNkKo0FeTm4ZiyN4hz7vuEPTxDOL5VghJvaYynC4Pg",
            "x-twitter-auth-type": "OAuth2Session",
            "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
            "accept": "*/*",
            "content-type": "application/x-www-form-urlencoded",
            "sec-gpc": "1",
            "accept-language": "en-US,en;q=0.6",
            "sec-fetch-site": "same-origin",
            "sec-fetch-mode": "cors",
            "sec-fetch-dest": "empty",
        }
        body = {
            "current_password": self.password,
            "password": new_password,
            "password_confirmation": new_password,
        }

        try:
            response = await self.client.post(url, headers=headers, data=body)
            if response.status_code == 410:
                debug.log(f"410 Error detected, moving to trash > {self.auth_token}")
                account_data_for_trash = self.account_info if self.account_info else {}
                if not self.account_info:
                    account_data_for_trash["auth"] = self.auth_token
                    account_data_for_trash["password"] = self.password
                    account_data_for_trash["ct0"] = self.ct0
                await database.move_account_to_trash(account_data_for_trash, "410")
                return False, self.auth_token
            if response.status_code == 200:
                response_json = response.json()
                if response_json.get("status") != "ok":
                    debug.log(
                        f"Password change failed (status not ok) > {self.auth_token}"
                    )
                    return False, self.auth_token
                cookies_header = response.headers.get("set-cookie", "")
                auth_token_match = re.search(r"auth_token=([^;]+)", cookies_header)
                if auth_token_match:
                    self.auth_token = auth_token_match.group(1)

                self.ct0 = await self.get_ct0()

                return True, self.auth_token
            elif (
                "This request requires a matching csrf cookie and header."
                in response.text
            ):
                self.ct0 = await self.get_ct0()
                if not self.ct0:
                    debug.log(f"Failed to retrieve ct0 token > {self.auth_token}")
                    return False, self.auth_token
                return await self.change_password(new_password)
            elif "incorrect current password." in response.text:
                debug.log(
                    f"Incorrect current password for {self.auth_token}, moving to trash."
                )
                account_data_for_trash = self.account_info if self.account_info else {}
                if not self.account_info:
                    account_data_for_trash["auth"] = self.auth_token
                    account_data_for_trash["password"] = self.password
                    account_data_for_trash["ct0"] = self.ct0
                await database.move_account_to_trash(
                    account_data_for_trash, "incorrect_password"
                )
                return False, self.auth_token
            else:
                debug.log(
                    f"Password change failed, status: {response.status_code} | {response.text} > {self.auth_token}"
                )
                return False, self.auth_token
        except Exception as e:
            debug.log(f"HTTP request failed: {e} > {self.auth_token}")
            return False, self.auth_token

    async def check_if_email_available(self, email: str) -> bool:
        if not self.ct0:
            self.ct0 = await self.get_ct0()
            if not self.ct0:
                return False
        url = "https://x.com/i/api/i/users/email_available.json"
        querystring = {"email": email}
        headers = self._headers("https://x.com/")
        max_csrf_retries = 3
        for attempt in range(max_csrf_retries):
            try:
                response = await self.client.get(
                    url, headers=headers, params=querystring
                )
                if await self._handle_api_response(
                    response, "Email availability check", max_csrf_retries - attempt
                ):
                    headers["X-Csrf-Token"] = self.ct0
                    continue
                return response.json().get("msg") == "Available!"
            except AccountError as e:
                return False
            except Exception as e:
                debug.log(f"❌ Error checking email: {str(e)[:50]} > {self.auth_token}")
                return False

    async def remove_phone(self, phone: str) -> bool | str:
        if not self.ct0:
            self.ct0 = await self.get_ct0()
            if not self.ct0:
                return False
        url = "https://x.com/i/api/1.1/device/unregister.json"
        payload = {"phone_number": phone}
        headers = self._headers("https://x.com/settings/phone")
        max_csrf_retries = 3
        for attempt in range(max_csrf_retries):
            try:
                response = await self.client.post(url, headers=headers, data=payload)
                if await self._handle_api_response(
                    response, "Phone removal", max_csrf_retries - attempt
                ):
                    headers["X-Csrf-Token"] = self.ct0
                    continue
                return True
            except AccountError as e:
                return (
                    False
                    if e.is_locked
                    else (
                        "unauthorized"
                        if "auth" in e.message.lower()
                        else "suspended" if "suspended" in e.message.lower() else False
                    )
                )
            except Exception as e:
                debug.log(f"❌ Error removing phone: {str(e)[:50]} > {self.auth_token}")
                return False

    @staticmethod
    def calculate_md5(file_path: str):
        md5_hash = hashlib.md5()
        with open(file_path, "rb") as file:
            for byte_block in iter(lambda: file.read(4096), b""):
                md5_hash.update(byte_block)
        return md5_hash.hexdigest()

    @staticmethod
    def get_file_size(file: str) -> Optional[str]:
        try:
            return str(path.getsize(file))
        except FileNotFoundError:
            debug.log(f"❌ File not found: {file}")
            return None

    async def _init_upload(self, size: str) -> str:
        params = {"command": "INIT", "total_bytes": size, "media_type": "image/jpeg"}
        headers = self._headers("https://x.com/")
        max_csrf_retries = 3
        for attempt in range(max_csrf_retries):
            try:
                response = await self.client.post(
                    "https://upload.x.com/i/media/upload.json",
                    params=params,
                    headers=headers,
                )
                if await self._handle_api_response(
                    response, "Upload init", max_csrf_retries - attempt
                ):
                    headers["X-Csrf-Token"] = self.ct0
                    continue
                return response.json().get("media_id_string", "")
            except AccountError as e:
                return ""
            except Exception as e:
                debug.log(
                    f"❌ Upload init error: {str(e)[:50]} > {self.auth_token}",
                    send=False,
                )
                return ""

    async def _first_append(self, media_id: str) -> bool:
        params = {"command": "APPEND", "media_id": media_id, "segment_index": "0"}
        headers = self._headers("https://x.com/")
        headers.update({"authority": "upload.x.com"})
        try:
            response = await self.client.options(
                "https://upload.x.com/i/media/upload.json",
                params=params,
                headers=headers,
                follow_redirects=True,
            )
            return response.status_code == 200
        except Exception as e:
            debug.log(
                f"❌ First append error: {str(e)[:50]} > {self.auth_token}", send=False
            )
            return False

    async def _upload_content(self, media_id: str, file: str) -> bool:
        params = {"command": "APPEND", "media_id": media_id, "segment_index": "0"}
        headers = self._headers("https://x.com/")
        headers.update({"authority": "upload.x.com"})
        if not file.startswith("http"):
            async with aiofiles.open(file, "rb") as f:
                file_content = await f.read()
        else:
            async with self.client.stream("GET", file) as r:
                file_content = await r.aread()
        try:
            response = await self.client.post(
                "https://upload.x.com/i/media/upload.json",
                params=params,
                files={"media": file_content},
                headers=headers,
                follow_redirects=True,
            )
            return response.status_code == 204
        except Exception as e:
            debug.log(
                f"❌ Upload content error: {str(e)[:50]} > {self.auth_token}",
                send=False,
            )
            return False

    async def _finalize(self, media_id: str, file_hash: Optional[str] = None) -> str:
        params = {"command": "FINALIZE", "media_id": media_id}
        if file_hash:
            params["original_md5"] = file_hash
        headers = self._headers("https://x.com/")
        headers.update({"host": "upload.x.com"})
        max_csrf_retries = 3
        for attempt in range(max_csrf_retries):
            try:
                response = await self.client.post(
                    "https://upload.x.com/i/media/upload.json",
                    params=params,
                    headers=headers,
                    follow_redirects=True,
                )
                if await self._handle_api_response(
                    response, "Upload finalize", max_csrf_retries - attempt
                ):
                    headers["X-Csrf-Token"] = self.ct0
                    continue
                return response.json()["media_id_string"]
            except AccountError as e:
                return ""
            except Exception as e:
                debug.log(
                    f"❌ Finalize error: {str(e)[:50]} > {self.auth_token}", send=False
                )
                return ""

    async def upload(
        self, file: str, confirm_hash: Optional[bool] = None
    ) -> Optional[str]:
        try:
            self.client.cookies.set("auth_token", self.auth_token)
            if not self.ct0:
                self.ct0 = await self.get_ct0()
                if not self.ct0:
                    return None
            file_hash = self.calculate_md5(file) if confirm_hash else None
            size = (
                self.get_file_size(file)
                if not file.startswith("http")
                else len((await self.client.get(file)).content)
            )
            if not size:
                return None
            media_id = await self._init_upload(size)
            if (
                not media_id
                or not await self._first_append(media_id)
                or not await self._upload_content(media_id, file)
            ):
                return None
            return await self._finalize(media_id, file_hash=file_hash)
        except Exception as e:
            debug.log(f"❌ Upload error: {str(e)[:50]} > {self.auth_token}", send=False)
            return None

    async def set_pfp(self, filename: str) -> bool:
        media_id = await self.upload(file=filename, confirm_hash=True)
        if not media_id:
            return False
        data = {
            "include_profile_interstitial_type": "1",
            "include_blocking": "1",
            "include_blocked_by": "1",
            "include_followed_by": "1",
            "include_want_retweets": "1",
            "include_mute_edge": "1",
            "include_can_dm": "1",
            "include_can_media_tag": "1",
            "include_ext_is_blue_verified": "1",
            "include_ext_verified_type": "1",
            "include_ext_profile_image_shape": "1",
            "skip_status": "1",
            "return_user": "true",
            "media_id": media_id,
        }
        headers = self._headers("https://x.com/")
        headers.update({"host": "api.x.com"})
        max_csrf_retries = 3
        for attempt in range(max_csrf_retries):
            try:
                response = await self.client.post(
                    "https://api.x.com/1.1/account/update_profile_image.json",
                    headers=headers,
                    data=data,
                )
                if await self._handle_api_response(
                    response, "Set PFP", max_csrf_retries - attempt
                ):
                    headers["X-Csrf-Token"] = self.ct0
                    continue
                debug.log(f"✅ PFP changed > {self.auth_token}")
                return True
            except AccountError as e:
                return False
            except Exception as e:
                debug.log(
                    f"❌ PFP error: {str(e)[:50]} > {self.auth_token}", send=False
                )
                return False

    async def set_banner(self, filename: str) -> bool:
        media_id = await self.upload(file=filename, confirm_hash=True)
        if not media_id:
            return False
        data = {
            "include_profile_interstitial_type": "1",
            "include_blocking": "1",
            "include_blocked_by": "1",
            "include_followed_by": "1",
            "include_want_retweets": "1",
            "include_mute_edge": "1",
            "include_can_dm": "1",
            "include_can_media_tag": "1",
            "include_ext_is_blue_verified": "1",
            "include_ext_verified_type": "1",
            "include_ext_profile_image_shape": "1",
            "skip_status": "1",
            "return_user": "true",
            "media_id": media_id,
        }
        headers = self._headers("https://x.com/")
        headers.update({"host": "api.x.com"})
        max_csrf_retries = 3
        for attempt in range(max_csrf_retries):
            try:
                response = await self.client.post(
                    "https://api.x.com/1.1/account/update_profile_banner.json",
                    headers=headers,
                    data=data,
                )
                if await self._handle_api_response(
                    response, "Set banner", max_csrf_retries - attempt
                ):
                    headers["X-Csrf-Token"] = self.ct0
                    continue
                debug.log(f"✅ Banner changed > {self.auth_token}")
                return True
            except AccountError as e:
                return False
            except Exception as e:
                debug.log(
                    f"❌ Banner error: {str(e)[:50]} > {self.auth_token}", send=False
                )
                return False


async def updateAccount(
    auth_token: str,
    old_password: str,
    new_password: str,
    change_pfp: bool = False,
    ct0: str = None,
    change_banner: bool = False,
    account_info: dict = None,
) -> Tuple[bool, str, str]:
    async with TwitterAccount(auth_token, ct0, old_password, account_info) as account:
        max_retries = 10
        last_error = None
        for attempt in range(max_retries):
            try:
                status, updated_auth_token = await account.change_password(new_password)
                if not status:
                    return False, auth_token, account.ct0 or ""
                if change_pfp:

                    pfp_dir = config.PFPS_HUMAN
                    images = [
                        f
                        for f in os.listdir(pfp_dir)
                        if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif"))
                    ]
                    if images and await account.set_pfp(
                        os.path.join(pfp_dir, random.choice(images))
                    ):
                        debug.log(f"✅ PFP updated > {updated_auth_token}")
                if change_banner:
                    images = [
                        f
                        for f in os.listdir(config.BANNERS)
                        if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif"))
                    ]
                    if images and await account.set_banner(
                        os.path.join(config.BANNERS, random.choice(images))
                    ):
                        debug.log(f"✅ Banner updated > {updated_auth_token}")
                return True, updated_auth_token, account.ct0 or ""
            except AccountError as e:
                last_error = e
                if attempt < max_retries - 1:
                    await asyncio.sleep(1)
                    continue
            except Exception as e:
                debug.log(f"❌ Update error: {str(e)[:50]} > {auth_token}", send=False)
                return False, auth_token, ""
        debug.log(f"⚠️ Max retries reached > {auth_token}", send=False)
        if last_error:
            raise last_error
        return False, auth_token, ""


async def bulk_change_password(
    account_type: str,
    accounts: List[Dict[str, str]],
    change_pfp: bool = False,
    change_banner: bool = False,
) -> List[Dict[str, str]]:
    processed = set()
    results = []
    failed_count = 0
    successful_changes = 0
    try:
        debug.log(
            f"[START] Initiating bulk password changer for | {account_type}", send=True
        )
        unique_auths = set()
        unique_accounts = [
            account
            for account in accounts
            if account.get("auth")
            and account.get("auth") not in unique_auths
            and not unique_auths.add(account.get("auth"))
        ]

        async def change(account):
            nonlocal failed_count, successful_changes
            try:
                auth = account.get("auth")
                if not auth or auth in processed:
                    debug.log(
                        f"[Password Change] Skipping already processed account: {account.get('username', 'unknown')}",
                        send=False,
                    )
                    return None
                async with GLOBAL_SEMAPHORE:
                    processed.add(auth)
                    new_password = secrets.token_hex(8)
                    try:
                        status, updated_auth, ct0 = await updateAccount(
                            auth,
                            account["password"],
                            new_password,
                            change_pfp,
                            account.get("ct0"),
                            change_banner,
                        )
                    except AccountError as e:
                        debug.log(
                            f"Account error for {account.get('username', 'unknown')}: {str(e)}"
                        )
                        failed_count += 1
                        return None
                    if not status:
                        debug.log(
                            f"Password change failed for: {account.get('username', 'unknown')}",
                            send=False,
                        )
                        failed_count += 1
                        return None
                    account["password"] = (
                        new_password if updated_auth != auth else account["password"]
                    )
                    account["auth"] = updated_auth
                    account["ct0"] = ct0
                    successful_changes += 1
                    try:
                        async with aiofiles.open(
                            f"tmp/unfiltered-{datetime.now().strftime('%Y_%m_%d_%H')}.txt",
                            "a+",
                        ) as f:
                            await f.write(
                                ":".join(str(account[k]) for k in account if account[k])
                                + "\n"
                            )
                    except Exception as e:
                        debug.log(
                            f"Error writing to file: {str(e)[:50]}, but continuing with account processing"
                        )
                    return account
            except Exception as e:
                debug.log(
                    f"Error processing account {account.get('username', 'unknown')}: {str(e)[:100]}"
                )
                failed_count += 1
                return None

        try:
            tasks = [
                asyncio.create_task(change(account)) for account in unique_accounts
            ]
            all_results = await asyncio.gather(*tasks, return_exceptions=True)
            valid_results = [
                r for r in all_results if r is not None and not isinstance(r, Exception)
            ]
            [
                debug.log(f"Exception in processing: {str(r)[:100]}")
                for r in all_results
                if isinstance(r, Exception)
            ]
            results.extend(valid_results)
            debug.log(
                f"[END] Password Change: {successful_changes} successful, {failed_count} failed"
            )
        except Exception as e:
            debug.log(f"Error processing accounts: {str(e)[:100]}")
    except Exception as e:
        debug.log(f"Critical error in bulk_change_password: {str(e)}")
    return results


async def change_bulk_pfp(
    accounts: List[Dict[str, str]], avatar_path: str = None
) -> List[Dict[str, str]]:
    results = []
    successful_changes = 0
    failed_count = 0

    if not avatar_path and not PFP_IMAGES:
        debug.log("❌ No images found")
        return []

    async def change_pfp(account):
        nonlocal successful_changes, failed_count
        async with GLOBAL_SEMAPHORE, TwitterAccount(
            account["auth"], account.get("ct0"), account.get("password")
        ) as twitter:
            twitter.ct0 = account.get("ct0")

            if not twitter.ct0 and not await twitter.get_ct0():
                failed_count += 1
                debug.log(
                    f"❌ CT0 retrieval failed for {account.get('username', 'unknown')}",
                    send=False,
                )
                return None

            if avatar_path:
                image_path = avatar_path
            else:
                if not PFP_IMAGES:
                    failed_count += 1
                    debug.log("❌ No images found in PFP directory", send=False)
                    return None
                image_path = os.path.join(config.PFPS, random.choice(PFP_IMAGES))

            if await twitter.set_pfp(image_path):
                successful_changes += 1
                return account
            failed_count += 1
            debug.log(
                f"❌ PFP update failed for {account.get('username', 'unknown')}",
                send=False,
            )
            return None

    batch_size = 20
    for i in range(0, len(accounts), batch_size):
        batch = accounts[i : i + batch_size]
        tasks = [asyncio.create_task(change_pfp(account)) for account in batch]
        batch_results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in batch_results:
            if isinstance(result, Exception):
                failed_count += 1
                debug.log(
                    f"❌ Exception during PFP update: {str(result)[:100]}", send=False
                )

        valid_results = [r for r in batch_results if r and not isinstance(r, Exception)]
        results.extend(valid_results)

    debug.log(
        f"PFP update complete: {successful_changes} successful, {failed_count} failed"
    )
    if len(accounts) > 0:
        debug.log(
            f"Success rate: {successful_changes/len(accounts)*100:.2f}% of total accounts"
        )
    return results


async def change_bulk_banner(
    accounts: List[Dict[str, str]], banner_path: str = None
) -> List[Dict[str, str]]:
    results = []
    successful_changes = 0
    failed_count = 0
    banner_images = (
        [
            f
            for f in os.listdir(config.BANNERS)
            if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif"))
        ]
        if os.path.exists(config.BANNERS)
        else []
    )
    if not banner_path and not banner_images:
        return []

    async def change_banner(account):
        nonlocal successful_changes, failed_count
        async with GLOBAL_SEMAPHORE, TwitterAccount(
            account["auth"], account.get("ct0"), account.get("password")
        ) as twitter:
            twitter.ct0 = account.get("ct0")
            if not twitter.ct0 and not await twitter.get_ct0():
                failed_count += 1
                return None
            image_path = (
                banner_path
                if banner_path
                else os.path.join(config.BANNERS, random.choice(banner_images))
            )
            if await twitter.set_banner(image_path):
                successful_changes += 1
                return account
            failed_count += 1

    batch_size = 20
    for i in range(0, len(accounts), batch_size):
        batch = accounts[i : i + batch_size]
        tasks = [asyncio.create_task(change_banner(account)) for account in batch]
        batch_results = await asyncio.gather(*tasks, return_exceptions=True)
        failed_count += sum(
            1 for result in batch_results if isinstance(result, Exception)
        )
        results.extend([r for r in batch_results if r and not isinstance(r, Exception)])
    return results


async def change_bulk_pfp_banner(
    accounts: List[Dict[str, str]],
    change_pfp: bool = False,
    avatar_path: str = None,
    change_banner: bool = False,
    banner_path: str = None,
    pfp_type: str = None,
) -> List[Dict[str, str]]:
    results = []
    successful_changes = 0
    failed_count = 0
    pfp_success_count = 0
    banner_success_count = 0
    if change_pfp and not avatar_path:
        if pfp_type == "human":
            pfp_dir = config.PFPS_HUMAN
        elif pfp_type == "nft":
            pfp_dir = config.PFPS_NFT
        else:
            pfp_dir = config.PFPS_HUMAN
        if not os.path.exists(pfp_dir) or not os.listdir(pfp_dir):
            return []
    banner_images = (
        [
            f
            for f in os.listdir(config.BANNERS)
            if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif"))
        ]
        if os.path.exists(config.BANNERS)
        else []
    )
    if change_banner and not banner_path and not banner_images:
        return []

    async def change_pfp_banner(account):
        nonlocal successful_changes, failed_count, pfp_success_count, banner_success_count
        async with GLOBAL_SEMAPHORE, TwitterAccount(
            account["auth"], account.get("ct0"), account.get("password")
        ) as twitter:
            twitter.ct0 = account.get("ct0")
            if not twitter.ct0 and not await twitter.get_ct0():
                failed_count += 1
                return None
            pfp_success = False
            banner_success = False
            if change_pfp:
                if avatar_path:
                    pfp_path = avatar_path
                    pfp_success = await twitter.set_pfp(pfp_path)
                    if pfp_success:
                        pfp_success_count += 1
                else:
                    pfp_dir = (
                        config.PFPS_HUMAN
                        if pfp_type == "human"
                        else config.PFPS_NFT if pfp_type == "nft" else config.PFPS_HUMAN
                    )
                    pfp_images = [
                        f
                        for f in os.listdir(pfp_dir)
                        if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif"))
                    ]
                    if pfp_images:
                        pfp_path = os.path.join(pfp_dir, random.choice(pfp_images))
                        pfp_success = await twitter.set_pfp(pfp_path)
                        if pfp_success:
                            pfp_success_count += 1
            if change_banner:
                if banner_path:
                    banner_img_path = banner_path
                    banner_success = await twitter.set_banner(banner_img_path)
                    if banner_success:
                        banner_success_count += 1
                elif banner_images:
                    banner_img_path = os.path.join(
                        config.BANNERS, random.choice(banner_images)
                    )
                    banner_success = await twitter.set_banner(banner_img_path)
                    if banner_success:
                        banner_success_count += 1
            operation_success = (change_pfp and pfp_success) or (
                change_banner and banner_success
            )
            if operation_success:
                successful_changes += 1
                return account
            failed_count += 1
            return None

    tasks = [asyncio.create_task(change_pfp_banner(account)) for account in accounts]
    results_with_exceptions = await asyncio.gather(*tasks, return_exceptions=True)
    for result in results_with_exceptions:
        if isinstance(result, Exception):
            failed_count += 1
    results = [r for r in results_with_exceptions if r and not isinstance(r, Exception)]
    return results


async def bulk_remove_phone(
    accounts: List[Dict[str, str]], phone: str
) -> List[Dict[str, str]]:
    results = []
    successful_removals = 0
    failed_count = 0

    async def remove(account):
        nonlocal successful_removals, failed_count
        async with GLOBAL_SEMAPHORE, TwitterAccount(
            account["auth"], account.get("ct0"), account.get("password")
        ) as twitter:
            twitter.ct0 = account.get("ct0")

            result = await twitter.remove_phone(phone)
            if result is True:
                successful_removals += 1
                return account

            failed_count += 1
            debug.log(
                f"❌ Phone removal failed for {account.get('username', 'unknown')}: {result}",
                send=False,
            )
            return None

    tasks = [asyncio.create_task(remove(account)) for account in accounts]
    results_with_exceptions = await asyncio.gather(*tasks, return_exceptions=True)

    for result in results_with_exceptions:
        if isinstance(result, Exception):
            failed_count += 1
            debug.log(
                f"❌ Exception during phone removal: {str(result)[:100]}", send=False
            )

    results = [r for r in results_with_exceptions if r and not isinstance(r, Exception)]

    debug.log(
        f"Phone removal complete: {successful_removals} successful, {failed_count} failed"
    )
    if len(accounts) > 0:
        debug.log(
            f"Success rate: {successful_removals/len(accounts)*100:.2f}% of total accounts"
        )

    return results


async def run_tests():
    auth_token = "2033e1bfb41b7bc9fc56ec127eac699c5ffb1a679bb"
    ct0 = "3510360571cabde09843cc908773710e69471ef2885bcss41d292036d88e98408ee28020573ab6f2ea673b9997515df84d8e51a86d0b9a95410974bae43c681029836e2fb96abfb459cccf70336b8b371b"
    password = "aaaa3tt23"
    accounts = [{"auth": auth_token, "ct0": ct0, "password": password}]
    await change_bulk_banner(accounts)


if __name__ == "__main__":
    asyncio.run(run_tests())
