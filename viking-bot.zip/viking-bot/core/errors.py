"""
Common error classes used across the application
"""


class AccountError(Exception):
    """Custom exception for account-related errors"""

    def __init__(
        self, message: str, is_locked: bool = False, should_remove: bool = False
    ):
        self.message = message
        self.is_locked = is_locked
        self.should_remove = should_remove
        super().__init__(message)
