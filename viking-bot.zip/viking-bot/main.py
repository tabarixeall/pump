import os
import sys
import re
import yaml
import shutil
import sqlite3
import traceback
import asyncio
from datetime import datetime
import uuid
from pathlib import Path

import config
from cogs.utils import *
from cogs.upload import *
from cogs.stocks import *
from cogs.shop import *
from cogs.coupons import *
from cogs.decorators import owner
from core.queue_manager import TaskQueueManager
from src.products import ProductTypes, Types

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.error import BadRequest, TimedOut, NetworkError
from telegram.ext import (
    Application,
    CommandHandler,
    ConversationHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)


WAITING_DB = range(99) #why not
CANCEL = range(1)
COUPON_CODE, COUPON_DISCOUNT, COUPON_MAX_USES, COUPON_EXPIRY = range(4)
GET_EMAIL, CONFIRM_EMAIL = range(2)
ANNOUNCE_MESSAGE = range(1)


WAITING_ZIP_TYPE, WAITING_ZIP_FILE = range(2)
WAITING_BANNER_ZIP_FILE = range(1)

USER_STATE_WAITING_FOR_QUANTITY = "waiting_for_quantity"
USER_STATE_WAITING_FOR_COUPON = "waiting_for_coupon"
USER_STATE_WAITING_FOR_EMAIL = "waiting_for_email"
USER_STATE_WAITING_FOR_GATEWAY = "waiting_for_gateway"


class Bot:
    def __init__(self) -> None:
        self.config = config
        self.BOT_OWNERS = config.OWNERS
        self.TOKEN = config.TOKEN
        self.UPLOAD_DIR = config.UPLOAD_DIR
        self.DEBUG_CHANNEL = config.DEBUG_CHANNEL
        self.debug = debugger.Debugger()
        self.database = db.DatabaseManager()
        self.coupon_manager = CouponManager(self.database)
        self.queue_manager = TaskQueueManager(max_concurrent=5)
        self.cooldown = cooldown.Cooldown(5)
        self.loop = asyncio.get_event_loop()
        self.stocks = stocks(self)
        self.upload = Uploader(self)
        self.shop = ShopModule(self)
        self.email_locks = {}

        if not os.path.exists(self.UPLOAD_DIR):
            os.makedirs(self.UPLOAD_DIR)

        tmp_dir = Path("tmp")
        if not tmp_dir.exists():
            tmp_dir.mkdir(exist_ok=True)

        self.loop.create_task(self.periodic_backup())

    async def init_settings(self):
        """Initialize bot settings"""
        pass

    async def cancel(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Cancel the current operation and clear context data"""
        user_id = update.effective_user.id

        if any(
            key.startswith(("selected_product", "product_", "payment_"))
            for key in context.user_data.keys()
        ):

            payment_keys = [
                k
                for k in context.user_data.keys()
                if k.startswith(
                    ("selected_product", "product_", "payment_", "quantity")
                )
            ]
            for key in payment_keys:
                context.user_data.pop(key, None)

            await update.message.reply_text("🛑 Payment process cancelled.")
        else:

            context.user_data.clear()
            await update.message.reply_text("🛑 Operation cancelled.")

        return ConversationHandler.END

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        keyboard = [
            [InlineKeyboardButton("🛍️ Buy Products", callback_data="buy")],
            [
                InlineKeyboardButton(
                    "🔔 Subscribe to Announcements",
                    callback_data="subscribe_newsletter",
                )
            ],
            [InlineKeyboardButton("📜 Terms of Service", callback_data="show_terms")],
        ]
        await update.message.reply_text(
            f"{user.first_name} 👋 Welcome to Viking Tokens Bot — your automated store for HQ Twitter accounts. Use the buttons below to get started.",
            reply_markup=InlineKeyboardMarkup(keyboard),
        )
        return ConversationHandler.END

    async def help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        is_admin = update.effective_user.id in self.BOT_OWNERS

        admin_commands = [
            "🔑 *Admin Commands*",
            "",
            "🏠 /admin - Admin dashboard (Not Implemented Yet)",
            "⚙️ /settings - Configure bot settings (inline keyboard)",
            "🔄 /pfpzip - Change PFP in db (zip file)",
            "🔄 /bannerzip - Change Banner in db (zip file)",
            "🔄 /upload - Learn how to upload stocks",
            "📦 /getstock <type> - Get stock file for a product type",
            "🗑️ /clear <type> - Clear stock database for a product type",
            "✏️ /edit <user\\_id> <email> - Update customer email",
            "👥 /customers - View all customers",
            "✅ /verify - Verify product settings against SellApp",
            "💾 /backup - Create a database backup",
            "🛠️ /updatedb - Replace current database (Upload .db file)",
            "🔐 /lockeds <help> - Fetch locked accounts (optional help arg)",
            "📊 /stock\\_status - View detailed stock status",
            "🔄 /retrieve <order\\_id> - Retrieve the sold account file",
            "♻️ /resend <order\\_id> - Resend order file to customer",
            "❓ /managefaq <add|edit|delete|list> [args] - Manage FAQ entries",
            "📋 /faqguide - Show FAQ/Terms management guide",
            "🔄 /initfaqterms - Initialize FAQ/Terms with example content",
            "🎫 /coupon - Manage discount coupons (inline keyboard)",
            "🆔 /order <invoice\\_uuid> - Get order details by UUID",
        ]

        user_commands = [
            "🤖 *Bot Commands*",
            "",
            "❓ /help - Show this help menu",
            "🛍️ /buy - Browse available products",
            "📦 /orders - View your order history",
            "📊 /stock <type> - Check stock availability for a type",
            "📜 /terms - Terms of Service",
            "❔ /faq - View the FAQ",
            "🔑 /login - Login as customer",
            "📈 /status <order\\_id> - Check your order status",
        ]

        message_parts = user_commands.copy()
        if is_admin:
            message_parts.extend(["", ""] + admin_commands)

        message = "\n".join(message_parts)

        keyboard_buttons = []
        if not is_admin:
            keyboard_buttons.append(
                [InlineKeyboardButton("🛍️ Buy Products", callback_data="buy")]
            )
        else:
            keyboard_buttons.append(
                [InlineKeyboardButton("⚙️ Settings", callback_data="settings")]
            )
        keyboard_buttons.append(
            [
                InlineKeyboardButton(
                    "🔔 Subscribe to Announcements",
                    callback_data="subscribe_newsletter",
                )
            ]
        )

        reply_markup = InlineKeyboardMarkup(keyboard_buttons)
        await update.message.reply_text(
            message, parse_mode="Markdown", reply_markup=reply_markup
        )

    async def error(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        tb_string = "".join(
            traceback.format_exception(None, context.error, context.error.__traceback__)
        )
        self.debug.log(f"🚨 Bot Error Report 🚨\n{tb_string}")

        try:
            await self.debug.notify_owner(f"🚨 Bot Error Report 🚨\n{tb_string[:4000]}")
        except Exception as e:
            self.debug.log(f"Failed to notify developer: {e}")

        if update and update.effective_message:
            try:

                if isinstance(
                    context.error,
                    (
                        NetworkError,
                        TimedOut,
                        httpx.ConnectTimeout,
                        telegram.error.TimedOut,
                    ),
                ):
                    await update.effective_message.reply_text(
                        "⏱️ Request timed out due to network issues.\n"
                        "Please try again in a few moments."
                    )
                elif isinstance(context.error, BadRequest):
                    await update.effective_message.reply_text(
                        "❌ Invalid request. Please check your input and try again."
                    )
                elif isinstance(
                    context.error, (httpx.ReadError, telegram.error.NetworkError)
                ):
                    await update.effective_message.reply_text(
                        "📶 Network connection error. Please check your internet connection and try again."
                    )
                else:
                    await update.effective_message.reply_text(
                        "Application error occured, try again."
                    )
            except Exception as e:
                self.debug.log(f"Failed to notify user: {e}")

        try:

            if isinstance(
                context.error,
                (NetworkError, TimedOut, httpx.ConnectTimeout, telegram.error.TimedOut),
            ):
                self.debug.log(
                    "Network error or timeout detected - waiting for recovery"
                )
                return ConversationHandler.WAITING

            if isinstance(
                context.error,
                (BadRequest, httpx.ReadError, telegram.error.NetworkError),
            ):
                self.debug.log(
                    "Bad request or read error detected - ending conversation"
                )
                return ConversationHandler.END
        except Exception as e:
            self.debug.log(f"Error while handling specific error types: {e}")

        return ConversationHandler.END

    async def settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        try:
            prices = {
                "Per Follower": f"${float(self.config.PRICE_PER_FOLLOWER):.4f}",
                "Blue": f"${float(self.config.PRICE_BLUE):.2f}",
                "Blue Plus": f"${float(self.config.PRICE_BLUE_PLUS):.2f}",
                "Grey/Gold": f"${float(self.config.PRICE_GREY_GOLD):.2f}",
                "Chars": f"${float(self.config.PRICE_CHARS):.2f}",
                "Mstats": f"${float(getattr(self.config, 'PRICE_MSTATS', 0)):.2f}",
            }
        except (ValueError, TypeError):
            prices = {
                k: "$0.0000"
                for k in [
                    "Per Follower",
                    "Blue",
                    "Blue Plus",
                    "Grey/Gold",
                    "Chars",
                    "Mstats",
                ]
            }
        change_pfp = "✅ ON" if self.config.CHANGE_PFP_ON_CHECK_NORMALS else "❌ OFF"
        debug_webhook = "✅ ON" if self.config.DEBUG_WEBHOOK else "❌ OFF"
        sellapp_api = (
            f"{self.config.SELL_APP_API_KEY[:6]}...{self.config.SELL_APP_API_KEY[-6:]}"
        )
        owners = ", ".join(str(owner) for owner in self.config.OWNERS)
        keyboard = [
            [
                InlineKeyboardButton(
                    "Product Settings", callback_data="product_settings"
                )
            ],
            [
                InlineKeyboardButton(
                    f"Price per Follower: {prices['Per Follower']}",
                    callback_data="edit_price_per_follower",
                )
            ],
            [
                InlineKeyboardButton(
                    f"Blue Price: {prices['Blue']}", callback_data="edit_price_blue"
                )
            ],
            [
                InlineKeyboardButton(
                    f"Blue Plus Price: {prices['Blue Plus']}",
                    callback_data="edit_price_blue_plus",
                )
            ],
            [
                InlineKeyboardButton(
                    f"Grey/Gold Price: {prices['Grey/Gold']}",
                    callback_data="edit_price_grey_gold",
                )
            ],
            [
                InlineKeyboardButton(
                    f"Chars Price: {prices['Chars']}", callback_data="edit_price_chars"
                )
            ],
            [
                InlineKeyboardButton(
                    f"Mstats Price: {prices['Mstats']}",
                    callback_data="edit_price_mstats",
                )
            ],
            [
                InlineKeyboardButton(
                    f"SellApp API Key: {sellapp_api}",
                    callback_data="edit_sellapp_api_key",
                )
            ],
            [
                InlineKeyboardButton(
                    f"Change PFP on Check: {change_pfp}",
                    callback_data="edit_change_pfp",
                )
            ],
            [
                InlineKeyboardButton(
                    f"Debug Webhook: {debug_webhook}",
                    callback_data="edit_debug_webhook",
                )
            ],
            [
                InlineKeyboardButton(
                    f"Manage Owners: {owners}", callback_data="edit_owners"
                )
            ],
            [InlineKeyboardButton("🔄 Reload", callback_data="reload")],
            [InlineKeyboardButton("Contact Developer", url="https://t.me/z4rdex")],
            [InlineKeyboardButton("🔙 Cancel", callback_data="cancel_settings")],
            [
                InlineKeyboardButton(
                    "💳 Payment Settings", callback_data="payment_settings"
                )
            ],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        message = "*Bot Settings*\nSelect a setting to modify:"
        if update.message:
            await update.message.reply_text(
                message, reply_markup=reply_markup, parse_mode="Markdown"
            )
        else:
            await update.callback_query.edit_message_text(
                message, reply_markup=reply_markup, parse_mode="Markdown"
            )

    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        try:
            setting = query.data
            user_id = update.effective_user.id
            self.debug.log(
                f"Button handler called with: {setting} by user ID: {user_id}"
            )

            public_callbacks = ["buy", "subscribe_newsletter", "show_terms"]

            if setting not in public_callbacks:
                if user_id not in self.BOT_OWNERS:
                    if hasattr(query, "reply_text"):
                        await query.message.reply_text(
                            "🚫 You are not authorized to use this button."
                        )
                        self.debug.log(
                            f"Unauthorized button press: {setting} by user ID: {user_id}"
                        )
                    else:
                        await query.message.reply_text(
                            "🚫 You are not authorized to use this button."
                        )
                        self.debug.log(
                            f"Unauthorized button press: {setting} by user ID: {user_id}"
                        )
                    return

            if setting == "buy":
                if hasattr(self.config, "MAINTENANCE") and self.config.MAINTENANCE:
                    self.debug.log(
                        f"⚠️ User ID: {user_id} attempted to use buy button during maintenance mode"
                    )
                    await self.debug.notify_owner(
                        f"⚠️ User ID: {user_id} attempted to use buy button during maintenance mode"
                    )

                    keyboard = [
                        [
                            InlineKeyboardButton(
                                "Contact Seller", url="https://t.me/vikingtokens"
                            )
                        ]
                    ]
                    reply_markup = InlineKeyboardMarkup(keyboard)

                    if hasattr(query.message, "reply_text"):
                        await query.message.reply_text(
                            "🚫 In-bot Buy functionality is disabled for now.\n\n"
                            "We are currently working on some internal updates to improve our service. Please check back soon!",
                            reply_markup=reply_markup,
                        )
                    else:
                        await query.message.reply_text(
                            "🚫 In-bot Buy functionality is disabled for now.\n\n"
                            "We are currently working on some internal updates to improve our service. Please check back soon!",
                            reply_markup=reply_markup,
                        )
                    return

                self.debug.log(f"🛍️ Buy button pressed by user ID: {user_id}")

                if not await self.database.get_customer_by_id(user_id):
                    self.debug.log(f"👤 User ID: {user_id} is not registered, redirecting to login")
                    if hasattr(self.shop, "login"):
                        # Handle login differently based on whether it's a callback query or direct command
                        if query.message:
                            await query.message.reply_text(
                                "Please login first to browse products.\n\n"
                                "Enter your email address or use /cancel to abort:"
                            )
                            context.user_data["state"] = GET_EMAIL
                            return GET_EMAIL
                        else:
                            await context.bot.send_message(
                                user_id, 
                                "Please use the /login command directly."
                            )
                            return ConversationHandler.END
                    else:
                        self.debug.log("Warning: self.shop.login not found or not callable as expected for 'buy' button redirect.")
                        if query.message:
                            await query.message.reply_text(
                                "Login is required. Please use the /login command."
                            )
                        else:
                            await context.bot.send_message(
                                user_id,
                                "Login is required. Please use the /login command."
                            )
                        return ConversationHandler.END
                else:
                    self.debug.log(
                        f"👤 User ID: {user_id} is registered, showing products"
                    )
                    await self.shop.cmd_products(update, context)
                return
            if setting == "settings":
                await self.settings(update, context)
                return
            if setting == "subscribe_newsletter":
                self.debug.log(f"🔔 Subscribe button pressed by user ID: {user_id}")
                await self.subscribe_command(update, context, from_button=True)
                return
            if setting == "prev_product_page":
                if hasattr(self, 'current_page') and self.current_page > 0:
                    self.current_page -= 1
                await self.view_products(update, context)
                return
            if setting == "next_product_page":
                if hasattr(self, 'current_page'):
                    self.current_page += 1
                else:
                    self.current_page = 1
                await self.view_products(update, context)
                return
            if setting == "send_announcement_confirm":
                await self.announce_confirm_send(update, context)
                return
            if setting == "page_info":
                return
            if setting == "show_terms":
                self.debug.log(f"📜 Terms button pressed by user ID: {user_id}")
                await self.terms(update, context)
                return
            if setting == "product_settings":
                try:
                    await self.edit_products(update, context)
                except Exception as e:
                    self.debug.log(f"Error in product_settings: {e}")
                    await query.edit_message_text(
                        "❌ Error loading product settings. Please try again."
                    )
                return
            if setting.startswith("product_"):
                await self.handle_product_edit(update, context)
                return
            if setting.startswith("coupon_"):
                parts = setting.split("_")
                action = parts[1]
                if action == "custom":
                    await query.edit_message_text("Enter the coupon code:")
                    context.user_data["current_setting"] = "coupon_code"
                    return
                elif action == "random":
                    code = self.coupon_manager.generate_code()
                    context.user_data["coupon_code"] = code
                    await query.edit_message_text(
                        f"Generated code: {code}\nEnter discount percentage (1-99):"
                    )
                    context.user_data["current_setting"] = "coupon_discount"
                    return
                elif action == "list":
                    coupons = await self.coupon_manager.list_coupons()
                    if not coupons:
                        await query.edit_message_text("No coupons found.")
                        return

                    page = context.user_data.get("coupon_page", 0)
                    items_per_page = 5
                    total_pages = (len(coupons) + items_per_page - 1) // items_per_page

                    start_idx = page * items_per_page
                    end_idx = start_idx + items_per_page
                    page_coupons = coupons[start_idx:end_idx]

                    msg = "*Active Coupons:*\n\n"
                    for coupon in page_coupons:
                        msg += f"Code: `{coupon['code']}`\nDiscount: {coupon['discount']}%\nUses: {coupon['uses']}"
                        if coupon["max_uses"]:
                            msg += f"/{coupon['max_uses']}"
                        msg += f"\nExpires: {coupon['expiry'] or 'Never'}\n\n"

                    keyboard = []
                    if total_pages > 1:
                        nav_buttons = []
                        if page > 0:
                            nav_buttons.append(
                                InlineKeyboardButton(
                                    "◀️ Prev", callback_data="coupon_page_prev"
                                )
                            )
                        nav_buttons.append(
                            InlineKeyboardButton(
                                f"{page+1}/{total_pages}", callback_data="page_info"
                            )
                        )
                        if page < total_pages - 1:
                            nav_buttons.append(
                                InlineKeyboardButton(
                                    "Next ▶️", callback_data="coupon_page_next"
                                )
                            )
                        keyboard.append(nav_buttons)

                    keyboard.append(
                        [InlineKeyboardButton("🔙 Back", callback_data="settings")]
                    )

                    await query.edit_message_text(
                        msg,
                        parse_mode="Markdown",
                        reply_markup=InlineKeyboardMarkup(keyboard),
                    )
                    return
                elif action == "delete":
                    await query.edit_message_text("Enter the coupon code to delete:")
                    context.user_data["current_setting"] = "coupon_delete"
                    return

            if setting == "reload":
                await self.reload_bot(update, context)
            if setting == "settings":
                await self.settings(update, context)
                return
            if setting == "cancel_settings":

                context.user_data.pop("coupon_page", None)
                context.user_data.pop("product_page", None)
                await query.delete_message()
                context.user_data["current_setting"] = None
                return
            if setting == "payment_settings":
                await self.payment_settings(update, context)
                return

            if setting == "edit_products":

                await self.edit_products(update, context)
                return

            if setting.startswith("edit_setting_"):
                setting_key = setting.replace("edit_setting_", "")
                setting_data = await self.database.fetch_one(
                    "SELECT * FROM bot_settings WHERE key = ?", (setting_key,)
                )
                if setting_data:
                    context.user_data["current_setting"] = f"setting_{setting_key}"
                    context.user_data["setting_type"] = setting_data["type"]
                    msg = (
                        f"*Edit {setting_data['description']}*\n\n"
                        f"Current value: `{setting_data['value'] or 'Not Set'}`\n\n"
                        "Enter new value:\n(Send /cancel to cancel)"
                    )
                    await query.edit_message_text(msg, parse_mode="Markdown")
                    return

            setting_prompts = {
                "edit_price_per_follower": "Enter the new price per follower:\n\n(Send /cancel to cancel)",
                "edit_price_blue": "Enter the new base price for Blue accounts:\n\n(Send /cancel to cancel)",
                "edit_price_blue_plus": "Enter the new base price for Blue Plus accounts:\n\n(Send /cancel to cancel)",
                "edit_price_grey_gold": "Enter the new base price for Grey/Gold accounts:\n\n(Send /cancel to cancel)",
                "edit_price_mstats": "Enter the new base price for Mstats accounts:\n\n(Send /cancel to cancel)",
                "edit_price_chars": "Enter the new base price for Char accounts:\n\n(Send /cancel to cancel)",
                "edit_sellapp_api_key": "Enter the new SellApp API Key:\n\n(Send /cancel to cancel)",
                "edit_change_pfp": "Checker changes normal pfp? (True/False):\n\n(Send /cancel to cancel)",
                "edit_debug_webhook": "Set DEBUG_WEBHOOK (True/False):\n\n(Send /cancel to cancel)",
                "edit_owners": "Enter the new owner IDs as comma-separated numbers:\n\n(Send /cancel to cancel)",
                "contact_dev": "Contact Developer",
            }

            context.user_data["current_setting"] = setting
            if setting.startswith("coupon"):
                return

            prompt = setting_prompts.get(setting)
            if prompt:
                await query.edit_message_text(prompt)
            else:
                self.debug.log(f"Unknown setting in button_handler: {setting}")
                await query.edit_message_text(
                    f"Unknown Setting: {setting}\n\nPlease try again or contact support."
                )
        except Exception as e:
            self.debug.log(f"Button handler error: {e}\n{traceback.format_exc()}")

            context.user_data.pop("coupon_page", None)
            context.user_data.pop("product_page", None)
            context.user_data.pop("current_setting", None)
            await query.edit_message_text(
                "❌ An error occurred. State reset. Please try again."
            )

    async def update_progress(
        self, task_id: str, current: int, total: int, details: dict = None
    ):
        self.debug.log(
            f"Task {task_id}: {current}/{total} completed. Details: {details}",
            send=False,
        )

    async def handle_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle user text input based on current state"""
        if not update.message or not update.message.text:
            return

        user_id = update.effective_user.id
        current_state = context.user_data.get("state")
        message_text = update.message.text

        if not current_state:
            self.debug.log(f"User {user_id} sent message: '{message_text}'")
        else:
            self.debug.log(
                f"handle_input: user={user_id}, state={current_state}, message='{message_text}'"
            )

        if message_text == "/cancel":
            return await self.cancel(update, context)

        if current_state == "waiting_for_quantity":
            self.debug.log(
                f"Forwarding to shop.handle_quantity_input: '{message_text}'"
            )
            return await self.shop.handle_quantity_input(update, context)

        elif current_state == "waiting_for_coupon":
            return await self.shop.handle_coupon_input(update, context)

        elif current_state == "waiting_for_email":
            email = message_text.strip()

            email_prompt = context.user_data.get("email_prompt")
            if email_prompt:
                try:
                    await email_prompt.delete()
                except Exception as e:
                    self.debug.log(f"Failed to delete email prompt: {e}")

            try:
                await update.message.delete()
            except Exception as e:
                self.debug.log(f"Failed to delete user message: {e}")

            if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                await update.message.reply_text(
                    "⚠️ Invalid email format. Please try again."
                )
                return

            context.user_data["email"] = email
            context.user_data["state"] = "waiting_for_gateway"
            await self.shop.prompt_gateway(update, context)
            return

        setting = context.user_data.get("current_setting")
        if setting:
            await self.handle_settings_input(update, context)
            return

        if self.is_awaiting_product_input(update, context):
            await self.handle_product_input(update, context)
            return

    def update_config(self, key, value):
        try:
            config_path = "config.py"
            with open(config_path, "r") as file:
                lines = file.readlines()
            with open(config_path, "w+") as file:
                for line in lines:
                    if line.startswith(f"{key} ="):
                        if key == "OWNERS":
                            existing_line = line.strip()
                            existing_owners = eval(existing_line.split("=")[1].strip())
                            combined_owners = list(set(existing_owners + value))
                            file.write(f"{key} = {repr(combined_owners)}\n")
                        else:
                            file.write(f"{key} = {repr(value)}\n")
                    else:
                        file.write(line)
            return True
        except Exception as e:
            self.debug.log(
                f"Failed to update config: {e}, {key}, {value}, reverting changes."
            )
            return False

    @owner()
    async def edit_email(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if len(context.args) != 2:
            await update.message.reply_text("Usage: /edit <user_id> <new_email>")
            return
        user_id, new_email = context.args
        if not re.match(r"[^@]+@[^@]+\.[^@]+", new_email):
            await update.message.reply_text("Invalid email address.")
            return
        await self.database.update_customer_email(int(user_id), new_email)
        await update.message.reply_text(
            f"Customer email updated to {new_email} for user_id {user_id}."
        )

    @owner()
    async def customers(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        try:
            customers = await self.database.get_all_customers()
            if not customers:
                await update.message.reply_text("No customers found in database.")
                return

            await update.message.reply_text(customers)
            await asyncio.sleep(0.5)
        except Exception as e:
            self.debug.log(f"Error fetching customers: {e}")
            await update.message.reply_text(
                "❌ Error fetching customer data. Please try again later."
            )

    async def reload_bot(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE, from_button=False
    ):
        if from_button:
            await update.callback_query.edit_message_text(
                "🔄 *Bot will be restarted.*", parse_mode="Markdown"
            )
        else:
            await context.bot.sendMessage(
                update.message.chat_id,
                "🔄 *Bot will be restarted.*",
                parse_mode="Markdown",
            )
        await self.debug.notify_owner("Bot is restarting...")
        python = sys.executable
        os.execl(python, python, *sys.argv)

    @owner()
    async def reload(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await self.reload_bot(update, context)

    async def dev(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        msg = (
            "*🔧 Developer Information*\n\n"
            "👨‍💻 *Developer*: Zardex\n\n"
            "🌐 *Links*:\n"
            "• Website: [zardex.cc](https://zardex.cc)\n"
            "• Telegram: [@z4rdex](https://t.me/z4rdex)\n"
            "• Discord: [Join](https://discord.zardex.cc)\n"
            "• Cracked.io: [Profile](https://cracked.io/pics)\n"
            "Available for freelance work, contact me on Telegram for more info."
        )
        await update.message.reply_text(
            msg, parse_mode="Markdown", disable_web_page_preview=True
        )

    async def faq(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Display FAQ entries"""
        try:
            faqs = await self.database.get_all_faqs()

            if not faqs:
                await update.message.reply_text(
                    "❓ *Frequently Asked Questions*\n\n"
                    "No FAQ entries available yet.",
                    parse_mode="Markdown",
                )
                return

            message = ["❓ *Frequently Asked Questions*\n"]

            for i, faq in enumerate(faqs, 1):
                message.append(f"\n*{i}. {faq['question']}*")
                message.append(f"{faq['answer']}\n")

            full_message = "\n".join(message)
            if len(full_message) > 4000:
                chunks = [
                    full_message[i : i + 4000]
                    for i in range(0, len(full_message), 4000)
                ]
                for chunk in chunks:
                    await update.message.reply_text(chunk, parse_mode="Markdown")
            else:
                await update.message.reply_text(full_message, parse_mode="Markdown")

        except Exception as e:
            self.debug.log(f"Error displaying FAQ: {e}")
            await update.message.reply_text(
                "❌ An error occurred while retrieving the FAQ."
            )

    async def terms(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if update.message:
            self.debug.log(
                f"📜 Terms of Service accessed via command by user ID: {user_id}"
            )
            await update.message.reply_text(
                "📜 Terms of Service: https://t.me/twitteragedaccounts/43"
            )
        elif update.callback_query:
            self.debug.log(
                f"📜 Terms of Service accessed via button by user ID: {user_id}"
            )
            await update.callback_query.answer()
            await update.callback_query.message.reply_text(
                "📜 Terms of Service: https://t.me/twitteragedaccounts/43"
            )

    @owner()
    async def manage_faq(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not context.args or len(context.args) < 2:
            await update.message.reply_text(
                "Usage:\n"
                "/managefaq add <question>|<answer> - Add new FAQ\n"
                "/managefaq edit <id> <question>|<answer> - Edit FAQ\n"
                "/managefaq delete <id> - Delete FAQ\n"
                "/managefaq list - List all FAQs with IDs"
            )
            return

        action = context.args[0].lower()
        if action == "list":
            faqs = await self.database.get_all_faqs()
            if not faqs:
                await update.message.reply_text("No FAQ entries found.")
                return
            message = ["*FAQ Entries:*\n"]
            for faq in faqs:
                message.append(f"\nID: `{faq['id']}`")
                message.append(f"Q: {faq['question']}")
                message.append(f"A: {faq['answer']}\n")
            await update.message.reply_text("\n".join(message), parse_mode="Markdown")
        elif action == "add":
            content = " ".join(context.args[1:])
            try:
                question, answer = content.split("|", 1)
                if await self.database.add_faq(question.strip(), answer.strip()):
                    await update.message.reply_text("✅ FAQ entry added successfully.")
                else:
                    await update.message.reply_text("❌ Failed to add FAQ entry.")
            except ValueError:
                await update.message.reply_text(
                    "❌ Invalid format. Use: question|answer"
                )
        elif action == "edit":
            try:
                faq_id = int(context.args[1])
                content = " ".join(context.args[2:])
                question, answer = content.split("|", 1)
                if await self.database.update_faq(
                    faq_id, question.strip(), answer.strip()
                ):
                    await update.message.reply_text(
                        "✅ FAQ entry updated successfully."
                    )
                else:
                    await update.message.reply_text("❌ Failed to update FAQ entry.")
            except (ValueError, IndexError):
                await update.message.reply_text(
                    "❌ Invalid format. Use: /managefaq edit <id> question|answer"
                )
        elif action == "delete":
            try:
                faq_id = int(context.args[1])
                if await self.database.delete_faq(faq_id):
                    await update.message.reply_text(
                        "✅ FAQ entry deleted successfully."
                    )
                else:
                    await update.message.reply_text("❌ Failed to delete FAQ entry.")
            except (ValueError, IndexError):
                await update.message.reply_text(
                    "❌ Invalid format. Use: /managefaq delete <id>"
                )

    @owner()
    async def manage_terms(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Manage Terms of Service entries (owner only)"""
        if not context.args or len(context.args) < 2:
            await update.message.reply_text(
                "Usage:\n"
                "/manageterms add <section>|<content> - Add new section\n"
                "/manageterms edit <id> <section>|<content> - Edit section\n"
                "/manageterms delete <id> - Delete section\n"
                "/manageterms list - List all sections with IDs"
            )
            return

        action = context.args[0].lower()

        if action == "list":
            terms = await self.database.get_all_terms()
            if not terms:
                await update.message.reply_text("No terms of service sections found.")
                return

            message = ["*Terms of Service Sections:*\n"]
            for term in terms:
                message.append(f"\nID: `{term['id']}`")
                message.append(f"Section: {term['section']}")
                message.append(f"Content: {term['content']}\n")

            await update.message.reply_text("\n".join(message), parse_mode="Markdown")

        elif action == "add":
            content = " ".join(context.args[1:])
            try:
                section, content = content.split("|", 1)
                if await self.database.add_terms_section(
                    section.strip(), content.strip()
                ):
                    await update.message.reply_text(
                        "✅ Terms section added successfully."
                    )
                else:
                    await update.message.reply_text("❌ Failed to add terms section.")
            except ValueError:
                await update.message.reply_text(
                    "❌ Invalid format. Use: section|content"
                )

        elif action == "edit":
            try:
                section_id = int(context.args[1])
                content = " ".join(context.args[2:])
                section, content = content.split("|", 1)
                if await self.database.update_terms_section(
                    section_id, section.strip(), content.strip()
                ):
                    await update.message.reply_text(
                        "✅ Terms section updated successfully."
                    )
                else:
                    await update.message.reply_text(
                        "❌ Failed to update terms section."
                    )
            except (ValueError, IndexError):
                await update.message.reply_text(
                    "❌ Invalid format. Use: /manageterms edit <id> section|content"
                )

        elif action == "delete":
            try:
                section_id = int(context.args[1])
                if await self.database.delete_terms_section(section_id):
                    await update.message.reply_text(
                        "✅ Terms section deleted successfully."
                    )
                else:
                    await update.message.reply_text(
                        "❌ Failed to delete terms section."
                    )
            except (ValueError, IndexError):
                await update.message.reply_text(
                    "❌ Invalid format. Use: /manageterms delete <id>"
                )

    @owner()
    async def faqterms_guide(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Display comprehensive guide for FAQ and Terms management"""
        message = """
*📚 FAQ & Terms of Service Management Guide*

This guide shows how to set up and manage FAQ entries and Terms of Service.

*🔍 For Users:*
Simply use these commands to view information:
• `/faq` - View all FAQ entries
• `/terms` - View Terms of Service

*⚙️ For Admins:*

*Managing FAQ:*
1️⃣ *Add a new FAQ entry:*
`/managefaq add Question text here?|Answer text here with detailed explanation.`

2️⃣ *List all FAQ entries with their IDs:*
`/managefaq list`

3️⃣ *Edit an existing FAQ entry:*
`/managefaq edit 1 Updated question?|Updated answer.`

4️⃣ *Delete an FAQ entry:*
`/managefaq delete 1`

*Managing Terms of Service:*
1️⃣ *Add a new Terms section:*
`/manageterms add Section Title|Section content goes here with all the details.`

2️⃣ *List all Terms sections with their IDs:*
`/manageterms list`

3️⃣ *Edit an existing Terms section:*
`/manageterms edit 1 Updated Section Title|Updated content.`

4️⃣ *Delete a Terms section:*
`/manageterms delete 1`

*📝 Example Commands:*

*Adding an FAQ:*
`/managefaq add What are fresh accounts?|Fresh accounts are Twitter accounts created in 2023 with clean history and email verification.`

*Adding a Terms section:*
`/manageterms add Payment Terms|1. All sales are final\n2. We accept crypto payments only\n3. Refunds are processed within 24 hours if service not delivered`

*Tips:*
• Use `|` to separate question/section from answer/content
• Use `\\n` for line breaks in your content
• Entries are displayed in the order they were added
"""
        await update.message.reply_text(message, parse_mode="Markdown")

    @owner()
    async def init_faq_terms(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Initialize FAQ and Terms with example entries"""

        faq_examples = [
            (
                "What types of accounts do you offer?",
                "We offer various Twitter accounts including: normal accounts, blue verified accounts, follower accounts, grey verified accounts, gold verified accounts, and accounts with special usernames.",
            ),
            (
                "Are the accounts guaranteed?",
                "Yes, all accounts come with a 24-hour replacement guarantee if they don't work as described at the time of purchase.",
            ),
            (
                "Do accounts come with email access?",
                "Most accounts include email access. This is clearly indicated in the product description when you use the /buy command.",
            ),
            (
                "What payment methods do you accept?",
                "We currently accept cryptocurrencies for payment, including Bitcoin and other major coins.",
            ),
            (
                "How fast will I receive my account?",
                "Accounts are delivered automatically and instantly after payment confirmation.",
            ),
        ]

        terms_examples = [
            (
                "General Terms",
                "By using this service, you agree to these terms and conditions. We reserve the right to modify these terms at any time.",
            ),
            (
                "Product Delivery",
                "1. All accounts are delivered automatically after payment confirmation.\n2. Delivery typically occurs within minutes of payment verification.\n3. In rare cases, manual verification may be required, which can take up to 12 hours.",
            ),
            (
                "Refund Policy",
                "1. All sales are final once accounts are delivered.\n2. Replacement accounts will be provided within 24 hours if the original account doesn't work as described.\n3. Refunds are only processed if we cannot provide a replacement account of similar quality.",
            ),
            (
                "Account Usage & Responsibility",
                "After purchase, the buyer assumes full responsibility for the account and its usage. The seller:\n1. Does not monitor or control account activities\n2. Is not liable for any actions taken with the accounts\n3. Bears no responsibility for account suspensions or restrictions\n\nBy purchasing, you acknowledge full accountability for how the account is used.",
            ),
        ]

        count = 0
        for question, answer in faq_examples:
            if await self.database.add_faq(question, answer, count):
                count += 1

        count = 0
        for section, content in terms_examples:
            if await self.database.add_terms_section(section, content, count):
                count += 1

        await update.message.reply_text(
            f"✅ Successfully initialized database with example entries:\n"
            f"• {len(faq_examples)} FAQ entries\n"
            f"• {len(terms_examples)} Terms of Service sections\n\n"
            f"Use /faq and /terms to view them."
        )

    async def fresh_accounts_info(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Provide information about the fresh 2025 accounts"""
        msg = (
            "🆕 *Fresh 2025 Accounts*\n\n"
            "These are brand new Twitter accounts created in 2025 with several advantages:\n\n"
            "✅ *Benefits*:\n"
            "• Less likely to get locked or suspended\n"
            "• Higher quality with fresh IPs\n"
            "• Great for long-term growth\n"
            "• Perfect for new businesses and projects\n"
            "• Full account access with credentials\n\n"
            "📋 *Features*:\n"
            "• Created in 2025\n"
            "• Email verified\n"
            "• Clean history\n"
            "• No previous usage\n"
            "• Original registration details\n\n"
            "🛒 Use the /buy command and look for the 🆕 Fresh 2025 category to purchase these accounts!"
        )

        keyboard = [
            [
                InlineKeyboardButton(
                    "Browse Fresh Accounts", callback_data="category_fresh"
                )
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await update.message.reply_text(
            msg, parse_mode="Markdown", reply_markup=reply_markup
        )

    async def buy_disabled(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        keyboard = [
            [InlineKeyboardButton("Contact Seller", url="https://t.me/vikingtokens")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await update.message.reply_text(
            "🚫 In-bot Buy functionality is disabled for now.\n\n"
            "We are currently working on some internal updates to improve our service. Please check back soon!",
            reply_markup=reply_markup,
        )

    @owner()
    async def coupon(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        keyboard = [
            [
                InlineKeyboardButton(
                    "Create Custom Coupon", callback_data="coupon_custom"
                )
            ],
            [
                InlineKeyboardButton(
                    "Generate Random Coupon", callback_data="coupon_random"
                )
            ],
            [InlineKeyboardButton("List Coupons", callback_data="coupon_list")],
            [InlineKeyboardButton("Delete Coupon", callback_data="coupon_delete")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            "🎫 *Coupon Management*\nWhat would you like to do?",
            reply_markup=reply_markup,
            parse_mode="Markdown",
        )

    @owner()
    async def view_products(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """View and manage all products using the new ProductTypes system"""
        try:
            self.current_page = 0

            products = await ProductTypes.list_all_products()

            if not products:
                await update.message.reply_text(
                    "❌ No products found. Use /defaults to add default products."
                )
                return

            products_per_page = 5
            total_pages = (len(products) + products_per_page - 1) // products_per_page

            start_idx = self.current_page * products_per_page
            end_idx = min(start_idx + products_per_page, len(products))
            page_products = products[start_idx:end_idx]

            stock_counts = await asyncio.gather(
                *[ProductTypes.get_stock_count_for_product(p) for p in page_products]
            )

            product_displays = []

            for i, (product, stock_count) in enumerate(
                zip(page_products, stock_counts)
            ):
                display = (
                    f"*{i+1}. {product.title}*\n"
                    f"ID: `{product.id}`\n"
                    f"Price: ${product.price:.2f}\n"
                    f"Type: {product.attributes.product_type}\n"
                    f"Stock: {stock_count} accounts\n"
                )

                if product.attributes.range:
                    display += f"Range: {product.attributes.range[0]}-{product.attributes.range[1]}\n"

                verifications = []
                if product.attributes.fully_verified:
                    verifications.append("Fully Verified")
                if product.attributes.unverified:
                    verifications.append("Unverified")
                if product.attributes.mixed:
                    verifications.append("Mixed")

                if verifications:
                    display += f"Verifications: {', '.join(verifications)}\n"

                if product.attributes.mail_access:
                    display += "Mail Access: Yes\n"
                else:
                    display += "Mail Access: No\n"

                product_displays.append(display)

            keyboard = []

            for i, product in enumerate(page_products):
                keyboard.append(
                    [
                        InlineKeyboardButton(
                            f"Edit {i+1}: {product.title[:15]}...",
                            callback_data=f"edit_product_{product.id}",
                        )
                    ]
                )

            nav_row = []
            if self.current_page > 0:
                nav_row.append(
                    InlineKeyboardButton("◀️ Prev", callback_data="prev_product_page")
                )
            nav_row.append(
                InlineKeyboardButton(
                    f"{self.current_page + 1}/{total_pages}", callback_data="page_info"
                )
            )
            if self.current_page < total_pages - 1:
                nav_row.append(
                    InlineKeyboardButton("Next ▶️", callback_data="next_product_page")
                )

            if nav_row:
                keyboard.append(nav_row)

            keyboard.append(
                [
                    InlineKeyboardButton("➕ Add Product", callback_data="add_product"),
                    InlineKeyboardButton(
                        "🔄 Refresh", callback_data="refresh_products"
                    ),
                ]
            )

            message_text = (
                f"🛍️ *Products* (Page {self.current_page + 1}/{total_pages})\n\n"
            )
            message_text += "\n\n".join(product_displays)

            await update.message.reply_text(
                message_text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown",
            )

        except Exception as e:
            self.debug.log(f"View products error: {e}\n{traceback.format_exc()}")
            await update.message.reply_text(f"❌ Error viewing products: {str(e)}")

    def _get_short_title(self, full_title: str) -> str:
        """Extract short, meaningful product title for buttons"""

        account_type = ""
        if "Fresh" in full_title:
            account_type = "Fresh"
        elif "Full Verified" in full_title:
            account_type = "Full Verified"
        elif "Email Verified" in full_title:
            account_type = "Email Verified"
        elif "Mixed" in full_title:
            account_type = "Mixed"

        follower_range = ""
        if "0-9" in full_title:
            follower_range = "0-9"
        elif "10-29" in full_title:
            follower_range = "10-29"
        elif "30-99" in full_title:
            follower_range = "30-99"
        elif "100-499" in full_title:
            follower_range = "100-499"
        elif "500-999" in full_title:
            follower_range = "500-999"

        features = []
        if "NFT" in full_title:
            features.append("NFT")
        if "Email Access" in full_title:
            features.append("Email Access")

        if account_type and follower_range:
            return f"{account_type} {follower_range}"
        elif account_type and features:
            return f"{account_type} {' '.join(features)}"
        elif account_type:
            return account_type
        else:

            return (
                full_title.split("(")[0].split("Twitter")[1].strip()
                if "Twitter" in full_title
                else full_title.split(" ")[0]
            )

    @owner()
    async def edit_products(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Edit products with the new YAML-based model"""
        try:
            products = await ProductTypes.list_all_products()

            if not products:
                if update.message:
                    await update.message.reply_text("No products found to edit.")
                else:
                    await update.callback_query.edit_message_text(
                        "No products found to edit."
                    )
                return

            current_page = context.user_data.get("edit_products_page", 0)
            items_per_page = 5
            total_pages = (len(products) + items_per_page - 1) // items_per_page

            if current_page >= total_pages:
                current_page = max(0, total_pages - 1)
                context.user_data["edit_products_page"] = current_page

            start_idx = current_page * items_per_page
            end_idx = min(start_idx + items_per_page, len(products))
            page_products = products[start_idx:end_idx]

            keyboard = []

            for product in page_products:

                display_title = self._get_short_title(product.title)

                indicators = []

                if hasattr(product.attributes, "fresh") and product.attributes.fresh:
                    indicators.append("🆕")

                if product.attributes.fully_verified:
                    indicators.append("✅")
                elif product.attributes.unverified:
                    indicators.append("⚠️")
                elif product.attributes.mixed:
                    indicators.append("🔄")

                if product.attributes.mail_access:
                    indicators.append("📧")

                if product.attributes.range:
                    display_title = f"{display_title} ({product.attributes.range[0]}-{product.attributes.range[1]})"

                if indicators:
                    display_title = f"{' '.join(indicators)} {display_title}"

                keyboard.append(
                    [
                        InlineKeyboardButton(
                            display_title, callback_data=f"product_edit_{product.id}"
                        )
                    ]
                )

            nav_buttons = []
            if total_pages > 1:
                if current_page > 0:
                    nav_buttons.append(
                        InlineKeyboardButton("◀️", callback_data="edit_products_prev")
                    )
                nav_buttons.append(
                    InlineKeyboardButton(
                        f"{current_page + 1}/{total_pages}", callback_data="page_info"
                    )
                )
                if current_page < total_pages - 1:
                    nav_buttons.append(
                        InlineKeyboardButton("▶️", callback_data="edit_products_next")
                    )
                keyboard.append(nav_buttons)

            keyboard.append(
                [InlineKeyboardButton("➕ Add Product", callback_data="add_product")]
            )
            keyboard.append(
                [InlineKeyboardButton("🔄 Refresh", callback_data="refresh_products")]
            )
            keyboard.append(
                [InlineKeyboardButton("❌ Cancel", callback_data="cancel_products")]
            )

            message = (
                "*Product Management*\n\n"
                "📧 - Email Access | ✅ - Fully Verified\n"
                "⚠️ - Email Verified | 🔄 - Mixed | 🆕 - Fresh 2025\n\n"
                "Select a product to edit:"
            )

            if update.message:
                await update.message.reply_text(
                    message,
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="Markdown",
                )
            else:
                await update.callback_query.edit_message_text(
                    message,
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="Markdown",
                )

        except Exception as e:
            self.debug.log(f"Error in edit_products: {str(e)}")
            if update.message:
                await update.message.reply_text(f"❌ Error: {str(e)}")
            else:
                await update.callback_query.edit_message_text(f"❌ Error: {str(e)}")

    async def handle_edit_products_pagination(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle pagination for product editing"""
        query = update.callback_query
        await query.answer()

        try:

            current_page = context.user_data.get("edit_products_page", 0)

            if query.data == "edit_products_prev" and current_page > 0:
                current_page -= 1
            elif query.data == "edit_products_next":
                current_page += 1

            context.user_data["edit_products_page"] = current_page

            await self.edit_products(update, context)

        except Exception as e:
            self.debug.log(f"Error in handle_edit_products_pagination: {str(e)}")
            await query.edit_message_text(
                "❌ Error navigating products. Please try again."
            )

    async def handle_product_edit(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle product edit selection"""
        try:
            query = update.callback_query
            await query.answer()

            product_id = query.data.split("_")[-1]

            product = await ProductTypes.get_product_by_id(product_id)
            if not product:
                await query.edit_message_text("❌ Product not found")
                return

            stock_count = await ProductTypes.get_stock_count_for_product(product)

            message = f"*Editing Product:* {product.title}\n"
            message += f"ID: `{product.id}`\n"
            message += f"Price: ${product.price:.2f}\n"
            message += f"Type: {product.attributes.product_type}\n"
            message += f"Stock: {stock_count} accounts\n\n"

            message += "*Attributes:*\n"
            if product.attributes.mail_access:
                message += "• Has Email Access: Yes\n"
            else:
                message += "• Has Email Access: No\n"

            if product.attributes.range:
                message += f"• Follower Range: {product.attributes.range[0]}-{product.attributes.range[1]}\n"

            if product.attributes.fully_verified:
                message += "• Verification: Fully Verified\n"
            elif product.attributes.unverified:
                message += "• Verification: Unverified\n"
            elif product.attributes.mixed:
                message += "• Verification: Mixed\n"

            keyboard = [
                [
                    InlineKeyboardButton(
                        "✏️ Edit Price", callback_data=f"product_edit_price_{product_id}"
                    )
                ],
                [
                    InlineKeyboardButton(
                        "🔄 Toggle Email Access",
                        callback_data=f"product_toggle_mail_{product_id}",
                    )
                ],
                [
                    InlineKeyboardButton(
                        "🏷️ Edit Category",
                        callback_data=f"product_edit_category_{product_id}",
                    )
                ],
            ]

            if product.attributes.product_type.lower() == "normal":
                keyboard.append(
                    [
                        InlineKeyboardButton(
                            "👥 Edit Follower Range",
                            callback_data=f"product_edit_range_{product_id}",
                        )
                    ]
                )

            keyboard.extend(
                [
                    [
                        InlineKeyboardButton(
                            "❌ Delete Product",
                            callback_data=f"product_delete_{product_id}",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "🔙 Back", callback_data="product_back_to_categories"
                        )
                    ],
                ]
            )

            await query.edit_message_text(
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown",
            )

        except Exception as e:
            self.debug.log(f"Error in handle_product_edit: {str(e)}")
            await query.edit_message_text(f"❌ Error: {str(e)}")

    async def handle_product_edit_price(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        user_input: str,
        product,
    ):
        """Handle product price editing"""
        try:
            new_price = float(user_input)
            if new_price <= 0:
                await update.message.reply_text("❌ Price must be greater than 0.")
                return

            result = await self.database.update_product_price(product.id, new_price)

            if result:
                ProductTypes.load_config(force_reload=True)
                all_products_config = ProductTypes._product_config.get("products", {})
                updated = False

                self.debug.log(
                    f"Attempting to update price in YAML for product ID: {product.id}, type: {product.attributes.product_type}"
                )

                if product.attributes.product_type == "normal":
                    normal_products_data = all_products_config.get("normal", {})
                    self.debug.log(
                        f"Normal product. Searching in categories and ranges. Config snippet: {str(normal_products_data)[:200]}"
                    )

                    if "categories" in normal_products_data:
                        for category_key, category_value in normal_products_data[
                            "categories"
                        ].items():
                            if (
                                isinstance(category_value, dict)
                                and category_value.get("id") == product.id
                            ):
                                self.debug.log(
                                    f"Found normal product in category '{category_key}'. Updating price."
                                )
                                category_value["price"] = new_price
                                updated = True
                                break

                    if not updated and "ranges" in normal_products_data:
                        for range_key, range_group in normal_products_data[
                            "ranges"
                        ].items():
                            if isinstance(range_group, dict):
                                for variant_key, variant_value in range_group.items():
                                    if (
                                        isinstance(variant_value, dict)
                                        and variant_value.get("id") == product.id
                                    ):
                                        self.debug.log(
                                            f"Found normal product in range '{range_key}', variant '{variant_key}'. Updating price."
                                        )
                                        variant_value["price"] = new_price
                                        updated = True
                                        break
                            if updated:
                                break
                else:
                    product_type_key = product.attributes.product_type
                    self.debug.log(f"Non-normal product. Type key: {product_type_key}")
                    if product_type_key in all_products_config:
                        product_data_yaml = all_products_config[product_type_key]
                        if (
                            isinstance(product_data_yaml, dict)
                            and product_data_yaml.get("id") == product.id
                        ):
                            self.debug.log(
                                f"Found non-normal product directly under key '{product_type_key}'. Updating price."
                            )
                            product_data_yaml["price"] = new_price
                            updated = True
                        else:
                            self.debug.log(
                                f"Non-normal product for key '{product_type_key}' is not a direct match or not a dict: {str(product_data_yaml)[:200]}"
                            )
                    else:
                        self.debug.log(
                            f"Product type key '{product_type_key}' not found in all_products_config."
                        )

                if updated:
                    self.debug.log(
                        f"Price updated in YAML structure for {product.id}. Saving config."
                    )
                    ProductTypes.save_config()
                else:
                    self.debug.log(
                        f"Failed to find product {product.id} in YAML structure. YAML not saved."
                    )

                if product.id in ProductTypes._products_cache:
                    del ProductTypes._products_cache[product.id]
                ProductTypes.invalidate_stock_cache(product.id)

                product.price = new_price

                await update.message.reply_text(
                    f"✅ Price for *{product.title}* has been updated to ${new_price:.2f}.",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back to Product",
                                    callback_data=f"product_edit_{product.id}",
                                )
                            ]
                        ]
                    ),
                )
            else:
                await update.message.reply_text(
                    "❌ Failed to update price in database.",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back to Product",
                                    callback_data=f"product_edit_{product.id}",
                                )
                            ]
                        ]
                    ),
                )
        except ValueError:
            await update.message.reply_text(
                "❌ Invalid price. Please enter a valid number."
            )

    async def handle_product_toggle_mail(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Toggle email access for a product"""
        try:
            query = update.callback_query
            await query.answer()

            product_id = query.data.split("_")[-1]

            product = await ProductTypes.get_product_by_id(product_id)
            if not product:
                await query.edit_message_text("❌ Product not found")
                return

            result = await self.database.toggle_product_mail_access(product_id)

            if result:

                new_mail_access = not product.attributes.mail_access
                product.attributes.mail_access = new_mail_access

                ProductTypes.load_config()
                all_products = ProductTypes._product_config.get("products", {})

                updated = False

                if product.attributes.product_type == "normal":
                    normals = all_products.get("normal", {})

                    for category_key, category_data in normals.items():
                        if (
                            category_key != "ranges"
                            and isinstance(category_data, dict)
                            and category_data.get("id") == product_id
                        ):
                            if "attributes" in category_data:
                                category_data["attributes"][
                                    "mail_access"
                                ] = new_mail_access
                                updated = True
                                break

                    if not updated and "ranges" in normals:
                        for range_key, range_data in normals["ranges"].items():
                            for variant_key, variant_data in range_data.items():
                                if (
                                    variant_data.get("id") == product_id
                                    and "attributes" in variant_data
                                ):
                                    variant_data["attributes"][
                                        "mail_access"
                                    ] = new_mail_access
                                    updated = True
                                    break
                            if updated:
                                break

                else:
                    product_type = product.attributes.product_type
                    if product_type in all_products:
                        product_data = all_products[product_type]
                        if (
                            product_data.get("id") == product_id
                            and "attributes" in product_data
                        ):
                            product_data["attributes"]["mail_access"] = new_mail_access
                            updated = True

                if updated:
                    ProductTypes.save_config()
                    ProductTypes.invalidate_stock_cache(product_id)

                    await query.edit_message_text(
                        f"✅ Email access for *{product.title}* has been "
                        f"{'enabled' if new_mail_access else 'disabled'}.",
                        parse_mode="Markdown",
                        reply_markup=InlineKeyboardMarkup(
                            [
                                [
                                    InlineKeyboardButton(
                                        "🔙 Back to Product",
                                        callback_data=f"product_edit_{product_id}",
                                    )
                                ]
                            ]
                        ),
                    )
                else:
                    await query.edit_message_text(
                        f"❓ Product configuration not found in YAML. Database was updated but "
                        f"the YAML file needs manual editing.",
                        reply_markup=InlineKeyboardMarkup(
                            [
                                [
                                    InlineKeyboardButton(
                                        "🔙 Back to Product",
                                        callback_data=f"product_edit_{product_id}",
                                    )
                                ]
                            ]
                        ),
                    )
            else:
                await query.edit_message_text(
                    "❌ Failed to toggle email access.",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back to Product",
                                    callback_data=f"product_edit_{product_id}",
                                )
                            ]
                        ]
                    ),
                )

        except Exception as e:
            self.debug.log(f"Error in handle_product_toggle_mail: {e}")
            await query.edit_message_text(f"❌ Error: {str(e)}")

    def is_awaiting_product_input(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> bool:
        """Check if the bot is waiting for product input from the user."""
        user_id = update.effective_user.id
        return (
            context.user_data
            and "edit_product" in context.user_data
            and "edit_mode" in context.user_data
        )

    async def handle_product_input(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle product input for editing"""
        if not self.is_awaiting_product_input(update, context):
            return

        try:
            user_input = update.message.text.strip()
            product_id = context.user_data.get("edit_product")
            edit_mode = context.user_data.get("edit_mode")

            if not product_id or not edit_mode:
                return

            product = await ProductTypes.get_product_by_id(product_id)
            if not product:
                await update.message.reply_text("❌ Product not found")
                return

            if edit_mode == "price":
                await self.handle_product_edit_price(
                    update, context, user_input, product
                )
            elif edit_mode == "range":
                await self.handle_product_edit_range(
                    update, context, user_input, product
                )
            elif edit_mode == "category":
                await self.handle_product_edit_category(
                    update, context, user_input, product
                )

            context.user_data.pop("edit_product", None)
            context.user_data.pop("edit_mode", None)

        except Exception as e:
            self.debug.log(f"Error in handle_product_input: {e}")
            await update.message.reply_text(f"❌ Error: {str(e)}")

    async def handle_product_edit_range(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        user_input: str,
        product,
    ):
        """Handle range editing for a product"""

        range_parts = user_input.split("-")
        if len(range_parts) != 2:
            await update.message.reply_text(
                "❌ Invalid range format. Please use format like '100-1000'."
            )
            return

        try:
            min_followers = int(range_parts[0])
            max_followers = int(range_parts[1])
            if min_followers < 0 or max_followers <= min_followers:
                await update.message.reply_text(
                    "❌ Invalid range. Min must be >= 0 and Max must be > Min."
                )
                return

            result = await self.database.update_product_range(product.id, user_input)

            if result:

                old_range = product.attributes.range
                new_range = (min_followers, max_followers)
                product.attributes.range = new_range

                ProductTypes.load_config()

                if product.id in ProductTypes._products_cache:
                    del ProductTypes._products_cache[product.id]

                await update.message.reply_text(
                    f"✅ Follower range for *{product.title}* has been updated to {min_followers}-{max_followers}.",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back to Product",
                                    callback_data=f"product_edit_{product.id}",
                                )
                            ]
                        ]
                    ),
                )
            else:
                await update.message.reply_text(
                    "❌ Failed to update range in database.",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(
                                    "🔙 Back to Product",
                                    callback_data=f"product_edit_{product.id}",
                                )
                            ]
                        ]
                    ),
                )
        except ValueError:
            await update.message.reply_text(
                "❌ Invalid range values. Please enter valid numbers."
            )

    async def handle_product_edit_category(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        user_input: str,
        product,
    ):
        """Handle category editing for a product"""

        category = user_input.lower()
        valid_categories = [
            "normal",
            "blue",
            "grey",
            "gold",
            "blueplus",
            "chars",
            "unverified",
            "mixed",
        ]

        if category not in valid_categories:
            categories_str = ", ".join(valid_categories)
            await update.message.reply_text(
                f"❌ Invalid category. Valid categories are: {categories_str}"
            )
            return

        result = await self.database.update_product_category(product.id, category)

        if result:

            await update.message.reply_text(
                f"✅ Category for product *{product.title}* has been updated to {category}.\n\n"
                f"⚠️ Note: Since you changed a fundamental product property, you should run "
                f"/migrate_products to ensure all product configurations are updated properly.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "🔙 Back to Product",
                                callback_data=f"product_edit_{product.id}",
                            )
                        ]
                    ]
                ),
            )
        else:
            await update.message.reply_text(
                "❌ Failed to update category in database.",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "🔙 Back to Product",
                                callback_data=f"product_edit_{product.id}",
                            )
                        ]
                    ]
                ),
            )

    @owner()
    async def delete_product(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Delete a product using the new model"""
        try:

            products = await ProductTypes.list_all_products()

            if not products:
                await update.message.reply_text("No products found to delete.")
                return

            keyboard = []
            row = []

            for i, product in enumerate(products):
                row.append(
                    InlineKeyboardButton(
                        f"{product.title[:15]}...",
                        callback_data=f"product_delete_{product.id}",
                    )
                )

                if len(row) == 3 or i == len(products) - 1:
                    keyboard.append(row)
                    row = []

            keyboard.append(
                [InlineKeyboardButton("Cancel", callback_data="cancel_products")]
            )

            await update.message.reply_text(
                "⚠️ *Select a product to delete:*\n\n" "This action cannot be undone!",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown",
            )

        except Exception as e:
            self.debug.log(f"Error in delete_product: {e}")
            await update.message.reply_text(f"❌ Error: {str(e)}")

    async def handle_product_delete(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle product deletion"""
        try:
            query = update.callback_query
            await query.answer()

            product_id = query.data.split("_")[-1]

            product = await ProductTypes.get_product_by_id(product_id)
            if not product:
                await query.edit_message_text("❌ Product not found")
                return

            result = await self.database.delete_bot_product(product_id)

            if result:

                ProductTypes.load_config()
                all_products = ProductTypes._product_config.get("products", {})

                removed = False

                if product.attributes.product_type == "normal":
                    normals = all_products.get("normal", {})

                    for category_key, category_data in list(normals.items()):
                        if (
                            category_key != "ranges"
                            and isinstance(category_data, dict)
                            and category_data.get("id") == product_id
                        ):
                            del normals[category_key]
                            removed = True
                            break

                    if not removed and "ranges" in normals:
                        for range_key, range_data in list(normals["ranges"].items()):
                            for variant_key, variant_data in list(range_data.items()):
                                if variant_data.get("id") == product_id:
                                    del range_data[variant_key]
                                    removed = True

                                    if not range_data:
                                        del normals["ranges"][range_key]
                                    break
                            if removed:
                                break

                else:
                    product_type = product.attributes.product_type
                    if product_type in all_products:
                        product_data = all_products[product_type]
                        if product_data.get("id") == product_id:
                            del all_products[product_type]
                            removed = True

                if removed:
                    ProductTypes.save_config()

                if product_id in ProductTypes._products_cache:
                    del ProductTypes._products_cache[product_id]
                ProductTypes.invalidate_stock_cache(product_id)

                await query.edit_message_text(
                    f"✅ Product *{product.title}* has been deleted.",
                    parse_mode="Markdown",
                )
            else:
                await query.edit_message_text(
                    f"❌ Failed to delete product {product.title} from database."
                )

        except Exception as e:
            self.debug.log(f"Error in handle_product_delete: {e}")
            await query.edit_message_text(f"❌ Error: {str(e)}")

    @owner()
    async def handle_product_category(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle product category selection"""
        query = update.callback_query
        await query.answer()

        _, _, category = query.data.partition("_category_")
        products = await self.database.list_bot_products()

        category_products = [p for p in products if p["type"] == category]
        if not category_products:
            await query.edit_message_text(f"No products found in category {category}.")
            return

        keyboard = []
        for product in category_products:
            product_id = product["id"]
            range_display = f" ({product['range']})" if product.get("range") else ""
            price_display = f"${product.get('price', 0.0):.2f}"
            keyboard.append(
                [
                    InlineKeyboardButton(
                        f"ID: {product_id}{range_display} - {price_display}",
                        callback_data=f"product_edit_{product_id}",
                    )
                ]
            )

        keyboard.append(
            [
                InlineKeyboardButton(
                    "🔙 Back to Categories", callback_data="product_back_to_categories"
                )
            ]
        )

        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"*{category.capitalize()} Products*\n\n" f"Select a product to edit:",
            reply_markup=reply_markup,
            parse_mode="Markdown",
        )

    async def handle_product_edit_category(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle category editing for a product"""
        query = update.callback_query
        await query.answer()

        _, _, _, product_id = query.data.split("_", 3)

        context.user_data["editing_product_id"] = product_id
        context.user_data["editing_field"] = "category"

        products = await self.database.list_bot_products()
        product = next((p for p in products if str(p["id"]) == product_id), None)
        current_category = product.get("type") if product else None

        await query.edit_message_text(
            f"Enter new category for product {product_id}\n"
            f"Current category: {current_category}\n\n"
            "Valid categories: fresh_accounts, cracked_accounts"
        )

        context.user_data["awaiting_product_input"] = True

    async def handle_product_edit_range(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle range editing for a product"""
        query = update.callback_query
        await query.answer()

        _, _, _, product_id = query.data.split("_", 3)

        context.user_data["editing_product_id"] = product_id
        context.user_data["editing_field"] = "range"

        products = await self.database.list_bot_products()
        product = next((p for p in products if str(p["id"]) == product_id), None)
        current_range = product.get("range", "None") if product else "None"

        await query.edit_message_text(
            f"Enter new follower range for product {product_id}\n"
            f"Current range: {current_range}\n\n"
            "Format: min-max (e.g. 10-99)\n"
            "Or type 'none' to remove the range"
        )

        context.user_data["awaiting_product_input"] = True

    async def handle_product_bulk_edit(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle bulk editing of products"""
        try:
            query = update.callback_query
            await query.answer()

            _, _, category = query.data.partition("_bulk_")

            if not category:
                await query.edit_message_text("Invalid category specified.")
                return

            products = []
            all_products = await ProductTypes.list_all_products()
            for product in all_products:
                if product.attributes.product_type.lower() == category.lower():
                    products.append(product)

            if not products:
                await query.edit_message_text(
                    f"No products found in category {category}."
                )
                return

            keyboard = [
                [
                    InlineKeyboardButton(
                        "✏️ Bulk Update Price", callback_data=f"bulk_price_{category}"
                    )
                ],
                [
                    InlineKeyboardButton(
                        "🔄 Toggle Mail Access for All",
                        callback_data=f"bulk_mail_{category}",
                    )
                ],
                [
                    InlineKeyboardButton(
                        "🔙 Back", callback_data="product_back_to_categories"
                    )
                ],
            ]

            await query.edit_message_text(
                f"*Bulk Edit {category.capitalize()} Products*\n\n"
                f"Found {len(products)} products in this category.\n"
                f"Select an action to apply to all products:",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown",
            )

        except Exception as e:
            self.debug.log(f"Error in handle_product_bulk_edit: {e}")
            await query.edit_message_text(f"❌ Error: {str(e)}")

    async def handle_product_cancel(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Cancel product editing"""
        try:
            query = update.callback_query
            await query.answer()
            await query.edit_message_text("Product editing cancelled.")
        except Exception as e:
            self.debug.log(f"Error in handle_product_cancel: {str(e)}")
            await query.edit_message_text(f"❌ Error: {str(e)}")

    @owner()
    async def defaults(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Reset to default products configuration from YAML"""
        try:
            yaml_file = os.path.join("database", "products.yml")
            if not os.path.exists(yaml_file):
                await update.message.reply_text(
                    "⚠️ products.yml file not found. Creating an empty one."
                )
                await ProductTypes.save_config()

            await self.database.clear_bot_products()
            await update.message.reply_text("🗑️ Cleared existing products")

            ProductTypes.load_config(force_reload=True)
            products_config = ProductTypes._product_config.get("products", {})

            if not products_config:
                await update.message.reply_text(
                    "⚠️ No products defined in YAML. Using default configuration."
                )
                return
            else:
                await update.message.reply_text(
                    "🔄 Loading products from YAML configuration..."
                )

                added_count = 0
                all_products_to_add = []

                for category_name, category_data in products_config.items():
                    if category_name == "normals":

                        if "categories" in category_data:
                            categories = category_data.get("categories", {})
                            all_products_to_add.extend(
                                [
                                    (subcategory_data, "normal")
                                    for subcategory_name, subcategory_data in categories.items()
                                    if isinstance(subcategory_data, dict)
                                    and "id" in subcategory_data
                                ]
                            )

                        if "ranges" in category_data:
                            ranges = category_data.get("ranges", {})
                            for range_name, range_variants in ranges.items():
                                all_products_to_add.extend(
                                    [
                                        (variant_data, "normal")
                                        for variant_name, variant_data in range_variants.items()
                                        if isinstance(variant_data, dict)
                                        and "id" in variant_data
                                    ]
                                )
                    else:

                        if isinstance(category_data, dict) and "id" in category_data:
                            all_products_to_add.append((category_data, category_name))

                success_count = 0
                for product_data, category_name in all_products_to_add:
                    if await self._add_product_from_yaml(product_data, category_name):
                        success_count += 1

                added_count = success_count

                await update.message.reply_text(
                    f"✅ Added {added_count} products from YAML configuration"
                )
                ProductTypes.load_config(force_reload=True)

            await self.update_sellapp_titles(update)
            return await self.settings(update, context)
        except Exception as e:
            self.debug.log(f"Error resetting products: {str(e)}")
            await update.message.reply_text(f"❌ Error resetting products: {str(e)}")
            return await self.settings(update, context)

    async def update_sellapp_titles(self, update: Update = None):
        """Update all product titles from SellApp"""
        try:
            products = await ProductTypes.list_all_products()
            if not products:
                if update:
                    await update.message.reply_text("No products found to update.")
                return

            titles = await asyncio.gather(
                *[
                    ProductTypes.fetch_and_cache_product_title(product.id)
                    for product in products
                ]
            )

            updated_count = sum(1 for title in titles if title)

            if update:
                await update.message.reply_text(
                    f"📝 Updated {updated_count}/{len(products)} product titles from SellApp"
                )
        except Exception as e:
            if update:
                await update.message.reply_text(
                    f"⚠️ Error updating SellApp titles: {str(e)}"
                )
            self.debug.log(f"Error updating SellApp titles: {str(e)}")

    async def _add_product_from_yaml(
        self, product_data: dict, category_name: str
    ) -> bool:
        """Add a product from YAML configuration to database"""
        try:

            product_id = product_data.get("id")
            if not product_id:
                self.debug.log(f"Skipping product without ID: {product_data}")
                return False

            attrs = product_data.get("attributes", {})

            product_type = category_name

            verifications = []
            if attrs.get("fully_verified"):
                verifications.append("fv")
            if attrs.get("unverified"):
                verifications.append("uv")
            if attrs.get("mixed"):
                verifications.append("mixed")

            fresh = bool(attrs.get("fresh", False))
            if fresh and "fresh" not in verifications:
                verifications.append("fresh")

            range_str = None
            if attrs.get("range"):
                try:
                    range_values = attrs.get("range")
                    if isinstance(range_values, list) and len(range_values) == 2:
                        range_str = f"{range_values[0]}-{range_values[1]}"
                except Exception as e:
                    self.debug.log(f"Error parsing range for product {product_id}: {e}")

            mail_access = bool(attrs.get("mail_access"))

            price = float(product_data.get("price", 0.0))

            title = product_data.get("title")
            description = product_data.get("description", "")

            if not title:
                title = await ProductTypes.fetch_and_cache_product_title(product_id)
                if not title:
                    title = f"{category_name.title()} Account"

            if (
                not fresh
                and title
                and ("fresh" in title.lower() or "2025" in title.lower())
            ):
                fresh = True
                if "fresh" not in verifications:
                    verifications.append("fresh")

            result = await ProductTypes.add_product(
                product_id=product_id,
                product_type=product_type,
                range_str=range_str,
                verifications=verifications,
                mail_access=mail_access,
                price=price,
                title=title,
                description=description,
                fresh=fresh,
            )

            return True

        except Exception as e:
            self.debug.log(
                f"Error adding product {product_data.get('id', 'unknown')}: {str(e)}"
            )
            return False

    async def handle_text_message(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle text messages based on the current state of the conversation."""
        if not update.message:
            return

        user_id = update.effective_user.id
        message_text = update.message.text if update.message.text else "None"
        self.debug.log(
            f"handle_text_message received: '{message_text}' from user {user_id}"
        )

        current_state = context.user_data.get("state")
        add_product_state = context.user_data.get("add_product_state")

        if message_text == "/cancel":
            return await self.cancel(update, context)

        if add_product_state:
            if add_product_state == "waiting_for_id":

                product_id = message_text.strip()
                if not product_id.isalnum():
                    await update.message.reply_text(
                        "❌ Invalid product ID. Please enter only alphanumeric characters."
                    )
                    return

                context.user_data["new_product_id"] = product_id
                context.user_data["add_product_state"] = "waiting_for_type"

                keyboard = [
                    [InlineKeyboardButton("❌ Cancel", callback_data="cancel_products")]
                ]
                await update.message.reply_text(
                    "*Select Product Type*\n\n"
                    "Please enter one of the following types:\n"
                    "• normal - Normal accounts\n"
                    "• blue - Blue verified accounts\n"
                    "• grey - Grey verified accounts\n"
                    "• gold - Gold verified accounts\n"
                    "• blueplus - Blue Plus accounts\n"
                    "• chars - Character accounts\n"
                    "• unverified - Unverified accounts\n\n"
                    "Send /cancel to abort.",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="Markdown",
                )
                return

            elif add_product_state == "waiting_for_type":
                product_type = message_text.strip().lower()
                valid_types = [
                    "normal",
                    "blue",
                    "grey",
                    "gold",
                    "blueplus",
                    "chars",
                    "unverified",
                ]

                if product_type not in valid_types:
                    await update.message.reply_text(
                        "❌ Invalid product type. Please enter one of the valid types listed above."
                    )
                    return

                context.user_data["new_product_type"] = product_type
                context.user_data["add_product_state"] = "waiting_for_price"

                keyboard = [
                    [InlineKeyboardButton("❌ Cancel", callback_data="cancel_products")]
                ]
                await update.message.reply_text(
                    "*Enter Product Price*\n\n"
                    "Please enter the price in USD (e.g. 10.99)\n\n"
                    "Send /cancel to abort.",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="Markdown",
                )
                return

            elif add_product_state == "waiting_for_price":
                try:
                    price = float(message_text.strip())
                    if price <= 0:
                        raise ValueError("Price must be positive")

                    context.user_data["new_product_price"] = price

                    product_id = context.user_data.get("new_product_id")
                    product_type = context.user_data.get("new_product_type")

                    success = await self.database.add_bot_product(
                        product_id=product_id,
                        product_type=product_type,
                        range_str=None,
                        verifications=[],
                        price=price,
                    )

                    if success:

                        context.user_data.pop("add_product_state", None)
                        context.user_data.pop("new_product_id", None)
                        context.user_data.pop("new_product_type", None)
                        context.user_data.pop("new_product_price", None)

                        await update.message.reply_text(
                            "✅ Product added successfully!\n\nReturning to product list..."
                        )
                        await self.edit_products(update, context)
                    else:
                        await update.message.reply_text(
                            "❌ Failed to add product. Please try again."
                        )
                except ValueError:
                    await update.message.reply_text(
                        "❌ Invalid price. Please enter a valid positive number (e.g. 10.99)."
                    )
                return

        if current_state == USER_STATE_WAITING_FOR_QUANTITY:
            await self.shop.handle_quantity_input(update, context)
        elif self.is_awaiting_product_input(update, context):
            await self.handle_product_input(update, context)
        elif current_state == USER_STATE_WAITING_FOR_COUPON:
            await self.shop.handle_coupon_input(update, context)
            return
        elif current_state == "waiting_for_email":
            email = update.message.text.strip()
            email_prompt = context.user_data.get("email_prompt")
            if email_prompt:
                try:
                    await email_prompt.delete()
                except Exception:
                    pass
            try:
                await update.message.delete()
            except Exception:
                pass
            if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                await update.message.reply_text(
                    "⚠️ Invalid email format. Please try again."
                )
                return
            context.user_data["email"] = email
            context.user_data["state"] = "waiting_for_gateway"
            await self.shop.prompt_gateway(update, context)
            return
        else:
            await self.handle_input(update, context)

    async def handle_settings_input(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        setting = context.user_data.get("current_setting")
        if not setting:
            return
        value = update.message.text.strip()
        if not any(
            [
                setting.startswith("setting_"),
                setting.startswith("edit_"),
                setting.startswith("add_product_"),
                setting
                in [
                    "coupon_code",
                    "coupon_discount",
                    "coupon_max_uses",
                    "coupon_delete",
                ],
            ]
        ):
            return
        try:
            if setting.startswith("setting_"):
                key = setting.replace("setting_", "")
                await self.database.update_setting(key, value)
                await update.message.reply_text(f"✅ Setting {key} updated to: {value}")
            elif setting in [
                "edit_price_per_follower",
                "edit_price_blue",
                "edit_price_blue_plus",
                "edit_price_grey_gold",
                "edit_price_chars",
                "edit_price_mstats",
            ]:
                try:
                    price = float(value)
                    if price <= 0:
                        raise ValueError
                    setting_map = {
                        "edit_price_per_follower": "PRICE_PER_FOLLOWER",
                        "edit_price_blue": "PRICE_BLUE",
                        "edit_price_blue_plus": "PRICE_BLUE_PLUS",
                        "edit_price_grey_gold": "PRICE_GREY_GOLD",
                        "edit_price_chars": "PRICE_CHARS",
                        "edit_price_mstats": "PRICE_MSTATS",
                    }
                    config_key = setting_map[setting]
                    if self.update_config(config_key, price):
                        setattr(self.config, config_key, price)
                        await update.message.reply_text(
                            f"✅ {config_key} updated to: ${price:.2f}"
                        )
                    else:
                        await update.message.reply_text(
                            "❌ Failed to update config file"
                        )
                except ValueError:
                    await update.message.reply_text(
                        "⚠️ Please enter a valid positive number"
                    )
                    return
            elif setting == "edit_sellapp_api_key":
                new_api_key = value
                if len(new_api_key) < 10:
                    await update.message.reply_text(
                        "⚠️ API key seems too short. Please enter a valid key."
                    )
                    await self.settings(update, context)
                    return

                old_api_key = self.config.SELL_APP_API_KEY
                old_shop_instance = self.shop

                self.config.SELL_APP_API_KEY = new_api_key

                try:
                    self.debug.log(
                        f"Attempting to re-initialize ShopModule with new API key: {new_api_key[:6]}..."
                    )
                    self.shop = ShopModule(self)
                    self.debug.log(
                        "ShopModule re-initialized successfully with new API key."
                    )

                    if self.update_config("SELL_APP_API_KEY", new_api_key):
                        await update.message.reply_text(
                            "✅ SellApp API key updated, verified, and saved to config.py."
                        )
                    else:
                        await update.message.reply_text(
                            "✅ SellApp API key updated and verified for this session. "
                            "However, it FAILED to save to config.py. "
                            "The change will be lost on next restart unless config.py is manually corrected."
                        )
                except ValueError as e:
                    self.config.SELL_APP_API_KEY = old_api_key
                    self.shop = old_shop_instance
                    if "Invalid API key" in str(e):
                        self.debug.log(
                            f"New API key {new_api_key[:6]}... is invalid. Reverted."
                        )
                        await update.message.reply_text(
                            "❌ The new API key is invalid. Your API key has NOT been changed."
                        )
                    else:
                        self.debug.log(
                            f"ValueError during ShopModule re-init with new API key: {e}\\n{traceback.format_exc()}"
                        )
                        await update.message.reply_text(
                            f"❌ An error occurred while applying the new key: {e}. "
                            "Your API key has NOT been changed."
                        )
                except Exception as e:
                    self.config.SELL_APP_API_KEY = old_api_key
                    self.shop = old_shop_instance
                    self.debug.log(
                        f"Unexpected error during ShopModule re-init: {e}\\n{traceback.format_exc()}"
                    )
                    await update.message.reply_text(
                        f"❌ A critical error occurred: {e}. "
                        "Your API key has NOT been changed."
                    )
                finally:
                    await self.settings(update, context)
            elif setting in ["edit_change_pfp", "edit_debug_webhook"]:
                value = value.lower() in ["true", "1", "yes", "on"]
                setting_map = {
                    "edit_change_pfp": "CHANGE_PFP_ON_CHECK_NORMALS",
                    "edit_debug_webhook": "DEBUG_WEBHOOK",
                }
                config_key = setting_map[setting]
                if self.update_config(config_key, value):
                    setattr(self.config, config_key, value)
                    await update.message.reply_text(f"✅ {config_key} set to: {value}")
                else:
                    await update.message.reply_text("❌ Failed to update config file")
            elif setting.startswith("edit_crypto_"):
                coin = setting.replace("edit_crypto_", "")
                if not value.strip():
                    await update.message.reply_text("⚠️ Address cannot be empty")
                    return
                addresses = self.config.CRYPTO_ADDRESSES.copy()
                addresses[coin] = value
                if self.update_config("CRYPTO_ADDRESSES", addresses):
                    self.config.CRYPTO_ADDRESSES = addresses
                    await update.message.reply_text(f"✅ {coin} address updated")
                else:
                    await update.message.reply_text("❌ Failed to update config file")
            elif setting == "edit_owners":
                try:
                    owners = [int(x.strip()) for x in value.split(",")]
                    if self.update_config("OWNERS", owners):
                        self.config.OWNERS = owners
                        await update.message.reply_text(
                            f"✅ Bot owners updated to: {owners}"
                        )
                    else:
                        await update.message.reply_text(
                            "❌ Failed to update config file"
                        )
                except ValueError:
                    await update.message.reply_text(
                        "⚠️ Please enter valid user IDs separated by commas"
                    )
                    return
            elif setting.startswith("add_product_"):
                field = setting.replace("add_product_", "")
                context.user_data[f"product_{field}"] = value
                if field == "id":
                    await update.message.reply_text(
                        "Enter product type (e.g. normal, blue, chars):"
                    )
                    context.user_data["current_setting"] = "add_product_type"
                elif field == "type":
                    await update.message.reply_text(
                        "Enter follower range (format: min-max or 0 for N/A)\n"
                        "Examples:\n• 1000-2000\n• 5000-10000\n• 0"
                    )
                    context.user_data["current_setting"] = "add_product_range"
                elif field == "range":
                    try:
                        if value != "0":
                            range_parts = value.split("-")
                            if len(range_parts) == 2:
                                min_val, max_val = map(int, range_parts)
                                if min_val >= max_val:
                                    raise ValueError(
                                        "Min value must be less than max value"
                                    )
                            else:
                                raise ValueError("Invalid range format")
                    except ValueError as e:
                        await update.message.reply_text(
                            f"⚠️ Invalid range format: {str(e)}"
                        )
                        return
                    product_data = {
                        "id": context.user_data.get("product_id"),
                        "type": context.user_data.get("product_type"),
                        "range": value if value != "0" else None,
                        "verifications": [],
                        "mail_access": False,
                    }
                    if await self.database.add_bot_product(**product_data):
                        await update.message.reply_text(
                            "✅ Product added successfully!"
                        )
                    else:
                        await update.message.reply_text("❌ Failed to add product")
                    context.user_data.clear()
            elif setting == "edit_default_confirmations":
                try:
                    confirmations = int(value)
                    if confirmations < 1:
                        raise ValueError
                    confirmations_dict = getattr(
                        self.config, "CONFIRMATIONS_REQUIRED", {}
                    ).copy()
                    confirmations_dict["DEFAULT"] = confirmations
                    if self.update_config("CONFIRMATIONS_REQUIRED", confirmations_dict):
                        self.config.CONFIRMATIONS_REQUIRED = confirmations_dict
                        await update.message.reply_text(
                            f"✅ Default confirmations set to: {confirmations}"
                        )
                    else:
                        await update.message.reply_text(
                            "❌ Failed to update config file"
                        )
                except ValueError:
                    await update.message.reply_text(
                        "⚠️ Please enter a valid positive number"
                    )
                    return
        except Exception as e:
            self.debug.log(f"Settings input error: {e}")
            await update.message.reply_text(f"❌ Error updating setting: {str(e)}")
        finally:
            if setting and any(
                [
                    setting.startswith("setting_"),
                    setting.startswith("edit_"),
                    setting.startswith("add_product_"),
                ]
            ):
                context.user_data["current_setting"] = None

    @owner()
    async def backup(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        try:
            db_path = "database/production.db"
            if not os.path.exists(db_path):
                await update.message.reply_text("❌ Database file not found!")
                return
            await update.message.reply_document(
                document=open(db_path, "rb"),
                filename="production.db",
                caption="📦 Here's your database backup",
            )
        except Exception as e:
            await update.message.reply_text(f"❌ Error sending backup: {str(e)}")

    @owner()
    async def update_database(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        await update.message.reply_text("Please upload the .db file now.")
        return WAITING_DB

    async def handle_db_upload(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        if (
            not update.message.document
            or not update.message.document.file_name.endswith(".db")
        ):
            await update.message.reply_text(
                "⚠️ Please upload a valid database (.db) file."
            )
            return WAITING_DB
        context.user_data["db_file"] = update.message.document
        keyboard = [
            [
                InlineKeyboardButton("✅ Yes", callback_data="confirm_db_update"),
                InlineKeyboardButton("❌ No", callback_data="cancel_db_update"),
            ]
        ]
        await update.message.reply_text(
            "⚠️ *Warning: Database Update*\n\nThis will replace your current database.\n"
            "A backup will be created automatically.\n\nAre you sure you want to continue?",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown",
        )
        return ConversationHandler.END

    async def handle_database_confirmation(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        query = update.callback_query
        await query.answer()
        if query.data == "cancel_db_update":
            await query.edit_message_text("❌ Database update cancelled.")
            context.user_data.pop("db_file", None)
            return
        msg = await query.edit_message_text("⏳ Processing database update...")
        try:
            backup_dir = "database/backups"
            os.makedirs(backup_dir, exist_ok=True)
            new_file = await context.bot.get_file(context.user_data["db_file"].file_id)
            temp_path = "database/temp_production.db"
            db_path = "database/production.db"
            await new_file.download_to_drive(temp_path)
            try:
                conn = sqlite3.connect(temp_path)
                conn.close()
            except sqlite3.Error:
                os.remove(temp_path)
                await msg.edit_text("❌ Invalid database file!")
                return
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = os.path.join(backup_dir, f"backup_{timestamp}.db")
            if os.path.exists(db_path):
                shutil.copy2(db_path, backup_path)
                self.debug.log(f"Created backup at: {backup_path}")
            shutil.move(temp_path, db_path)
            await msg.edit_text(
                "✅ Database updated!\n\n"
                f"📂 Backup: `backup_{timestamp}.db`\n"
                "🔄 Restarting bot...",
                parse_mode="Markdown",
            )
            await context.bot.send_document(
                chat_id=update.effective_chat.id,
                document=open(backup_path, "rb"),
                filename=f"backup_{timestamp}.db",
            )
            await self.debug.notify_owner(
                "Bot is undergoing a database update and will be restarted."
            )
            await asyncio.sleep(1)
            python = sys.executable
            os.execl(python, python, *sys.argv)
        except Exception as e:
            self.debug.log(f"Database update error: {str(e)}")
            if os.path.exists(temp_path):
                os.remove(temp_path)
            await msg.edit_text(
                f"❌ Error updating database: `{str(e)}`", parse_mode="Markdown"
            )
        finally:
            context.user_data.pop("db_file", None)

    async def handle_coupon_code(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        code = update.message.text.strip().upper()
        context.user_data["coupon_code"] = code
        if context.user_data.get("current_setting") == "coupon_delete":
            if await self.coupon_manager.delete_coupon(code):
                await update.message.reply_text(
                    f"✅ Coupon `{code}` deleted successfully!", parse_mode="Markdown"
                )
            else:
                await update.message.reply_text("❌ Coupon not found!")
            return ConversationHandler.END
        await update.message.reply_text("Enter discount percentage (1-99):")
        context.user_data["current_setting"] = "coupon_discount"
        return COUPON_DISCOUNT

    async def handle_coupon_discount(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        try:
            discount = float(update.message.text)
            if not 0 < discount < 100:
                raise ValueError
            context.user_data["coupon_discount"] = discount
            await update.message.reply_text("Enter max uses (0 for unlimited):")
            context.user_data["current_setting"] = "coupon_max_uses"
            return COUPON_MAX_USES
        except ValueError:
            await update.message.reply_text(
                "⚠️ Please enter a valid discount percentage between 1 and 99"
            )
            return COUPON_DISCOUNT

    async def handle_coupon_max_uses(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        max_uses = update.message.text.strip()
        if max_uses:
            try:
                max_uses = int(max_uses)
                if max_uses < 0:
                    raise ValueError
            except ValueError:
                await update.message.reply_text(
                    "⚠️ Please enter a valid number for max uses or 0 for unlimited"
                )
                return COUPON_MAX_USES
        else:
            max_uses = 0
        context.user_data["coupon_max_uses"] = max_uses
        await update.message.reply_text(
            "Enter expiry in days (0 for no expiry):\nExamples:\n• 7 = Expires in 7 days\n• 30 = Expires in 30 days\n• 0 = Never expires"
        )
        return COUPON_EXPIRY

    async def handle_coupon_callback(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        query = update.callback_query
        await query.answer()
        action = query.data.split("_")[1]
        if action == "custom":
            await query.edit_message_text("Enter the coupon code:")
            context.user_data["current_setting"] = "coupon_code"
            return COUPON_CODE
        elif action == "random":
            code = self.coupon_manager.generate_code()
            context.user_data["coupon_code"] = code
            await query.edit_message_text(
                f"Generated code: {code}\nEnter discount percentage (1-99):"
            )
            context.user_data["current_setting"] = "coupon_discount"
            return COUPON_DISCOUNT
        elif action == "delete":
            await query.edit_message_text("Enter the coupon code to delete:")
            context.user_data["current_setting"] = "coupon_delete"
            return COUPON_CODE
        return ConversationHandler.END

    async def handle_coupon_expiry(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        try:
            expiry_days = int(update.message.text.strip())
            if expiry_days < 0:
                raise ValueError
            code = context.user_data["coupon_code"]
            discount = context.user_data["coupon_discount"]
            max_uses = context.user_data["coupon_max_uses"]
            if await self.coupon_manager.add_coupon(
                code, discount, max_uses, expiry_days if expiry_days > 0 else None
            ):
                expiry_text = (
                    f"\nExpires in: {expiry_days} days"
                    if expiry_days > 0
                    else "\nNo expiry date"
                )
                await update.message.reply_text(
                    f"✅ Coupon created successfully!\nCode: `{code}`\nDiscount: {discount}%\n"
                    f"Max Uses: {max_uses or 'Unlimited'}{expiry_text}",
                    parse_mode="Markdown",
                )
                context.user_data.clear()
                return ConversationHandler.END
            else:
                await update.message.reply_text("❌ Coupon code already exists!")
                context.user_data.clear()
                return ConversationHandler.END
        except ValueError:
            await update.message.reply_text(
                "⚠️ Please enter a valid number of days or 0 for no expiry"
            )
            return COUPON_EXPIRY

    @owner()
    async def fix_followers(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        msg = await update.message.reply_text("🔄 Fixing follower counts...")
        try:
            await self.database.fix_follower_counts()
            await msg.edit_text(
                "✅ Successfully fixed follower/following counts in all tables."
            )
        except Exception as e:
            await msg.edit_text(f"❌ Error fixing follower counts: {str(e)}")
            self.debug.log(f"Error in fix_followers: {e}")

    @owner()
    async def migrate_chars(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        msg = await update.message.reply_text(
            "🔄 Migrating char accounts from normals to chars table..."
        )
        try:
            migrated, failed = await self.database.migrate_chars_accounts()
            await msg.edit_text(
                "🚀 Migration complete!\n\n"
                f"✅ Successful: {migrated}\n❌ Failed: {failed}"
            )
        except Exception as e:
            await msg.edit_text(f"❌ Error migrating characters: {str(e)}")
            self.debug.log(f"Error in migrate_chars: {e}")

    @owner()
    async def fix_migration(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        msg = await update.message.reply_text("🔄 Fixing migration issues...")
        try:
            await self.database.fix_migration()
            await msg.edit_text("✅ Successfully fixed migration issues.")
        except Exception as e:
            await msg.edit_text(f"❌ Error fixing migration issues: {str(e)}")
            self.debug.log(f"Error in fix_migration: {e}")

    async def payment_settings(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        try:
            addresses = {
                f"{coin}_ADDRESS": addr
                for coin, addr in self.config.CRYPTO_ADDRESSES.items()
            }
            keyboard = [
                [InlineKeyboardButton("📑 Crypto Addresses", callback_data="page_info")]
            ]
            for coin, address in addresses.items():
                display_addr = (
                    f"{address[:6]}...{address[-4:]}" if address else "Not Set"
                )
                keyboard.append(
                    [
                        InlineKeyboardButton(
                            f"{coin}: {display_addr}",
                            callback_data=f"edit_crypto_{coin}",
                        )
                    ]
                )
            keyboard.extend(
                [
                    [
                        InlineKeyboardButton(
                            "📑 Payment Confirmations", callback_data="page_info"
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            f"Default Confirmations: {self.config.CONFIRMATIONS_REQUIRED.get('DEFAULT', 6)}",
                            callback_data="edit_default_confirmations",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "📑 Payment Tolerances", callback_data="page_info"
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            f"Default Tolerance: {self.config.PAYMENT_TOLERANCE.get('DEFAULT', 0.98)}",
                            callback_data="edit_default_tolerance",
                        )
                    ],
                    [InlineKeyboardButton("🔙 Back", callback_data="settings")],
                ]
            )
            reply_markup = InlineKeyboardMarkup(keyboard)
            message = "*Payment Settings*\nSelect a setting to modify:"
            if update.callback_query:
                await update.callback_query.edit_message_text(
                    message, reply_markup=reply_markup, parse_mode="Markdown"
                )
            else:
                await update.message.reply_text(
                    message, reply_markup=reply_markup, parse_mode="Markdown"
                )
        except Exception as e:
            self.debug.log(f"Error in payment settings: {e}")

    async def handle_crypto_setting(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        query = update.callback_query
        setting = query.data.replace("edit_crypto_", "")
        if setting not in self.config.CRYPTO_ADDRESSES:
            await query.answer("Invalid setting")
            return
        context.user_data["current_setting"] = setting
        await query.edit_message_text(
            f"Enter new address for {setting}:\nSend /cancel to cancel"
        )

    async def add_product(self, product_data: dict):
        """Add a product to the database and SellApp with title fetching"""
        try:
            product_id = product_data.get("id", "")
            product_type = product_data.get("product_type", "normal")
            range_str = product_data.get("range_str")
            verifications = product_data.get("verifications", [])
            mail_access = product_data.get("mail_access", False)
            price = product_data.get("price", 0.0)
            title = product_data.get("title", "")

            if not title:
                title = await ProductTypes.fetch_and_cache_product_title(product_id)

            fresh = product_data.get("fresh", False)
            if (
                not fresh
                and title
                and ("fresh" in title.lower() or "2025" in title.lower())
            ):
                fresh = True

                if "fresh" not in verifications:
                    verifications = list(verifications)
                    verifications.append("fresh")

            await ProductTypes.add_product(
                product_id=product_id,
                product_type=product_type,
                range_str=range_str,
                verifications=verifications,
                mail_access=mail_access,
                price=float(price),
                title=title,
                fresh=fresh,
            )

            return True
        except Exception as e:
            self.debug.log(f"Error adding product: {e}")
            print(f"Error adding product: {e}")
            return False

    @owner()
    async def order_by_uuid(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not context.args or len(context.args) < 1:
            await update.message.reply_text("Usage: /order <invoice_uuid>")
            return
        invoice_uuid = context.args[0]
        order = await self.database.get_order_by_uuid(invoice_uuid)
        if not order:
            sellapp_order = self.shop.sellapp.get_order(invoice_uuid)
            if not sellapp_order or "data" not in sellapp_order:
                await update.message.reply_text(
                    f"Order with UUID {invoice_uuid} not found."
                )
                return
            order_data = sellapp_order["data"]
            payment = order_data.get("payment", {})
            status = order_data.get("status", {}).get("status", {})
            customer = order_data.get("customer_information", {})
            product_title = order_data.get("product", {}).get("title", "N/A")
            overview = (
                f"📄 <b>SellApp Order Overview</b>\n\n"
                f"Invoice ID: <code>{invoice_uuid}</code>\n"
                f"Product: {product_title}\n"
                f"Status: {status.get('status', 'Unknown')}\n"
                f"Customer Email: <code>{customer.get('email', 'N/A')}</code>\n"
                f"Customer Location: {customer.get('location', 'N/A')}, {customer.get('country', 'N/A')}\n"
                f"Customer IP: <code>{customer.get('ip', 'N/A')}</code>\n\n"
                f"Payment Details:\n"
                f"Gateway: {payment.get('gateway', {}).get('type', 'N/A')}\n"
                f"Transaction ID: <code>{payment.get('gateway', {}).get('data', {}).get('transaction_id', 'N/A')}</code>\n"
                f"Amount: {payment.get('full_price', {}).get('base', 'N/A')} {payment.get('full_price', {}).get('currency', 'USD')}\n"
                f"Created At: {order_data.get('created_at', 'N/A')}\n"
                f"Updated At: {order_data.get('updated_at', 'N/A')}\n"
                f"Expires At: {payment.get('expires_at', 'N/A')}"
            )
        else:
            product_title = order.get("product_title", "N/A")
            overview = (
                f"📄 <b>Order Overview</b>\n\n"
                f"Invoice ID: <code>{order['order_id']}</code>\n"
                f"Telegram User ID: <code>{order['user_id']}</code>\n"
                f"Product ID: <code>{order['product_id']}</code>\n"
                f"Product: {product_title}\n"
                f"Quantity: {order['quantity']}\n"
                f"Total Amount: {order['total_amount']}\n"
                f"Status: {order['status']}\n"
                f"Payment Address: <code>{order.get('payment_address', 'N/A')}</code>\n"
                f"Payment TxID: <code>{order.get('payment_txid', 'N/A')}</code>\n"
                f"Payment Amount: {order.get('payment_amount', 'N/A')}\n"
                f"Payment Currency: {order.get('payment_currency', 'N/A')}\n"
                f"Created At: {order.get('created_at', 'N/A')}\n"
                f"Completed At: {order.get('completed_at', 'N/A')}\n"
            )
        await update.message.reply_text(overview, parse_mode="HTML")

    @owner()
    async def clear_products(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Clear all products"""
        try:

            keyboard = [
                [
                    InlineKeyboardButton(
                        "Yes, clear all", callback_data="confirm_clear_products"
                    ),
                    InlineKeyboardButton(
                        "No, cancel", callback_data="cancel_clear_products"
                    ),
                ]
            ]

            await update.message.reply_text(
                "⚠️ *Are you sure you want to clear ALL products?*\n\n"
                "This will delete all products from both the database and YAML configuration. "
                "This action cannot be undone!",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown",
            )

        except Exception as e:
            self.debug.log(f"Error in clear_products: {e}")
            await update.message.reply_text(f"❌ Error: {str(e)}")

    async def handle_clear_products(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle confirmation for clearing all products"""
        try:
            query = update.callback_query
            await query.answer()

            if query.data == "cancel_clear_products":
                await query.edit_message_text(
                    "Operation cancelled. Products were not cleared."
                )
                return

            result = await self.database.clear_bot_products()

            if result:

                ProductTypes.load_config()
                ProductTypes._product_config["products"] = {}
                ProductTypes.save_config()

                ProductTypes._products_cache.clear()
                ProductTypes.invalidate_stock_cache()

                await query.edit_message_text(
                    "✅ All products have been cleared from both database and YAML configuration."
                )
            else:
                await query.edit_message_text(
                    "❌ Failed to clear products from database."
                )

        except Exception as e:
            self.debug.log(f"Error in handle_clear_products: {e}")
            await query.edit_message_text(f"❌ Error: {str(e)}")

    @owner()
    async def stock_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show detailed stock status with the new model"""
        try:

            products = await ProductTypes.list_all_products()

            if not products:
                await update.message.reply_text("No products found.")
                return

            stock_counts = {}
            for product in products:
                count = await ProductTypes.get_stock_count_for_product(product)
                stock_counts[product.id] = count

            output = ["📊 *Stock Status*\n"]

            grouped = {}
            for product in products:
                product_type = product.attributes.product_type
                if product_type not in grouped:
                    grouped[product_type] = []
                grouped[product_type].append(product)

            for product_type, type_products in grouped.items():
                output.append(f"\n*{product_type.upper()} ACCOUNTS*")
                total_type_stock = sum(stock_counts[p.id] for p in type_products)
                output.append(f"Total stock: {total_type_stock} accounts")

                fresh_products = [
                    p
                    for p in type_products
                    if hasattr(p.attributes, "fresh") and p.attributes.fresh
                ]
                if fresh_products:
                    fresh_stock = sum(stock_counts[p.id] for p in fresh_products)
                    output.append(f"Fresh 2025 accounts: {fresh_stock}")

                for product in type_products:
                    count = stock_counts[product.id]
                    status = (
                        "✅ Good"
                        if count > 10
                        else "⚠️ Low" if count > 0 else "❌ Out of stock"
                    )

                    display_title = product.title
                    if (
                        hasattr(product.attributes, "fresh")
                        and product.attributes.fresh
                        and "fresh" not in display_title.lower()
                        and "2025" not in display_title.lower()
                    ):
                        display_title = f"🆕 Fresh 2025 - {display_title}"

                    output.append(f"• {display_title}: {count} accounts - {status}")

                    attrs = []
                    if product.attributes.mail_access:
                        attrs.append("Email Access")
                    if product.attributes.fully_verified:
                        attrs.append("Fully Verified")
                    if product.attributes.unverified:
                        attrs.append("Unverified")
                    if product.attributes.mixed:
                        attrs.append("Mixed")
                    if product.attributes.range:
                        attrs.append(
                            f"{product.attributes.range[0]}-{product.attributes.range[1]} Followers"
                        )
                    if (
                        hasattr(product.attributes, "fresh")
                        and product.attributes.fresh
                    ):
                        attrs.append("Fresh 2025")

                    if attrs:
                        output.append(f"  ({', '.join(attrs)})")

            all_fresh_products = [
                p
                for p in products
                if hasattr(p.attributes, "fresh") and p.attributes.fresh
            ]
            if all_fresh_products:
                total_fresh_stock = sum(stock_counts[p.id] for p in all_fresh_products)
                fresh_summary = f"\n🆕 *FRESH 2025 ACCOUNTS*: {total_fresh_stock} total across all categories\n"
                output.insert(1, fresh_summary)

            message = "\n".join(output)
            if len(message) > 4000:
                chunks = [message[i : i + 4000] for i in range(0, len(message), 4000)]
                for i, chunk in enumerate(chunks):
                    if i == 0:
                        await update.message.reply_text(chunk, parse_mode="Markdown")
                    else:
                        await update.message.reply_text(chunk, parse_mode="Markdown")
            else:
                await update.message.reply_text(message, parse_mode="Markdown")
        except Exception as e:
            self.debug.log(f"Error in stock_status: {e}")
            await update.message.reply_text(f"❌ Error: {str(e)}")

    async def get_dashboard_stats(self):
        """Get statistics for the dashboard"""
        try:
            products = await self.db.list_bot_products()

            product_types = {}
            for p in products:
                try:
                    attrs = await ProductTypes.get_product_attributes(p["id"])
                    if attrs:
                        if attrs.product_type not in product_types:
                            product_types[attrs.product_type] = []
                        product_types[attrs.product_type].append(p)
                except Exception:
                    continue

            stats = {}
            for product_type, type_products in product_types.items():
                try:
                    counts = await asyncio.gather(
                        *[
                            ProductTypes.get_stock_count_for_product(p)
                            for p in type_products
                        ]
                    )
                    stats[product_type] = sum(counts)
                except Exception:
                    stats[product_type] = 0

            return stats

        except Exception:
            return {}

    async def handle_product_back(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle back button to return to product list"""
        try:
            query = update.callback_query
            await query.answer()

            if "back_to_categories" in query.data:

                await self.edit_products(update, context)
            else:

                parts = query.data.split("_")
                if len(parts) > 2 and parts[-2] == "to" and parts[-1] == "product":
                    product_id = parts[2]

                    callback_data = f"product_edit_{product_id}"

                    context.user_data["callback_data"] = callback_data
                    await self.handle_product_edit(update, context)
                else:

                    await self.edit_products(update, context)

        except Exception as e:
            self.debug.log(f"Error in handle_product_back: {e}")
            await query.edit_message_text(f"❌ Error: {str(e)}")

    @owner()
    async def update_titles(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Command to update all product titles from SellApp"""
        message = await update.message.reply_text("🔄 Fetching products...")

        try:

            products = await ProductTypes.list_all_products()
            await message.edit_text(
                f"🔍 Found {len(products)} products. Updating titles from SellApp..."
            )

            updated_count = 0
            failed_count = 0
            skipped_count = 0

            status_update_interval = 5

            async def update_title(product):
                nonlocal updated_count, skipped_count, failed_count

                new_title = await ProductTypes.fetch_and_cache_product_title(product.id)

                if new_title:
                    if product.title != new_title:
                        updated_count += 1
                        return "updated"
                    else:
                        skipped_count += 1
                        return "skipped"
                else:
                    failed_count += 1
                    return "failed"

            results = await asyncio.gather(
                *[update_title(product) for product in products]
            )

            for i in range(0, len(products), status_update_interval):
                progress = min(100, (i + status_update_interval) / len(products) * 100)
                await message.edit_text(
                    f"🔄 Updating product titles: {i+min(status_update_interval, len(products)-i)}/{len(products)} ({progress:.1f}%)\n"
                    f"✅ Updated: {updated_count} | ⏭️ Same title: {skipped_count} | ❌ Failed: {failed_count}"
                )

            await message.edit_text(
                f"✅ Title update complete!\n\n"
                f"📊 Results:\n"
                f"• Total products: {len(products)}\n"
                f"• Titles updated: {updated_count}\n"
                f"• Already correct: {skipped_count}\n"
                f"• Failed to update: {failed_count}"
            )
        except Exception as e:
            self.debug.log(f"Error updating SellApp titles: {str(e)}")
            await message.edit_text(f"❌ Error updating product titles: {str(e)}")

        await asyncio.sleep(3)
        await self.settings(update, context)

    async def handle_add_product(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """Handle adding a new product"""
        query = update.callback_query
        await query.answer()

        try:

            context.user_data["add_product_state"] = "waiting_for_id"

            message = (
                "*Add New Product*\n\n"
                "Please enter the SellApp product ID.\n\n"
                "You can find this in your SellApp dashboard or product URL.\n"
                "Example: `12345` from `https://sell.app/p/12345`\n\n"
                "Send /cancel to abort."
            )

            keyboard = [
                [InlineKeyboardButton("❌ Cancel", callback_data="cancel_products")]
            ]

            await query.edit_message_text(
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown",
            )

        except Exception as e:
            self.debug.log(f"Error in handle_add_product: {e}")
            await query.edit_message_text(
                "❌ Error starting product creation. Please try again."
            )

    @owner()
    async def retrieve_order(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Retrieve an order text file by order_id and send it to the owner."""
        if not context.args or len(context.args) < 1:
            await update.message.reply_text(
                "❌ Please provide an order ID.\n\nUsage: /retrieve <order_id>"
            )
            return

        order_id = context.args[0]
        tmp_dir = Path("tmp")
        file_path = tmp_dir / f"{order_id}.txt"

        if not file_path.exists():
            await update.message.reply_text(
                f"❌ Order file not found for order ID: {order_id}\n\n"
                f"Make sure the order ID is correct and the file exists in the tmp directory."
            )
            return

        try:

            with open(file_path, "rb") as f:
                await update.message.reply_document(
                    document=f,
                    filename=f"order_{order_id}.txt",
                    caption=f"📂 Order content for ID: {order_id}",
                )

            self.debug.log(f"Retrieved order content for ID: {order_id}")

        except Exception as e:
            error_trace = traceback.format_exc()
            await update.message.reply_text(
                f"❌ Error retrieving order content: {str(e)}"
            )
            self.debug.log(f"Error retrieving order {order_id}: {error_trace}")

    async def periodic_backup(self):
        while True:
            try:
                await self.database.create_backup()
                await self.database.cleanup_old_backups()
            except Exception as e:
                pass
            await asyncio.sleep(3600)

    @owner()
    async def change_pfp_zip(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        """Start the process of uploading a ZIP file to replace PFPs"""
        keyboard = [
            [InlineKeyboardButton("Human PFPs", callback_data="zip_type_human")],
            [InlineKeyboardButton("NFT PFPs", callback_data="zip_type_nft")],
            [InlineKeyboardButton("❌ Cancel", callback_data="zip_cancel")],
        ]
        await update.message.reply_text(
            "🖼️ *Replace Profile Pictures*\n\n"
            "Choose which type of PFPs you want to replace:\n"
            "• Human - Regular human profile pictures\n"
            "• NFT - NFT-style profile pictures\n\n"
            "The uploaded ZIP file will replace all existing PFPs in the selected folder.",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown",
        )
        return WAITING_ZIP_TYPE

    async def handle_zip_type_selection(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        """Handle the selection of PFP type for ZIP upload"""
        query = update.callback_query
        await query.answer()

        if query.data == "zip_cancel":
            await query.edit_message_text("❌ Operation cancelled.")
            return ConversationHandler.END

        pfp_type = query.data.split("_")[-1]
        context.user_data["pfp_type"] = pfp_type

        await query.edit_message_text(
            f"📤 Please upload the ZIP file containing the new {pfp_type.upper()} profile pictures.\n\n"
            "Requirements:\n"
            "• File must be in ZIP format\n"
            "• Images should be in JPG/PNG format\n"
            "• Maximum file size: 20MB\n\n"
            "Send /cancel to abort."
        )
        return WAITING_ZIP_FILE

    async def handle_zip_upload(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        """Handle the uploaded ZIP file for PFP replacement"""
        try:
            if (
                not update.message.document
                or not update.message.document.file_name.endswith(".zip")
            ):
                await update.message.reply_text("⚠️ Please upload a valid ZIP file.")
                return WAITING_ZIP_FILE

            pfp_type = context.user_data.get("pfp_type")
            if not pfp_type:
                await update.message.reply_text(
                    "❌ Error: PFP type not specified. Please start over."
                )
                return ConversationHandler.END

            msg = await update.message.reply_text("⏳ Processing ZIP file...")

            file = await context.bot.get_file(update.message.document.file_id)
            zip_path = f"tmp/pfp_upload_{update.effective_user.id}.zip"
            await file.download_to_drive(zip_path)

            target_dir = f"database/pfps/{pfp_type}"
            if os.path.exists(target_dir):
                shutil.rmtree(target_dir)

            os.makedirs(target_dir, exist_ok=True)

            import zipfile

            with zipfile.ZipFile(zip_path, "r") as zip_ref:

                image_files = [
                    f
                    for f in zip_ref.namelist()
                    if f.lower().endswith((".png", ".jpg", ".jpeg"))
                ]

                if not image_files:
                    os.remove(zip_path)
                    await msg.edit_text(
                        "❌ No valid image files found in the ZIP file."
                    )
                    return ConversationHandler.END

                for image in image_files:
                    zip_ref.extract(image, target_dir)

            os.remove(zip_path)

            await msg.edit_text(
                f"✅ Successfully replaced {pfp_type.upper()} profile pictures!\n\n"
                f"📊 Statistics:\n"
                f"• Images processed: {len(image_files)}\n"
                f"• Old PFPs removed: Yes"
            )

            return ConversationHandler.END

        except Exception as e:
            self.debug.log(f"Error processing ZIP file: {e}")
            await update.message.reply_text(f"❌ Error processing ZIP file: {str(e)}")
            return ConversationHandler.END

    @owner()
    async def maintenance(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Toggle maintenance mode and update the buy command handler."""
        try:

            new_state = not config.MAINTENANCE
            config.MAINTENANCE = new_state

            config_path = "config.py"
            with open(config_path, "r") as f:
                content = f.read()

            import re

            updated_content = re.sub(
                r"MAINTENANCE\s*=\s*(True|False)",
                f"MAINTENANCE = {str(new_state)}",
                content,
            )

            with open(config_path, "w") as f:
                f.write(updated_content)

            status = "enabled" if config.MAINTENANCE else "disabled"
            await update.message.reply_text(
                f"✅ Maintenance mode {status}. /buy command is now {'disabled' if config.MAINTENANCE else 'enabled'}."
            )

            app = context.application

            handlers_to_remove = []
            if hasattr(app, "handlers") and 0 in app.handlers:
                for handler in app.handlers[0]:
                    if (
                        isinstance(handler, CommandHandler)
                        and "buy" in handler.commands
                    ):
                        handlers_to_remove.append(handler)

                for handler in handlers_to_remove:
                    app.remove_handler(handler, 0)

            if config.MAINTENANCE:
                app.add_handler(CommandHandler("buy", self.buy_disabled), 0)
            else:
                app.add_handler(CommandHandler("buy", self.shop.cmd_products), 0)

            self.debug.log(f"Maintenance mode toggled to: {new_state}")

        except Exception as e:
            error_trace = traceback.format_exc()
            self.debug.log(f"Error toggling maintenance mode: {error_trace}")
            await update.message.reply_text(
                f"❌ Failed to toggle maintenance mode: {str(e)}"
            )

    async def subscribe_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        from_button: bool = False,
    ):
        user_id = update.effective_user.id
        source = "button" if from_button else "command"
        self.debug.log(f"🔔 Subscription attempt via {source} by user ID: {user_id}")

        if await self.database.is_subscribed(user_id):
            message = "🎉 You are already subscribed to announcements!"
            self.debug.log(f"👤 User ID: {user_id} is already subscribed")
        else:
            if await self.database.add_subscriber(user_id):
                message = "✅ You have successfully subscribed to announcements!"
                self.debug.log(
                    f"✅ User ID: {user_id} successfully subscribed to announcements"
                )
            else:
                message = "❌ Failed to subscribe. Please try again later."
                self.debug.log(
                    f"❌ Failed to subscribe user ID: {user_id} to announcements"
                )

        if from_button:
            await update.callback_query.message.reply_text(message)
        else:
            await update.message.reply_text(message)

    async def unsubscribe_command(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        user_id = update.effective_user.id
        if not await self.database.is_subscribed(user_id):
            message = "ℹ️ You are not currently subscribed to announcements."
        else:
            if await self.database.remove_subscriber(user_id):
                message = "✅ You have successfully unsubscribed from announcements."
            else:
                message = "❌ Failed to unsubscribe. Please try again later."
        await update.message.reply_text(message)

    @owner()
    async def announce_start(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        await update.message.reply_text(
            "📝 Please enter the message you want to announce to all subscribers. Send /cancel_announce to abort."
        )
        return ANNOUNCE_MESSAGE

    async def announce_message_handler(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        message_to_announce = update.message.text
        subscribers = await self.database.get_all_subscribers()

        if not subscribers:
            await update.message.reply_text(
                "📢 No subscribers to send the announcement to."
            )
            return ConversationHandler.END

        context.user_data["announcement_message"] = message_to_announce
        context.user_data["subscribers_to_announce"] = subscribers

        keyboard = [
            [
                InlineKeyboardButton(
                    "🚀 Send Announcement", callback_data="send_announcement_confirm"
                )
            ],
            [
                InlineKeyboardButton(
                    "❌ Cancel", callback_data="send_announcement_cancel"
                )
            ],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await update.message.reply_text(
            f"📢 *Preview Announcement:* \n\n{message_to_announce}\n\nThis message will be sent to {len(subscribers)} subscriber(s). Are you sure?",
            reply_markup=reply_markup,
            parse_mode="Markdown",
        )
        return ConversationHandler.END

    async def announce_confirm_send(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        query = update.callback_query
        await query.answer()

        message_to_announce = context.user_data.get("announcement_message")
        subscribers = context.user_data.get("subscribers_to_announce")

        if not message_to_announce or not subscribers:
            await query.edit_message_text(
                "❌ Error: Announcement data not found. Please start over."
            )
            return

        await query.edit_message_text(
            f"🚀 Sending announcement to {len(subscribers)} subscribers..."
        )

        sent_count = 0
        failed_count = 0

        for user_id in subscribers:
            try:
                await context.bot.send_message(
                    chat_id=int(user_id),
                    text=f"📢 *Announcement*\n\n{message_to_announce}",
                    parse_mode="Markdown",
                )
                sent_count += 1
                await asyncio.sleep(0.1)
            except Exception as e:
                self.debug.log(f"Failed to send announcement to {user_id}: {e}")
                failed_count += 1

        await query.message.reply_text(
            f"🏁 Announcement process finished.\n"
            f"✅ Sent: {sent_count}\n"
            f"❌ Failed: {failed_count}"
        )
        context.user_data.pop("announcement_message", None)
        context.user_data.pop("subscribers_to_announce", None)

    async def announce_cancel_send(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        query = update.callback_query
        await query.answer()
        await query.edit_message_text("❌ Announcement cancelled.")
        context.user_data.pop("announcement_message", None)
        context.user_data.pop("subscribers_to_announce", None)

    async def cancel_announce(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        await update.message.reply_text("🛑 Announcement process cancelled.")
        context.user_data.pop("announcement_message", None)
        context.user_data.pop("subscribers_to_announce", None)
        return ConversationHandler.END

    @owner()
    async def subscribers_list(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ):
        """View all subscribers"""
        subscribers = await self.database.get_all_subscribers()

        if not subscribers:
            await update.message.reply_text("📭 No subscribers found.")
            return

        message = f"📊 *Subscribers List*\nTotal: {len(subscribers)}\n\n"

        for i, user_id in enumerate(subscribers, 1):
            message += f"{i}. `{user_id}`\n"

            if i % 50 == 0 and i < len(subscribers):
                await update.message.reply_text(message, parse_mode="Markdown")
                message = ""

        if message:
            await update.message.reply_text(message, parse_mode="Markdown")

    @owner()
    async def change_banner_zip(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        await update.message.reply_text(
            "🖼️ *Replace Banners*\n\nUpload a ZIP file containing new banner images. All existing banners will be deleted and replaced.\n\nSend /cancel to abort.",
            parse_mode="Markdown",
        )
        return WAITING_BANNER_ZIP_FILE

    async def handle_banner_zip_upload(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> int:
        msg = await update.message.reply_text("⏳ Processing ZIP file...")
        ok = await self.stocks.process_zip_banner_upload(update)
        if ok:
            await msg.edit_text("✅ Successfully replaced all banners.")
        else:
            await msg.edit_text("❌ Failed to process banner ZIP.")
        return ConversationHandler.END

    @staticmethod
    def get_mstats_static_price(acc):
        followers = int(acc.get("followers", 0))
        verified = acc.get("verified", "").lower()
        if 100 <= followers <= 499:
            if verified in ["ev", "uv"]:
                return 4.5
            elif verified == "fv":
                return 5.5
        elif 500 <= followers <= 999:
            if verified in ["ev", "uv"]:
                return 10.0
            elif verified == "fv":
                return 11.0
        return 0.0


class convHandlers:
    def __init__(self) -> None:
        self.sell_items = ConversationHandler(
            entry_points=[CommandHandler("sell", bot.stocks.sell)],
            states={
                SELL: [
                    MessageHandler(
                        filters.TEXT & ~filters.COMMAND, bot.stocks.handle_sell
                    ),
                    CommandHandler("cancel", bot.cancel),
                ],
            },
            fallbacks=[CommandHandler("cancel", bot.cancel)],
            allow_reentry=True,
        )

        self.settings = ConversationHandler(
            entry_points=[CommandHandler("settings", bot.settings)],
            states={
                CANCEL: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, bot.handle_input)
                ]
            },
            fallbacks=[CommandHandler("cancel", bot.cancel)],
        )
        self.button_handler = CallbackQueryHandler(bot.button_handler)
        self.login = ConversationHandler(
            entry_points=[CommandHandler("login", bot.shop.login)],
            states={
                EMAIL_LOGIN: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, bot.shop.cmd_login),
                    CommandHandler("cancel", bot.cancel),
                ],
                EMAIL_VERIFY: [
                    MessageHandler(
                        filters.TEXT & ~filters.COMMAND, bot.shop.confirm_login
                    ),
                    CommandHandler("cancel", bot.cancel),
                ],
            },
            fallbacks=[CommandHandler("cancel", bot.cancel)],
            conversation_timeout=300,
        )
        self.clear_stock = ConversationHandler(
            entry_points=[CommandHandler("clear", bot.stocks.clearstock)],
            states={
                CONFIRM_CLEAR: [
                    MessageHandler(
                        filters.TEXT & ~filters.COMMAND,
                        bot.stocks.handle_clear_confirmation,
                    )
                ]
            },
            fallbacks=[CommandHandler("cancel", bot.cancel)],
        )
        self.get_fv = ConversationHandler(
            entry_points=[CommandHandler("getfv", bot.stocks.getfv)],
            states={
                CONFIRM_FV: [
                    MessageHandler(
                        filters.TEXT & ~filters.COMMAND,
                        bot.stocks.handle_fv_confirmation,
                    )
                ]
            },
            fallbacks=[CommandHandler("cancel", bot.cancel)],
        )
        self.view_products = CommandHandler("products_list", bot.view_products)
        self.delete_product = CommandHandler("delete_product", bot.delete_product)
        self.update_db = ConversationHandler(
            entry_points=[CommandHandler("updatedb", bot.update_database)],
            states={
                WAITING_DB: [MessageHandler(filters.Document.ALL, bot.handle_db_upload)]
            },
            fallbacks=[CommandHandler("cancel", bot.cancel)],
        )
        self.coupon_handler = ConversationHandler(
            entry_points=[
                CallbackQueryHandler(
                    bot.handle_coupon_callback,
                    pattern="^coupon_(custom|random|delete)$",
                )
            ],
            states={
                COUPON_CODE: [
                    MessageHandler(
                        filters.TEXT & ~filters.COMMAND, bot.handle_coupon_code
                    )
                ],
                COUPON_DISCOUNT: [
                    MessageHandler(
                        filters.TEXT & ~filters.COMMAND, bot.handle_coupon_discount
                    )
                ],
                COUPON_MAX_USES: [
                    MessageHandler(
                        filters.TEXT & ~filters.COMMAND, bot.handle_coupon_max_uses
                    )
                ],
                COUPON_EXPIRY: [
                    MessageHandler(
                        filters.TEXT & ~filters.COMMAND, bot.handle_coupon_expiry
                    )
                ],
            },
            fallbacks=[CommandHandler("cancel", bot.cancel)],
        )
        self.announce_handler = ConversationHandler(
            entry_points=[CommandHandler("announce", bot.announce_start)],
            states={
                ANNOUNCE_MESSAGE: [
                    MessageHandler(
                        filters.TEXT & ~filters.COMMAND, bot.announce_message_handler
                    )
                ]
            },
            fallbacks=[CommandHandler("cancel_announce", bot.cancel_announce)],
            conversation_timeout=300,
        )

        self.zip_upload_handler = ConversationHandler(
            entry_points=[
                CommandHandler("change_pfp_zip", bot.change_pfp_zip),
                CommandHandler("pfpzip", bot.change_pfp_zip),
            ],
            states={
                WAITING_ZIP_TYPE: [
                    CallbackQueryHandler(
                        bot.handle_zip_type_selection, pattern="^zip_type_"
                    ),
                    CallbackQueryHandler(
                        bot.handle_zip_type_selection, pattern="^zip_cancel$"
                    ),
                ],
                WAITING_ZIP_FILE: [
                    MessageHandler(filters.Document.ZIP, bot.handle_zip_upload),
                    CommandHandler("cancel", bot.cancel),
                ],
            },
            fallbacks=[CommandHandler("cancel", bot.cancel)],
            conversation_timeout=600,
        )

        self.banner_zip_upload_handler = ConversationHandler(
            entry_points=[
                CommandHandler("change_banner_zip", bot.change_banner_zip),
                CommandHandler("bannerzip", bot.change_banner_zip),
            ],
            states={
                WAITING_BANNER_ZIP_FILE: [
                    MessageHandler(filters.Document.ZIP, bot.handle_banner_zip_upload),
                    CommandHandler("cancel", bot.cancel),
                ]
            },
            fallbacks=[CommandHandler("cancel", bot.cancel)],
            conversation_timeout=600,
        )


if __name__ == "__main__":
    bot = Bot()
    app = Application.builder().token(bot.TOKEN).build()

    handlers = convHandlers()
    handler_list = [
        handlers.sell_items,
        handlers.login,
        handlers.coupon_handler,
        handlers.clear_stock,
        handlers.get_fv,
        handlers.settings,
        handlers.update_db,
        handlers.view_products,
        handlers.zip_upload_handler,
        handlers.banner_zip_upload_handler,
        CommandHandler("start", bot.start),
        CommandHandler("help", bot.help),
        CommandHandler("reload", bot.reload),
        CommandHandler("retrieve", bot.retrieve_order),
        CommandHandler("faq", bot.faq),
        CommandHandler("terms", bot.terms),
        CommandHandler("tos", bot.terms),
        CommandHandler("managefaq", bot.manage_faq),
        CommandHandler("manageterms", bot.manage_terms),
        CommandHandler("faqguide", bot.faqterms_guide),
        CommandHandler("initfaqterms", bot.init_faq_terms),
        CommandHandler("subscribe", bot.subscribe_command),
        CommandHandler("unsubscribe", bot.unsubscribe_command),
        CommandHandler("subscribers", bot.subscribers_list),
        CallbackQueryHandler(bot.settings, pattern="^settings$"),
        CommandHandler("stock", bot.stocks.stock_count),
        CommandHandler("calcprice", bot.stocks.calc_price),
        CommandHandler("update", bot.stocks.updatestock),
        CommandHandler("upload", bot.upload.instruct),
        CommandHandler("buy", bot.shop.cmd_products),
        CommandHandler("getstock", bot.stocks.getstock),
        CommandHandler("change", bot.stocks.change),
        CommandHandler("secure", bot.stocks.secure),
        CommandHandler("edit", bot.edit_email),
        CommandHandler("customers", bot.customers),
        CommandHandler("verify", bot.shop.verify_products),
        CommandHandler("order", bot.order_by_uuid),
        CommandHandler("secured", bot.stocks.secured_check),
        CommandHandler("unsecured", bot.stocks.unsecured_check),
        CommandHandler("edit_products", bot.edit_products),
        CallbackQueryHandler(bot.handle_product_category, pattern="^product_category_"),
        CallbackQueryHandler(
            bot.handle_product_edit, pattern="^product_edit_[A-Za-z0-9]+$"
        ),
        CallbackQueryHandler(
            bot.handle_product_edit_price, pattern="^product_edit_price_[A-Za-z0-9]+$"
        ),
        CallbackQueryHandler(
            bot.handle_product_toggle_mail, pattern="^product_toggle_mail_[A-Za-z0-9]+$"
        ),
        CallbackQueryHandler(
            bot.handle_product_edit_category,
            pattern="^product_edit_category_[A-Za-z0-9]+$",
        ),
        CallbackQueryHandler(
            bot.handle_product_edit_range, pattern="^product_edit_range_[A-Za-z0-9]+$"
        ),
        CallbackQueryHandler(
            bot.handle_product_delete, pattern="^product_delete_[A-Za-z0-9]+$"
        ),
        CallbackQueryHandler(bot.handle_product_back, pattern="^product_back_"),
        CallbackQueryHandler(bot.handle_product_cancel, pattern="^cancel_products$"),
        CallbackQueryHandler(
            bot.handle_clear_products,
            pattern="^confirm_clear_products|cancel_clear_products$",
        ),
        CallbackQueryHandler(
            bot.handle_edit_products_pagination, pattern="^edit_products_(prev|next)$"
        ),
        CommandHandler("getfv", bot.stocks.getfv),
        CommandHandler("lockeds", bot.stocks.get_locked_tokens),
        CommandHandler("trash", bot.stocks.get_trash_accounts),
        CommandHandler("dev", bot.dev),
        CommandHandler("credits", bot.dev),
        CommandHandler("developer", bot.dev),
        CommandHandler("coupon", bot.coupon),
        CommandHandler("defaults", bot.defaults),
        CommandHandler("backup", bot.backup),
        CommandHandler("orders", bot.shop.cmd_orders),
        CommandHandler("status", bot.shop.cmd_status),
        CommandHandler("locked", bot.stocks.get_locked_tokens),
        CommandHandler("resend", bot.shop.cmd_resend),
        CommandHandler("migrate_mstats", bot.stocks.migrate_mstats),
        CallbackQueryHandler(
            bot.shop.paginate_handler, pattern="^(browse_|refresh_products|page_info)"
        ),
        CallbackQueryHandler(bot.shop.category_handler, pattern="^category_"),
        CallbackQueryHandler(bot.shop.range_handler, pattern="^range_"),
        CallbackQueryHandler(
            bot.shop.refresh_categories_handler, pattern="^refresh_categories$"
        ),
        CallbackQueryHandler(
            bot.shop.callback_query_handler,
            pattern="^(category_|range_|back_categories|refresh_categories|purchase_|browse_|page_info|refresh_products|back_to_products)",
        ),
        CallbackQueryHandler(bot.shop.handle_purchase, pattern="^purchase_"),
        CallbackQueryHandler(bot.shop.handle_gateway, pattern="^network_"),
        CallbackQueryHandler(bot.shop.handle_gateway, pattern="^coupon_(yes|no)$"),
        CallbackQueryHandler(bot.shop.handle_gateway, pattern="^cancel_payment$"),
        CallbackQueryHandler(bot.shop.select_product, pattern="^select_"),
        handlers.button_handler,
        handlers.view_products,
        handlers.delete_product,
        handlers.announce_handler,
        CallbackQueryHandler(
            bot.announce_cancel_send, pattern="^send_announcement_cancel$"
        ),
        CallbackQueryHandler(
            bot.handle_database_confirmation,
            pattern="^confirm_db_update|cancel_db_update$",
        ),
        MessageHandler(filters.TEXT & ~filters.COMMAND, bot.handle_text_message),
        MessageHandler(filters.Document.TXT, bot.upload.file_handler),
        CallbackQueryHandler(bot.handle_crypto_setting, pattern="^edit_crypto_"),
        CommandHandler("clear_products", bot.clear_products),
        CommandHandler("stock_status", bot.stock_status),
        CommandHandler("fresh", bot.fresh_accounts_info),
        CallbackQueryHandler(
            bot.handle_clear_products,
            pattern="^confirm_clear_products|cancel_clear_products$",
        ),
        CommandHandler("update_titles", bot.update_titles),
        CallbackQueryHandler(bot.handle_add_product, pattern="^add_product$"),
        CommandHandler("maintenance", bot.maintenance),
    ]

    [app.add_handler(h) for h in handler_list]
    app.add_error_handler(bot.error)

    bot.debug.log(f"Server: `{sys.platform}` All operations functional.")
    app.run_polling()
