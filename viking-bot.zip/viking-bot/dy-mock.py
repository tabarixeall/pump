payload = {
    "data": {
        "id": 2029138,
        "status": {
            "status": {
                "setAt": "2025-03-22T10:39:51.000000Z",
                "status": "COMPLETED",
                "updatedAt": "2025-03-22T10:39:51.000000Z",
            },
            "history": [
                {
                    "setAt": "2025-03-22T10:29:39.000000Z",
                    "status": "PENDING",
                    "updatedAt": "2025-03-22T10:39:51.000000Z",
                }
            ],
        },
        "payment": {
            "fee": {
                "vat": 0,
                "base": "10",
                "total": {"exclusive": "10", "inclusive": "10"},
                "units": 1,
                "currency": "USD",
            },
            "total": {
                "total_usd": "310",
                "revenue_usd": "310",
                "exchange_rate": "1",
                "gross_sale_usd": "310",
                "payment_details": {
                    "vat": 0,
                    "total": "310",
                    "revenue": "310",
                    "currency": "USD",
                    "quantity": 1,
                    "subtotal": "310",
                    "gross_sale": "310",
                    "unit_price": "310",
                    "modifications": [],
                },
            },
            "gateway": {
                "data": {"transaction_id": "ohojvBoOleYCnHQuksCQng"},
                "type": "LTC",
            },
            "subtotal": {
                "vat": 0,
                "base": "310",
                "total": {"exclusive": "310", "inclusive": "310"},
                "units": 1,
                "currency": "USD",
            },
            "expires_at": "2025-03-23T10:29:39.000000Z",
            "full_price": {
                "vat": 0,
                "base": "310",
                "total": {"exclusive": "310", "inclusive": "310"},
                "units": 1,
                "currency": "USD",
            },
            "original_amount": {
                "vat": 0,
                "base": "310",
                "total": {"exclusive": "310", "inclusive": "310"},
                "units": 1,
                "currency": "USD",
            },
        },
        "feedback": "",
        "store_id": 56247,
        "webhooks": [],
        "coupon_id": None,
        "created_at": "2025-03-22T10:29:39.000000Z",
        "updated_at": "2025-03-22T10:39:51.000000Z",
        "is_migrated": 0,
        "subscription_id": None,
        "product_variants": [
            {
                "quantity": 1,
                "invoice_id": 2029138,
                "deliverable": {"types": ["TEXT"]},
                "product_title": "Twitter Full Verified Cracked ged NFT Accounts 2009-2022 100-499 Followers",
                "variant_title": "Default",
                "invoice_payment": {
                    "total_usd": "310",
                    "revenue_usd": "310",
                    "exchange_rate": "1",
                    "gross_sale_usd": "310",
                    "payment_details": {
                        "vat": 0,
                        "total": "310",
                        "revenue": "310",
                        "currency": "USD",
                        "quantity": 1,
                        "subtotal": "310",
                        "gross_sale": "0",
                        "unit_price": "310",
                        "modifications": [
                            {
                                "key": "payment_method",
                                "type": "payment_method",
                                "amount": "0",
                                "attributes": {
                                    "discount": "+ 0.00% + $0.00",
                                    "description": "0.00% + $0.00 Fee",
                                    "discount_data": {
                                        "fixed": "0.00",
                                        "percentage": "0.00",
                                    },
                                    "payment_method": "LTC",
                                },
                            }
                        ],
                    },
                },
                "product_variant_id": 282706,
                "additional_information": [],
                "issue_replacement_invoice_id": None,
            }
        ],
        "customer_information": {
            "id": 898247,
            "ip": "119.155.163.99",
            "vat": {"amount": 0, "country": "PK"},
            "email": "tariqkhanahmdani999@gmail.com",
            "country": "Pakistan",
            "proxied": False,
            "location": "undefined",
            "browser_agent": "Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.39 Mobile Safari/537.36",
        },
        "product_variants_count": 1,
    },
    "event": "order.completed",
    "store": 56247,
}


import httpx

r = httpx.post("http://localhost:7071/dynamic", params=payload, timeout=30000)
print(r.text)
